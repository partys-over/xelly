<?php

$mm41 = "Drapion @ Lansat Berry  
Ability: Sniper  
Tera Type: &
EVs: 252 HP / 4 Atk / 60 Def / 192 Spe  
Impish Nature  
- Night Slash  
- Cross Poison  
- Substitute  
- Bulldoze  

";
$mm411 = "Vanilluxe (F) @ Rocky Helmet  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Flash Cannon  
- Aurora Veil  
- Blizzard  

";
$mm422 = "Entei @ Custap Berry  
Ability: Pressure  
Tera Type: &
EVs: 60 HP / 252 Atk / 196 Spe  
Naughty Nature  
- Sacred Fire  
- Bulldoze  
- Eruption  
- Endure  

";
$mm432 = "xelly the genius (Darmanitan-Galar) @ Assault Vest  
Ability: Gorilla Tactics  
Tera Type: &
EVs: 116 HP / 12 Atk / 140 Def / 140 SpD / 100 Spe  
Adamant Nature  
- Icicle Crash  
- Superpower  
- Earthquake  
- Payback  

";
$mm442 = "Skarmory @ Focus Sash  
Ability: Keen Eye  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spikes  
- Stealth Rock  
- Taunt  
- Icy Wind  

";
$mm453 = "Infernape @ Expert Belt  
Ability: Blaze  
Tera Type: &
EVs: 64 Atk / 252 SpA / 192 Spe  
Naive Nature  
- Fire Blast  
- Close Combat  
- Hidden Power [Ice]  
- U-turn  

";
$mm463 = "Palafin @ Choice Scarf  
Ability: Zero to Hero  
Tera Type: &
EVs: 184 HP / 252 Atk / 72 Spe  
Adamant Nature  
- Wave Crash  
- Close Combat  
- Haze  
- Flip Turn  

";
$mm473 = "Enamorus-Therian @ Throat Spray  
Ability: Overcoat  
Tera Type: &
EVs: 200 HP / 60 Def / 100 SpA / 148 Spe  
Modest Nature  
IVs: 0 Atk  
- Alluring Voice  
- Healing Wish  
- Earth Power  
- Tailwind  

";
$mm484 = "Diggersby @ Rindo Berry  
Ability: Huge Power  
Tera Type: &
EVs: 252 Atk / 168 Def / 88 Spe  
Adamant Nature  
- Giga Impact  
- Laser Focus  
- Earthquake  
- Bulldoze  

";
$mm494 = "Lucario @ Occa Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 248 HP / 72 Atk / 68 Def / 120 Spe  
Adamant Nature  
- Meteor Mash  
- Bullet Punch  
- Bulldoze  
- Close Combat  

";
$mm4104 = "Hawlucha @ Toxic Orb  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Fling  
- Encore  
- Feather Dance  
- Roost  

";
$mm4114 = "Frosmoth @ Occa Berry  
Ability: Ice Scales  
Tera Type: &
EVs: 88 HP / 168 SpA / 252 SpD  
Modest Nature  
IVs: 0 Atk  
- Quiver Dance  
- Giga Drain  
- Ice Beam  
- Mirror Coat  

";
$mm4125 = "Vanilluxe @ Petaya Berry  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 84 SpD / 172 Spe  
Modest Nature  
IVs: 0 Atk  
- Endure  
- Flash Cannon  
- Freeze-Dry  
- Taunt  

";
$mm4136 = "Cobalion @ Weakness Policy  
Ability: Justified  
Tera Type: &
EVs: 108 HP / 36 Def / 172 SpA / 192 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Taunt  
- Flash Cannon  
- Focus Blast  

";
$mm4147 = "Grimmsnarl (M) @ Weakness Policy  
Ability: Prankster  
Tera Type: &
EVs: 128 HP / 144 Atk / 208 Def / 20 SpD / 8 Spe  
Adamant Nature  
- Bulk Up  
- Light Screen  
- Play Rough  
- Sucker Punch  

";
$mm4157 = "Centiskorch @ Sitrus Berry  
Ability: White Smoke  
Tera Type: &
EVs: 248 HP / 164 Def / 96 SpD  
Careful Nature  
- Will-O-Wisp  
- Struggle Bug  
- Fire Lash  
- Rest  

";
$mm4167 = "Golisopod @ Rocky Helmet  
Ability: Emergency Exit  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Spite  
- Aqua Jet  
- Iron Defense  
- Rest  

";
$mm4177 = "Pheromosa @ Darkinium Z  
Ability: Beast Boost  
Tera Type: &
EVs: 80 HP / 152 Atk / 252 Def / 24 Spe  
Naive Nature  
- Lunge  
- High Jump Kick  
- Foul Play  
- Taunt  

";
$mm4187 = "Pheromosa @ Dark Gem  
Ability: Beast Boost  
Tera Type: &
EVs: 80 HP / 152 Atk / 252 Def / 24 Spe  
Naive Nature  
- Lunge  
- High Jump Kick  
- Foul Play  
- Taunt  

";
$mm4197 = "Vikavolt @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 84 SpA / 172 Spe  
Naughty Nature  
- Agility  
- Acrobatics  
- Thunder  
- Bug Buzz  

";
$mm4207 = "Ursaring @ Salac Berry  
Ability: Guts  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Endure  
- Giga Impact  
- Chip Away  

";
$mm4217 = "Haxorus @ Choice Scarf  
Ability: Unnerve  
Tera Type: &
EVs: 36 Atk / 252 SpA / 220 Spe  
Naughty Nature  
- Outrage  
- Grass Knot  
- Superpower  
- Earthquake  

";
$mm4227 = "Dragonite @ Dragon Gem  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Substitute  
- Outrage  
- Dragon Dance  
- Aerial Ace  

";
$mm4237 = "Arceus-Bug @ Insect Plate  
Ability: Multitype  
Tera Type: &
EVs: 96 HP / 160 Atk / 252 Spe  
Jolly Nature  
- Swords Dance  
- X-Scissor  
- Recover  
- Defog  



";
$mm4249 = "Garchomp @ Rocky Helmet  
Ability: Rough Skin  
Tera Type: &
EVs: 248 HP / 76 SpA / 184 Spe  
Naive Nature  
- Spikes  
- Earthquake  
- Draco Meteor  
- Scale Shot  

";
$mm4259 = "Rotom (Rotom-Wash) @ Yache Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 220 SpD / 40 Spe  
Calm Nature  
IVs: 0 Atk  
- Hydro Pump  
- Volt Switch  
- Pain Split  
- Thunderbolt  

";
$mm4270 = "Ceruledge @ Clear Amulet  
Ability: Weak Armor  
Tera Type: &
EVs: 96 HP / 252 Atk / 160 Spe  
Jolly Nature  
- Swords Dance  
- Bitter Blade  
- Poltergeist  
- Shadow Sneak  

";
$mm4280 = "Revavroom @ Choice Scarf  
Ability: Filter  
Tera Type: &
EVs: 24 HP / 252 Atk / 232 Spe  
Jolly Nature  
- Parting Shot  
- Gunk Shot  
- High Horsepower  
- Iron Head  

";
$mm4290 = "Gorebyss @ Ghostium Z  
Ability: Swift Swim  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Ice Beam  
- Shadow Ball  
- Shell Smash  

";
$mm4301 = "Jellicent @ Heavy-Duty Boots  
Ability: Water Absorb  
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe  
Modest Nature  
IVs: 0 Atk  
- Scald  
- Shadow Ball  
- Dazzling Gleam  
- Taunt  

";
$mm4312 = "Jellicent (M) @ Heavy-Duty Boots  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 120 Def / 136 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Hex  
- Taunt  
- Strength Sap  

";
$mm4323 = "Silvally-Fire @ Fire Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Work Up  
- Flamethrower  
- Terrain Pulse  
- Thunderbolt  

";
$mm4334 = "Sawsbuck @ Leftovers  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Substitute  
- Swords Dance  
- Horn Leech  
- Return  

";
$mm4344 = "Dragonair @ Eviolite  
Ability: Marvel Scale  
Tera Type: &
EVs: 244 HP / 56 Def / 208 SpD  
Careful Nature  
- Rest  
- Dragon Tail  
- Thunder Wave  
- Sleep Talk  

";
$mm4354 = "Golurk @ Colbur Berry  
Ability: No Guard  
Tera Type: &
EVs: 184 HP / 96 Atk / 16 Def / 140 SpD / 72 Spe  
Adamant Nature  
- Stealth Rock  
- Earthquake  
- Dynamic Punch  
- Stone Edge  

";
$mm4364 = "Garbodor @ Light Ball  
Ability: Aftermath  
Tera Type: &
EVs: 248 HP / 164 Def / 96 Spe  
Impish Nature  
- Spikes  
- Fling  
- Thief  
- Gunk Shot  

";
$mm4374 = "Rotom-Frost @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Discharge  
- Blizzard  
- Pain Split  

";
$mm4385 = "Ludicolo @ Rocky Helmet  
Ability: Swift Swim  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
- Fake Out  
- Hydro Pump  
- Energy Ball  
- Ice Beam  

";
$mm4395 = "Flutter Mane @ Focus Sash  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Power Gem  
- Icy Wind  
- Protect  

";
$mm4406 = "Vikavolt @ Buginium Z  
Ability: Levitate  
Tera Type: &
EVs: 104 HP / 252 SpA / 152 Spe  
Modest Nature  
- Bug Buzz  
- Volt Switch  
- Energy Ball  
- Roost  

";
$mm4416 = "Victreebel @ Rocky Helmet  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 172 Def / 84 Spe  
Timid Nature  
- Leaf Storm  
- Sludge Bomb  
- Strength Sap  
- Sleep Powder  

";
$mm4426 = "Slowking @ Psychium Z  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 216 Def / 44 Spe  
Bold Nature  
- Nasty Plot  
- Scald  
- Future Sight  
- Slack Off  

";
$mm4436 = "Dragonite @ Flyinium Z  
Ability: Multiscale  
Tera Type: &
EVs: 176 HP / 8 Atk / 108 SpA / 216 Spe  
Naive Nature  
- Metronome  
- Fly  
- Defog  
- Roost  

";
$mm4446 = "Comfey @ Life Orb  
Ability: Triage  
Shiny: Yes  
Tera Type: &
EVs: 236 HP / 252 SpA / 20 Spe  
Modest Nature  
IVs: 0 Atk  
- Draining Kiss  
- Giga Drain  
- Hidden Power [Ground]  
- Calm Mind  

";
$mm4458 = "Dhelmise @ Colbur Berry  
Ability: Steelworker  
Tera Type: &
EVs: 52 HP / 252 Atk / 204 Spe  
Adamant Nature  
- Power Whip  
- Anchor Shot  
- Synthesis  
- Knock Off  

";
$mm4468 = "Victreebel @ Poisonium Z  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 40 Def / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Giga Drain  
- Sludge Bomb  
- Strength Sap  
- Acid Spray  

";
$mm4479 = "Blastoise @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 60 Def / 196 Spe  
Bold Nature  
- Scald  
- Toxic  
- Rapid Spin  
- Refresh  

";
$mm4489 = "Comfey @ Life Orb  
Ability: Triage  
Tera Type: &
EVs: 236 HP / 252 SpA / 20 Spe  
Modest Nature  
IVs: 0 Atk  
- Draining Kiss  
- Giga Drain  
- Protect  
- Hidden Power [Ground]  



";
$mm4502 = "Regirock @ Heat Rock  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- Stealth Rock  
- Sunny Day  
- Explosion  
- Stone Edge  

";
$mm4512 = "Fezandipiti @ Leftovers  
Ability: Toxic Chain  
Tera Type: &
EVs: 248 HP / 44 Def / 216 SpD  
Calm Nature  
- U-turn  
- Roost  
- Icy Wind  
- Acid Spray  

";
$mm4522 = "Fezandipiti @ Utility Umbrella  
Ability: Toxic Chain  
Tera Type: &
EVs: 248 HP / 44 Def / 216 SpD  
Calm Nature  
- U-turn  
- Roost  
- Icy Wind  
- Acid Spray  

";
$mm4532 = "Tyranitar @ Leftovers  
Ability: Sand Stream  
Tera Type: &
EVs: 240 HP / 16 Def / 252 Spe  
Impish Nature  
- Crunch  
- Body Press  
- Iron Defense  
- Dragon Dance  

";
$mm4542 = "Tyranitar @ Tyranitarite  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 156 Def / 96 SpD / 4 Spe  
Impish Nature  
- Foul Play  
- Breaking Swipe  
- Stealth Rock  
- Thunder Wave  

";
$mm4552 = "Tyranitar @ Tyranitarite  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Stone Edge  
- Knock Off  
- Thunder Wave  
- Stealth Rock  

";
$mm4562 = "Tyranitar @ Choice Band  
Ability: Sand Stream  
Tera Type: &
EVs: 76 HP / 252 Atk / 180 Spe  
Adamant Nature  
- Knock Off  
- Sleep Talk  

";
$mm4570 = "Tyranitar @ Power Herb  
Ability: Sand Stream  
Tera Type: &
EVs: 136 HP / 100 Atk / 20 Def / 252 SpA  
Brave Nature  
- Knock Off  
- Dig  
- Hone Claws  
- Blizzard  

";
$mm4580 = "Tyranitar @ Choice Specs  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Dark Pulse  
- Earth Power  
- Focus Blast  
- Ice Beam  

";
$mm4591 = "Tyranitar @ Dragonium Z  
Ability: Sand Stream  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Protect  
- Breaking Swipe  
- Outrage  
- Dragon Dance  

";
$mm4601 = "Tyranitar @ Rockium Z  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Body Press  
- Stealth Rock  
- Rest  
- Detect  

";
$mm4612 = "Tyranitar @ Life Orb  
Ability: Sand Stream  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 172 Spe  
Naughty Nature  
- Double-Edge  
- Dragon Dance  
- Thunder  
- Protect  

";
$mm4622 = "Tyranitar @ Heavy-Duty Boots  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 52 Atk / 48 Def / 68 SpD / 88 Spe  
Adamant Nature  
- Knock Off  
- Toxic  
- Taunt  
- Protect  

";
$mm4632 = "Mandibuzz (F) @ Assault Vest  
Ability: Overcoat  
Tera Type: &
EVs: 240 HP / 252 Atk / 16 SpD  
Brave Nature  
IVs: 0 Spe  
- Knock Off  
- Brave Bird  
- Snarl  
- U-turn  

";
$mm4643 = "Mamoswine @ Assault Vest  
Ability: Thick Fat  
Tera Type: &
EVs: 36 HP / 176 Atk / 112 SpD / 184 Spe  
Adamant Nature  
- Earthquake  
- Icicle Crash  
- Knock Off  
- Ice Shard  

";
$mm4653 = "Wigglytuff @ Expert Belt  
Ability: Competitive  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
- Psychic  
- Dazzling Gleam  
- Fire Blast  
- Knock Off  

";
$mm4663 = "Electabuzz @ Eviolite  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk / 30 Def  
- Volt Switch  
- Thunderbolt  
- Focus Blast  
- Hidden Power [Ice]  

";
$mm4674 = "Dustox @ Black Sludge  
Ability: Shield Dust  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Careful Nature  
- U-turn  
- Roost  
- Defog  
- Sludge Bomb  

";
$mm4684 = "Wormadam-Trash (F) @ Leftovers  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Stealth Rock  
- Toxic  
- Skill Swap  
- Bug Bite  

";
$mm4694 = "Simisage @ Choice Scarf  
Ability: Overgrow  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Leaf Storm  
- Gunk Shot  
- Rock Slide  
- Knock Off  

";
$mm4704 = "Seaking @ Leftovers  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 220 SpD / 36 Spe  
Careful Nature  
- Knock Off  
- Scald  
- Rest  
- Sleep Talk  

";
$mm4714 = "Iron Hands @ Sitrus Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 40 HP / 92 Atk / 252 SpD / 124 Spe  
Adamant Nature  
- Wild Charge  
- Body Press  
- Iron Defense  
- Fake Out  

";
$mm4724 = "Tyranitar @ Tanga Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 248 HP / 88 Atk / 172 SpD  
Adamant Nature  
- Crunch  
- Pursuit  
- Thunder Wave  
- Superpower  

";
$mm4734 = "Sawk (M) @ Fighting Gem  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Close Combat  
- Earthquake  
- Payback  
- Substitute  



";
$mm4746 = "Jumpluff @ Safety Goggles  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 120 Def / 136 Spe  
Timid Nature  
IVs: 0 Atk  
- Giga Drain  
- Toxic  
- Switcheroo  
- Rage Powder  

";
$mm4757 = "Kyurem-Black @ Assault Vest  
Ability: Teravolt  
Tera Type: &
EVs: 248 HP / 64 Atk / 20 Def / 136 SpA / 32 SpD / 8 Spe  
- Dragon Tail  
- Earth Power  
- Freeze-Dry  
- Icy Wind  

";
$mm4766 = "Iron Treads @ Expert Belt  
Ability: Quark Drive  
Tera Type: &
EVs: 248 Atk / 112 SpD / 148 Spe  
Adamant Nature  
- Earthquake  
- Supercell Slam  
- Ice Spinner  
- Knock Off  

";
$mm4776 = "Weavile @ King's Rock  
Ability: Pressure  
Tera Type: &
EVs: 204 Atk / 52 Def / 252 Spe  
Jolly Nature  
- Swords Dance  
- Icicle Crash  
- Beat Up  
- Ice Shard  

";
$mm4786 = "Tapu Fini @ Leftovers  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 120 Def / 132 SpA / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Heal Pulse  
- Psych Up  
- Muddy Water  
- Hidden Power [Grass]  

";
$mm4797 = "Mew @ Normalium Z  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Transform  
- Snarl  
- Life Dew  
- Will-O-Wisp  

";
$mm4808 = "Tornadus @ Covert Cloak  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 120 Def / 56 SpA / 24 SpD / 56 Spe  
Modest Nature  
IVs: 0 Atk  
- Bleakwind Storm  
- Tailwind  
- Defog  
- Rain Dance  

";
$mm4819 = "Rotom @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 96 HP / 244 SpA / 168 Spe  
Timid Nature  
IVs: 0 Atk  
- Hex  
- Volt Switch  
- Signal Beam  
- Will-O-Wisp  

";
$mm4830 = "Ribombee @ Kebia Berry  
Ability: Shield Dust  
Tera Type: &
EVs: 44 HP / 4 Def / 116 SpA / 200 SpD / 144 Spe  
Timid Nature  
IVs: 0 Atk  
- Quiver Dance  
- Stored Power  
- Bug Buzz  
- Moonblast  

";
$mm4841 = "Enamorus-Therian (F) @ Charti Berry  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 60 SpA / 196 Spe  
Modest Nature  
IVs: 0 Atk  
- Tailwind  
- Dazzling Gleam  
- Earth Power  
- Protect  

";
$mm4852 = "Deoxys-Speed @ Rockium Z  
Ability: Pressure  
Tera Type: &
EVs: 216 HP / 252 SpA / 40 Spe  
Modest Nature  
IVs: 0 Atk  
- Psycho Boost  
- Icy Wind  
- Meteor Beam  
- Stealth Rock  

";
$mm4863 = "Scizor @ Assault Vest  
Ability: Technician  
Tera Type: &
EVs: 200 HP / 40 Atk / 252 SpD / 16 Spe  
Adamant Nature  
- Bullet Punch  
- U-turn  
- Close Combat  
- Knock Off  

";
$mm4873 = "Wo-Chien @ Yache Berry  
Ability: Tablets of Ruin  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Foul Play  
- Giga Drain  
- Ruination  
- Stun Spore  

";
$mm4884 = "Greninja (Greninja-Bond) @ Mystic Water  
Ability: Battle Bond  
Tera Type: &
EVs: 16 HP / 4 Def / 252 SpA / 236 Spe  
Timid Nature  
- Dark Pulse  
- U-turn  
- Water Shuriken  
- Surf  

";
$mm4894 = "Bellibolt @ Shuca Berry  
Ability: Static  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Volt Switch  
- Muddy Water  
- Slack Off  
- Toxic  

";
$mm4905 = "Breloom @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 144 HP / 16 Atk / 252 SpD / 96 Spe  
Adamant Nature  
- Seed Bomb  
- Superpower  
- Facade  
- Swords Dance  

";
$mm4915 = "Manectric-Mega @ Manectite  
Ability: Lightning Rod  
Tera Type: &
EVs: 76 HP / 180 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk / 30 Def  
- Volt Switch  
- Thunderbolt  
- Flamethrower  
- Hidden Power [Ice]  

";
$mm4926 = "Bisharp @ Custap Berry  
Ability: Defiant  
Tera Type: &
EVs: 112 HP / 252 Atk / 4 SpD / 140 Spe  
Adamant Nature  
- Taunt  
- Sucker Punch  
- Knock Off  
- Iron Head  

";
$mm4936 = "Azumarill @ Assault Vest  
Ability: Huge Power  
Happiness: 0  
Tera Type: &
EVs: 248 HP / 216 Atk / 20 Def / 16 SpD / 8 Spe  
Adamant Nature  
- Play Rough  
- Power-Up Punch  
- Aqua Jet  
- Knock Off  

";
$mm4947 = "Landorus-Therian @ Rocky Helmet  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 164 Def / 96 Spe  
Jolly Nature  
- Earthquake  
- U-turn  
- Smack Down  
- Stealth Rock  

";
$mm4957 = "Volcanion @ Shuca Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 120 HP / 180 SpA / 72 SpD / 136 Spe  
Modest Nature  
IVs: 0 Atk / 30 SpA  
- Sludge Bomb  
- Steam Eruption  
- Flamethrower  
- Hidden Power [Grass]  

";
$mm4968 = "Latias (F) @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 168 HP / 56 Def / 24 SpA / 8 SpD / 252 Spe  
Timid Nature  
IVs: 1 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Defog  
- Healing Wish  
- Psychic  
- Hidden Power [Fighting]  

";
$mm4979 = "Girafarig @ Choice Scarf  
Ability: Sap Sipper  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Psychic  
- Hyper Voice  
- High Horsepower  
- Trick  

";
$mm4989 = "Druddigon @ Power Herb  
Ability: Rough Skin  
Tera Type: &
EVs: 244 HP / 72 Atk / 48 Def / 72 SpD / 72 Spe  
Adamant Nature  
- Dragon Tail  
- Dig  
- Gunk Shot  
- Stealth Rock  



";
$mm41001 = "Thundurus @ Assault Vest  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Wild Charge  
- Sky Drop  
- Superpower  
- Volt Switch  

";
$mm41011 = "Weezing @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 84 Atk / 72 Def / 32 SpA / 60 SpD / 8 Spe  
Brave Nature  
- Fire Blast  
- Sludge Bomb  
- Haze  
- Protect  

";
$mm41021 = "Zapdos @ Grassy Seed  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 252 SpA / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hurricane  
- Tailwind  
- Roost  

";
$mm41032 = "Ampharos @ Leftovers  
Ability: Plus  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Magnetic Flux  
- Thunderbolt  
- Protect  
- Dragon Tail  

";
$mm41042 = "Mareanie @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 76 Def / 180 SpD  
Bold Nature  
IVs: 0 Atk  
- Recover  
- Haze  
- Infestation  
- Toxic Spikes  

";
$mm41053 = "Raboot @ Heavy-Duty Boots  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Flare Blitz  
- High Jump Kick  
- U-turn  
- Taunt  

";
$mm41063 = "Clefairy @ Eviolite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Night Shade  
- Encore  
- Stealth Rock  
- Moonlight  

";
$mm41074 = "Frogadier @ Choice Specs  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Surf  
- Ice Beam  
- U-turn  
- Hydro Pump  

";
$mm41084 = "Drakloak @ Eviolite  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Night Shade  
- Dragon Tail  
- Rest  
- Sleep Talk  

";
$mm41094 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 208 Atk / 48 Def  
Adamant Nature  
- High Horsepower  
- Icicle Crash  
- Reversal  
- Ice Shard  

";
$mm41104 = "Whimsicott @ Rocky Helmet  
Ability: Prankster  
Tera Type: &
EVs: 160 HP / 140 SpA / 208 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Encore  
- Tailwind  
- Protect  

";
$mm41115 = "Koffing @ Eviolite  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 252 HP / 4 Def / 204 SpD / 48 Spe  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Flamethrower  
- Toxic Spikes  
- Pain Split  

";
$mm41126 = "Sneasler @ Booster Energy  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Gunk Shot  
- Close Combat  
- Substitute  
- Fake Out  

";
$mm41136 = "Tornadus (M) @ Normal Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- U-turn  
- Tailwind  
- Protect  

";
$mm41146 = "Archaludon @ Life Orb  
Ability: Stalwart  
Tera Type: &
EVs: 252 SpA / 232 SpD / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Flash Cannon  
- Electro Shot  
- Protect  

";
$mm41157 = "Kommo-o @ Sitrus Berry  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 84 Def / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Clanging Scales  
- Vacuum Wave  
- Boomburst  
- Clangorous Soul  

";
$mm41168 = "Ogerpon-Hearthflame (F) @ Hearthflame Mask  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 HP / 72 Def / 184 Spe  
Jolly Nature  
- Power Whip  
- Ivy Cudgel  
- Follow Me  
- Spiky Shield  

";
$mm41178 = "Sylveon @ Life Orb  
Ability: Pixilate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Hyper Voice  
- Shadow Ball  
- Double-Edge  
- Protect  

";
$mm41188 = "Audino @ Audinite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD  
Calm Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Grass Knot  
- Wish  
- Protect  

";
$mm41199 = "Tyranitar @ Focus Sash  
Ability: Sand Stream  
Tera Type: &
EVs: 144 Atk / 112 SpA / 252 Spe  
Hasty Nature  
- Earthquake  
- Ice Beam  
- Thunder Wave  
- Stealth Rock  

";
$mm41209 = "Landorus (M) @ Choice Scarf  
Ability: Sand Force  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Earthquake  
- Stone Edge  
- Hidden Power [Ice]  
- U-turn  

";
$mm41219 = "Poliwrath @ Expert Belt  
Ability: Water Absorb  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Rash Nature  
- Scald  
- Focus Blast  
- Earthquake  
- Vacuum Wave  

";
$mm41229 = "Misdreavus @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 116 HP / 252 SpA / 140 Spe  
Timid Nature  
IVs: 3 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Shadow Ball  
- Hidden Power [Fighting]  
- Will-O-Wisp  
- Nasty Plot  

";
$mm41240 = "Rotom-Mow @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Leaf Storm  
- Volt Switch  
- Signal Beam  
- Hidden Power [Fire]  



";
$mm41253 = "Thundurus @ Assault Vest  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Wild Charge  
- Sky Drop  
- Superpower  
- Volt Switch  

";
$mm41263 = "Weezing @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 84 Atk / 72 Def / 32 SpA / 60 SpD / 8 Spe  
Brave Nature  
- Fire Blast  
- Sludge Bomb  
- Haze  
- Protect  

";
$mm41273 = "Zapdos @ Grassy Seed  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 252 SpA / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hurricane  
- Tailwind  
- Roost  

";
$mm41284 = "Ampharos @ Leftovers  
Ability: Plus  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Magnetic Flux  
- Thunderbolt  
- Protect  
- Dragon Tail  

";
$mm41294 = "Mareanie @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 76 Def / 180 SpD  
Bold Nature  
IVs: 0 Atk  
- Recover  
- Haze  
- Infestation  
- Toxic Spikes  

";
$mm41305 = "Raboot @ Heavy-Duty Boots  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Flare Blitz  
- High Jump Kick  
- U-turn  
- Taunt  

";
$mm41315 = "Clefairy @ Eviolite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Night Shade  
- Encore  
- Stealth Rock  
- Moonlight  

";
$mm41326 = "Frogadier @ Choice Specs  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Surf  
- Ice Beam  
- U-turn  
- Hydro Pump  

";
$mm41336 = "Drakloak @ Eviolite  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Night Shade  
- Dragon Tail  
- Rest  
- Sleep Talk  

";
$mm41346 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 208 Atk / 48 Def  
Adamant Nature  
- High Horsepower  
- Icicle Crash  
- Reversal  
- Ice Shard  

";
$mm41356 = "Whimsicott @ Rocky Helmet  
Ability: Prankster  
Tera Type: &
EVs: 160 HP / 140 SpA / 208 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Encore  
- Tailwind  
- Protect  

";
$mm41367 = "Koffing @ Eviolite  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 252 HP / 4 Def / 204 SpD / 48 Spe  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Flamethrower  
- Toxic Spikes  
- Pain Split  

";
$mm41378 = "Sneasler @ Booster Energy  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Gunk Shot  
- Close Combat  
- Substitute  
- Fake Out  

";
$mm41388 = "Tornadus (M) @ Normal Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- U-turn  
- Tailwind  
- Protect  

";
$mm41398 = "Archaludon @ Life Orb  
Ability: Stalwart  
Tera Type: &
EVs: 252 SpA / 232 SpD / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Flash Cannon  
- Electro Shot  
- Protect  

";
$mm41409 = "Kommo-o @ Sitrus Berry  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 84 Def / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Clanging Scales  
- Vacuum Wave  
- Boomburst  
- Clangorous Soul  

";
$mm41420 = "Ogerpon-Hearthflame (F) @ Hearthflame Mask  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 HP / 72 Def / 184 Spe  
Jolly Nature  
- Power Whip  
- Ivy Cudgel  
- Follow Me  
- Spiky Shield  

";
$mm41430 = "Sylveon @ Life Orb  
Ability: Pixilate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Hyper Voice  
- Shadow Ball  
- Double-Edge  
- Protect  

";
$mm41440 = "Audino @ Audinite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD  
Calm Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Grass Knot  
- Wish  
- Protect  

";
$mm41451 = "Tyranitar @ Focus Sash  
Ability: Sand Stream  
Tera Type: &
EVs: 144 Atk / 112 SpA / 252 Spe  
Hasty Nature  
- Earthquake  
- Ice Beam  
- Thunder Wave  
- Stealth Rock  

";
$mm41461 = "Landorus (M) @ Choice Scarf  
Ability: Sand Force  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Earthquake  
- Stone Edge  
- Hidden Power [Ice]  
- U-turn  

";
$mm41471 = "Poliwrath @ Expert Belt  
Ability: Water Absorb  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Rash Nature  
- Scald  
- Focus Blast  
- Earthquake  
- Vacuum Wave  

";
$mm41481 = "Misdreavus @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 116 HP / 252 SpA / 140 Spe  
Timid Nature  
IVs: 3 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Shadow Ball  
- Hidden Power [Fighting]  
- Will-O-Wisp  
- Nasty Plot  

";
$mm41492 = "Rotom-Mow @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Leaf Storm  
- Volt Switch  
- Signal Beam  
- Hidden Power [Fire]  

";
$mm41503 = "Cetitan @ Salac Berry  
Ability: Thick Fat  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Belly Drum  
- Icicle Crash  
- Endure  
- Earthquake

";
$mm41513 = "Basculin-Blue-Striped @ Choice Band  
Ability: Rock Head  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Wave Crash  
- Aqua Jet  
- Flip Turn  
- Head Smash

";
$mm41523 = "Hydrapple @ Eject Button  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 136 Def / 112 SpA / 12 Spe  
Bold Nature  
IVs: 0 Atk  
- Nasty Plot  
- Recover  
- Fickle Beam  
- Giga Drain

";
$mm41534 = "Clodsire @ Sitrus Berry  
Ability: Poison Point  
Tera Type: &
EVs: 248 HP / 84 Def / 176 SpD  
Careful Nature  
- Stealth Rock  
- Spikes  
- Recover  
- Toxic

";
$mm41544 = "Porygon2 @ Eviolite  
Ability: Download  
Tera Type: &
EVs: 232 HP / 180 Atk / 96 Spe  
Adamant Nature  
- Agility  
- Sharpen  
- Recover  
- Last Resort

";
$mm41554 = "Vikavolt @ Iapapa Berry  
Ability: Levitate  
Tera Type: &
EVs: 44 HP / 252 SpA / 212 Spe  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Volt Switch  
- Energy Ball  
- Roost  

";
$mm41565 = "Liepard @ Damp Rock  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Knock Off  
- Encore  
- U-turn  
- Rain Dance  

";
$mm41575 = "Omastar @ Life Orb  
Ability: Swift Swim  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk / 30 SpA  
- Surf  
- Ice Beam  
- Hidden Power [Grass]  
- Shell Smash  

";
$mm41586 = "Pinsir @ Focus Sash  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- X-Scissor  
- Earthquake  
- Rain Dance  
- Stealth Rock  

";
$mm41596 = "Annihilape @ Ghostium Z  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Phantom Force  
- U-turn  
- Stealth Rock  
- Detect  

";
$mm41606 = "Kartana @ Mago Berry  
Ability: Beast Boost  
Shiny: Yes  
Tera Type: &
EVs: 72 HP / 48 Atk / 180 SpD / 208 Spe  
Jolly Nature  
- Leaf Blade  
- Sacred Sword  
- Tailwind  
- Detect  

";
$mm41617 = "Kartana @ Fightinium Z  
Ability: Beast Boost  
Tera Type: &
EVs: 120 Atk / 96 SpD / 252 Spe  
Jolly Nature  
- Tailwind  
- Leaf Blade  
- Sacred Sword  
- Detect  

";
$mm41627 = "Incineroar @ Figy Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 12 Atk / 20 Def / 136 SpD / 88 Spe  
Careful Nature  
- Fake Out  
- Flare Blitz  
- Taunt  
- U-turn  

";
$mm41637 = "Landorus-Therian (M) @ Mago Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 28 Atk / 44 Def / 120 SpD / 64 Spe  
Calm Nature  
- Earth Power  
- Rock Tomb  
- U-turn  
- Stealth Rock  

";
$mm41647 = "Tapu Fini @ Wiki Berry  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 100 Def / 16 SpD / 140 Spe  
Calm Nature  
IVs: 0 Atk  
- Moonblast  
- Nature's Madness  
- Icy Wind  
- Defog  

";
$mm41658 = "Naganadel @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 64 HP / 48 Def / 144 SpA / 252 Spe  
Timid Nature  
- Sludge Bomb  
- Draco Meteor  
- Fire Blast  
- U-turn  

";
$mm41668 = "Skarmory @ Focus Sash  
Ability: Keen Eye  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spikes  
- Stealth Rock  
- Taunt  
- Icy Wind  

";
$mm41679 = "Golbat @ Eviolite  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 160 SpA / 96 Spe  
Modest Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Heat Wave  
- Roost  
- Nasty Plot  

";
$mm41690 = "Bronzor @ Lagging Tail  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Trick  
- Calm Mind  
- Iron Defense  
- Stored Power  

";
$mm41701 = "Weezing @ Electrium Z  
Ability: Levitate  
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe  
Modest Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Thunder  
- Flamethrower  
- Toxic Spikes  

";
$mm41712 = "Flutter Mane @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 152 Def / 40 SpA / 68 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Charm  
- Pain Split  
- Misty Terrain  

";
$mm41723 = "Tornadus (M) @ Charti Berry  
Ability: Defiant  
Tera Type: &
EVs: 52 HP / 152 Atk / 48 Def / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- Giga Impact  
- Protect  
- Bulk Up  

";
$mm41733 = "Bronzong @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 188 Def / 68 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Body Press  
- Heal Block  
- Hypnosis  
- Trick Room  

";
$mm41744 = "Bronzong @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Calm Mind  
- Psychic Noise  
- Hypnosis  
- Trick Room  

";
$mm41755 = "Bronzong @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 44 Def / 208 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Hypnosis  
- Charge Beam  
- Psychic  
- Trick Room  

";
$mm41766 = "Bronzong @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpA  
Quiet Nature  
- Future Sight  
- Heavy Slam  
- Stealth Rock  
- Protect  

";
$mm41776 = "Bronzong @ Air Balloon  
Ability: Heatproof  
Tera Type: &
EVs: 200 HP / 124 Def / 104 SpA / 16 SpD / 64 Spe  
Lax Nature  
IVs: 0 Atk  
- Stored Power  
- Body Press  
- Iron Defense  
- Calm Mind  

";
$mm41787 = "Salamence @ Salamencite  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Fly  
- Dragon Dance  
- Roost  
- Protect  

";
$mm41797 = "Dragonite @ Ghostium Z  
Ability: Inner Focus  
Tera Type: &
EVs: 240 HP / 40 Atk / 128 SpA / 100 SpD  
Brave Nature  
- Extreme Speed  
- Ominous Wind  
- Brick Break  
- Curse  

";
$mm41807 = "Ekans @ Poison Gem  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Toxic Spikes  
- Knock Off  
- Glare  
- Gunk Shot

";

$t11 = "Torkoal @ Weakness Policy  
Ability: Drought  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Eruption  
- Heat Wave  
- Protect  
- Earth Power  

";
$t112 = "Bruxish @ Focus Sash  
Ability: Dazzling  
Tera Type: &
EVs: 140 HP / 116 Atk / 252 SpD  
Brave Nature  
IVs: 0 Spe  
- Protect  
- Trick Room  
- Aqua Jet  
- Psychic Fangs  

";
$t123 = "Cresselia @ Safety Goggles  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD  
Calm Nature  
IVs: 0 Atk / 0 Spe  
- Lunar Blessing  
- Trick Room  
- Helping Hand  
- Moonblast  

";
$t134 = "Mismagius @ Sitrus Berry  
Ability: Levitate  
Tera Type: &
EVs: 120 Def / 252 SpA / 136 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Energy Ball  
- Taunt  
- Will-O-Wisp  

";
$t145 = "Cyclizar @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 84 SpD / 176 Spe  
Jolly Nature  
- Body Slam  
- U-turn  
- Draco Meteor  
- Knock Off  

";
$t155 = "Quaxwell @ Eviolite  
Ability: Moxie  
Tera Type: &
EVs: 248 HP / 208 Def / 52 Spe  
Impish Nature  
- Roost  
- Liquidation  
- Encore  
- Hydro Pump  

";
$t165 = "Tinkaton (F) @ Shed Shell  
Ability: Mold Breaker  
Tera Type: &
EVs: 248 HP / 52 Atk / 52 Def / 156 Spe  
Adamant Nature  
- Stealth Rock  
- Gigaton Hammer  
- Stone Edge  
- Knock Off  

";
$t175 = "Sandy Shocks @ Soft Sand  
Ability: Protosynthesis  
Tera Type: &
EVs: 64 HP / 236 SpA / 208 Spe  
Timid Nature  
IVs: 0 Atk  
- Earth Power  
- Volt Switch  
- Spikes  
- Tri Attack  

";
$t186 = "Iron Valiant @ Lum Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 48 HP / 252 Atk / 208 Spe  
Jolly Nature  
- Swords Dance  
- Close Combat  
- Spirit Break  
- Psycho Cut  

";
$t196 = "Flamigo @ Salac Berry  
Ability: Scrappy  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Endure  
- Reversal  
- Swords Dance  
- Facade  

";
$t1106 = "Regirock @ Sharp Beak  
Ability: Clear Body  
Tera Type: &
EVs: 200 HP / 252 Atk / 56 Spe  
Adamant Nature  
- Hidden Power [Flying]  
- Counter  
- Rock Slide  
- Superpower  

";
$t1116 = "Sawsbuck @ Heavy-Duty Boots  
Ability: Serene Grace  
Tera Type: &
EVs: 56 HP / 252 Atk / 4 SpD / 196 Spe  
Adamant Nature  
- Body Slam  
- Aromatherapy  
- Camouflage  
- Dig  

";
$t1126 = "Sharpedo @ Leftovers  
Ability: Rough Skin  
Tera Type: &
EVs: 76 HP / 252 Atk / 4 SpD / 176 Spe  
Jolly Nature  
- Taunt  
- Earthquake  
- Crunch  
- Waterfall  

";
$t1136 = "Manectric @ Choice Scarf  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 2 Atk / 30 Def / 30 SpA  
- Thunderbolt  
- Thunder Wave  
- Switcheroo  
- Hidden Power [Water]  

";
$t1147 = "Heracross @ Payapa Berry  
Ability: Guts  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 SpD  
Careful Nature  
- Counter  
- Megahorn  
- Close Combat  
- Toxic  

";
$t1157 = "Weezing @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 24 HP / 252 Def / 232 Spe  
Timid Nature  
- Destiny Bond  
- Explosion  
- Sludge Bomb  
- Haze  

";
$t1167 = "Heracross @ Normal Gem  
Ability: Guts  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Facade  
- Trailblaze  
- Knock Off  

";
$t1177 = "Infernape @ Punching Glove  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fire Punch  
- Mach Punch  
- Drain Punch  
- Fake Out  

";
$t1187 = "Scyther @ Eviolite  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Tailwind  
- Helping Hand  
- Protect  
- Feint  

";
$t1197 = "Ursaring @ Eviolite  
Ability: Guts  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Protect  
- Facade  
- Close Combat  
- Shadow Claw  

";
$t1208 = "Mimikyu @ Iron Ball  
Ability: Disguise  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Play Rough  
- Shadow Claw  
- Trick Room  
- Will-O-Wisp  

";
$t1219 = "Iron Hands @ Payapa Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpD  
Brave Nature  
IVs: 0 Spe  
- Fake Out  
- Close Combat  
- Wild Charge  
- Stomping Tantrum  

";
$t1230 = "Arcanine @ Iapapa Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Atk / 76 Def / 172 SpD / 4 Spe  
Jolly Nature  
- Flare Blitz  
- Snarl  
- Will-O-Wisp  
- Morning Sun  

";
$t1240 = "Ampharos @ Heavy-Duty Boots  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 8 SpD / 248 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hidden Power [Ice]  
- Heal Bell  
- Thunder Wave  



";
$t1253 = "Diancie @ Diancite  
Ability: Clear Body  
Tera Type: &
EVs: 100 HP / 32 Atk / 24 SpA / 100 SpD / 252 Spe  
Jolly Nature  
- Diamond Storm  
- Heal Bell  
- Baton Pass  
- Spikes  

";
$t1263 = "Hydrapple @ Dragon Gem  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 8 Atk / 100 SpA / 152 SpD  
Quiet Nature  
- Fickle Beam  
- Power Whip  
- Curse  
- Recover  

";
$t1273 = "Flygon @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 140 Def / 112 SpA / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Scorching Sands  
- Psychic Noise  
- Roost  
- Defog  

";
$t1284 = "Thundurus (M) @ Heavy-Duty Boots  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Defog  
- Heal Block  
- Volt Switch  
- Knock Off  

";
$t1294 = "Unfezant @ Scope Lens  
Ability: Super Luck  
Tera Type: &
EVs: 85 HP / 85 Atk / 85 Def / 85 SpA / 85 SpD / 85 Spe  
- Roost  
- Night Slash  
- Pluck  
- Return  

";
$t1303 = "Starmie @ Mystic Water  
Ability: Analytic  
Tera Type: &
EVs: 56 HP / 252 SpA / 200 Spe  
Timid Nature  
- Rapid Spin  
- Hydro Pump  
- Ice Beam  
- Recover  

";
$t1313 = "Mew @ Expert Belt  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Relaxed Nature  
- Heal Bell  
- Earth Power  
- Icicle Spear  
- Soft-Boiled  

";
$t1323 = "Empoleon (F) @ Covert Cloak  
Ability: Competitive  
Tera Type: &
EVs: 168 HP / 252 SpA / 88 Spe  
Modest Nature  
IVs: 0 Atk  
- Vacuum Wave  
- Grass Knot  
- Surf  
- Roost  

";
$t1334 = "Cresselia @ Mental Herb  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 204 Def / 52 Spe  
Bold Nature  
IVs: 0 Atk  
- Psychic Terrain  
- Reflect  
- Thunder Wave  
- Moonlight  

";
$t1345 = "Ogerpon-Cornerstone (F) @ Cornerstone Mask  
Ability: Sturdy  
Tera Type: &
EVs: 108 HP / 252 Atk / 148 Spe  
Adamant Nature  
- Ivy Cudgel  
- Horn Leech  
- Trailblaze  
- Spiky Shield  

";
$t1355 = "Manectric (F) @ Manectite  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder  
- Volt Switch  
- Hidden Power [Grass]  
- Overheat  

";
$t1366 = "Bronzong @ Aguav Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Stealth Rock  
- Toxic  
- Trick Room  
- Psywave  

";
$t1377 = "Primarina (F) @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Scald  
- Brine  
- Rest  
- Sleep Talk  

";
$t1388 = "Muk-Alola @ Aguav Berry  
Ability: Gluttony  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Recycle  
- Substitute  
- Poison Jab  
- Focus Punch  

";
$t1398 = "Corviknight @ Safety Goggles  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Impish Nature  
- Brave Bird  
- Defog  
- Roost  
- U-turn  

";
$t1408 = "Scream Tail @ Expert Belt  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 24 SpA / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Stealth Rock  
- Ice Beam  
- Psychic  

";
$t1419 = "Polteageist @ Safety Goggles  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Shadow Ball  
- Strength Sap  
- Will-O-Wisp  
- Shell Smash  

";
$t1430 = "Forretress @ Covert Cloak  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Counter  
- Body Press  
- Spikes  

";
$t1441 = "Quaquaval @ Assault Vest  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Careful Nature  
- Aqua Step  
- U-turn  
- Close Combat  
- Rapid Spin  

";
$t1451 = "Palafin-Hero (F) @ Assault Vest  
Ability: Zero to Hero  
Tera Type: &
EVs: 240 HP / 16 Atk / 252 Spe  
Adamant Nature  
- Flip Turn  
- Jet Punch  
- Liquidation  
- Ice Punch  

";
$t1461 = "Dudunsparce-Three-Segment @ Chople Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 40 HP / 56 Atk / 124 Def / 192 SpD / 96 Spe  
Careful Nature  
- Coil  
- Roost  
- Body Slam  
- Earthquake  

";
$t1471 = "Garchomp (F) @ Passho Berry  
Ability: Rough Skin  
Tera Type: &
EVs: 252 Atk / 16 SpD / 240 Spe  
Jolly Nature  
- Stealth Rock  
- Swords Dance  
- Earthquake  
- Poison Jab  

";
$t1481 = "Pawmot (F) @ Chilan Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 48 HP / 148 Atk / 72 Def / 24 SpD / 216 Spe  
Jolly Nature  
- Close Combat  
- Thunder Punch  
- Ice Punch  
- Revival Blessing  

";
$t1491 = "Sylveon (F) @ Wise Glasses  
Ability: Pixilate  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Wish  
- Protect  
- Calm Mind  

";
$t1502 = "Oricorio (F) @ Heavy-Duty Boots  
Ability: Dancer  
Tera Type: &
EVs: 248 HP / 148 Def / 80 SpA / 32 Spe  
Timid Nature  
IVs: 0 Atk  
- Quiver Dance  
- Roost  
- Revelation Dance  
- Hurricane  



";
$t1515 = "Roserade @ Heat Rock  
Ability: Technician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Solar Beam  
- Weather Ball  
- Hidden Power [Ice]  
- Sunny Day  

";
$t1526 = "Roserade @ Black Sludge  
Ability: Poison Point  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Weather Ball  
- Leech Seed  
- Substitute  
- Sunny Day  

";
$t1537 = "Iron Crown @ Power Herb  
Ability: Quark Drive  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Tachyon Cutter  
- Psychic  
- Solar Blade  
- Protect  

";
$t1547 = "Salamence @ Eject Pack  
Ability: Intimidate  
Tera Type: &
EVs: 108 HP / 28 Def / 120 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Defog  
- Refresh  
- Roost  

";
$t1558 = "Slaking @ Flame Orb  
Ability: Truant  
Tera Type: &
EVs: 252 SpA  
Serious Nature  
- Fling  
- Knock Off  
- Focus Blast  
- Giga Impact  

";
$t1568 = "Serperior @ Heat Rock  
Ability: Overgrow  
Tera Type: &
EVs: 164 HP / 4 Def / 88 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Solar Beam  
- Sunny Day  
- Synthesis  
- Calm Mind  

";
$t1579 = "Terapagos @ Assault Vest  
Ability: Tera Shift  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Ice Beam  
- Scorching Sands  
- Meteor Beam  

";
$t1590 = "Hariyama @ Leftovers  
Ability: Thick Fat  
Tera Type: &
EVs: 68 HP / 252 Atk / 16 Def / 172 SpD  
Adamant Nature  
- Drain Punch  
- Knock Off  
- Refresh  
- Bulk Up  

";
$t1600 = "Terapagos @ Choice Specs  
Ability: Tera Shift  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Flamethrower  
- Scorching Sands  
- Aura Sphere  

";
$t1611 = "Mienshao @ Payapa Berry  
Ability: Regenerator  
Tera Type: &
EVs: 240 Atk / 36 SpD / 232 Spe  
Jolly Nature  
- Drain Punch  
- Payback  
- Stone Edge  
- Bulk Up  

";
$t1621 = "Sneasel @ Eviolite  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Pursuit  
- Ice Punch  
- Punishment  
- Ice Shard  

";
$t1631 = "Venusaur @ Venusaurite  
Ability: Chlorophyll  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Terrain Pulse  
- Grassy Terrain  
- Leech Seed  
- Substitute  

";
$t1642 = "Slowking-Galar @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 164 SpD / 96 Spe  
Calm Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Future Sight  
- Focus Blast  
- Whirlpool  

";
$t1653 = "Slither Wing @ Utility Umbrella  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Impish Nature  
- Close Combat  
- U-turn  
- Will-O-Wisp  
- Morning Sun  

";
$t1663 = "Ogerpon (F) @ Yache Berry  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 80 Atk / 176 Spe  
Jolly Nature  
- Power Whip  
- Encore  
- Spikes  
- U-turn  

";
$t1673 = "Ogerpon (F) @ Utility Umbrella  
Ability: Defiant  
Tera Type: &
EVs: 148 HP / 48 Atk / 56 Def / 4 SpD / 252 Spe  
Jolly Nature  
- Wood Hammer  
- Synthesis  
- Double Kick  
- Rock Tomb  

";
$t1683 = "Zapdos @ Rocky Helmet  
Ability: Static  
Tera Type: &
EVs: 252 HP / 104 Def / 152 Spe  
Timid Nature  
IVs: 0 Atk  
- U-turn  
- Ancient Power  
- Thunder Wave  
- Roost  

";
$t1694 = "Scrafty @ Protective Pads  
Ability: Shed Skin  
Tera Type: &
EVs: 216 HP / 36 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Dragon Claw  
- Dragon Dance  
- Encore  

";
$t1704 = "Scraggy @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Drain Punch  
- Knock Off  
- Encore  
- Dragon Dance  

";
$t1714 = "Scraggy @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Drain Punch  
- Fake Out  
- Spite  
- Bulk Up  

";
$t1724 = "Scraggy @ Fightinium Z  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- Focus Punch  
- Detect  
- Substitute  
- Knock Off  

";
$t1734 = "Mew @ Dragonium Z  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 64 Def / 56 SpA / 48 SpD / 88 Spe  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Future Sight  
- Dragon Cheer  
- Roost  

";
$t1745 = "Victini @ Psychium Z  
Ability: Victory Star  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Future Sight  
- U-turn  
- Flamethrower  
- Encore  

";
$t1755 = "Victini @ Shell Bell  
Ability: Victory Star  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Searing Shot  
- Toxic  
- Charge Beam  
- Substitute  

";
$t1766 = "Alakazam @ Alakazite  
Ability: Inner Focus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Psychic  
- Foul Play  
- Energy Ball  

";
$t1777 = "Durant @ Rock Gem  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Superpower  
- Stone Edge  
- Iron Head  
- X-Scissor  

";
$t1787 = "Raticate-Alola @ Aguav Berry  
Ability: Gluttony  
Tera Type: &
EVs: 128 HP / 8 Atk / 252 Def / 120 Spe  
Impish Nature  
- Taunt  
- Bulk Up  
- Quick Attack  
- Counter  

";
$t1797 = "Swoobat @ Mago Berry  
Ability: Simple  
Tera Type: &
EVs: 112 HP / 252 Def / 144 Spe  
Timid Nature  
IVs: 0 Atk  
- Amnesia  
- Light Screen  
- Roost  
- Stored Power  

";
$t1808 = "Pheromosa @ Ice Gem  
Ability: Beast Boost  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Focus Blast  
- Outrage  
- Bug Buzz  
- Ice Beam  

";
$t1818 = "Alakazam @ Alakazite  
Ability: Trace  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Mild Nature  
IVs: 0 Atk  
- Psychic  
- Shadow Ball  
- Focus Blast  
- Signal Beam  

";
$t1829 = "Scolipede @ Bug Gem  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Megahorn  
- Superpower  
- Iron Tail  
- Earthquake  

";
$t1839 = "Mawile @ Choice Scarf  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Play Rough  
- Iron Head  
- Crunch  
- Rock Slide  

";
$t1849 = "Alomomola @ Leftovers  
Ability: Healer  
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe  
Calm Nature  
IVs: 0 Atk  
- Scald  
- Wish  
- Protect  
- Mirror Coat  

";
$t1860 = "Breloom @ Life Orb  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Spore  
- Bullet Seed  
- Mach Punch  
- Substitute  

";
$t1870 = "Heatran (F) @ Air Balloon  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 152 Def / 104 SpD  
Bold Nature  
IVs: 0 Atk  
- Attract  
- Captivate  
- Fire Blast  
- Will-O-Wisp  

";
$t1881 = "Tangrowth @ Rock Incense  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 140 Def / 116 Spe  
Lax Nature  
- Synthesis  
- Leech Seed  
- Protect  
- Rock Slide  

";
$t1891 = "Emolga @ Electrium Z  
Ability: Motor Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Ion Deluge  
- Thunder  
- Hidden Power [Fire]  
- Air Slash  

";
$t1902 = "Probopass @ Iron Ball  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Curse  
- Heavy Slam  
- Explosion  
- Magnetic Flux  

";
$t1912 = "Oricorio @ Charcoal  
Ability: Dancer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Revelation Dance  
- Calm Mind  
- Hurricane  
- Substitute  

";
$t1923 = "Purugly @ Normal Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fake Out  
- Super Fang  
- Giga Impact  
- Taunt  

";
$t1933 = "Trevenant @ Sitrus Berry  
Ability: Harvest  
Tera Type: &
EVs: 244 HP / 12 Atk / 252 SpD  
Careful Nature  
- Curse  
- Substitute  
- Phantom Force  
- Wood Hammer  

";
$t1943 = "Samurott @ Weakness Policy  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Substitute  
- Aqua Tail  
- Aqua Jet  
- Sacred Sword  

";
$t1953 = "Wigglytuff @ Wide Lens  
Ability: Cute Charm  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Sing  
- Dazzling Gleam  
- Hyper Beam  
- Fire Blast  

";
$t1964 = "Cloyster @ White Herb  
Ability: Skill Link  
Tera Type: &
EVs: 88 HP / 168 SpA / 252 Spe  
Modest Nature  
IVs: 1 Atk  
- Barrier  
- Shell Smash  
- Hidden Power [Electric]  
- Hydro Pump  

";
$t1975 = "Excadrill @ Choice Scarf  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 Def / 4 SpD / 248 Spe  
Adamant Nature  
- Earthquake  
- Rock Slide  
- Iron Head  
- Dig  

";
$t1985 = "Amoonguss @ Grass Gem  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Spore  
- Giga Drain  
- Foul Play  
- Sludge Bomb  

";
$t1996 = "Beartic @ Ice Gem  
Ability: Slush Rush  
Tera Type: &
EVs: 144 HP / 252 Atk / 112 Spe  
Adamant Nature  
- Hail  
- Icicle Crash  
- Aqua Jet  
- Low Kick  

";
$t11006 = "Shaymin @ Grass Gem  
Ability: Natural Cure  
Tera Type: &
EVs: 212 Atk / 72 SpA / 224 Spe  
Naive Nature  
- Swords Dance  
- Seed Bomb  
- Seed Flare  
- Grass Whistle  

";
$t11016 = "Latios @ Latiosite  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 56 SpD / 200 Spe  
Calm Nature  
IVs: 0 Atk  
- Light Screen  
- Calm Mind  
- Psychic  
- Roost  

";
$t11027 = "Cloyster @ Water Gem  
Ability: Skill Link  
Tera Type: &
EVs: 252 HP / 136 Def / 12 SpA / 108 Spe  
Bold Nature  
- Icicle Spear  
- Hydro Pump  
- Shell Smash  
- Substitute  

";
$t11037 = "Thundurus @ Flying Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fly  
- Wild Charge  
- Bulk Up  
- Superpower  

";
$t11047 = "Gigalith @ Rock Gem  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 7 Spe  
- Earthquake  
- Stone Edge  
- Superpower  
- Protect  

";
$t11058 = "Aerodactyl @ Focus Band  
Ability: Unnerve  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Stone Edge  
- Earthquake  
- Hone Claws  
- Sky Drop  

";
$t11068 = "Shedinja @ Bright Powder  
Ability: Wonder Guard  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Screech  
- Fury Cutter  
- Shadow Sneak  
- Phantom Force  

";
$t11078 = "Zoroark @ Fightinium Z  
Ability: Illusion  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Focus Blast  
- Dark Pulse  
- Detect  
- Substitute  

";
$t11089 = "Dedenne @ Sitrus Berry  
Ability: Cheek Pouch  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Eerie Impulse  
- Recycle  
- Discharge  
- Substitute  

";
$t11100 = "Venusaur @ Venusaurite  
Ability: Overgrow  
Tera Type: &
EVs: 252 HP / 172 Def / 84 SpD  
Careful Nature  
- Curse  
- Amnesia  
- Synthesis  
- Petal Blizzard  

";
$t11110 = "Umbreon @ Chople Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 232 Def / 24 SpD  
Calm Nature  
IVs: 0 Atk  
- Yawn  
- Protect  
- Screech  
- Foul Play  

";
$t11121 = "Aggron @ Aggronite  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def  
Brave Nature  
IVs: 0 Spe  
- Stone Edge  
- Earthquake  
- Taunt  
- Metal Burst  

";
$t11132 = "Stunfisk @ Petaya Berry  
Ability: Sand Veil  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Yawn  
- Endure  
- Thunder  
- Earth Power  

";
$t11143 = "Toucannon @ Flyinium Z  
Ability: Keen Eye  
Tera Type: &
EVs: 252 Def / 4 SpD / 252 Spe  
Adamant Nature  
- Beak Blast  
- Feather Dance  
- Mirror Move  
- Tailwind  

";
$t11153 = "Beheeyem @ Psychium Z  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Hidden Power [Flying]  
- Reflect  
- Recover  
- Trick  

";
$t11164 = "Articuno-Galar @ Red Card  
Ability: Competitive  
Tera Type: &
EVs: 252 HP / 60 Def / 60 SpD / 136 Spe  
Timid Nature  
IVs: 0 Atk  
- Imprison  
- Protect  
- Recover  
- Psychic Noise  

";
$t11175 = "Gholdengo @ Big Nugget  
Ability: Good as Gold  
Tera Type: &
EVs: 248 HP / 180 Atk / 16 SpA / 64 Spe  
Rash Nature  
- Make It Rain  
- Fling  
- Thief  
- Recover  

";
$t11185 = "Grafaiai @ Black Sludge  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 172 Def / 88 SpD  
Sassy Nature  
- Metronome  
- Substitute  
- Encore  
- Copycat  

";
$t11195 = "Palkia @ Flame Orb  
Ability: Telepathy  
Tera Type: &
EVs: 76 HP / 248 Atk / 76 SpA / 108 Spe  
Lonely Nature  
- Fling  
- Facade  
- Psych Up  
- Dragon Breath  

";
$t11205 = "Blaziken @ Sitrus Berry  
Ability: Speed Boost  
Tera Type: &
EVs: 248 HP / 80 Def / 80 SpD / 100 Spe  
Adamant Nature  
- Swords Dance  
- Coaching  
- Last Resort  

";
$t11214 = "Dudunsparce @ Chople Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 40 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Boomburst  
- Ancient Power  
- Hurricane  
- Stealth Rock  

";
$t11225 = "Dragonite @ Wide Lens  
Ability: Multiscale  
Tera Type: &
EVs: 160 HP / 252 SpA / 96 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Focus Blast  
- Hurricane  
- Thunder  

";
$t11236 = "Kleavor @ Protective Pads  
Ability: Sharpness  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Stone Axe  
- Night Slash  
- X-Scissor  
- Feint  

";
$t11246 = "Pelipper @ Choice Specs  
Ability: Drizzle  
Tera Type: &
EVs: 248 HP / 72 Def / 188 SpA  
Bold Nature  
- Fling  
- Weather Ball  
- Hurricane  
- Ice Beam

";
$t11256 = "Whiscash @ Leftovers
Ability: Oblivious
Tera Type: &
EVs: 236 HP / 64 Atk / 128 Def / 80 Spe
Impish Nature
- Stealth Rock
- Waterfall
- Stone Edge
- Protect

";
$t11266 = "Zygarde @ Absorb Bulb  
Ability: Aura Break  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dragon Dance  
- Haze  
- Camouflage  
- Snore  

";
$t11277 = "Alakazam @ Psychium Z  
Ability: Magic Guard  
Tera Type: &
EVs: 252 Def / 252 SpA / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Telekinesis  
- Disable  
- Zap Cannon  
- Focus Blast  

";
$t11288 = "Furfrou-Pharaoh @ Rocky Helmet  
Ability: Fur Coat  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Calm Nature  
IVs: 0 Atk  
- Cotton Guard  
- Growl  
- Echoed Voice  
- Rest  

";
$t11299 = "Mismagius @ Psychic Gem  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Telekinesis  
- Pain Split  
- Zap Cannon  
- Shadow Ball  

";
$t11310 = "Alakazam @ Psychic Gem  
Ability: Magic Guard  
Tera Type: &
EVs: 68 HP / 224 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Future Sight  
- Calm Mind  
- Substitute  
- Encore  

";
$t11321 = "Walrein @ Water Gem  
Ability: Oblivious  
Tera Type: &
EVs: 252 HP / 92 Atk / 52 Def / 112 SpD  
Adamant Nature  
- Yawn  
- Protect  
- Belly Drum  
- Waterfall  

";
$t11331 = "Alakazam @ Alakazite  
Ability: Inner Focus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Serious Nature  
IVs: 0 Atk  
- Psychic  

";
$t11339 = "Charizard @ Charizardite Y  
Ability: Blaze  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Blast Burn  

";
$t11347 = "Kartana @ Life Orb  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Giga Impact  

Arceus-Dragon  
Ability: Multitype  

";
$t11358 = "Breloom @ Occa Berry  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpD  
Careful Nature  
- Rock Tomb  
- Bullet Seed  
- Mach Punch  
- Superpower  

";
$t11368 = "Genesect @ Choice Scarf  
Ability: Download  
Tera Type: &
EVs: 16 HP / 212 Atk / 252 Def / 28 Spe  
Lax Nature  
- Fly  
- X-Scissor  
- Flamethrower  
- Ice Beam  

";
$t11378 = "Thundurus (M) @ Custap Berry  
Ability: Prankster  
Tera Type: &
EVs: 72 HP / 184 Atk / 252 SpD  
Adamant Nature  
- Wild Charge  
- Crunch  
- Bulk Up  
- Substitute  

";
$t11388 = "Serperior @ Occa Berry  
Ability: Overgrow  
Tera Type: &
EVs: 252 HP / 156 SpD / 100 Spe  
Calm Nature  
IVs: 0 Atk  
- Mirror Coat  
- Leech Seed  
- Substitute  
- Giga Drain  

";
$t11399 = "Magnezone @ Custap Berry  
Ability: Magnet Pull  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Magnet Rise  
- Toxic  
- Electroweb  

";
$t11410 = "Abomasnow (F) @ Abomasite  
Ability: Snow Warning  
Shiny: Yes  
Tera Type: &
EVs: 80 HP / 252 SpD / 176 Spe  
Gentle Nature  
- Rock Tomb  
- Earthquake  
- Blizzard  
- Protect  

";
$t11421 = "Magnezone @ Choice Band  
Ability: Sturdy  
Tera Type: &
EVs: 184 HP / 252 Atk / 72 SpA  
Quiet Nature  
- Hidden Power [Ice]  
- Thunderbolt  
- Iron Head  
- Wild Charge  

";
$t11431 = "Guzzlord @ Dragon Gem  
Ability: Beast Boost  
Tera Type: &
EVs: 184 HP / 252 Def / 72 SpD  
Relaxed Nature  
- Draco Meteor  
- Dark Pulse  
- Fire Blast  
- Stone Edge  

";
$t11441 = "Abomasnow @ Salac Berry  
Ability: Snow Warning  
Tera Type: &
EVs: 12 HP / 252 Atk / 4 SpD / 240 Spe  
Jolly Nature  
- Endure  
- Rock Tomb  
- Blizzard  
- Earthquake  

";
$t11451 = "Exeggutor-Alola @ Sitrus Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Leech Seed  
- Sleep Powder  
- Endure  
- Energy Ball  

";
$t11462 = "Servine @ Eviolite  
Ability: Contrary  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Glare  
- Leaf Storm  
- Taunt  
- Rest  

";
$t11473 = "Manectric @ Manectite  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Charge  
- Thunderbolt  
- Flamethrower  
- Substitute  

";
$t11484 = "Abra (F) @ Eviolite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psyshock  
- Calm Mind  
- Taunt  
- Encore  

";
$t11495 = "Kecleon @ Life Orb  
Ability: Protean  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Fake Out  
- Shadow Sneak  
- Sucker Punch  
- Aerial Ace  

";
$t11505 = "Absol @ Absolite  
Ability: Justified  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Ice Beam  
- Superpower  
- Stone Edge  
- Night Slash  

";
$t11515 = "Accelgor @ Poison Gem  
Ability: Hydration  
Tera Type: &
EVs: 4 HP / 88 Def / 252 SpA / 164 Spe  
Timid Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Bug Buzz  
- Acid Spray  
- Hidden Power [Electric]  

";
$t11526 = "Stoutland @ Fairy Feather  
Ability: Intimidate  
Tera Type: &
EVs: 4 HP / 252 Def / 252 Spe  
Jolly Nature  
- Charm  
- Play Rough  
- Rest  
- Sleep Talk  

";
$t11536 = "Accelgor @ Weakness Policy  
Ability: Unburden  
Shiny: Yes  
Tera Type: &
EVs: 252 Atk / 252 SpA / 4 SpD  
Mild Nature  
- Bug Buzz  
- Endure  
- Hidden Power [Ground]  
- Me First  

";
$t11547 = "Avalugg @ Fighting Gem  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 152 Atk / 104 Def  
Adamant Nature  
- Avalanche  
- Superpower  
- Curse  
- Mirror Coat  
s
";
$t11557 = "Cursola @ Loaded Dice  
Ability: Perish Body  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Icicle Spear  
- Rock Blast  
- Pin Missile  
- Protect  

";
$t11567 = "Cursola @ Wiki Berry  
Ability: Perish Body  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Shadow Ball  
- Ice Beam  
- Strength Sap  
- Calm Mind  

";
$t11578 = "Kingdra @ Lum Berry  
Ability: Sniper  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Waterfall  
- Wave Crash  
- Scale Shot  
- Focus Energy  

";
$t11588 = "Hydrapple @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Giga Drain  
- Fickle Beam  
- Earth Power  
- Nasty Plot  

";
$t11599 = "Leavanny @ Expert Belt  
Ability: Swarm  
Tera Type: &
EVs: 220 Atk / 36 Def / 252 Spe  
Jolly Nature  
- Leaf Blade  
- Lunge  
- Triple Axel  
- Substitute  

";
$t11609 = "Weavile @ Blunder Policy  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Knock Off  
- Triple Axel  
- Dynamic Punch  
- Swords Dance  

";
$t11619 = "Jynx (F) @ Blunder Policy  
Ability: Dry Skin  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Hasty Nature  
- Lovely Kiss  
- Blizzard  
- Dynamic Punch  
- Protect  

";
$t11629 = "Lanturn @ Blunder Policy  
Ability: Volt Absorb  
Tera Type: &
EVs: 216 HP / 252 Def / 40 SpD  
Bold Nature  
IVs: 0 Atk  
- Zap Cannon  
- Blizzard  
- Sleep Talk  
- Rest  

";
$t11640 = "Lanturn @ Salac Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 HP / 16 Atk / 240 SpD  
Sassy Nature  
- Liquidation  
- Rest  
- Whirlpool  
- Curse  

";
$t11650 = "Terrakion @ Salac Berry  
Ability: Justified  
Tera Type: &
EVs: 252 HP / 140 Def / 108 SpA / 8 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Rest  
- Block  
- Calm Mind  

";
$t11661 = "Hoopa-Unbound @ Kee Berry  
Ability: Magician  
Tera Type: &
EVs: 224 HP / 252 Def / 32 SpD  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Hyperspace Hole  
- Block  
- Calm Mind  

";
$t11672 = "Hoopa-Unbound @ Sitrus Berry  
Ability: Magician  
Tera Type: &
EVs: 160 HP / 92 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hyperspace Hole  
- Focus Blast  
- Block  
- Calm Mind  

";
$t11683 = "Sableye @ Sablenite  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 176 Def / 8 SpA / 56 SpD / 20 Spe  
Bold Nature  
IVs: 0 Atk  
- Icy Wind  
- Hidden Power [Electric]  
- Recover  
- Calm Mind  

";
$t11694 = "Hydrapple @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Fickle Beam  
- Grassy Terrain  
- Substitute  
- Protect  

";
$t11705 = "Hydrapple @ Blunder Policy  
Ability: Sticky Hold  
Tera Type: &
EVs: 120 HP / 24 Atk / 36 Def / 76 SpA / 252 Spe  
Naive Nature  
- Hydro Pump  
- Power Whip  
- Recover  
- Protect  

";
$t11715 = "Terapagos @ Choice Scarf  
Ability: Tera Shift  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Ice Beam  
- Thunderbolt  
- Earth Power  

";
$t11726 = "Terapagos @ Metronome  
Ability: Tera Shift  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
- Tera Starstorm  
- Aura Sphere  
- Thunderbolt  
- Rapid Spin  

";
$t11736 = "Terapagos @ Choice Band  
Ability: Tera Shift  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Flare Blitz  
- Ice Spinner  
- Supercell Slam  
- Rapid Spin  

";
$t11746 = "Mew @ Aguav Berry  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Stored Power  
- Soft-Boiled  
- Block  
- Bulk Up  

";
$t11757 = "Mew @ Sitrus Berry  
Ability: Synchronize  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Drain Punch  
- Soft-Boiled  
- Block  
- Bulk Up  

";
$t11767 = "Mew @ Starf Berry  
Ability: Synchronize  
Tera Type: &
EVs: 240 HP / 28 Def / 28 SpA / 80 SpD / 132 Spe  
Timid Nature  
IVs: 0 Atk  
- Stored Power  
- Tera Blast  
- Terrain Pulse  
- Calm Mind  

";
$t11778 = "Metagross @ Starf Berry  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Rash Nature  
- Psychic  
- Heavy Slam  
- Substitute  
- Agility  

";
$t11788 = "Beldum @ Eviolite  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA  
Brave Nature  
- Iron Defense  
- Iron Head  
- Zen Headbutt  
- Tera Blast  

";
$t11798 = "Enamorus (F) @ Damp Rock  
Ability: Cute Charm  
Tera Type: &
EVs: 168 HP / 48 Def / 252 SpA / 4 SpD / 36 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Extrasensory  
- Rain Dance  
- Protect  

";
$t11809 = "Gliscor @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 244 HP / 252 SpD / 12 Spe  
Careful Nature  
- Facade  
- Knock Off  
- Swords Dance  
- Protect  

";
$t11819 = "Gliscor @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 244 HP / 252 SpD / 12 Spe  
Careful Nature  
- Facade  
- Knock Off  
- Sand Attack  
- Protect  

";
$t11829 = "Gliscor @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 252 HP / 120 Def / 136 SpD  
Impish Nature  
- Facade  
- Tailwind  
- Rest  
- Sleep Talk  

";
$t11839 = "Swampert @ Assault Vest  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA  
Brave Nature  
- Flip Turn  
- High Horsepower  
- Knock Off  
- Ice Beam  

";
$t11849 = "Dragapult @ Expert Belt  
Ability: Infiltrator  
Tera Type: &
EVs: 28 HP / 184 Atk / 140 SpA / 156 Spe  
Rash Nature  
- Shadow Ball  
- Fire Blast  
- Tera Blast  
- Dragon Dance  

";
$t11859 = "Lucario @ Air Balloon  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 196 SpD / 60 Spe  
Adamant Nature  
- Close Combat  
- Meteor Mash  
- Extreme Speed  
- Swords Dance  

";
$t11869 = "Machamp @ Custap Berry  
Ability: No Guard  
Tera Type: &
EVs: 172 HP / 204 Atk / 132 SpD  
Adamant Nature  
- Dynamic Punch  
- Metronome  
- Stone Edge  
- Endure  

";
$t11879 = "Weezing-Galar @ Leftovers  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 92 Def / 56 SpA / 108 SpD  
Bold Nature  
IVs: 0 Atk  
- Strange Steam  
- Overheat  
- Will-O-Wisp  
- Protect  

";
$t11890 = "Archaludon @ Maranga Berry  
Ability: Stamina  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Dragon Pulse  
- Electro Shot  
- Rest  
- Sleep Talk  

";
$t11901 = "Duraludon @ Eviolite  
Ability: Heavy Metal  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Breaking Swipe  
- Dragon Cheer  
- Body Press  
- Stealth Rock  

";
$t11911 = "Masquerain @ Custap Berry  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
- Hurricane  
- U-turn  
- Roost  
- Sticky Web  

";
$t11921 = "Dragapult @ Shell Bell  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 104 Atk / 156 Spe  
Serious Nature  
- Dragon Darts  
- Substitute  
- Protect  
- Curse  

";
$t11931 = "Wailord @ Lum Berry  
Ability: Pressure  
Tera Type: &
EVs: 172 Def / 252 SpA / 84 Spe  
Modest Nature  
IVs: 0 Atk  
- Water Spout  
- Scald  
- Aqua Ring  
- Protect  

";
$t11942 = "Blastoise @ Lum Berry  
Ability: Torrent  
Tera Type: &
EVs: 92 HP / 152 Atk / 48 Def / 48 SpA / 168 SpD  
Sassy Nature  
- Water Spout  
- Scald  
- Aqua Ring  
- Aqua Jet  

";
$t11952 = "Hitmonlee (M) @ Choice Band  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- High Jump Kick  
- Mach Punch  
- Knock Off  
- Poison Jab  

";
$t11962 = "Hitmonchan (M) @ Leftovers  
Ability: Keen Eye  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Close Combat  
- Rapid Spin  
- Encore  
- Protect  

";
$t11972 = "Hitmonlee (M) @ Fighting Gem  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Jump Kick  
- Knock Off  
- Rapid Spin  
- Substitute  

";
$t11982 = "Greedent @ Sitrus Berry  
Ability: Cheek Pouch  
Tera Type: &
EVs: 248 HP / 140 Atk / 60 Def / 60 SpD  
Adamant Nature  
- Double-Edge  
- Knock Off  
- Protect  
- Swords Dance  

";
$t11992 = "Gliscor @ Waterium Z  
Ability: Poison Heal  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Horsepower  
- Crabhammer  
- Gunk Shot  
- Swords Dance  

";
$t12002 = "Crabominable @ Poisonium Z  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Ice Punch  
- Drain Punch  
- Gunk Shot  
- Bulk Up  

";
$t12012 = "Hitmonlee (M) @ Covert Cloak  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Jump Kick  
- Refresh  
- Rapid Spin  
- Fake Out  

";
$t12022 = "Kyurem-Black @ Loaded Dice  
Ability: Teravolt  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Icicle Spear  
- Scale Shot  
- Roost  
- Protect  

";
$t12033 = "Alomomola @ Loaded Dice  
Ability: Regenerator  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Scale Shot  
- Protect  
- Wish  

";
$t12043 = "Krookodile @ Loaded Dice  
Ability: Intimidate  
Tera Type: &
EVs: 120 HP / 96 Atk / 44 SpD / 248 Spe  
Jolly Nature  
- Stomping Tantrum  
- Beat Up  
- Scale Shot  
- Bulk Up  

";
$t12053 = "Marowak-Alola @ Utility Umbrella  
Ability: Lightning Rod  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Poltergeist  
- Will-O-Wisp  
- Stealth Rock  
- Protect  

";
$t12063 = "Marowak-Alola @ Leftovers  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Tera Blast  
- Shadow Bone  
- Rest  
- Curse  

";
$t12073 = "Weezing-Galar @ Heavy-Duty Boots  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 212 Def / 40 SpA / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Strange Steam  
- Acid Spray  
- Defog  
- Pain Split  

";
$t12084 = "Toxel @ Eviolite  
Ability: Static  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Nuzzle  
- Tearful Look  
- Encore  
- Protect  

";
$t12094 = "Ogerpon-Wellspring (F) @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 120 SpD / 252 Spe  
Jolly Nature  
- Leech Seed  
- Substitute  
- Power Whip  
- Ivy Cudgel  

";
$t12104 = "Weezing-Galar @ Assault Vest  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Strange Steam  
- Fire Blast  
- Thunder  
- Acid Spray  

";
$t12115 = "Marowak-Alola @ Thick Club  
Ability: Cursed Body  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Brave Nature  
- Flare Blitz  
- Shadow Bone  
- Tera Blast  
- Swords Dance  

";
$t12125 = "Marowak-Alola @ Leftovers  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Flame Charge  
- Toxic  
- Substitute  
- Protect  

";
$t12135 = "Marowak-Alola @ Leftovers  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Shadow Bone  
- Toxic  
- Substitute  
- Protect  

";
$t12145 = "Marowak-Alola @ Choice Specs  
Ability: Lightning Rod  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Shadow Ball  
- Fire Blast  
- Ice Beam  
- Scorching Sands  

";
$t12156 = "Marowak-Alola @ Heavy-Duty Boots  
Ability: Lightning Rod  
Tera Type: &
EVs: 144 HP / 252 Atk / 112 Spe  
Adamant Nature  
- Flare Blitz  
- Poltergeist  
- Will-O-Wisp  
- Protect  

";
$t12166 = "Marowak-Alola @ Choice Band  
Ability: Rock Head  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Poltergeist  
- Flare Blitz  
- Knock Off  
- Double-Edge  

";
$t12176 = "Marowak-Alola @ Thick Club  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Flame Charge  
- Poltergeist  
- Substitute  
- Endeavor  

";
$t12186 = "Weezing-Galar @ Weakness Policy  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 84 Def / 172 SpA  
Modest Nature  
IVs: 0 Atk  
- Strange Steam  
- Fire Blast  
- Will-O-Wisp  
- Taunt  

";
$t12197 = "Weezing-Galar @ Iapapa Berry  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Aromatherapy  
- Haze  
- Defog  

";
$t12208 = "Tapu Fini @ Terrain Extender  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Scald  
- Draining Kiss  
- Knock Off  
- Calm Mind  

";
$t12218 = "Tapu Fini @ Tapunium Z  
Ability: Misty Surge  
Tera Type: &
EVs: 172 HP / 68 Def / 172 SpA / 52 SpD / 44 Spe  
Calm Nature  
- Natures Madness  
- Defog  
- Knock Off  
- Moonblast  

";
$t12228 = "Tapu Fini @ Tapunium Z  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draining Kiss  
- Natures Madness  
- Substitute  
- Protect  

";
$t12239 = "Tapu Fini @ Metronome  
Ability: Misty Surge  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Nature Power  
- Blizzard  
- Protect  

";
$t12250 = "Cinderace @ Shuca Berry  
Ability: Blaze  
Tera Type: &
EVs: 252 HP / 52 Atk / 60 Def / 144 Spe  
Jolly Nature  
- Pyro Ball  
- Gunk Shot  
- Sucker Punch  
- Court Change  

";
$t12260 = "Tapu Fini @ Leftovers  
Ability: Telepathy  
Tera Type: &
EVs: 248 HP / 8 Def / 164 SpA / 88 Spe  
Modest Nature  
IVs: 0 Atk  
- Draining Kiss  
- Refresh  
- Protect  
- Calm Mind  

";
$t12271 = "Tapu Fini @ Terrain Extender  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 88 Atk / 128 SpA / 44 SpD  
Sassy Nature  
- Brine  
- Knock Off  
- Haze  
- Natures Madness  

";
$t12281 = "Tapu Fini @ Throat Spray  
Ability: Misty Surge  
Tera Type: &
EVs: 28 HP / 252 SpA / 228 Spe  
Modest Nature  
IVs: 0 Atk  
- Echoed Voice  
- Draining Kiss  
- Light Screen  
- Iron Defense  

";
$t12292 = "Greninja @ Kings Rock  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Blizzard  
- Sludge Wave  
- Protect  

";
$t12303 = "Avalugg-Hisui @ Choice Band  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Mountain Gale  
- Rock Blast  
- Heavy Slam  
- Earthquake  

";
$t12313 = "Enamorus (F) @ Throat Spray  
Ability: Cute Charm  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Alluring Voice  
- Mystical Fire  
- Calm Mind  

";
$t12324 = "Aromatisse @ Throat Spray  
Ability: Aroma Veil  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Disarming Voice  
- Hyper Beam  
- Wish  
- Protect  

";
$t12335 = "Pincurchin @ Electric Seed  
Ability: Electric Surge  
Tera Type: &
EVs: 252 HP / 116 Atk / 80 Def / 56 SpA / 4 SpD  
Brave Nature  
- Zing Zap  
- Scald  
- Protect  
- Charge  

";
$t12345 = "Veluza @ Berry Juice  
Ability: Sharpness  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Aqua Cutter  
- Psycho Cut  
- Protect  
- Fillet Away  

";
$t12355 = "Veluza @ Leftovers  
Ability: Sharpness  
Tera Type: &
EVs: 40 HP / 80 Atk / 136 Def / 252 Spe  
Jolly Nature  
- Aqua Cutter  
- Substitute  
- Protect  
- Fillet Away  

";
$t12365 = "Tapu Bulu @ Tapunium Z  
Ability: Grassy Surge  
Tera Type: &
EVs: 132 HP / 124 Atk / 252 Spe  
Jolly Nature  
- Horn Leech  
- Leech Seed  
- Protect  
- Natures Madness  

";
$t12375 = "Rillaboom @ Normalium Z  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Grassy Glide  
- Double-Edge  
- Superpower  
- Swords Dance  

";
$t12385 = "Rillaboom @ Custap Berry  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 HP / 76 Atk / 164 SpD / 16 Spe  
Adamant Nature  
- Wood Hammer  
- Drain Punch  
- Endure  
- Bulk Up  

";
$t12395 = "Fezandipiti (M) @ Throat Spray  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Alluring Voice  
- Taunt  
- Roost  
- Protect  

";
$t12406 = "Indeedee (M) @ Chesto Berry  
Ability: Psychic Surge  
Tera Type: &
EVs: 204 HP / 12 Def / 40 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Hidden Power [Ground]  
- Rest  
- Calm Mind  

";
$t12417 = "Indeedee (M) @ Terrain Extender  
Ability: Inner Focus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Expanding Force  
- Encore  
- Psychic Terrain  

";
$t12428 = "Iron Crown @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 168 HP / 93 Def / 7 SpA / 85 SpD / 155 Spe  
Modest Nature  
- Stored Power  
- Tachyon Cutter  
- Iron Defense  
- Calm Mind  

";
$t12439 = "Gholdengo @ Normalium Z  
Ability: Good as Gold  
Tera Type: &
EVs: 132 HP / 192 Def / 20 SpA / 152 SpD / 12 Spe  
Bold Nature  
IVs: 0 Atk  
- Memento  
- Rest  
- Tera Blast  
- Sleep Talk  

";
$t12450 = "Bisharp @ Kings Rock  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Beat Up  
- Rest  
- Sleep Talk  
- Dual Chop  

";
$t12460 = "Wugtrio @ Kings Rock  
Ability: Gooey  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Hasty Nature  
- Triple Dive  
- Muddy Water  
- Protect  
- Substitute  

";
$t12470 = "Wugtrio @ Rockium Z  
Ability: Sand Veil  
Tera Type: &
EVs: 252 HP / 80 SpD / 176 Spe  
Hasty Nature  
- Triple Dive  
- Whirlpool  
- Sandstorm  
- Protect  

";
$t12480 = "Wugtrio @ Chesto Berry  
Ability: Gooey  
Tera Type: &
EVs: 124 Def / 132 SpD / 252 Spe  
Timid Nature  
IVs: 0 HP / 0 Atk  
- Final Gambit  
- Rest  
- Whirlpool  
- Protect  

";
$t12491 = "Scrafty @ Expert Belt  
Ability: Intimidate  
Tera Type: &
EVs: 232 HP / 252 Atk / 24 Spe  
Adamant Nature  
- High Jump Kick  
- Ice Punch  
- Fake Out  
- Crunch  

";
$t12501 = "Brute Bonnet @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 212 HP / 252 Atk / 44 Spe  
Adamant Nature  
- Close Combat  
- Sucker Punch  
- Payback  
- Seed Bomb  

";
$t12511 = "Hoopa-Unbound @ Choice Band  
Ability: Magician  
Tera Type: &
EVs: 240 HP / 252 Def / 16 Spe  
Impish Nature  
- Ice Punch  
- Drain Punch  
- Skitter Smack  
- Dual Chop  

";
$t12521 = "Iron Crown @ Flyinium Z  
Ability: Quark Drive  
Tera Type: &
EVs: 60 HP / 192 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Steel Beam  
- Air Slash  
- Calm Mind  
- Protect  

";
$t12532 = "Toxapex @ Wide Lens  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 68 Def / 24 SpA / 164 SpD  
Sassy Nature  
- Muddy Water  
- Blizzard  
- Baneful Bunker  
- Knock Off  

";
$t12542 = "Landorus (M) @ Jaboca Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 48 HP / 160 Atk / 48 SpA / 252 Spe  
Hasty Nature  
- Sludge Wave  
- Rock Slide  
- Focus Blast  
- Endure  

";
$t12552 = "Sandslash @ Passho Berry  
Ability: Sand Veil  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- High Horsepower  
- Knock Off  
- Stealth Rock  
- Rapid Spin  

";
$t12562 = "Iron Boulder @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Mighty Cleave  
- Rest  
- Sleep Talk  
- Swords Dance  

";
$t12572 = "Sandy Shocks @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 48 HP / 208 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Electro Ball  
- Scorching Sands  
- Zap Cannon  
- Charge  

";
$t12583 = "Basculegion-F (F) @ Leftovers  
Ability: Adaptability  
Tera Type: &
EVs: 148 HP / 252 Atk / 108 SpD  
Adamant Nature  
- Phantom Force  
- Protect  
- Whirlpool  
- Tail Whip  

";
$t12593 = "Ursaluna-Bloodmoon (M) @ Petaya Berry  
Ability: Minds Eye  
Tera Type: &
EVs: 140 HP / 252 SpA / 52 SpD / 64 Spe  
Modest Nature  
IVs: 0 Atk  
- Blood Moon  
- Roar  
- Substitute  
- Protect  

";
$t12604 = "Moltres @ Salac Berry  
Ability: Pressure  
Tera Type: &
EVs: 72 HP / 252 SpA / 184 Spe  
Modest Nature  
IVs: 3 Atk / 30 SpA  
- Overheat  
- Air Slash  
- Hidden Power [Electric]  
- Endure  

";
$t12615 = "Gastrodon @ Choice Scarf  
Ability: Sticky Hold  
Tera Type: &
EVs: 60 Def / 252 SpA / 196 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA  
- Surf  
- Earth Power  
- Ice Beam  
- Hidden Power [Grass]  

";
$t12626 = "Sandy Shocks @ Custap Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Thunder  
- Endure  
- Charge  

";
$t12637 = "Mew @ Electric Gem  
Ability: Synchronize  
Tera Type: &
EVs: 116 HP / 76 Atk / 252 SpA / 64 Spe  
Mild Nature  
- Close Combat  
- Thunder  
- Roost  
- Charge  

";
$t12647 = "Porygon-Z @ Custap Berry  
Ability: Adaptability  
Tera Type: &
EVs: 212 HP / 40 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Thunder  
- Recover  
- Charge  

";
$t12658 = "Porygon2 @ Eviolite  
Ability: Download  
Tera Type: &
EVs: 248 HP / 96 Def / 164 SpA  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Ice Beam  
- Recover  
- Charge  

";
$t12669 = "Porygon-Z @ Figy Berry  
Ability: Download  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Foul Play  
- Flash  
- Protect  

";
$t12680 = "Avalugg @ Maranga Berry  
Ability: Ice Body  
Tera Type: &
EVs: 116 HP / 252 SpD / 140 Spe  
Careful Nature  
- Icicle Crash  
- Rapid Spin  
- Snowscape  
- Recover  

";
$t12690 = "Vikavolt @ Wide Lens  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Zap Cannon  
- Rest  
- Sleep Talk  
- Charge  

";
$t12701 = "Hoopa-Unbound @ Assault Vest  
Ability: Magician  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Gentle Nature  
IVs: 0 Def  
- Drain Punch  
- Power-Up Punch  
- Knock Off  
- Lash Out  

";
$t12712 = "Regice @ Assault Vest  
Ability: Ice Body  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Frost Breath  
- Zap Cannon  
- Hidden Power [Fire]  
- Tera Blast  

";
$t12723 = "Shuckle @ Assault Vest  
Ability: Gluttony  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
- Infestation  
- Knock Off  
- Sludge Bomb  
- Dig  

";
$t12733 = "Bastiodon @ Assault Vest  
Ability: Soundproof  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Rock Tomb  
- Foul Play  
- Body Slam  
- Metal Burst  

";
$t12743 = "Corviknight @ Figy Berry  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Body Press  
- Sand Attack  
- Defog  
- Protect  

";
$t12754 = "Kyurem-Black @ Throat Spray  
Ability: Teravolt  
Tera Type: &
EVs: 100 HP / 152 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hyper Voice  
- Freeze-Dry  
- Hidden Power [Dark]  
- Protect  

";
$t12765 = "Spiritomb @ Chesto Berry  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpA  
Quiet Nature  
IVs: 30 Atk  
- Hidden Power [Dark]  
- Poltergeist  
- Rest  
- Calm Mind  

";
$t12776 = "Tapu Fini @ Clear Amulet  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 48 Def / 68 SpA / 4 SpD / 140 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Draining Kiss  
- Protect  
- Calm Mind  

";
$t12787 = "Alomomola @ Clear Amulet  
Ability: Regenerator  
Tera Type: &
EVs: 140 Def / 252 SpA / 116 SpD  
Bold Nature  
IVs: 0 Atk  
- Whirlpool  
- Hydro Pump  
- Wish  
- Calm Mind  

";
$t12798 = "Tapu Lele @ Psychic Seed  
Ability: Psychic Surge  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Modest Nature  
IVs: 0 Atk  
- Focus Blast  
- Hyper Beam  
- Rest  
- Sleep Talk  

";
$t12809 = "Skuntank @ Choice Scarf  
Ability: Aftermath  
Tera Type: &
EVs: 72 HP / 252 Atk / 184 Spe  
Adamant Nature  
- Pursuit  
- Crunch  
- Roar  
- Defog  

";
$t12819 = "Kingdra @ Haban Berry  
Ability: Swift Swim  
Tera Type: &
EVs: 176 HP / 152 SpA / 180 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Surf  
- Draco Meteor  
- Sleep Talk  

";
$t12830 = "Azelf @ Salac Berry  
Ability: Levitate  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Mild Nature  
- Endure  
- Nasty Plot  
- Psychic  
- Explosion  

";
$t12840 = "Porygon2 @ Choice Scarf  
Ability: Download  
Tera Type: &
EVs: 252 HP / 40 Def / 40 SpA / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Rain Dance  
- Recover  
- Ice Beam  
- Trick  

";
$t12851 = "Banette @ Leftovers  
Ability: Insomnia  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Shadow Sneak  
- Skill Swap  
- Will-O-Wisp  
- Pain Split  

";
$t12861 = "Tentacruel @ Expert Belt  
Ability: Liquid Ooze  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Sludge Bomb  
- Hydro Pump  
- Hidden Power [Flying]  
- Rapid Spin  

";
$t12871 = "Carnivine @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 204 Atk / 16 SpD / 36 Spe  
Adamant Nature  
- Leech Seed  
- Substitute  
- Power Whip  
- Swords Dance  

";
$t12881 = "Milotic @ Leftovers  
Ability: Marvel Scale  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Surf  
- Ice Beam  

";
$t12892 = "Muk @ Custap Berry  
Ability: Sticky Hold  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Curse  
- Gunk Shot  
- Pain Split  
- Explosion  

";
$t12902 = "Gliscor @ Leftovers  
Ability: Hyper Cutter  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Roost  
- U-turn  
- Earthquake  
- Stealth Rock  

";
$t12912 = "Togekiss @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 72 SpA / 184 Spe  
Modest Nature  
IVs: 0 Atk  
- Ancient Power  
- Flamethrower  
- Tri Attack  
- Roost  

";
$t12923 = "Smeargle @ Leftovers  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Belly Drum  
- Spore  
- Substitute  
- Bullet Punch  

";
$t12933 = "Gholdengo @ Shuca Berry  
Ability: Good as Gold  
Tera Type: &
EVs: 248 HP / 124 Def / 136 SpA  
Modest Nature  
IVs: 0 Atk  
- Make It Rain  
- Shadow Ball  
- Power Gem  
- Recover  

";
$t12944 = "Braviary (M) @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Brave Nature  
- Air Slash  
- Body Slam  
- U-turn  
- Roost  

";
$t12954 = "Lokix @ Heavy-Duty Boots  
Ability: Tinted Lens  
Tera Type: &
EVs: 56 HP / 236 Atk / 216 Spe  
Jolly Nature  
- First Impression  
- U-turn  
- Knock Off  
- Sucker Punch  

";
$t12964 = "Lokix @ Weakness Policy  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 HP / 124 Atk / 4 SpD / 128 Spe  
Adamant Nature  
- First Impression  
- Sucker Punch  
- Axe Kick  
- Endure  

";
$t12974 = "Raging Bolt @ Red Card  
Ability: Protosynthesis  
Tera Type: &
EVs: 196 HP / 252 SpA / 60 Spe  
Modest Nature  
IVs: 20 Atk  
- Calm Mind  
- Thunderclap  
- Weather Ball  
- Dragon Pulse  

";
$t12985 = "Jirachi @ Occa Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Wish  
- Psyshock  
- Thunder Wave  

";
$t12996 = "Zorua-Hisui (M) @ Choice Specs  
Ability: Illusion  
Tera Type: &
EVs: 48 HP / 252 Def / 208 SpA  
Modest Nature  
IVs: 0 Atk  
- Foul Play  
- Shadow Ball  
- Curse  
- Memento  

";
$t13007 = "Iron Treads @ Weakness Policy  
Ability: Quark Drive  
Tera Type: &
EVs: 120 HP / 252 Def / 136 Spe  
Jolly Nature  
- Earthquake  
- Body Press  
- Iron Defense  
- Rapid Spin  

";
$t13017 = "Latias (F) @ Latiasite  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Mystical Fire  
- Mist Ball  
- Roost  

";
$t13028 = "Froslass (F) @ Sitrus Berry  
Ability: Cursed Body  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Triple Axel  
- Poltergeist  
- Spikes  
- Taunt  

";
$t13038 = "Froslass (F) @ Icy Rock  
Ability: Snow Cloak  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Triple Axel  
- Poltergeist  
- Spikes  
- Snowscape  

";
$t13048 = "Kingambit @ Shed Shell  
Ability: Supreme Overlord  
Tera Type: &
EVs: 240 HP / 252 Atk / 16 Spe  
Adamant Nature  
- Kowtow Cleave  
- Foul Play  
- Pursuit  
- Swords Dance  

";
$t13058 = "Alakazam @ Lum Berry  
Ability: Synchronize  
Tera Type: &
EVs: 240 SpA / 196 Spe  
Modest Nature  
IVs: 30 Atk  
- Substitute  
- Psychic  
- Hidden Power [Water]  
- Thief  

";
$t13069 = "Sneasel-Hisui @ Choice Band  
Ability: Inner Focus  
Tera Type: &
EVs: 76 Atk / 216 Def / 216 Spe  
Jolly Nature  
- Gunk Shot  
- Close Combat  
- Throat Chop  
- Dig  

";
$t13079 = "Kommo-o @ Eject Pack  
Ability: Soundproof  
Tera Type: &
EVs: 100 HP / 24 Atk / 144 SpA / 28 SpD / 212 Spe  
Hasty Nature  
- Draco Meteor  
- Upper Hand  
- Stealth Rock  
- Protect  

";
$t13089 = "Armarouge @ Weakness Policy  
Ability: Flash Fire  
Tera Type: &
EVs: 248 HP / 200 Def / 60 Spe  
Bold Nature  
IVs: 0 Atk  
- Armor Cannon  
- Stored Power  
- Iron Defense  
- Calm Mind  

";
$t13100 = "Sceptile @ Leftovers  
Ability: Overgrow  
Tera Type: &
EVs: 248 HP / 84 Def / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Energy Ball  
- Leech Seed  
- Substitute  
- Protect  

";
$t13111 = "Pawmot @ Life Orb  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double Shock  
- Close Combat  
- Ice Punch  
- Fake Out  

";
$t13121 = "Kommo-o @ Life Orb  
Ability: Soundproof  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Giga Impact  
- Protect  
- Substitute  
- Dragon Dance  

";
$t13131 = "Kommo-o @ Leftovers  
Ability: Bulletproof  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Giga Impact  
- Protect  
- Substitute  
- Dragon Dance  

";
$t13141 = "Charizard @ Charizardite X  
Ability: Solar Power  
Tera Type: &
EVs: 252 Atk / 8 Def / 248 Spe  
Adamant Nature  
- Giga Impact  
- Substitute  
- Protect  
- Dragon Dance  

";
$t13151 = "Samurott-Hisui @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 164 HP / 52 Atk / 36 Def / 4 SpD / 252 Spe  
Jolly Nature  
- Ceaseless Edge  
- Upper Hand  
- Aqua Jet  
- Avalanche  

";
$t13161 = "Pineco @ Sitrus Berry  
Ability: Sturdy  
Tera Type: &
EVs: 196 HP / 76 Atk / 36 Def / 156 SpD  
Impish Nature  
- Spikes  
- Earthquake  
- Rock Slide  
- Explosion  

";
$t13171 = "Pineco @ Eviolite  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
- Struggle Bug  
- Rapid Spin  
- Spikes  
- Protect  

";
$t13181 = "Pineco @ Eviolite  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Counter  
- Ice Spinner  
- Pain Split  
- Spikes  

";
$t13191 = "Pineco @ Heavy-Duty Boots  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
- Rapid Spin  
- Spikes  
- Toxic Spikes  
- Protect  

";
$t13201 = "Pineco @ Eviolite  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Drill Run  
- Ice Spinner  
- Rest  
- Curse  

";
$t13211 = "Swoobat @ Assault Vest  
Ability: Klutz  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Calm Mind  
- Trick  
- Roost  

";
$t13222 = "Annihilape @ Power Herb  
Ability: Defiant  
Tera Type: &
EVs: 100 HP / 156 SpD / 252 Spe  
Jolly Nature  
- Rage Fist  
- Skull Bash  
- Outrage  
- Bulk Up  

";
$t13232 = "Scizor @ Scizorite  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 192 Def / 68 SpD  
Impish Nature  
- Toxic  
- Defog  
- Bullet Punch  
- Roost  

";
$t13242 = "Heatran @ Normalium Z  
Ability: Flash Fire  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Magma Storm  
- Nature Power  
- Substitute  
- Stealth Rock  

";
$t13253 = "Zapdos @ Expert Belt  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 20 Def / 56 SpA / 184 Spe  
Timid Nature  
IVs: 0 Atk  
- Hidden Power [Ice]  
- Volt Switch  
- Defog  
- Roost  

";
$t13265 = "Salamence @ Scope Lens  
Ability: Intimidate  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Focus Energy  
- Draco Meteor  
- Flamethrower  
- Earthquake  

";
$t13275 = "Diancie @ Diancite  
Ability: Clear Body  
Tera Type: &
EVs: 172 Atk / 84 SpA / 252 Spe  
Naive Nature  
- Diamond Storm  
- Moonblast  
- Earth Power / Hidden Power [Fire]  
- Endeavor  

";
$t13285 = "Diancie @ Diancite  
Ability: Clear Body  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Diamond Storm  
- Moonblast  
- Substitute  
- Endeavor  

";
$t13295 = "Qwilfish @ Life Orb  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Aqua Tail  
- Poison Jab  
- Explosion  
- Swords Dance  

";
$t13305 = "Dragonite @ Groundium Z  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Fire Punch  
- Earthquake  
- Blizzard  
- Dragon Dance  

";
$t13315 = "Breloom @ Fightinium Z  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Focus Punch  
- Mach Punch  
- Bullet Seed  

";
$t13325 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 16 Def / 96 SpA / 36 SpD / 112 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Hydro Pump  
- Flamethrower  
- Chilling Water  

";
$t13336 = "Hitmonchan (M) @ Kee Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Drain Punch  
- Mach Punch  
- Encore  
- Swords Dance  

";
$t13346 = "Hitmonchan (M) @ Leftovers  
Ability: Iron Fist  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Drain Punch  
- Substitute  
- Encore  
- Swords Dance  

";
$t13356 = "Hitmonchan (M) @ Payapa Berry  
Ability: Keen Eye  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Focus Punch  
- Counter  
- Rapid Spin  
- Encore  

";
$t13366 = "Hitmonchan (M) @ Life Orb  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Drain Punch  
- Pursuit  
- Protect  
- Swords Dance  

";
$t13376 = "Hitmonchan (M) @ Coba Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 248 HP / 132 Atk / 120 Def / 8 SpD  
Adamant Nature  
- Drain Punch  
- Pursuit  
- Counter  
- Encore  

";
$t13386 = "Hitmonchan (M) @ Fightinium Z  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Focus Punch  
- Rapid Spin  
- Thunder Punch  
- Substitute  

";
$t13396 = "Conkeldurr @ Choice Band  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Focus Punch  
- Defog  
- Sleep Talk  
- Chip Away  

";
$t13406 = "Crabominable @ Fightinium Z  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Ice Hammer  
- Focus Punch  
- Substitute  
- Protect  

";
$t13416 = "Spectrier @ Leftovers  
Ability: Grim Neigh  
Tera Type: &
EVs: 248 HP / 20 Def / 52 SpA / 92 SpD / 96 Spe  
Timid Nature  
- Hex  
- Body Slam  
- Pain Split  
- Substitute  

";
$t13426 = "Rabsca @ Heavy-Duty Boots  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Expanding Force  
- Sleep Talk  
- Rest  
- Revival Blessing  

";
$t13437 = "Pyroar @ Normalium Z  
Ability: Unnerve  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Fire Blast  
- Hyper Beam  
- Protect  

";
$t13448 = "Pyroar @ Fire Gem  
Ability: Moxie  
Tera Type: &
EVs: 148 Atk / 108 SpA / 252 Spe  
Naive Nature  
- Sunny Day  
- Overheat  
- Double-Edge  
- Tera Blast  

";
$t13458 = "Registeel @ Weakness Policy  
Ability: Clear Body  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 SpA  
Brave Nature  
- Heavy Slam  
- Hidden Power [Fire]  
- Ice Spinner  
- Hyper Beam  

";
$t13468 = "Urshifu @ Petaya Berry  
Ability: Unseen Fist  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Snarl  
- Hidden Power [Fighting]  
- Tera Blast  
- Endure  

";
$t13479 = "Tapu Lele @ Electric Gem  
Ability: Psychic Surge  
Tera Type: &
EVs: 196 HP / 40 Def / 16 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psyshock  
- Draining Kiss  
- Thunder  
- Calm Mind  

";
$t13490 = "Metagross @ Heat Rock  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpA  
Quiet Nature  
IVs: 30 Atk  
- Heavy Slam  
- Icy Wind  
- Hidden Power [Fire]  
- Sunny Day  

";
$t13501 = "Ursaluna @ Electric Gem  
Ability: Guts  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Supercell Slam  
- Double-Edge  
- Power-Up Punch  
- Protect  

";
$t13511 = "Scovillain @ Coba Berry  
Ability: Moody  
Tera Type: &
EVs: 56 HP / 252 SpA / 4 SpD / 196 Spe  
Modest Nature  
IVs: 0 Atk  
- Burning Jealousy  
- Leaf Storm  
- Spicy Extract  
- Protect  

";
$t13522 = "Scovillain @ Safety Goggles  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Burning Jealousy  
- Leech Seed  
- Endeavor  
- Substitute  

";
$t13533 = "Infernape @ Starf Berry  
Ability: Blaze  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Blast Burn  
- Drain Punch  
- Encore  
- Substitute  

";
$t13543 = "Moltres @ Throat Spray  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Fire Blast  
- Hurricane  
- Roar  
- Roost  

";
$t13554 = "Calyrex @ Life Orb  
Ability: Unnerve  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Trick Room  
- Encore  
- Leaf Storm  
- Psychic  

";
$t13565 = "Calyrex @ Aguav Berry  
Ability: Unnerve  
Tera Type: &
EVs: 76 HP / 252 SpA / 180 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Stored Power  
- Leech Seed  
- Substitute  

";
$t13576 = "Calyrex @ Choice Specs  
Ability: Unnerve  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Future Sight  
- Leaf Storm  
- Pollen Puff  
- Trick  

";
$t13587 = "Araquanid @ Custap Berry  
Ability: Water Bubble  
Tera Type: &
EVs: 248 HP / 16 Atk / 244 Def  
Impish Nature  
- Liquidation  
- Iron Defense  
- Rest  
- Endure  

";
$t13597 = "Meowstic (M) @ Throat Spray  
Ability: Prankster  
Tera Type: &
EVs: 32 HP / 252 SpA / 224 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Alluring Voice  
- Reflect  
- Light Screen  

";
$t13608 = "Swampert @ Throat Spray  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Stealth Rock  
- Roar  

";
$t13619 = "Hydreigon @ Chople Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Dark Pulse  
- Focus Blast  
- Scale Shot  
- Nasty Plot  

";
$t13629 = "Uxie @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
- Psychic  
- Heal Bell  
- U-turn  
- Stealth Rock  

";
$t13639 = "Shiinotic @ Covert Cloak  
Ability: Rain Dish  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Spore  
- Rest  
- Hidden Power [Fire]  

";
$t13650 = "Morelull @ Eviolite  
Ability: Illuminate  
Tera Type: &
EVs: 248 HP / 52 Def / 68 SpA / 140 SpD  
Calm Nature  
IVs: 0 Atk  
- Moonblast  
- Leech Seed  
- Spore  
- Substitute  

";
$t13661 = "Shiinotic @ Damp Rock  
Ability: Rain Dish  
Tera Type: &
EVs: 252 HP / 104 Def / 148 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Spore  
- Rain Dance  
- Draining Kiss  
- Charge Beam  

";
$t13672 = "Pecharunt @ Leftovers  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Malignant Chain  
- Hex  
- Recover  
- Mean Look  

";
$t13683 = "Pecharunt @ Aguav Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 40 SpA / 216 SpD  
Calm Nature  
IVs: 0 Atk  
- Malignant Chain  
- Shadow Ball  
- Recover  
- Mean Look  

";
$t13694 = "Iron Valiant @ Choice Scarf  
Ability: Quark Drive  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Calm Mind  
- Close Combat  
- Knock Off  
- Trick  

";
$t13704 = "Zebstrika @ Life Orb  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Supercell Slam  
- High Horsepower  
- Tera Blast  
- Trailblaze  

";
$t13714 = "Jolteon @ Heavy-Duty Boots  
Ability: Volt Absorb  
Tera Type: &
EVs: 112 HP / 252 SpA / 144 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Weather Ball  
- Tera Blast  
- Calm Mind  

";
$t13725 = "Baxcalibur @ Heavy-Duty Boots  
Ability: Thermal Exchange  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Adamant Nature  
- Glaive Rush  
- Icicle Crash  
- Earthquake  
- Ice Shard  

";
$t13735 = "Slither Wing @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 224 HP / 252 Atk / 32 Spe  
Adamant Nature  
- Leech Life  
- Zen Headbutt  
- Flare Blitz  
- Substitute  

";
$t13745 = "Archaludon @ Leftovers  
Ability: Stamina  
Tera Type: &
EVs: 224 HP / 168 Atk / 52 Def / 28 SpD / 36 Spe  
Naughty Nature  
- Dragon Cheer  
- Iron Head  
- Thunder Wave  
- Protect  

";
$t13755 = "Alakazam @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 Def / 252 SpA / 4 SpD  
Timid Nature  
IVs: 0 Atk  
- Barrier  
- Stored Power  
- Disable  
- Recover  

";
$t13766 = "Hatterene (F) @ Rocky Helmet  
Ability: Magic Bounce  
Tera Type: &
EVs: 244 HP / 44 Def / 124 SpA / 96 SpD  
Modest Nature  
- Future Sight  
- Nuzzle  
- Draining Kiss  
- Protect  

";
$t13776 = "Magnezone @ Zoom Lens  
Ability: Analytic  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Zap Cannon  
- Thunder  
- Electroweb  
- Flash Cannon  

";
$t13787 = "Emboar @ Expert Belt  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 128 Def / 124 Spe  
Adamant Nature  
- Flame Charge  
- Flare Blitz  
- Close Combat  
- Head Smash  

";
$t13797 = "Golem @ Weakness Policy  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 8 Def / 248 Spe  
Jolly Nature  
- Rock Tomb  
- Earthquake  
- Fire Punch  
- Protect  

";
$t13807 = "Parasect @ Heavy-Duty Boots  
Ability: Dry Skin  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Seed Bomb  
- X-Scissor  
- Spore  
- Aromatherapy  

";
$t13817 = "Lilligant-Hisui (F) @ Life Orb  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Triple Axel  
- Aromatherapy  
- Protect  

";
$t13827 = "Latias (F) @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 232 Def / 24 Spe  
Timid Nature  
- Calm Mind  
- Agility  
- Stored Power  
- Aura Sphere  

";
$t13837 = "Hawlucha @ Grassy Seed  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 28 SpD / 228 Spe  
Adamant Nature  
- Swords Dance  
- Close Combat  
- Acrobatics  
- Encore  

";
$t13847 = "Primarina @ Grassy Seed  
Ability: Torrent  
Tera Type: &
EVs: 208 HP / 116 Def / 184 Spe  
Bold Nature  
IVs: 0 Atk  
- Draining Kiss  
- Psychic Noise  
- Encore  
- Calm Mind  

";
$t13858 = "Iron Crown @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 80 HP / 4 Def / 172 SpA / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Calm Mind  
- Psychic Noise  
- Tachyon Cutter  
- Focus Blast  

";
$t13869 = "Thwackey @ Eviolite  
Ability: Grassy Surge  
Tera Type: &
EVs: 248 HP / 36 Def / 8 SpD / 216 Spe  
Jolly Nature  
- Trailblaze  
- Substitute  
- Endeavor  
- Leech Seed  

";
$t13879 = "Arbok @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 252 Def  
- Facade  
- Leech Life  
- Ice Fang  
- Glare  

";
$t13888 = "Blissey @ Assault Vest  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
- Body Slam  
- Brick Break  
- Fling  
- Rock Slide  

";
$t13897 = "Smeargle @ Focus Sash  
Ability: Moody  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Fake Out  
- Follow Me  
- Spore  
- Wide Guard  

";
$t13907 = "Muk-Alola @ Leftovers  
Ability: Power of Alchemy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Minimize  
- Substitute  
- Knock Off  
- Drain Punch  

";
$t13917 = "Electrode @ Figy Berry  
Ability: Soundproof  
Tera Type: &
EVs: 252 SpD / 252 Spe  
- Explosion  
- Supercell Slam  
- Foul Play  
- Facade  

";
$t13926 = "Floatzel @ Life Orb  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 252 SpA  
- Bulk Up  
- Focus Blast  
- Low Kick  
- Low Sweep  

";
$t13935 = "Great Tusk @ Electrium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Supercell Slam  
- Protect  
- Stealth Rock  
- Substitute  

";
$t13945 = "Landorus-Therian (M) @ Air Balloon  
Ability: Intimidate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Earth Power  
- Tera Blast  
- Protect  
- Calm Mind  

";
$t13956 = "Slowking-Galar @ Ground Gem  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Sludge Wave  
- Dig  
- Slack Off  
- Chilly Reception  

";
$t13966 = "Umbreon @ Aguav Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Careful Nature  
- Bide  
- Taunt  
- Moonlight  
- Foul Play  

";
$t13976 = "Blastoise @ Blastoisinite  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Relaxed Nature  
- Aura Sphere  
- Protect  
- Bide  
- Aqua Jet  

";
$t13986 = "Finneon @ Salac Berry  
Ability: Storm Drain  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Endure  
- Attract  
- Toxic  
- Scald  

";
$t13997 = "Shedinja @ Bright Powder  
Ability: Wonder Guard  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Screech  
- Fury Cutter  
- Shadow Sneak  
- Phantom Force  

";
$t14007 = "Stunfisk @ Normalium Z  
Ability: Sand Veil  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Camouflage  
- Sandstorm  
- Discharge  
- Pain Split  

";
$t14018 = "Florges @ Psychium Z  
Ability: Flower Veil  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Magic Coat  
- Calm Mind  
- Moonblast  
- Rest  

";
$t14029 = "Golbat @ Eviolite  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Confuse Ray  
- Toxic  
- Roost  
- Venom Drench  

";
$t14040 = "Steelix @ Steelixite  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
IVs: 0 Spe  
- Sandstorm  
- Gyro Ball  
- Curse  
- Rest  

";
$t14051 = "Stoutland @ Fairium Z  
Ability: Intimidate  
Tera Type: &
EVs: 4 HP / 252 Def / 252 Spe  
Jolly Nature  
- Charm  
- Play Rough  
- Rest  
- Sleep Talk  

";
$t14061 = "Accelgor @ Poisonium Z  
Ability: Hydration  
Tera Type: &
EVs: 4 HP / 88 Def / 252 SpA / 164 Spe  
Timid Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Bug Buzz  
- Acid Spray  
- Hidden Power [Electric]  

";
$t14072 = "Accelgor @ Weakness Policy  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 252 SpA / 4 SpD  
Mild Nature  
- Bug Buzz  
- Endure  
- Hidden Power [Ground]  
- Me First  

";
$t14082 = "Sprigatito @ Beast Ball  
Ability: Protean  
Tera Type: &
EVs: 104 Atk / 228 Spe  
Bashful Nature  
- Leech Seed  
- Shadow Claw  
- U-turn  
- Protect  

";
$t14092 = "Kangaskhan (F) @ Choice Band  
Ability: Scrappy  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double-Edge  
- Aerial Ace  
- Fire Punch  
- Hammer Arm  

";
$t14102 = "Clefable @ Scope Lens  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Ice Beam  
- Thunderbolt  
- Soft-Boiled  
- Calm Mind  

";
$t14113 = "Azelf @ Sitrus Berry  
Ability: Levitate  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Hasty Nature  
- Psychic  
- Fire Blast  
- Explosion  
- Calm Mind  

";
$t14123 = "Swampert @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Earthquake  
- Ice Beam  
- Stealth Rock  
- Protect  

";
$t14133 = "Rotom @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 76 HP / 252 SpA / 180 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Shadow Ball  
- Will-O-Wisp  
- Trick  

";
$t14144 = "Venusaur @ Throat Spray  
Ability: Overgrow  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Sludge Bomb  
- Hidden Power [Fire]  
- Roar  
- Synthesis  

";
$t14155 = "Ferrothorn @ Rawst Berry  
Ability: Iron Barbs  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Spikes  
- Knock Off  
- Power Whip  
- Gyro Ball  

";
$t14166 = "Alakazam @ Eject Button  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Grass Knot  
- Gravity  
- Encore  

";
$t14177 = "Deoxys-Defense @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 108 Def / 148 Spe  
Calm Nature  
- Taunt  
- Agility  
- Toxic  
- Recover  

";
$t14187 = "Tsareena (F) @ Weakness Policy  
Ability: Queenly Majesty  
Tera Type: &
EVs: 240 HP / 48 SpD / 220 Spe  
Careful Nature  
- Trop Kick  
- Rapid Spin  
- Aromatherapy  
- Synthesis  

";
$t14197 = "Tsareena (F) @ Life Orb  
Ability: Sweet Veil  
Tera Type: &
EVs: 156 HP / 252 Atk / 100 Spe  
Adamant Nature  
- Power Whip  
- High Jump Kick  
- Aromatherapy  
- Rapid Spin  

";
$t14207 = "Moltres @ Poisonium Z  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 32 SpA / 172 SpD / 56 Spe  
Modest Nature  
IVs: 0 Atk  
- Mystical Fire  
- Toxic  
- Agility  
- Roost  

";
$t14218 = "Pignite @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Drain Punch  
- Temper Flare  
- Will-O-Wisp  
- Protect  

";
$t14228 = "Keldeo @ Roseli Berry  
Ability: Justified  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Scald  
- Upper Hand  
- Hyper Beam  
- Calm Mind  

";
$t14238 = "Munkidori (M) @ Mirror Herb  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Flatter  
- Psychic Noise  
- Calm Mind  
- Fake Out  

";
$t14248 = "Toxicroak @ Mirror Herb  
Ability: Dry Skin  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flatter  
- Focus Blast  
- Sludge Bomb  
- Hidden Power [Ice]  

";
$t14259 = "Cacturne @ Tanga Berry  
Ability: Sand Veil  
Tera Type: &
EVs: 40 HP / 252 Def / 216 Spe  
Impish Nature  
- Spiky Shield  
- Encore  
- Disable  
- Pin Missile  

";
$t14269 = "Cacturne @ Custap Berry  
Ability: Sand Veil  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Knock Off  
- Sandstorm  
- Spikes  
- Encore  

";
$t14279 = "Ogerpon-Cornerstone (F) @ Cornerstone Mask  
Ability: Sturdy  
Tera Type: &
EVs: 24 HP / 140 Atk / 92 SpA / 252 Spe  
Hasty Nature  
- Ivy Cudgel  
- Wood Hammer  
- Spiky Shield  
- Sandstorm  

";
$t14289 = "Ogerpon-Hearthflame (F) @ Hearthflame Mask  
Ability: Mold Breaker  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Modest Nature  
IVs: 0 Atk  
- Tera Blast  
- Solar Beam  
- Sunny Day  
- Growth  

";
$t14300 = "Forretress @ Rocky Helmet  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Poison Jab  
- Body Press  
- Iron Defense  
- Volt Switch  

";
$t14310 = "Marowak @ Thick Club  
Ability: Rock Head  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Bonemerang  
- Earthquake  
- Giga Impact  
- Stone Edge  

";
$t14320 = "bathbwoy (Jellicent) @ Choice Scarf  
Ability: Cursed Body  
Tera Type: &
EVs: 196 HP / 84 Def / 228 Spe  
Timid Nature  
IVs: 0 Atk  
- Water Spout  
- Trick  
- Recover  
- Taunt  

";
$t14331 = "Gastrodon @ Mental Herb  
Ability: Storm Drain  
Tera Type: &
EVs: 252 HP / 172 Def / 84 SpD  
Careful Nature  
- Earthquake  
- Dive  
- Toxic  
- Protect  

";
$t14341 = "ITS SPECS WATCH OUT (Latios) (M) @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Luster Purge  
- Mystical Fire  
- Aura Sphere  

";
$t14352 = "Jirachi @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 40 Def / 108 SpA / 108 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Thunder  
- Ice Punch  
- Calm Mind  

";
$t14363 = "Azelf @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 40 Atk / 220 Def  
Adamant Nature  
- Explosion  
- Thunder Wave  
- Stealth Rock  
- Taunt  

";
$t14373 = "Venusaur @ Leftovers  
Ability: Overgrow  
Tera Type: &
EVs: 248 HP / 90 SpA / 170 Spe  
Timid Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Sludge Bomb  
- Hidden Power [Fire]  
- Sleep Powder  
- Leech Seed  

";
$t14384 = "Clefable @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Grass Knot  
- Fire Blast  
- Soft-Boiled  
- Calm Mind  

";
$t14395 = "Kangaskhan (F) @ Choice Scarf  
Ability: Scrappy  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- Double-Edge  
- Hammer Arm  
- Fire Blast  
- Toxic  

";
$t14405 = "Altaria @ Choice Band  
Ability: Natural Cure  
Tera Type: &
EVs: 248 HP / 208 Atk / 52 SpD  
Lonely Nature  
- Outrage  
- Earthquake  
- Pursuit  
- Fire Blast  

";
$t14415 = "Swampert @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Earthquake  
- Ice Beam  
- Roar  
- Protect  

";
$t14425 = "Azelf @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Rash Nature  
- Psychic  
- U-turn  
- Flamethrower  

";
$t14434 = "Jolteon @ Expert Belt  
Ability: Volt Absorb  
Tera Type: &
EVs: 124 HP / 252 SpA / 132 Spe  
Modest Nature  
IVs: 3 Atk / 30 SpA / 30 SpD  
- Hidden Power [Ground]  
- Thunderbolt  
- Wish  
- Protect  

";
$t14445 = "Dragonite @ Choice Scarf  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 44 SpD / 212 Spe  
Adamant Nature  
- Outrage  
- Earthquake  
- Extreme Speed  
- Roost  

";
$t14455 = "Tentacruel @ Black Sludge  
Ability: Liquid Ooze  
Tera Type: &
EVs: 252 HP / 120 SpA / 136 Spe  
Timid Nature  
- Rapid Spin  
- Protect  
- Knock Off  
- Surf  

";
$t14465 = "Raikou @ Lum Berry  
Ability: Pressure  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
IVs: 2 Atk / 30 Def  
- Calm Mind  
- Thunderbolt  
- Hidden Power [Ice]  
- Substitute  

";
$t14476 = "Hippowdon @ Leftovers  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Earthquake  
- Slack Off  
- Ice Fang  
- Roar  

";
$t14486 = "Weezing @ Payapa Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 28 Atk / 136 Def / 92 SpD  
Relaxed Nature  
- Explosion  
- Protect  
- Will-O-Wisp  
- Pain Split  

";
$t14496 = "Spiritomb @ Darkinium Z  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Pursuit  
- Will-O-Wisp  
- Pain Split  
- Memento  

";
$t14506 = "Clefable @ Leftovers  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Wish  
- Stealth Rock  
- Protect  
- Thunder Wave  

";
$t14517 = "Froslass (F) @ Choice Specs  
Ability: Snow Cloak  
Tera Type: &
EVs: 248 HP / 84 Def / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Spikes  
- Trick  
- Ice Beam  
- Taunt  

";
$t14528 = "Swampert @ Rindo Berry  
Ability: Torrent  
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe  
Hasty Nature  
- Hydro Pump  
- Earthquake  
- Endeavor  
- Stealth Rock  

";
$t14538 = "Dragonite @ Zoom Lens  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 108 Atk / 148 SpA  
Brave Nature  
- Extreme Speed  
- Draco Meteor  
- Focus Blast  
- Thunder  



";
$t14550 = "Revavroom @ Leftovers  
Ability: Filter  
Tera Type: &
EVs: 140 HP / 252 Atk / 116 Spe  
Adamant Nature  
- Poison Jab  
- Temper Flare  
- Magnet Rise  
- Shift Gear  

";
$t14560 = "Scizor @ Covert Cloak  
Ability: Technician  
Tera Type: &
EVs: 44 HP / 252 Atk / 212 Spe  
Adamant Nature  
- U-turn  
- Swords Dance  
- Knock Off  
- Bullet Punch  

";
$t14570 = "Cinccino @ Power Herb  
Ability: Skill Link  
Tera Type: &
EVs: 252 Atk / 48 SpD / 208 Spe  
Jolly Nature  
- Triple Axel  
- U-turn  
- Tail Slap  
- Dig  

";
$t14580 = "Clefable @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 228 HP / 252 SpA / 28 SpD  
Modest Nature  
IVs: 0 Atk  
- Ice Beam  
- Moonlight  
- Focus Blast  
- Healing Wish  

";
$t14591 = "Mamoswine @ Assault Vest  
Ability: Thick Fat  
Tera Type: &
EVs: 208 HP / 220 Atk / 80 Spe  
Jolly Nature  
- Ice Shard  
- Earthquake  
- Facade  
- Icicle Crash  

";
$t14601 = "Dondozo @ Rocky Helmet  
Ability: Unaware  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Yawn  
- Liquidation  
- Sleep Talk  
- Rest  

";
$t14611 = "Iron Valiant @ Air Balloon  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Moonblast  
- Shadow Ball  

";
$t14622 = "Morgrem (M) @ Light Clay  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Reflect  
- Light Screen  
- Parting Shot  
- Fake Out  

";
$t14632 = "Honchkrow @ Mirror Herb  
Ability: Super Luck  
Tera Type: &
EVs: 80 HP / 136 Def / 140 SpA / 152 Spe  
Modest Nature  
IVs: 0 Atk  
- Dark Pulse  
- Heat Wave  
- Roost  
- Flatter  

";
$t14643 = "Terapagos @ Leftovers  
Ability: Tera Shift  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Stored Power  
- Rock Polish  
- Calm Mind  

";
$t14654 = "Terapagos @ Covert Cloak  
Ability: Tera Shift  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Stored Power  
- Rock Polish  
- Calm Mind  

";
$t14665 = "Terapagos @ Starf Berry  
Ability: Tera Shift  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Sleep Talk  
- Rest  
- Substitute  

";
$t14676 = "Terapagos @ Leftovers  
Ability: Tera Shift  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Sleep Talk  
- Rest  
- Rock Polish  

";
$t14687 = "Mew @ Electric Gem  
Ability: Synchronize  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Soft-Boiled  
- Electro Ball  
- Encore  
- Rock Polish  

";
$t14698 = "Calyrex @ Heavy-Duty Boots  
Ability: Unnerve  
Tera Type: &
EVs: 192 HP / 252 Def / 64 Spe  
Bold Nature  
IVs: 0 Atk  
- Body Press  
- Protect  
- Aromatherapy  
- Leech Seed  

";
$t14709 = "Mew @ Electric Gem  
Ability: Synchronize  
Tera Type: &
EVs: 48 Def / 252 SpA / 208 Spe  
Modest Nature  
IVs: 0 Atk  
- Soft-Boiled  
- Electro Ball  
- Charge  
- Rock Polish  

";
$t14720 = "Manaphy @ Life Orb  
Ability: Hydration  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Hyper Beam  
- Heal Bell  
- Take Heart  

";
$t14731 = "Raging Bolt @ Throat Spray  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 20 Atk  
- Thunder  
- Thunderclap  
- Dragon Pulse  
- Roar  

";
$t14742 = "Meloetta @ Heavy-Duty Boots  
Ability: Serene Grace  
Tera Type: &
EVs: 168 HP / 4 Def / 84 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Focus Blast  
- Heal Bell  
- Calm Mind  

";
$t14753 = "Clodsire @ Mail  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 132 Def / 128 SpD  
Careful Nature  
- Poison Sting  
- Dig  
- Recover  
- Curse  

";
$t14763 = "Serperior @ Eject Pack  
Ability: Contrary  
Tera Type: &
EVs: 136 HP / 116 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Leaf Storm  
- Protect  
- Aromatherapy  
- Calm Mind  

";
$t14774 = "Enamorus (F) @ Eject Pack  
Ability: Contrary  
Tera Type: &
EVs: 100 HP / 16 Atk / 8 Def / 136 SpA / 4 SpD / 244 Spe  
Naive Nature  
- Moonblast  
- Superpower  
- Torment  
- Calm Mind  

";
$t14784 = "Serperior @ Eject Pack  
Ability: Contrary  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
- Leaf Storm  
- Knock Off  
- Defog  
- Calm Mind  

";
$t14794 = "Serperior @ Eject Pack  
Ability: Contrary  
Tera Type: &
EVs: 248 HP / 88 Def / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Leaf Storm  
- Glare  
- Synthesis  
- Calm Mind  



";
$t14807 = "Walking Wake @ Custap Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 196 HP / 252 SpA / 60 Spe  
Modest Nature  
IVs: 0 Atk  
- Hydro Steam  
- Sunny Day  
- Rain Dance  
- Substitute  

";
$t14818 = "Slowking-Galar @ Kings Rock  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Hyper Beam  
- Muddy Water  
- Substitute  
- Trick Room  

";
$t14829 = "Slowking-Galar @ Shell Bell  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Sludge Wave  
- Calm Mind  
- Muddy Water  
- Substitute  

";
$t14840 = "Sylveon @ Shell Bell  
Ability: Pixilate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Hidden Power [Fire]  
- Substitute  
- Calm Mind  

";
$t14851 = "Indeedee @ Terrain Extender  
Ability: Psychic Surge  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Expanding Force  
- Dazzling Gleam  
- Encore  
- Healing Wish  

";
$t14862 = "Snorunt @ Salac Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Spikes  
- Ice Beam  
- Hidden Power [Grass]  
- Endure  

";
$t14872 = "Aipom @ Choice Band  
Ability: Run Away  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double-Edge  
- Brick Break  
- Shadow Ball  
- Baton Pass  

";
$t14882 = "Chinchou @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Thunderbolt  
- Surf  

";
$t14893 = "Castform @ Leftovers  
Ability: Forecast  
Tera Type: &
EVs: 248 HP / 112 Atk / 120 SpD / 28 Spe  
Brave Nature  
- Protect  
- Double-Edge  
- Ice Beam  
- Thunderbolt  

";
$t14903 = "Shuppet @ Leftovers  
Ability: Insomnia  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Shadow Ball  
- Hidden Power [Fighting]  
- Substitute  
- Thunder Wave  

";
$t14913 = "Spoink @ Leftovers  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 2 Atk / 30 SpA  
- Calm Mind  
- Psychic  
- Hidden Power [Grass]  
- Substitute  

";
$t14924 = "Darkrai @ Leftovers  
Ability: Bad Dreams  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Dark Pulse  
- Hex  
- Focus Punch  
- Substitute  

";
$t14934 = "Meloetta @ Metronome  
Ability: Serene Grace  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Relic Song  
- Shadow Ball  
- Rest  
- Sleep Talk  

";
$t14945 = "Amoonguss @ Rocky Helmet  
Ability: Effect Spore  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Clear Smog  
- Hex  
- Synthesis  
- Endure  

";
$t14956 = "Vileplume @ Mental Herb  
Ability: Effect Spore  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Leech Seed  
- Strength Sap  
- Moonlight  
- Endure  

";
$t14967 = "Hawlucha @ Lum Berry  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Fling  
- Encore  
- Defog  
- Roost  

";
$t14977 = "Blissey @ Choice Specs  
Ability: Serene Grace  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Shadow Ball  
- Trick  
- Calm Mind  
- Healing Wish  

";
$t14988 = "Crocalor @ Eviolite  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Fire Spin  
- Slack Off  
- Will-O-Wisp  
- Roar  

";
$t14999 = "Sinistea @ Focus Sash  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Shell Smash  
- Shadow Ball  
- Stored Power  
- Tera Blast  

";
$t15010 = "Shiftry @ Focus Sash  
Ability: Wind Rider  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Tailwind  
- Explosion  
- X-Scissor  
- Leaf Blade  

";
$t15020 = "Clawitzer @ Choice Scarf  
Ability: Mega Launcher  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Water Pulse  
- Dragon Pulse  
- Aura Sphere  
- U-turn  

";
$t15030 = "Glimmet @ Focus Sash  
Ability: Toxic Debris  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Stealth Rock  
- Spikes  
- Power Gem  
- Sludge Bomb  

";
$t15041 = "Rabsca @ Focus Sash  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Earth Power  
- Revival Blessing  
- Dazzling Gleam  

";
$t15052 = "Hitmonchan (M) @ Life Orb  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Bullet Punch  
- Drain Punch  
- Thunder Punch  
- Rapid Spin  



";
$t15064 = "Weavile @ Dark Gem  
Ability: Pickpocket  
Tera Type: &
EVs: 200 Atk / 116 Def / 192 Spe  
Adamant Nature  
- Fake Out  
- Icicle Crash  
- Throat Chop  
- Substitute  

";
$t15074 = "Ninetales-Alola @ Fairy Feather  
Ability: Snow Warning  
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe  
Modest Nature  
IVs: 0 Atk  
- Protect  
- Hidden Power [Ground]  
- Blizzard  
- Moonblast  

";
$t15085 = "Blaziken @ Blazikenite  
Ability: Speed Boost  
Tera Type: &
EVs: 244 Atk / 32 Def / 232 Spe  
Adamant Nature  
- Bulk Up  
- Thunder Punch  
- Flare Blitz  
- High Jump Kick  

";
$t15095 = "Latios @ Latiosite  
Ability: Levitate  
Shiny: Yes  
Tera Type: &
EVs: 152 HP / 104 Atk / 252 Spe  
Jolly Nature  
- Outrage  
- Zen Headbutt  
- Dragon Dance  
- Roost  

";
$t15106 = "Ninetales @ Fire Gem  
Ability: Drought  
Shiny: Yes  
Tera Type: &
EVs: 152 Atk / 140 SpA / 216 Spe  
Hasty Nature  
- Flare Blitz  
- Laser Focus  
- Overheat  
- Substitute  

";
$t15117 = "Arcanine @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 216 HP / 96 Atk / 196 SpD  
Adamant Nature  
- Flare Blitz  
- Bulldoze  
- Outrage  
- Substitute  

";
$t15127 = "Tapu Fini @ Leftovers  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Whirlpool  
- Moonblast  
- Natures Madness  
- Taunt  

";
$t15138 = "Camerupt @ Cameruptite  
Ability: Solid Rock  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Protect  
- Eruption  
- Earth Power  
- Heat Wave  

";
$t15150 = "Machoke @ Eviolite  
Ability: No Guard  
Tera Type: &
EVs: 248 HP / 216 SpD / 44 Spe  
Careful Nature  
- Dynamic Punch  
- Knock Off  
- Rest  
- Sleep Talk  

";
$t15160 = "Silvally-Dark @ Dark Memory  
Ability: RKS System  
Tera Type: &
EVs: 248 HP / 180 Def / 80 Spe  
Bold Nature  
- U-turn  
- Toxic  
- Flamethrower  
- Defog  

";
$t15170 = "Gourgeist-Super @ Colbur Berry  
Ability: Frisk  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Synthesis  
- Will-O-Wisp  
- Foul Play  
- Leech Seed  

";
$t15181 = "Lapras @ Leftovers  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Surf  
- Frost Breath  
- Heal Bell  

";
$t15192 = "Trapinch @ Eviolite  
Ability: Arena Trap  
Tera Type: &
EVs: 160 HP / 92 Atk / 252 Def / 4 Spe  
Brave Nature  
- Earthquake  
- First Impression  
- Earth Power  
- Rest  

";
$t15202 = "Mawile @ Rocky Helmet  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Play Rough  
- Stealth Rock  
- Magnet Rise  
- Rest  

";
$t15212 = "Wigglytuff @ Chesto Berry  
Ability: Cute Charm  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Spe  
- Perish Song  
- Protect  
- Rest  
- Thunder Wave  

";
$t15223 = "Pikachu-World @ Eviolite  
Ability: Static  
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD  
Calm Nature  
- Agility  
- Encore  
- Nuzzle  
- Fake Out  

";
$t15233 = "Yanmega @ Life Orb  
Ability: Speed Boost  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Rash Nature  
- Psychic Noise  
- Lunge  
- Air Slash  
- Protect  

";
$t15243 = "Barraskewda @ Silk Scarf  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Rest  
- Sleep Talk  
- Thrash  
- Protect  

";
$t15253 = "Silvally-Dragon @ Dragon Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Draco Meteor  
- Flamethrower  
- Defog  
- U-turn  

";
$t15263 = "Iron Treads @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Protect  
- Hard Press  
- Ice Fang  
- Body Slam  

";
$t15273 = "Mew @ Mental Herb  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Sassy Nature  
IVs: 0 Atk / 0 Spe  
- Trick Room  
- Transform  
- Taunt  
- Encore  

";
$t15284 = "Camerupt @ Cameruptite  
Ability: Solid Rock  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Protect  
- Eruption  
- Earth Power  
- Heat Wave  

";
$t15296 = "Exeggutor @ Scope Lens  
Ability: No Ability  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 26 Atk / 26 Def  
- Leech Seed  
- Psychic  
- Hidden Power [Bug]  
- Synthesis  

";
$t15307 = "Porygon-Z @ Petaya Berry  
Ability: Illuminate  
Tera Type: &
EVs: 232 HP / 252 SpA / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Ice Beam  
- Thunderbolt  
- Agility  
- Recover  

";
$t15318 = "Typhlosion @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 12 HP / 244 SpA / 252 Spe  
Hasty Nature  
- Substitute  
- Blast Burn  
- Flamethrower  
- Focus Punch  

";
$t15328 = "Hakamo-o @ Eviolite  
Ability: Soundproof  
Tera Type: &
EVs: 248 HP / 76 Atk / 184 Spe  
Adamant Nature  
- Dragon Dance  
- Drain Punch  
- Dragon Claw  
- Substitute  

";
$t15338 = "Great Tusk @ Roseli Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 124 Atk / 128 Def / 8 Spe  
Impish Nature  
- Stealth Rock  
- Ice Spinner  
- Earthquake  
- Rapid Spin  

";
$t15348 = "Xi JinPing (Alakazam) @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Expanding Force  
- Dazzling Gleam  
- Charge Beam  
- Protect  

";
$t15359 = "Indeedee (M) @ Terrain Extender  
Ability: Psychic Surge  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Expanding Force  
- Dazzling Gleam  
- Healing Wish  
- Mystical Fire  

";
$t15370 = "Wigglytuff @ Chesto Berry  
Ability: Cute Charm  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Spe  
- Perish Song  
- Protect  
- Rest  
- Thunder Wave  

";
$t15381 = "Pikachu-World @ Eviolite  
Ability: Static  
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD  
Calm Nature  
- Agility  
- Encore  
- Nuzzle  
- Fake Out  

";
$t15391 = "Yanmega @ Life Orb  
Ability: Speed Boost  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Rash Nature  
- Psychic Noise  
- Lunge  
- Air Slash  
- Protect  

";
$t15401 = "Barraskewda @ Silk Scarf  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Rest  
- Sleep Talk  
- Thrash  
- Protect  

";
$t15411 = "Iron Treads @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Protect  
- Hard Press  
- Ice Fang  
- Body Slam  

";
$t15421 = "Flutter Mane @ Leftovers  
Ability: Protosynthesis  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Thunderbolt  
- Taunt  
- Magical Leaf  

";
$t15432 = "Kingdra @ Lansat Berry  
Ability: Sniper  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Substitute  
- Outrage  
- Waterfall  
- Dragon Dance  

";
$t15442 = "Garchomp @ Garchompite  
Ability: Rough Skin  
Tera Type: &
EVs: 252 HP / 176 Def / 76 SpD / 4 Spe  
Impish Nature  
- Rock Tomb  
- Outrage  
- Earthquake  
- Surf  

";
$t15452 = "Kommo-o @ Haban Berry  
Ability: Overcoat  
Tera Type: &
EVs: 160 HP / 192 Atk / 84 Def / 72 Spe  
Impish Nature  
- Dragon Dance  
- Outrage  
- Close Combat  
- Counter  

";
$t15462 = "Health Hazard (Revavroom) @ Life Orb  
Ability: Filter  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Shift Gear  
- Spin Out  
- Poison Jab  
- Giga Impact  

";
$t15472 = "Salt and Pepper (Scovillain) @ Custap Berry  
Ability: Insomnia  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spicy Extract  
- Endure  
- Overheat  
- Leaf Storm  

";
$t15483 = "Primeape @ Eviolite  
Ability: Anger Point  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Bulk Up  
- Spite  
- Rest  
- Drain Punch  

";
$t15493 = "Slowking @ Leftovers  
Ability: Oblivious  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Swagger  
- Foul Play  
- Calm Mind  
- Slack Off  

";
$t15505 = "Klefki @ Choice Scarf  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Switcheroo  
- Torment  
- Protect  
- Draining Kiss  

";
$t15516 = "Klawf @ Sitrus Berry  
Ability: Anger Shell  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Bulldoze  
- Crabhammer  
- Rock Slide  
- Knock Off  

";
$t15526 = "Klawf @ Sitrus Berry  
Ability: Anger Shell  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Impish Nature  
- Iron Defense  
- Metal Claw  
- Rest  
- Rock Smash  

";
$t15536 = "Polteageist @ Salac Berry  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Endure  
- Shell Smash  
- Shadow Ball  
- Psychic  

";
$t15547 = "Ting-Lu @ Shell Bell  
Ability: Vessel of Ruin  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Earthquake  
- Heavy Slam  
- Body Press  
- Payback  

";
$t15557 = "Ting-Lu @ Weakness Policy  
Ability: Vessel of Ruin  
Tera Type: &
EVs: 84 HP / 172 Atk / 252 SpD  
Adamant Nature  
- Rock Slide  
- Bulldoze  
- Earthquake  
- Payback  

";
$t15567 = "Squawkabilly-Yellow @ Kee Berry  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Parting Shot  
- Roost  
- Fake Tears  
- Air Slash  

";
$t15578 = "Greedent @ Sitrus Berry  
Ability: Cheek Pouch  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Belly Drum  
- Giga Impact  
- Seed Bomb  
- Earthquake  

";
$t15588 = "Bombirdier @ Leftovers  
Ability: Big Pecks  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Parting Shot  
- Roost  
- Leer  
- Rock Blast  

";
$t15598 = "Kilowattrel @ Leftovers  
Ability: Competitive  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Feather Dance  
- Stockpile  
- Roost  
- Air Slash  

";
$t15609 = "Scovillain @ Life Orb  
Ability: Insomnia  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Leaf Storm  
- Overheat  
- Trailblaze  
- Crunch  

";
$t15619 = "Murkrow @ Eviolite  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 208 Def / 48 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Perish Song  
- Feather Dance  
- Roost  
- Taunt  

";
$t15630 = "Sylveon @ Life Orb  
Ability: Pixilate  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Draining Kiss  
- Hyper Beam  
- Hyper Voice  

";
$t15641 = "Crustle @ Weakness Policy  
Ability: Sturdy  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Shell Smash  
- Stone Edge  
- Earthquake  
- Aerial Ace  

";
$t15651 = "Doublade @ Eviolite  
Ability: No Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
- Protect  
- Reflect  
- Toxic  
- Rest  

";
$t15661 = "Swellow @ Toxic Orb  
Ability: Guts  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Brave Bird  
- Facade  
- Protect  
- Quick Attack  

";
$t15671 = "Kyurem-Black @ Haban Berry  
Ability: Teravolt  
Tera Type: &
EVs: 192 Atk / 64 SpA / 252 Spe  
Hasty Nature  
- Outrage  
- Fusion Bolt  
- Substitute  
- Earth Power  

";
$t15681 = "Wyrdeer @ Choice Specs  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Hyper Beam  
- Psychic Noise  
- Trick  
- Disable  

";
$t15692 = "Roaring Moon @ Chople Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 92 HP / 252 Def / 4 SpD / 160 Spe  
Jolly Nature  
- Knock Off  
- Dragon Dance  
- Outrage  
- Acrobatics  

";
$t15702 = "Keldeo @ Weakness Policy  
Ability: Justified  
Tera Type: &
EVs: 8 HP / 28 SpA / 240 SpD / 232 Spe  
Modest Nature  
IVs: 0 Atk  
- Secret Sword  
- Hydro Pump  
- Reflect  
- Calm Mind  

";
$t15713 = "Porygon-Z @ Clear Amulet  
Ability: Adaptability  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Eerie Impulse  
- Recover  
- Hyper Beam  
- Dark Pulse  

";
$t15724 = "Wigglytuff @ Leftovers  
Ability: Competitive  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Fake Tears  
- Stockpile  
- Spit Up  
- Draining Kiss  

";
$t15735 = "Entei @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 56 HP / 200 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Protect  
- Eruption  

";
$t15746 = "Dragonite @ Heavy-Duty Boots  
Ability: Inner Focus  
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe  
Adamant Nature  
- Dragon Claw  
- Earthquake  
- Thunder Punch  
- Dragon Dance  

";
$t15756 = "Urshifu-Rapid-Strike @ Punching Glove  
Ability: Unseen Fist  
Tera Type: &
EVs: 56 HP / 252 Atk / 200 Spe  
Jolly Nature  
- Surging Strikes  
- Ice Punch  
- Thunder Punch  
- Swords Dance  

";
$t15766 = "Forretress @ Red Card  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Gyro Ball  
- Rapid Spin  
- Thunder Wave  
- Pain Split  

";
$t15777 = "Darkrai @ Life Orb  
Ability: Bad Dreams  
Tera Type: &
EVs: 48 HP / 252 SpA / 208 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Sludge Bomb  
- Focus Blast  
- Hypnosis  

";
$t15788 = "Alomomola @ Leftovers  
Ability: Hydration  
Shiny: Yes  
Tera Type: &
EVs: 252 Def / 4 SpA / 252 SpD  
Bold Nature  
IVs: 0 Atk  
- Soak  
- Wish  
- Calm Mind  
- Shadow Ball  

";
$t15800 = "Chi-Yu @ Weakness Policy  
Ability: Beads of Ruin  
Tera Type: &
EVs: 248 HP / 112 SpA / 148 SpD  
Modest Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Snarl  
- Overheat  
- Dark Pulse  

";
$t15811 = "Appletun @ Sitrus Berry  
Ability: Ripen  
Tera Type: &
EVs: 4 HP / 252 Def / 252 SpD  
Serious Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Recycle  
- Apple Acid  

";
$t15822 = "Ampharos @ Leftovers  
Ability: Static  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Cotton Guard  
- Eerie Impulse  
- Rest  
- Charge Beam  

";
$t15834 = "Bellibolt @ Custap Berry  
Ability: Electromorphosis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Soak  
- Endure  
- Thunderbolt  
- Acid Spray  

";
$t15845 = "Pawmot @ Salac Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Bulk Up  
- Wish  
- Double Shock  
- Charge  

";
$t15855 = "Pawmot @ Liechi Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Fake Out  
- Double Shock  
- Bulk Up  

";
$t15865 = "Cacturne @ Rocky Helmet  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA  
Brave Nature  
- Leaf Storm  
- Dark Pulse  
- Sucker Punch  
- Seed Bomb  

";
$t15875 = "Armarouge @ Weakness Policy  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Endure  
- Armor Cannon  
- Aura Sphere  
- Psychic  

";
$t15886 = "Baxcalibur @ Custap Berry  
Ability: Thermal Exchange  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Glaive Rush  
- Endure  
- Earthquake  
- Icicle Spear  

";
$t15897 = "Gholdengo @ Choice Scarf  
Ability: Good as Gold  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Trick  
- Recover  
- Night Shade  
- Thunder Wave  

";
$t15908 = "Glimmora @ Assault Vest  
Ability: Toxic Debris  
Tera Type: &
EVs: 252 HP / 48 SpA / 208 SpD  
Modest Nature  
IVs: 0 Atk  
- Power Gem  
- Earth Power  
- Sludge Bomb  
- Acid Spray  

";
$t15919 = "Eiscue @ Rocky Helmet  
Ability: Ice Face  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Snowscape  
- Rain Dance  
- Protect  
- Ice Spinner  

";
$t15929 = "Revavroom @ Leftovers  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Parting Shot  
- Toxic  
- Rest  
- Taunt  

";
$t15940 = "Jirachi @ Weakness Policy  
Ability: Serene Grace  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Follow Me  
- Last Resort  

";
$t15948 = "Pecharunt @ Maranga Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 Atk / 252 SpD / 4 Spe  
Adamant Nature  
- Curse  
- Recover  
- Gunk Shot  
- Phantom Force  

";
$t15958 = "Pecharunt @ Choice Band  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Gunk Shot  
- Phantom Force  
- Tera Blast  
- Poltergeist  

";
$t15968 = "Pecharunt @ Assault Vest  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 Atk / 252 SpD / 4 Spe  
Adamant Nature  
- Gunk Shot  
- Foul Play  
- Tera Blast  
- Night Shade  

";
$t15978 = "Pecharunt @ Choice Scarf  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 4 Def / 252 SpD / 252 Spe  
Jolly Nature  
- Destiny Bond  
- Phantom Force  
- Foul Play  
- Parting Shot  

";
$t15988 = "Pecharunt @ Salac Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Substitute  
- Malignant Chain  
- Shadow Ball  

";
$t15999 = "Pecharunt @ Red Card  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Shadow Ball  
- Malignant Chain  
- Tera Blast  

";
$t16010 = "Pecharunt @ Starf Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Calm Nature  
IVs: 0 Atk  
- Recover  
- Night Shade  
- Mean Look  
- Poison Gas  

";
$t16021 = "Pecharunt @ Poison Barb  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Acid Spray  
- Malignant Chain  
- Recover  
- Tera Blast  

";
$t16032 = "Pecharunt @ Eject Pack  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Curse  
- Gunk Shot  
- Tera Blast  
- Rest  

";
$t16043 = "Pecharunt @ Bright Powder  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Poison Gas  
- Substitute  
- Recover  
- Phantom Force  

";
$t16053 = "Pecharunt @ Focus Sash  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 248 HP / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Memento  
- Mean Look  
- Fake Tears  
- Spite  

";
$t16064 = "Pecharunt @ Eject Button  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 248 HP / 60 Def / 200 SpD  
Calm Nature  
IVs: 0 Atk  
- Recover  
- Nasty Plot  
- Malignant Chain  
- Tera Blast  

";
$t16075 = "Pecharunt @ Liechi Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Substitute  
- Gunk Shot  
- Phantom Force  
- Tera Blast  

";
$t16085 = "Pecharunt @ Rocky Helmet  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Withdraw  
- Poison Gas  
- Rest  
- Venoshock  

";
$t16096 = "Pecharunt @ Iapapa Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Acid Spray  
- Sludge Bomb  
- Shadow Ball  
- Parting Shot  

";
$t16107 = "Pecharunt @ Sticky Barb  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 4 SpA / 252 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Imprison  
- Recover  
- Protect  
- Rest  

";
$t16118 = "Pecharunt @ Heavy-Duty Boots  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 4 SpA / 252 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Parting Shot  
- Recover  
- Destiny Bond  
- Night Shade  

";
$t16129 = "Pecharunt @ Air Balloon  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 100 HP / 156 Atk / 252 SpD  
Careful Nature  
- Defense Curl  
- Rollout  
- Rest  
- Tera Blast  

";
$t16139 = "Pecharunt @ Kings Rock  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Poison Gas  
- Venoshock  

";
$t16150 = "Pecharunt @ Quick Claw  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Nasty Plot  
- Tera Blast  
- Recover  
- Curse  

";
$t16161 = "Pecharunt @ Zoom Lens  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Smog  
- Recover  
- Hex  
- Fake Tears  

";
$t16172 = "Pecharunt @ Weakness Policy  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Endure  
- Recover  
- Malignant Chain  
- Hex  

";
$t16183 = "Pecharunt @ Lum Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Rest  
- Curse  
- Phantom Force  
- Rollout  



";
$t16195 = "Espathra @ Choice Scarf  
Ability: Speed Boost  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Calm Nature  
- Lumina Crash  
- Trick  
- Roost  
- Calm Mind

";
$t16205 = "Dudunsparce @ Life Orb  
Ability: Rattled  
Tera Type: &
EVs: 248 HP / 44 Def / 144 SpA / 72 SpD  
Modest Nature  
- Boomburst  
- Calm Mind  
- Roost  
- Toxic

";
$t16215 = "Torterra @ Sitrus Berry  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Iron Defense  
- Body Press  
- Synthesis  
- Rest

";
$t16226 = "Hydrapple @ Yache Berry  
Ability: Supersweet Syrup  
Tera Type: &
EVs: 248 HP / 48 SpA / 116 SpD / 96 Spe  
Modest Nature  
- Draco Meteor  
- Leaf Storm  
- Syrup Bomb  
- Protect

";
$t16236 = "Klefki @ Choice Scarf  
Ability: Prankster  
Tera Type: &
EVs: 200 HP / 188 Def / 120 Spe  
Bold Nature  
- Dazzling Gleam  
- Flash Cannon  
- Switcheroo  
- Rest

";
$t16245 = "Azumarill @ Wacan Berry  
Ability: Huge Power  
Tera Type: &
EVs: 240 HP / 236 Atk / 16 Def / 16 Spe  
Adamant Nature  
- Belly Drum  
- Aqua Jet  
- Play Rough  
- Superpower

";
$t16254 = "Cradily @ Mental Herb  
Ability: Storm Drain  
Tera Type: &
EVs: 224 HP / 36 Atk / 248 SpD  
Careful Nature  
- Swords Dance  
- Power Whip  
- Rock Blast  
- Recover

";
$t16263 = "Latias @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 64 HP / 168 SpA / 84 SpD / 192 Spe  
Timid Nature  
- Draco Meteor  
- Psyshock  
- Ice Beam  
- Mystical Fire

";
$t16272 = "Meowscarada @ Liechi Berry  
Ability: Overgrow  
Tera Type: &
EVs: 12 HP / 244 Atk / 252 Spe  
Jolly Nature  
- Leech Seed  
- Protect  
- Substitute  
- Flower Trick

";
$t16282 = "Iron Bundle @ Life Orb  
Ability: Quark Drive  
Tera Type: &
EVs: 88 HP / 252 SpA / 168 Spe  
Timid Nature  
- Hydro Pump  
- Freeze-Dry  
- Encore  
- Rain Dance

";
$t16292 = "Arcanine-Hisui @ Weakness Policy  
Ability: Intimidate  
Tera Type: &
EVs: 16 HP / 160 Atk / 168 SpD / 164 Spe  
Adamant Nature  
- Head Smash  
- Raging Fury  
- Rock Blast  
- Will-O-Wisp

";
$t16302 = "Sneasler @ Black Sludge  
Ability: Pressure  
Tera Type: &
EVs: 148 HP / 76 Atk / 108 Def / 176 Spe  
Jolly Nature  
- Protect  
- Substitute  
- Gunk Shot  
- Toxic

";
$t16312 = "Corviknight @ Weakness Policy  
Ability: Mirror Armor  
Tera Type: &
EVs: 200 HP / 152 Atk / 132 Def / 24 Spe  
Impish Nature  
- Brave Bird  
- Agility  
- Iron Head  
- Bulk Up

";
$t16322 = "Goodra-Hisui @ Chople Berry  
Ability: Shell Armor  
Tera Type: &
EVs: 248 HP / 160 Atk / 100 Def  
Adamant Nature  
- Rest  
- Tearful Look  
- Counter  
- Heavy Slam

";
$t16332 = "Munkidori (M) @ Expert Belt  
Ability: Toxic Chain  
Tera Type: &
EVs: 16 HP / 168 Def / 112 SpA / 212 Spe  
Modest Nature  
IVs: 0 Atk  
- Sludge Wave  
- Psychic  
- Calm Mind  
- Clear Smog

";
$t16343 = "Empoleon @ Weakness Policy  
Ability: Competitive  
Tera Type: &
EVs: 248 HP / 12 Def / 148 SpA / 100 SpD  
Modest Nature  
- Ice Beam  
- Flash Cannon  
- Hydro Pump  
- Haze

";
$t16353 = "Iron Hands @ Lum Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 SpD  
Adamant Nature  
- Fake Out  
- Swords Dance  
- Wild Charge  
- Close Combat

";
$t16363 = "Lilligant-Hisui @ Life Orb  
Ability: Hustle  
Tera Type: &
EVs: 16 HP / 244 Atk / 16 SpD / 232 Spe  
Jolly Nature  
- Victory Dance  
- Close Combat  
- Leaf Blade  
- Ice Spinner

";
$t16373 = "Iron Jugulis @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Hurricane  
- Dark Pulse  
- Knock Off  
- Taunt

";
$t16383 = "Kommo-o @ Weakness Policy  
Ability: Soundproof  
Tera Type: &
EVs: 240 HP / 16 Atk / 248 Def / 4 Spe  
Impish Nature  
- Dragon Dance  
- Counter  
- Close Combat  
- Outrage

";
$t16393 = "Sandy Shocks @ Booster Energy  
Ability: Protosynthesis  
Shiny: Yes  
Tera Type: &
EVs: 48 HP / 208 SpA / 252 Spe  
Timid Nature  
- Charge  
- Thunderbolt  
- Earth Power  
- Substitute

";
$t16404 = "Grafaiai @ Life Orb  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 4 Atk / 156 Def / 100 SpD  
Careful Nature  
- Gunk Shot  
- Knock Off  
- Encore  
- Copycat

";
$t16414 = "Roaring Moon @ Roseli Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 216 HP / 48 Atk / 244 SpD  
Adamant Nature  
- Dragon Dance  
- Knock Off  
- Iron Head  
- Substitute

";
$t16424 = "Okidogi (M) @ Expert Belt  
Ability: Toxic Chain  
Tera Type: &
EVs: 248 HP / 120 Atk / 32 Def / 12 SpD / 96 Spe  
Adamant Nature  
- Bulk Up  
- Gunk Shot  
- Low Kick  
- High Horsepower

";
$t16434 = "Okidogi (M) @ Black Sludge  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 HP / 100 Atk / 24 Def / 36 SpD / 96 Spe  
Adamant Nature  
- Bulk Up  
- Close Combat  
- Gunk Shot  
- Knock Off

";
$t16444 = "Tinkaton (F) @ Life Orb  
Ability: Mold Breaker  
Tera Type: &
EVs: 248 HP / 24 Atk / 120 Def / 116 SpD  
Impish Nature  
- Gigaton Hammer  
- Ice Hammer  
- Encore  
- Swords Dance

";
$t16454 = "Manaphy @ Rocky Helmet  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
- Acid Armor  
- Take Heart  
- Stored Power  
- Icy Wind

";
$t16464 = "Moltres-Galar @ Sharp Beak  
Ability: Berserk  
Tera Type: &
EVs: 248 HP / 56 Def / 116 SpA / 88 SpD  
Sassy Nature  
- Sucker Punch  
- Brave Bird  
- Fiery Wrath  
- Hurricane

";
$t16474 = "Walking Wake @ Life Orb  
Ability: Protosynthesis  
Tera Type: &
EVs: 244 SpA / 12 SpD / 252 Spe  
Timid Nature  
- Sunny Day  
- Flamethrower  
- Draco Meteor  
- Hydro Pump

";
$t16484 = "Dragalge @ Life Orb  
Ability: Adaptability  
Tera Type: &
EVs: 220 HP / 96 Atk / 192 SpD  
Sassy Nature  
- Gunk Shot  
- Draco Meteor  
- Toxic  
- Protect

";
$t16494 = "Flutter Mane @ Babiri Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 96 HP / 252 Def / 160 Spe  
Timid Nature  
- Charm  
- Moonblast  
- Pain Split  
- Mystical Fire

";
$t16504 = "Braviary (M) @ Choice Band  
Ability: Defiant  
Tera Type: &
EVs: 232 HP / 32 Atk / 244 SpD  
Careful Nature  
- Giga Impact  
- Brave Bird  
- Thrash  
- Superpower

";
$t16514 = "Magnezone @ Clear Amulet  
Ability: Sturdy  
Tera Type: &
EVs: 92 Atk / 252 SpA / 164 SpD  
Quiet Nature  
IVs: 0 Spe  
- Flash Cannon  
- Thunderbolt  
- Gyro Ball  
- Screech

";
$t16525 = "Arcanine (F) @ Clear Amulet  
Ability: Intimidate  
Tera Type: &
EVs: 224 HP / 140 Atk / 32 SpA / 80 SpD / 32 Spe  
Lonely Nature  
- Flare Blitz  
- Overheat  
- Will-O-Wisp  
- Morning Sun

";
$t16535 = "Rhydon @ Eviolite  
Ability: Lightning Rod  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Iron Defense  
- Body Press  
- Rest  
- Counter

";
$t16544 = "Registeel @ Leftovers  
Ability: Clear Body  
Tera Type: &
EVs: 148 HP / 220 Atk / 140 Spe  
Careful Nature  
- Heavy Slam  
- Curse  
- Amnesia  
- Rest

";
$t16553 = "Kartana @ Life Orb  
Ability: Beast Boost  
Shiny: Yes  
Tera Type: &
EVs: 64 HP / 112 Atk / 252 SpD / 80 Spe  
Adamant Nature  
- Knock Off  
- Leaf Blade  
- Sacred Sword  
- Swords Dance

";
$t16563 = "Rillaboom @ Miracle Seed  
Ability: Grassy Surge  
Tera Type: &
EVs: 120 Atk / 192 Def / 196 Spe  
Jolly Nature  
- Fake Out  
- Wood Hammer  
- Drum Beating  
- Bulk Up

";
$t16573 = "Braviary-Hisui (M) @ Life Orb  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Esper Wing  
- Hurricane  
- Icy Wind  
- Calm Mind

";
$t16583 = "Ursaluna @ Sitrus Berry  
Ability: Guts  
Tera Type: &
EVs: 204 HP / 8 Atk / 252 SpD / 44 Spe  
Adamant Nature  
- Earthquake  
- Rock Tomb  
- Giga Impact  
- Belly Drum

";
$t16593 = "Tauros-Paldea-Blaze (M) @ Liechi Berry  
Ability: Cud Chew  
Tera Type: &
EVs: 24 HP / 116 Atk / 172 Def / 196 Spe  
Adamant Nature  
- Reversal  
- Substitute  
- Flare Blitz  
- Protect

";
$t16603 = "Iron Bundle @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 112 HP / 64 SpA / 240 SpD / 92 Spe  
Modest Nature  
- Hydro Pump  
- Ice Beam  
- Freeze-Dry  
- Encore

";
$t16613 = "Dragapult @ Weakness Policy  
Ability: Infiltrator  
Tera Type: &
EVs: 224 HP / 72 Def / 212 Spe  
Jolly Nature  
- Outrage  
- Disable  
- Substitute  
- Dragon Dance

";
$t16623 = "Mesprit @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 112 HP / 48 Def / 252 SpA / 96 Spe  
Modest Nature  
- Calm Mind  
- Encore  
- Psyshock  
- Ice Beam

";
$t16633 = "Regidrago @ Yache Berry  
Ability: Dragons Maw  
Tera Type: &
EVs: 4 HP / 48 Atk / 236 Def / 16 SpA / 160 SpD / 44 Spe  
Hasty Nature  
- Dragon Energy  
- Dragon Dance  
- Outrage  
- Draco Meteor

";
$t16643 = "Sylveon @ Chilan Berry  
Ability: Pixilate  
Tera Type: &
EVs: 36 HP / 160 Def / 136 SpA / 176 Spe  
Modest Nature  
- Calm Mind  
- Hyper Voice  
- Hyper Beam  
- Substitute

";
$t16653 = "Squawkabilly-Blue @ Choice Scarf  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 40 Def / 216 Spe  
Adamant Nature  
- Giga Impact  
- Brave Bird  
- Fly  
- Aerial Ace

";
$t16663 = "Darmanitan-Galar @ Weakness Policy  
Ability: Zen Mode  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Will-O-Wisp  
- Encore  
- Icicle Crash  
- Flare Blitz

";
$t16672 = "Haxorus @ Haban Berry  
Ability: Unnerve  
Tera Type: &
EVs: 240 HP / 44 Def / 8 SpD / 216 Spe  
Jolly Nature  
- Counter  
- Dragon Dance  
- Outrage  
- Taunt

";
$t16681 = "Dracovish @ Leftovers  
Ability: Strong Jaw  
Tera Type: &
EVs: 8 HP / 124 Atk / 144 SpD / 232 Spe  
Adamant Nature  
- Fishious Rend  
- Earthquake  
- Substitute  
- Protect

";
$t16690 = "Ursaluna @ Expert Belt  
Ability: Bulletproof  
Tera Type: &
EVs: 208 HP / 52 Def / 8 SpD / 240 Spe  
Impish Nature  
- Bulldoze  
- Headlong Rush  
- Swords Dance  
- Avalanche

";
$t16700 = "Haxorus @ Mental Herb  
Ability: Unnerve  
Tera Type: &
EVs: 36 HP / 252 Atk / 204 Def / 16 Spe  
Adamant Nature  
- Swords Dance  
- Outrage  
- Scale Shot  
- Close Combat

";
$t16710 = "Annihilape @ Coba Berry  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 72 Atk / 92 Def / 20 SpD / 72 Spe  
Adamant Nature  
- Rock Tomb  
- Stone Edge  
- Bulk Up  
- Drain Punch

";
$t16720 = "Annihilape @ Sitrus Berry  
Ability: Defiant  
Tera Type: &
EVs: 212 HP / 40 Atk / 184 Def / 72 Spe  
Jolly Nature  
- Curse  
- Protect  
- Substitute  
- Phantom Force

";
$t16730 = "Thundurus (M) @ Life Orb  
Ability: Prankster  
Tera Type: &
EVs: 160 HP / 152 Atk / 196 SpD  
Adamant Nature  
- Charge  
- Wild Charge  
- Taunt  
- Brick Break

";
$t16740 = "Cyclizar @ Choice Scarf  
Ability: Shed Skin  
Tera Type: &
EVs: 252 Atk / 108 SpD / 148 Spe  
Adamant Nature  
- Giga Impact  
- Outrage  
- Knock Off  
- Power Whip

";
$t16750 = "Gardevoir @ Pixie Plate  
Ability: Trace  
Tera Type: &
EVs: 96 HP / 248 SpA / 164 Spe  
Timid Nature  
- Calm Mind  
- Encore  
- Psyshock  
- Moonblast

";
$t16760 = "Roaring Moon @ Weakness Policy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Night Slash  
- Focus Energy  
- Outrage  
- Endure

";
$t16770 = "Hoopa @ Weakness Policy  
Ability: Magician  
Tera Type: &
EVs: 88 HP / 116 SpA / 52 SpD / 252 Spe  
Timid Nature  
- Calm Mind  
- Shadow Ball  
- Thunderbolt  
- Psyshock

";
$t16780 = "Golduck @ Leftovers  
Ability: Cloud Nine  
Tera Type: &
EVs: 216 HP / 24 Def / 16 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Protect  
- Disable  
- Encore  
- Scald

";
$t16790 = "Arcanine @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 128 HP / 4 Atk / 252 SpD / 124 Spe  
Careful Nature  
- Flare Blitz  
- Burn Up  
- Outrage  
- Agility

";
$t16799 = "Arctozolt @ Lum Berry  
Ability: Slush Rush  
Tera Type: &
EVs: 8 HP / 40 Atk / 208 SpD / 252 Spe  
Adamant Nature  
- Bolt Beak  
- Charge  
- Protect  
- Bulldoze

";
$t16808 = "Frosmoth @ Petaya Berry  
Ability: Ice Scales  
Tera Type: &
EVs: 248 HP / 112 Def / 148 Spe  
Timid Nature  
- Quiver Dance  
- Bug Buzz  
- Ice Beam  
- Substitute

";
$t16817 = "Kartana @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 152 HP / 156 SpD / 200 Spe  
Jolly Nature  
- Leaf Blade  
- Knock Off  
- Sacred Sword  
- Smart Strike

";
$t16826 = "Darmanitan-Galar @ Salac Berry  
Ability: Zen Mode  
Tera Type: &
EVs: 16 HP / 188 Atk / 208 Def / 96 Spe  
Adamant Nature  
- Endure  
- Encore  
- Icicle Crash  
- Flare Blitz

";
$t16835 = "Nidoqueen @ Custap Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 48 Def / 144 SpA / 20 SpD / 48 Spe  
Modest Nature  
- Sludge Wave  
- Ice Beam  
- Earth Power  
- Endure

";
$t16844 = "Ninetales-Alola @ Choice Scarf  
Ability: Snow Warning  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Blizzard  
- Moonblast  
- Frost Breath  
- Freeze-Dry

";
$t16853 = "Mawile @ Expert Belt  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 100 Atk / 144 Def / 16 Spe  
Adamant Nature  
- Play Rough  
- Iron Head  
- Counter  
- Taunt

";
$t16862 = "Ferrothorn @ Occa Berry  
Ability: Iron Barbs  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Iron Defense  
- Body Press  
- Leech Seed  
- Gyro Ball

";
$t16872 = "Murdurr (Gurdurr) @ Eviolite  
Ability: Sheer Force  
Tera Type: &
EVs: 208 HP / 252 Atk / 48 Def  
Adamant Nature  
- Close Combat  
- Mach Punch  
- Ice Punch  
- Bulk Up

";
$t16881 = "Arcanine @ Metronome  
Ability: Intimidate  
Shiny: Yes  
Tera Type: &
EVs: 40 HP / 160 Atk / 72 Def / 236 Spe  
Adamant Nature  
- Flare Blitz  
- Burn Up  
- Extreme Speed  
- Bulldoze

";
$t16891 = "Registeel @ Rocky Helmet  
Ability: Clear Body  
Tera Type: &
EVs: 244 HP / 68 Atk / 128 Def / 64 SpD / 4 Spe  
Impish Nature  
- Counter  
- Seismic Toss  
- Heavy Slam  
- Toxic

";
$t16900 = "4340 (Metagross) @ Leftovers  
Ability: Clear Body  
Tera Type: &
EVs: 16 HP / 240 SpD / 252 Spe  
Jolly Nature  
- Meteor Mash  
- Bulldoze  
- Cosmic Power  
- Rest

";
$t16909 = "Porygon-Z @ Normalium Z  
Ability: Adaptability  
Tera Type: &
EVs: 80 HP / 252 Def / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Recover  
- Hyper Beam  
- Conversion

";
$t16919 = "Venusaur @ Venusaurite  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Curse  
- Power Whip  
- Outrage  
- Synthesis

";
$t16928 = "Swampert @ Swampertite  
Ability: Torrent  
Tera Type: &
EVs: 212 HP / 240 Def / 56 Spe  
Adamant Nature  
- Rock Tomb  
- Ice Punch  
- Earthquake  
- Curse

";
$t16937 = "Camerupt @ Cameruptite  
Ability: Magma Armor  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpA  
Quiet Nature  
- Flamethrower  
- Earth Power  
- Iron Head  
- Focus Energy

";
$t16946 = "Kyurem-Black @ Choice Band  
Ability: Teravolt  
Tera Type: &
EVs: 8 HP / 12 Atk / 252 Def / 236 Spe  
Adamant Nature  
- Outrage  
- Ice Beam  
- Fusion Bolt  
- Iron Head

";
$t16955 = "Samurott @ Petaya Berry  
Ability: Torrent  
Tera Type: &
EVs: 4 HP / 164 Def / 152 SpA / 188 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Encore  
- Icy Wind  
- Hydro Cannon

";
$t16965 = "Alakazam @ Psychic Gem  
Ability: Magic Guard  
Tera Type: &
EVs: 64 HP / 228 Def / 216 Spe  
Timid Nature  
- Protect  
- Encore  
- Disable  
- Psychic  

";
$t16974 = "Infernape @ Life Orb  
Ability: Blaze  
Tera Type: &
EVs: 188 Atk / 120 SpD / 200 Spe  
Jolly Nature  
- Substitute  
- Low Kick  
- Flare Blitz  
- Fake Out  

";
$t16983 = "Scrafty @ Expert Belt  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 120 Atk / 136 SpD  
Careful Nature  
- Fake Out  
- Payback  
- High Jump Kick  
- Knock Off

";
$t16992 = "Meloetta @ Chilan Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 244 HP / 104 Atk / 24 Def / 24 SpD / 112 Spe  
Jolly Nature  
- Relic Song  
- Close Combat  
- Substitute  
- Giga Impact

";
$t17001 = "Darmanitan @ Fire Gem  
Ability: Sheer Force  
Tera Type: &
EVs: 100 Atk / 192 SpD / 216 Spe  
Jolly Nature  
- Flare Blitz  
- Rock Slide  
- Encore  
- Will-O-Wisp

";
$t17010 = "Alakazam @ Alakazite  
Ability: Inner Focus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Serious Nature  
IVs: 0 Atk  
- Psychic  

";
$t17018 = "Baxcalibur @ Choice Band  
Ability: Thermal Exchange  
Tera Type: &
EVs: 44 HP / 252 Atk / 212 Spe  
Adamant Nature  
- Glaive Rush  
- Icicle Crash  
- Earthquake  
- Ice Shard  

";
$t17028 = "Slowking-Galar @ Heavy-Duty Boots  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Grass Knot  
- Toxic  
- Chilly Reception  

";
$t17039 = "Ogerpon (F) @ Utility Umbrella  
Ability: Defiant  
Tera Type: &
EVs: 248 HP / 232 Def / 28 Spe  
Impish Nature  
- Horn Leech  
- Knock Off  
- Encore  
- Synthesis  

";
$t17049 = "Slither Wing @ Covert Cloak  
Ability: Protosynthesis  
Tera Type: &
EVs: 232 HP / 252 Atk / 24 Spe  
Adamant Nature  
- Close Combat  
- First Impression  
- Morning Sun  
- Bulk Up  

";
$t17059 = "Hydreigon @ Chople Berry  
Ability: Levitate  
Tera Type: &
EVs: 132 HP / 252 SpA / 124 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Dark Pulse  
- Flash Cannon  
- Nasty Plot  

";
$t17070 = "Jolteon @ Heavy-Duty Boots  
Ability: Quick Feet  
Tera Type: &
EVs: 124 HP / 252 SpA / 132 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Tera Blast  
- Volt Switch  
- Calm Mind  

";
$t17081 = "Raging Bolt @ Assault Vest
Ability: Protosynthesis
Tera Type: &
EVs: 212 HP / 12 Def / 252 SpA / 28 SpD / 4 Spe
Modest Nature
- Thunderclap
- Thunderbolt
- Draco Meteor
- Heavy Slam

";
$t17091 = "Conkeldurr (M) @ Coba Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Ice Punch  
- Thunder Punch  
- Close Combat  
- Mach Punch  

";
$t17101 = "Dragonite @ Eject Pack  
Ability: Multiscale  
Tera Type: &
EVs: 72 HP / 124 Atk / 56 Def / 200 SpA / 56 Spe  
Quiet Nature  
- Draco Meteor  
- Flamethrower  
- Focus Punch  
- Hurricane  

";
$t17111 = "Cinderace @ Silk Scarf  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Double-Edge  
- Pyro Ball  
- High Jump Kick  

";
$t17121 = "Dragonite @ Rocky Helmet  
Ability: Multiscale  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Roost  
- Haze  
- Earthquake  
- Encore  

";
$t17131 = "Great Tusk @ Rocky Helmet  
Ability: Protosynthesis  
Tera Type: &
EVs: 184 HP / 100 Atk / 116 SpD / 108 Spe  
Adamant Nature  
- Bulk Up  
- Knock Off  
- Rapid Spin  
- Rest  

";
$t17141 = "Exeggutor-Alola @ Chesto Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Sunny Day  
- Rest  
- Leech Seed  
- Protect  

";
$t17152 = "Jolteon @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 128 SpA / 132 Spe  
Timid Nature  
IVs: 0 Atk  
- Light Screen  
- Volt Switch  
- Hidden Power [Ice]  
- Heal Bell  

";
$t17163 = "Conkeldurr (M) @ Coba Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Ice Punch  
- Thunder Punch  
- Close Combat  
- Mach Punch  

";
$t17173 = "Dragonite @ Eject Pack  
Ability: Multiscale  
Tera Type: &
EVs: 72 HP / 124 Atk / 56 Def / 200 SpA / 56 Spe  
Quiet Nature  
- Draco Meteor  
- Flamethrower  
- Focus Punch  
- Hurricane  

";
$t17183 = "Cinderace @ Silk Scarf  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Double-Edge  
- Pyro Ball  
- High Jump Kick  

";
$t17193 = "Dragonite @ Rocky Helmet  
Ability: Multiscale  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Roost  
- Haze  
- Earthquake  
- Encore  

";
$t17203 = "Great Tusk @ Rocky Helmet  
Ability: Protosynthesis  
Tera Type: &
EVs: 184 HP / 100 Atk / 116 SpD / 108 Spe  
Adamant Nature  
- Bulk Up  
- Knock Off  
- Rapid Spin  
- Rest  

";
$t17213 = "Exeggutor-Alola @ Chesto Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Sunny Day  
- Rest  
- Leech Seed  
- Protect  

";
$t17224 = "Kyurem-Black @ Power Herb  
Ability: Teravolt  
Tera Type: &
EVs: 252 HP / 52 Atk / 140 Def / 44 SpD / 20 Spe  
Adamant Nature  
- Freeze Shock  
- Outrage  
- Substitute  
- Iron Head  

";
$t17234 = "Ampharos @ Ampharosite  
Ability: Static  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Discharge  
- Rest  
- Cotton Guard  
- Counter  

";
$t17245 = "Araquanid @ Aguav Berry  
Ability: Water Bubble  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Relaxed Nature  
- Lunge  
- Scald  
- Reflect  
- Rest  

";
$t17255 = "Electrode @ Electric Gem  
Ability: Soundproof  
Tera Type: &
EVs: 248 HP / 68 Def / 60 SpA / 80 SpD / 52 Spe  
Calm Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hidden Power [Fire]  
- Taunt  
- Mirror Coat  

";
$t17266 = "Sableye @ Focus Sash  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
- Taunt  
- Shadow Sneak  
- Metal Burst  
- Toxic  

";
$t17276 = "Nidoqueen @ Poison Gem  
Ability: Sheer Force  
Tera Type: &
EVs: 176 HP / 252 SpA / 80 Spe  
Timid Nature  
IVs: 0 Atk  
- Taunt  
- Earth Power  
- Sludge Wave  
- Counter  

";
$t17287 = "Delphox @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Psychic  
- Blast Burn  
- Hypnosis  

";
$t17298 = "Togekiss @ Flying Gem  
Ability: Super Luck  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Tailwind  
- Dazzling Gleam  
- Air Slash  
- Shock Wave  

";
$t17309 = "Bastiodon @ Mago Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Metal Burst  
- Counter  
- Protect  
- Torment  

";
$t17319 = "Vespiquen @ Flyinium Z  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Tailwind  
- Defend Order  
- Attack Order  
- Heal Order  

";
$t17329 = "Articuno @ Icicle Plate  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 20 Def / 92 SpA / 72 SpD / 76 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Roost  
- Freeze-Dry  
- Hurricane  

";
$t17341 = "Mesprit @ Aguav Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 12 Def / 244 SpD  
Calm Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Charm  
- Calm Mind  
- Rest  

";
$t17352 = "Stoutland @ Normal Gem  
Ability: Scrappy  
Tera Type: &
EVs: 136 HP / 108 Atk / 252 Def / 12 Spe  
Impish Nature  
- Giga Impact  
- Play Rough  
- Wild Charge  
- Fire Fang  

";
$t17362 = "Aurorus @ Air Balloon  
Ability: Refrigerate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Thunder Wave  
- Mirror Coat  
- Earth Power  

";
$t17373 = "Magmortar @ Sitrus Berry  
Ability: Vital Spirit  
Tera Type: &
EVs: 16 HP / 252 Def / 240 Spe  
Jolly Nature  
- Belly Drum  
- Flare Blitz  
- Thunder Punch  
- Will-O-Wisp  

";
$t17383 = "Electivire @ Choice Scarf  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Supercell Slam  
- Cross Chop  
- Rock Slide  
- Earthquake  

";
$t17393 = "Lapras @ Water Gem  
Ability: Shell Armor  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Hydro Pump  
- Freeze-Dry  
- Thunder  
- Hidden Power [Fire]  

";
$t17404 = "Azelf @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 128 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Psychic  
- Fire Blast  
- Thunder  

";
$t17415 = "Piplup @ Petaya Berry  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Yawn  
- Endure  
- Hydro Pump  
- Defog  

";
$t17426 = "Bisharp @ Liechi Berry  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 176 Def / 80 Spe  
Adamant Nature  
- Thunder Wave  
- Low Kick  
- Substitute  
- Stone Edge  

";
$t17436 = "Dedenne @ Sitrus Berry  
Ability: Cheek Pouch  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Eerie Impulse  
- Recycle  
- Discharge  
- Substitute  

";
$t17447 = "Breloom @ Darkinium Z  
Ability: Poison Heal  
Tera Type: &
EVs: 248 HP / 16 Def / 244 Spe  
Timid Nature  
IVs: 0 Atk  
- Leech Seed  
- Substitute  
- Snatch  
- Spore  

";
$t17458 = "Wishiwashi @ Wiki Berry  
Ability: Schooling  
Tera Type: &
EVs: 252 HP / 248 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Tearful Look  
- Scald  
- Ice Beam  
- Rest  

";
$t17469 = "Basculin @ Choice Specs  
Ability: Mold Breaker  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Ice Beam  
- Surf  
- Hidden Power [Fire]  
- Uproar  

";
$t17480 = "Porygon-Z @ Aguav Berry  
Ability: Adaptability  
Tera Type: &
EVs: 88 HP / 36 Def / 200 SpA / 184 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Icy Wind  
- Ice Beam  
- Hyper Beam  

";
$t17491 = "Basculin @ Water Gem  
Ability: Mold Breaker  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Surf  
- Waterfall  
- Attract  
- Sleep Talk  

";
$t17501 = "Bastiodon @ Weakness Policy  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Endure  
- Heavy Slam  
- Earthquake  
- Rock Blast  

";
$t17511 = "Celesteela @ Rocky Helmet  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Autotomize  
- Flash Cannon  
- Air Slash  
- Fire Blast  

";
$t17522 = "Golduck @ Water Gem  
Ability: Cloud Nine  
Tera Type: &
EVs: 224 Def / 224 SpA / 60 Spe  
Rash Nature  
- Hydro Pump  
- Aqua Jet  
- Counter  
- Substitute  

";
$t17532 = "Gothitelle @ Electric Gem  
Ability: Competitive  
Tera Type: &
EVs: 248 HP / 168 Def / 8 SpA / 84 SpD  
Calm Nature  
IVs: 0 Atk  
- Thunderbolt  
- Rest  
- Taunt  
- Mirror Coat  

";
$t17543 = "Stakataka @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Earthquake  
- Iron Head  
- Zen Headbutt  
- Stone Edge  

";
$t17553 = "Wailord @ Assault Vest  
Ability: Water Veil  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Avalanche  
- Earthquake  
- Facade  
- Waterfall  

";
$t17563 = "Bibarel @ Salac Berry  
Ability: Simple  
Tera Type: &
EVs: 224 HP / 32 Atk / 252 SpD  
Careful Nature  
- Swords Dance  
- Skull Bash  
- Waterfall  
- Last Resort  

";
$t17573 = "Gumshoos @ Normalium Z  
Ability: Adaptability  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Last Resort  
- Protect  
- Scary Face  

";
$t17582 = "Celesteela @ Choice Band  
Ability: Beast Boost  
Tera Type: &
EVs: 248 HP / 160 Atk / 96 Def / 4 SpD  
Impish Nature  
- Heavy Slam  
- Earthquake  
- Seed Bomb  
- Acrobatics  

";
$t17592 = "Blacephalon @ Choice Band  
Ability: Beast Boost  
Shiny: Yes  
Happiness: 0  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Shadow Claw  
- Flame Charge  
- Knock Off  
- Frustration  

";
$t17604 = "Blacephalon @ Kings Rock  
Ability: Beast Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Mind Blown  
- Overheat  
- Shadow Ball  
- Fling  

";
$t17614 = "Blaziken @ Kings Rock  
Ability: Speed Boost  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Mild Nature  
- Fling  
- Substitute  
- Focus Blast  
- Blast Burn  

";
$t17624 = "Latios @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 92 HP / 80 SpA / 252 SpD / 84 Spe  
Modest Nature  
IVs: 0 Atk  
- Heal Block  
- Psyshock  
- Draco Meteor  
- Icy Wind  

";
$t17635 = "Primarina @ Throat Spray  
Ability: Liquid Voice  
Tera Type: &
EVs: 176 HP / 252 SpA / 4 SpD / 76 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic Noise  
- Alluring Voice  
- Echoed Voice  
- Hyper Voice  

";
$t17646 = "Primarina (M) @ Assault Vest  
Ability: Liquid Voice  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Gentle Nature  
IVs: 30 Spe  
- Psychic Noise  
- Flip Turn  
- Moonblast  
- Draining Kiss  

";
$t17657 = "Bastiodon @ Choice Band  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Metal Burst  
- Outrage  
- Heavy Slam  
- Earthquake  

";
$t17667 = "Porygon-Z @ Kee Berry  
Ability: Adaptability  
Tera Type: &
EVs: 80 HP / 252 Def / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Conversion  
- Thunder Wave  
- Recover  

";
$t17678 = "Zoroark @ Weakness Policy  
Ability: Illusion  
Tera Type: &
EVs: 40 HP / 152 SpA / 252 SpD / 64 Spe  
Modest Nature  
IVs: 0 Atk  
- Agility  
- Dark Pulse  
- Encore  
- Sludge Bomb  

";
$t17689 = "Runerigus @ Weakness Policy  
Ability: Wandering Spirit  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Brave Nature  
- Trick Room  
- Earthquake  
- Poltergeist  
- Disable  

";
$t17699 = "Cresselia @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 40 Def / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Thunder Wave  
- Lunar Dance  
- Trick  

";
$t17710 = "Klefki @ Chesto Berry  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Relaxed Nature  
- Rest  
- Thunder Wave  
- Thief  
- Flash Cannon  

";
$t17720 = "Blaziken @ Life Orb  
Ability: Speed Boost  
Tera Type: &
EVs: 248 Atk / 84 SpA / 176 Spe  
Naive Nature  
- Protect  
- High Jump Kick  
- Blast Burn  
- Rock Slide  

";
$t17730 = "Zoroark @ Choice Specs  
Ability: Illusion  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Extrasensory  
- Hidden Power [Rock]  
- Trick  

";
$t17741 = "Bouffalant @ Iapapa Berry  
Ability: Soundproof  
Tera Type: &
EVs: 4 Atk / 252 Def / 252 Spe  
Impish Nature  
- Cotton Guard  
- Rest  
- Swords Dance  
- Head Charge  

";
$t17751 = "Braviary @ Flying Gem  
Ability: Defiant  
Tera Type: &
EVs: 248 HP / 64 Atk / 88 Def / 108 Spe  
Adamant Nature  
- Bulk Up  
- Roost  
- Brave Bird  
- Laser Focus  

";
$t17761 = "Magearna @ Life Orb  
Ability: Soul-Heart  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Shift Gear  
- Iron Head  
- Zen Headbutt  
- Brick Break  

";
$t17771 = "Regigigas @ Choice Specs  
Ability: Slow Start  
Happiness: 0  
Tera Type: &
EVs: 220 HP / 32 Def / 104 SpA / 152 Spe  
Modest Nature  
IVs: 0 Atk  
- Hyper Beam  
- Earth Power  
- Icy Wind  
- Sleep Talk  

";
$t17783 = "Zamazenta @ Leftovers  
Ability: Dauntless Shield  
Tera Type: &
EVs: 104 HP / 252 Def / 152 Spe  
Jolly Nature  
- Body Press  
- Crunch  
- Roar  
- Iron Defense  

";
$t17793 = "Gholdengo @ Heavy-Duty Boots  
Ability: Good as Gold  
Tera Type: &
EVs: 252 HP / 192 Def / 64 Spe  
Bold Nature  
IVs: 0 Atk  
- Hex  
- Thunder Wave  
- Nasty Plot  
- Recover  

";
$t17804 = "Bronzong @ Sitrus Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Metal Sound  
- Flash Cannon  
- Psychic  
- Psyshock  

";
$t17815 = "Cacturne @ Liechi Berry  
Ability: Sand Veil  
Tera Type: &
EVs: 252 HP / 252 Atk  
Adamant Nature  
- Spiky Shield  
- Seed Bomb  
- Sucker Punch  
- Swords Dance  

";
$t17825 = "Kabutops (F) @ Chople Berry  
Ability: Weak Armor  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Liquidation  
- Stone Edge  
- Aqua Jet  

";
$t17835 = "Simipour (M) @ Petaya Berry  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Focus Blast  
- Ice Beam  
- Substitute  

";
$t17846 = "Toxicroak @ Fighting Gem  
Ability: Dry Skin  
Tera Type: &
EVs: 12 HP / 112 Atk / 160 SpA / 76 SpD / 148 Spe  
Mild Nature  
- Fake Out  
- Focus Blast  
- Gunk Shot  
- Focus Punch  

";
$t17856 = "Dustox @ Charti Berry  
Ability: Shield Dust  
Tera Type: &
EVs: 72 HP / 220 Def / 216 Spe  
Bold Nature  
IVs: 0 Atk  
- Iron Defense  
- Roost  
- Quiver Dance  
- Bug Buzz  

";
$t17867 = "Toucannon @ Power Herb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Sky Attack  
- Gunk Shot  
- Feather Dance  
- Roost  

";
$t17877 = "Golurk @ Ghost Gem  
Ability: No Guard  
Tera Type: &
EVs: 252 HP / 120 Atk / 136 SpD  
Adamant Nature  
- Earthquake  
- Phantom Force  
- Gravity  
- Dynamic Punch  

";
$t17887 = "Tyranitar @ Shuca Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 56 HP / 252 Atk / 8 SpA / 12 SpD / 180 Spe  
Hasty Nature  
- Crunch  
- Taunt  
- Ice Beam  
- Rock Tomb  

";
$t17897 = "Celebi @ Life Orb  
Ability: Natural Cure  
Tera Type: &
EVs: 228 Def / 240 SpA / 40 Spe  
Timid Nature  
- Leaf Storm  
- Psychic  
- Hidden Power [Ice]  
- Sucker Punch  

";
$t17907 = "Celesteela @ Choice Scarf  
Ability: Beast Boost  
Tera Type: &
EVs: 88 HP / 96 Atk / 156 Def / 168 Spe  
Jolly Nature  
- Heavy Slam  
- Superpower  
- Zen Headbutt  
- Rock Slide  

";
$t17917 = "Togekiss @ Life Orb  
Ability: Serene Grace  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Thunder Wave  
- Grass Knot  
- Air Slash  

";
$t17928 = "Necrozma @ Lum Berry  
Ability: Prism Armor  
Shiny: Yes  
Tera Type: &
EVs: 152 HP / 252 Atk / 104 Spe  
Adamant Nature  
- Dragon Dance  
- Photon Geyser  
- Earthquake  
- Outrage  

";
$t17939 = "Meloetta @ Assault Vest  
Ability: Serene Grace  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Relic Song  
- Zen Headbutt  
- Drain Punch  
- Thunder Punch  

";
$t17949 = "Sigilyph (F) @ Flame Orb  
Ability: Magic Guard  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Cosmic Power  
- Roost  
- Psycho Shift  
- Stored Power  

";
$t17961 = "Hakamo-o @ Big Nugget  
Ability: Bulletproof  
Tera Type: &
EVs: 216 Atk / 228 Spe  
Quirky Nature  
- X-Scissor  
- Swords Dance  
- Focus Blast  
- Scale Shot  

";
$t17971 = "Magnezone @ Air Balloon  
Ability: Analytic  
Tera Type: &
EVs: 16 HP / 12 Def / 252 SpA / 228 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Flash Cannon  
- Electroweb  
- Thunderbolt  

";
$t17982 = "Corsola (M) @ Assault Vest  
Ability: Hustle  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Head Smash  
- Earthquake  
- Liquidation  
- Mirror Coat  

";
$t17992 = "Gastrodon @ Choice Scarf  
Ability: Storm Drain  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Earth Power  
- Hidden Power [Fire]  
- Ice Beam  

";
$t18003 = "Volcanion @ Rockium Z  
Ability: Water Absorb  
Tera Type: &
EVs: 76 HP / 252 SpA / 4 SpD / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Sandstorm  
- Weather Ball  
- Flamethrower  
- Steam Eruption  

";
$t18014 = "Genesect-Burn @ Burn Drive  
Ability: Download  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Techno Blast  
- Ice Beam  
- Bug Buzz  
- Thunderbolt  

";
$t18025 = "Genesect-Shock @ Shock Drive  
Ability: Download  
Tera Type: &
EVs: 152 HP / 116 SpA / 68 SpD / 172 Spe  
Modest Nature  
IVs: 0 Atk  
- Techno Blast  
- Charge Beam  
- Ice Beam  
- Giga Drain  

";
$t18036 = "Genesect-Chill @ Chill Drive  
Ability: Download  
Tera Type: &
EVs: 196 HP / 252 SpA / 60 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Techno Blast  
- Charge Beam  
- Signal Beam  

";
$t18047 = "Skarmory @ Flying Gem  
Ability: Sturdy  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Brave Bird  
- Taunt  
- Swords Dance  
- Rock Tomb  

";
$t18057 = "Xurkitree @ Electrium Z  
Ability: Beast Boost  
Tera Type: &
EVs: 108 HP / 148 Def / 252 Spe  
Bold Nature  
IVs: 0 Atk  
- Zap Cannon  
- Magnet Rise  
- Hypnosis  
- Hidden Power [Ice]  

";
$t18068 = "Enamorus-Therian (F) @ Throat Spray  
Ability: Overcoat  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Agility  
- Alluring Voice  
- Taunt  
- Tera Blast  

";
$t18079 = "Serperior @ Grass Gem  
Ability: Contrary  
Tera Type: &
EVs: 224 Def / 164 SpA / 120 Spe  
Timid Nature  
IVs: 0 Atk  
- Leaf Storm  
- Substitute  
- Grassy Terrain  
- Taunt  

";
$t18090 = "Drifblim @ Petaya Berry  
Ability: Unburden  
Tera Type: &
EVs: 208 Def / 252 SpA / 20 SpD / 28 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Shadow Ball  
- Calm Mind  
- Endure  

";
$t18101 = "Roserade (F) @ Choice Scarf  
Ability: Technician  
Tera Type: &
EVs: 40 Def / 252 SpA / 216 Spe  
Modest Nature  
IVs: 0 Atk  
- Petal Dance  
- Sludge Bomb  
- Hidden Power [Fire]  
- Dazzling Gleam  

";
$t18112 = "Eelektross @ Electrium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Magnet Rise  
- Thunder  
- Giga Drain  
- Acid Spray  

";
$t18123 = "Ekans @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Coil  
- Gunk Shot  
- Substitute  
- Rest  

";
$t18133 = "Raichu @ Life Orb  
Ability: Lightning Rod  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Fake Out  
- Grass Knot  
- Volt Tackle  
- Hidden Power [Ground]  

";
$t18143 = "Hawlucha @ Fighting Gem  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Jump Kick  
- Substitute  
- Thunder Punch  
- Swords Dance  

";
$t18153 = "Tapu Fini @ Choice Scarf  
Ability: Misty Surge  
Tera Type: &
EVs: 252 HP / 72 Def / 184 Spe  
Calm Nature  
IVs: 0 Atk  
- Surf  
- Moonblast  
- Hidden Power [Rock]  
- Ice Beam  

";
$t18164 = "Umbreon @ Aguav Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Careful Nature  
- Bide  
- Taunt  
- Moonlight  
- Foul Play  

";
$t18174 = "Cinccino @ Loaded Dice  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Tidy Up  
- Tail Slap  
- Knock Off  
- Rock Blast  

";
$t18184 = "Dragonair @ Heavy-Duty Boots  
Ability: Shed Skin  
Tera Type: &
EVs: 252 Atk / 252 Spe  
Adamant Nature  
- Aqua Jet  
- Aqua Tail  
- Dragon Rush  
- Flamethrower  

";
$t18194 = "Misdreavus @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Destiny Bond  
- Thunderbolt  
- Memento  
- Burning Jealousy  

";
$t18205 = "Liepard (F) @ Normal Gem  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Serious Nature  
- Fake Out  
- Encore  
- Nasty Plot  
- Hyper Voice  

";
$t18215 = "Metagross @ Sitrus Berry  
Ability: Clear Body  
Shiny: Yes  
Tera Type: &
EVs: 156 HP / 252 Atk / 4 Def / 96 Spe  
Adamant Nature  
- Meteor Mash  
- Earthquake  
- Substitute  
- Bullet Punch  



";
$t18228 = "Archaludon @ Scope Lens  
Ability: Stamina  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Focus Energy  
- Body Press  
- Flash Cannon  
- Draco Meteor  

";
$t18239 = "Audino @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Tera Blast  
- Heal Bell  
- Wish  
- Calm Mind  

";
$t18250 = "Blaziken @ Mirror Herb  
Ability: Speed Boost  
Tera Type: &
EVs: 216 HP / 252 Atk / 4 SpD / 36 Spe  
Adamant Nature  
- Last Resort  
- Swagger  
- Substitute  
- Protect  

";
$t18260 = "Empoleon @ Poisonium Z  
Ability: Competitive  
Tera Type: &
EVs: 20 HP / 232 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Power Trip  
- Toxic  
- Agility  

";
$t18270 = "Skarmory @ Occa Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Spikes  
- Brave Bird  
- Roost  
- Whirlwind  

";
$t18280 = "Barbaracle @ Assault Vest  
Ability: Tough Claws  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Return  
- Razor Shell  
- Power-Up Punch  
- Rock Slide  

";
$t18290 = "Dracozolt @ Dragon Fang  
Ability: Volt Absorb  
Tera Type: &
EVs: 64 HP / 72 Atk / 120 SpA / 252 Spe  
Naive Nature  
- Bolt Beak  
- Draco Meteor  
- Taunt  
- Protect  

";
$t18300 = "Tyrantrum @ Leftovers  
Ability: Rock Head  
Tera Type: &
EVs: 228 HP / 28 Atk / 252 Spe  
Jolly Nature  
- Head Smash  
- Close Combat  
- Stealth Rock  
- Protect  

";
$t18310 = "Deoxys @ Power Herb  
Ability: Pressure  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
- Meteor Beam  
- Psychic Noise  
- Extreme Speed  
- Protect  

";
$t18319 = "Sirfetch’d @ Bug Gem  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Close Combat  
- First Impression  
- Defog  
- Protect  

";
$t18329 = "Thundurus (M) @ Liechi Berry  
Ability: Prankster  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Supercell Slam  
- Acrobatics  
- Substitute  
- Protect  

";
$t18339 = "Clefable @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 SpA  
Quiet Nature  
- Double-Edge  
- Fire Blast  
- Grass Knot  
- Soft-Boiled  

";
$t18349 = "Azelf @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 84 Def / 172 SpA / 252 Spe  
Naive Nature  
- Psychic  
- Fire Blast  
- Explosion  
- Calm Mind  

";
$t18359 = "Kangaskhan (F) @ Leftovers  
Ability: Early Bird  
Tera Type: &
EVs: 152 HP / 252 Atk / 104 Spe  
Adamant Nature  
- Return  
- Sucker Punch  
- Focus Punch  
- Substitute  

";
$t18369 = "Gyarados @ Liechi Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 88 SpD / 168 Spe  
Jolly Nature  
- Waterfall  
- Natural Gift  
- Thunder Wave  
- Dragon Dance  

";
$t18379 = "Sirfetch’d @ Covert Cloak  
Ability: Scrappy  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Meteor Assault  
- Sleep Talk  
- Rest  
- Bulk Up  

";
$t18389 = "Sirfetch’d @ Leftovers  
Ability: Scrappy  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Brave Nature  
- Revenge  
- Sleep Talk  
- Rest  
- Bulk Up  

";
$t18399 = "Zapdos @ Electrium Z  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hurricane  
- Eerie Impulse  
- Substitute  
- Roost  

";
$t18410 = "Jolteon @ Throat Spray  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Alluring Voice  
- Hidden Power [Ice]  
- Calm Mind  

";
$t18421 = "Gouging Fire @ Rusted Shield  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Iron Head  
- Flare Blitz  
- Dragon Dance  
- Outrage  

";
$t18431 = "Rotom-Wash @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 68 Def / 184 SpD / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Volt Switch  
- Foul Play  
- Pain Split  
- Thunder Wave  

";
$t18442 = "Probopass @ Weakness Policy  
Ability: Magnet Pull  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Head Smash  
- Heavy Slam  
- Rest  
- Sleep Talk  

";
$t18452 = "Probopass @ Rockium Z  
Ability: Sand Force  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Careful Nature  
- Head Smash  
- Protect  
- Sandstorm  
- Curse  

";
$t18462 = "Probopass @ Sitrus Berry  
Ability: Magnet Pull  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Body Press  
- Toxic  
- Stealth Rock  
- Volt Switch  

";

$tt41 = "Chatot @ Throat Spray  
Ability: Big Pecks  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Chatter  
- Encore  
- Protect  
- Tailwind  

";
$tt412 = "Heliolisk @ Throat Spray  
Ability: Dry Skin  
Tera Type: &
EVs: 60 HP / 144 SpA / 112 SpD / 192 Spe  
Timid Nature  
IVs: 0 Atk  
- Parabolic Charge  
- Glare  
- Ally Switch  
- Hyper Voice  

";
$tt423 = "Helioptile @ Eviolite  
Ability: Dry Skin  
Tera Type: &
EVs: 128 HP / 240 SpA / 4 SpD / 136 Spe  
Modest Nature  
IVs: 0 Atk  
- Parabolic Charge  
- Charge Beam  
- Tera Blast  
- Glare  

";
$tt434 = "Helioptile @ Throat Spray  
Ability: Dry Skin  
Tera Type: &
EVs: 228 HP / 252 SpA / 4 SpD / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Snore  
- Flash  
- Rest  

";
$tt445 = "Hoopa-Unbound @ Throat Spray  
Ability: Magician  
Tera Type: &
EVs: 184 HP / 252 SpA / 72 Spe  
Modest Nature  
IVs: 0 Atk  
- Snore  
- Thunder Wave  
- Rest  
- Substitute  

";
$tt456 = "Delphox @ Throat Spray  
Ability: Magician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Burning Jealousy  
- Snore  
- Rest  
- Calm Mind  

";
$tt467 = "Klefki @ Throat Spray  
Ability: Magician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Draining Kiss  
- Snore  
- Rest  
- Defog  

";
$tt478 = "Florges (F) @ Heavy-Duty Boots  
Ability: Flower Veil  
Tera Type: &
EVs: 248 HP / 236 Def / 24 Spe  
Bold Nature  
IVs: 0 Atk  
- Moonblast  
- Toxic  
- Aromatherapy  
- Synthesis  

";
$tt489 = "Zygarde-10% @ Leftovers  
Ability: Aura Break  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Thousand Waves  
- Skitter Smack  
- Substitute  
- Protect  

";
$tt499 = "Feraligatr @ Lum Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Ice Punch  
- Flip Turn  
- Dragon Dance  

";
$tt4109 = "Tsareena (F) @ Light Ball  
Ability: Queenly Majesty  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Stomp  
- Fling  
- Synthesis  
- Teeter Dance  

";
$tt4119 = "Snorlax @ Chesto Berry  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 116 Def / 116 SpD / 24 Spe  
Adamant Nature  
- Last Resort  
- Block  
- Curse  
- Rest  

";
$tt4129 = "Regidrago @ Razor Claw  
Ability: Dragons Maw  
Tera Type: &
EVs: 216 Atk / 104 Def / 36 SpD / 152 Spe  
Adamant Nature  
- Focus Energy  
- Dragon Dance  
- Outrage  
- Earthquake  

";
$tt4139 = "Zygarde-10% @ Dragonium Z  
Ability: Aura Break  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Thousand Arrows  
- Outrage  
- Glare  
- Dragon Dance  

";
$tt4149 = "Zygarde @ Ice Gem  
Ability: Aura Break  
Tera Type: &
EVs: 4 Atk / 40 Def / 196 SpA / 16 SpD / 252 Spe  
Naive Nature  
IVs: 30 Atk  
- Hidden Power [Ice]  
- Haze  
- Draco Meteor  
- Thousand Waves  

";
$tt4160 = "Latios (M) @ Haban Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Scale Shot  
- Outrage  
- Recover  

";
$tt4170 = "Cryogonal @ Heavy-Duty Boots  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
- Recover  
- Rapid Spin  
- Haze  
- Bind  

";
$tt4180 = "Cryogonal @ Grip Claw  
Ability: floats  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
- Bind  
- Haze  
- Recover  
- Freeze-Dry  

";
$tt4190 = "Meltan @ Grassy Seed  
Ability: Magnet Pull  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
IVs: 0 Atk  
- Toxic  
- Iron Defense  
- Rest  
- Sleep Talk  

";
$tt4202 = "Persian-Alola @ Throat Spray  
Ability: Fur Coat  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Dark Pulse  
- Burning Jealousy  
- Hidden Power [Poison]  
- Roar  

";
$tt4213 = "Persian @ Throat Spray  
Ability: Technician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Tera Blast  
- Shadow Ball  
- Covet  
- Roar  

";
$tt4223 = "Venomoth @ Throat Spray  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Bug Buzz  
- Psychic Noise  
- Thief  
- Protect  

";
$tt4233 = "Iron Moth @ Throat Spray  
Ability: Quark Drive  
Tera Type: &
EVs: 80 HP / 24 Def / 140 SpA / 68 SpD / 196 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Bug Buzz  
- Morning Sun  
- Sunny Day  

";
$tt4244 = "Ogerpon-Wellspring (F) @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 172 Def / 84 SpD  
Impish Nature  
- Leech Seed  
- Sleep Talk  
- Quick Attack  
- Rest  



";
$tt4256 = "Persian @ Throat Spray  
Ability: Technician  
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe  
Modest Nature  
- Tera Blast  
- Shadow Ball  
- Thief  
- Roar  

";
$tt4266 = "Meloetta @ Throat Spray  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Snore  
- Psyshock  
- Rest  
- Thunder Wave  

";
$tt4277 = "Loudred @ Eviolite  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 52 Def / 4 SpA / 200 SpD  
Calm Nature  
IVs: 0 Atk  
- Tera Blast  
- Toxic  
- Teeter Dance  
- Protect  

";
$tt4288 = "Pecharunt @ Sitrus Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 20 Def / 4 SpA / 232 SpD  
Bold Nature  
IVs: 0 Atk  
- Tera Blast  
- Recover  
- Parting Shot  
- Poison Gas  

";
$tt4299 = "Salazzle (F) @ Leftovers  
Ability: Corrosion  
Tera Type: &
EVs: 80 HP / 196 SpA / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Protect  
- Poison Gas  
- Substitute  

";
$tt4310 = "Muk-Alola @ Poisonium Z  
Ability: Poison Touch  
Tera Type: &
EVs: 248 HP / 76 Def / 184 SpD  
Careful Nature  
- Knock Off  
- Pain Split  
- Protect  
- Poison Gas  

";
$tt4320 = "Luvdisc @ Heavy-Duty Boots  
Ability: Swift Swim  
Tera Type: &
EVs: 81 HP / 85 Def / 85 SpA / 85 SpD / 85 Spe  
IVs: 0 Atk  
- Endeavor  
- Substitute  
- Whirlpool  
- Surf  

";
$tt4330 = "Latias (F) @ Soul Dew  
Ability: Levitate  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Psyshock  
- Roost  
- Calm Mind  

";
$tt4341 = "Toucannon @ Heavy-Duty Boots  
Ability: Skill Link  
Tera Type: &
EVs: 108 HP / 44 Atk / 104 SpA / 252 SpD  
Sassy Nature  
- Boomburst  
- Bullet Seed  
- Roost  
- U-turn  

";
$tt4351 = "Piloswine @ Never-Melt Ice  
Ability: Oblivious  
Tera Type: &
EVs: 168 HP / 228 Atk / 88 SpA / 24 Spe  
Brave Nature  
- Ice Beam  
- Earthquake  
- Mud Shot  
- Blizzard  

";
$tt4361 = "Cloyster @ White Herb  
Ability: Skill Link  
Tera Type: &
EVs: 112 Atk / 144 SpA / 252 Spe  
Naughty Nature  
- Icicle Spear  
- Hydro Pump  
- Hidden Power [Grass]  
- Shell Smash  

";
$tt4371 = "Cloyster @ Loaded Dice  
Ability: Shell Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Icicle Spear  
- Rock Blast  
- Rapid Spin  
- Shell Smash  

";
$tt4381 = "Ferrothorn @ Colbur Berry  
Ability: Iron Barbs  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Body Press  
- Thunder Wave  
- Spikes  
- Sleep Talk  

";
$tt4392 = "Slowking-Galar @ Covert Cloak  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Scald  
- Chilly Reception  
- Slack Off  

";
$tt4403 = "Mawile @ Mawilite  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Seismic Toss  
- Power-Up Punch  
- Protect  
- Swords Dance  

";
$tt4413 = "Skeledirge @ Electric Seed  
Ability: Blaze  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Torch Song  
- Will-O-Wisp  
- Slack Off  
- Hex  

";
$tt4424 = "Talonflame @ Flyinium Z  
Ability: Gale Wings  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Brave Bird  
- Flare Blitz  
- Steel Wing  
- Swords Dance  

";
$tt4434 = "Tapu Fini @ Leftovers  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Taunt  
- Moonblast  

";
$tt4445 = "Dragonite @ Throat Spray  
Ability: Multiscale  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Quiet Nature  
- Dragon Tail  
- Roar  
- Roost  
- Hurricane  

";
$tt4455 = "Venusaur @ Throat Spray  
Ability: Overgrow  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Frenzy Plant  
- Sludge Bomb  
- Roar  
- Synthesis  

";
$tt4466 = "Blastoise @ Throat Spray  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Hydro Pump  
- Hidden Power [Fire]  
- Roar  
- Rapid Spin  

";
$tt4476 = "Garganacl @ Chesto Berry  
Ability: Clear Body  
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpD / 108 Spe  
Jolly Nature  
- Salt Cure  
- Tera Blast  
- Protect  
- Rest  

";
$tt4486 = "Zygarde @ Life Orb  
Ability: Aura Break  
Tera Type: &
EVs: 244 HP / 12 Atk / 252 SpD  
Careful Nature  
- Lands Wrath  
- Glare  
- Brick Break  
- Extreme Speed  

";
$tt4496 = "Lunatone @ Icium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 8 SpD / 248 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Blizzard  
- Meteor Beam  
- Substitute  



";
$tt4509 = "Gigalith @ Power Herb  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Meteor Beam  
- Hidden Power [Ice]  
- Earth Power  
- Stealth Rock  

";
$tt4520 = "Aerodactyl @ Power Herb  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Meteor Beam  
- Defog  
- Roost  
- Substitute  

";
$tt4531 = "Cyclizar @ Choice Band  
Ability: Regenerator  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Rapid Spin  
- Sleep Talk  

";
$tt4539 = "Meowscarada @ Heavy-Duty Boots  
Ability: Overgrow  
Tera Type: &
EVs: 56 HP / 252 Atk / 200 Spe  
Jolly Nature  
- Knock Off  
- Flower Trick  
- U-turn  
- Protect  

";
$tt4549 = "Quaquaval @ Covert Cloak  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 188 SpD / 68 Spe  
Jolly Nature  
- Aqua Step  
- Taunt  
- Roost  
- Bulk Up  

";
$tt4559 = "Mamoswine @ Loaded Dice  
Ability: Thick Fat  
Tera Type: &
EVs: 60 HP / 252 Atk / 196 Spe  
Adamant Nature  
- Earthquake  
- Icicle Spear  
- Rock Blast  
- Trailblaze  

";
$tt4569 = "Mesprit @ Heavy-Duty Boots  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 228 SpD / 28 Spe  
Careful Nature  
- Knock Off  
- Encore  
- Stealth Rock  
- U-turn  

";
$tt4579 = "Sceptile @ Flying Gem  
Ability: Unburden  
Tera Type: &
EVs: 160 HP / 252 Atk / 96 Spe  
Adamant Nature  
- Seed Bomb  
- Drain Punch  
- Acrobatics  
- Swords Dance  

";
$tt4589 = "Hydreigon @ Earth Plate  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Earth Power  
- Thunder Wave  
- Stealth Rock  

";
$tt4600 = "Kangaskhan (F) @ Assault Vest  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Return  
- Dig  
- Sucker Punch  
- Fake Out  

";
$tt4610 = "Coalossal @ Power Herb  
Ability: Flash Fire  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Meteor Beam  
- Burn Up  
- Flamethrower  
- Protect  

";
$tt4621 = "Drapion @ Life Orb  
Ability: Battle Armor  
Tera Type: &
EVs: 252 Atk / 20 SpD / 236 Spe  
Adamant Nature  
- Fire Fang  
- Poison Jab  
- Rest  
- Protect  

";
$tt4631 = "Zeraora @ Sitrus Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Tera Blast  
- Hidden Power [Ghost]  
- Protect  
- Calm Mind  

";
$tt4642 = "Jolteon @ Throat Spray  
Ability: Volt Absorb  
Tera Type: &
EVs: 72 HP / 252 SpA / 184 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Alluring Voice  
- Tera Blast  
- Volt Switch  

";
$tt4653 = "Mamoswine @ Choice Scarf  
Ability: Thick Fat  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Earthquake  
- Icicle Crash  
- Knock Off  
- Haze  

";
$tt4663 = "Celebi @ Tanga Berry  
Ability: Natural Cure  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Leech Seed  
- Substitute  
- Protect  
- Psychic  

";
$tt4674 = "Armaldo @ Rockium Z  
Ability: Battle Armor  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 SpD  
Careful Nature  
- Toxic  
- Protect  
- Substitute  
- Stone Edge  

";
$tt4684 = "Bruxish @ Throat Spray  
Ability: Strong Jaw  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Wave Crash  
- Psyshock  
- Scald  
- Screech  

";
$tt4694 = "Registeel @ Mail  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 124 Def / 136 SpD  
Careful Nature  
IVs: 0 Atk  
- Amnesia  
- Defense Curl  
- Seismic Toss  
- Rest  

";
$tt4705 = "Dusknoir @ Choice Scarf  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Trick  
- Disable  
- Rest  
- Seismic Toss  

";
$tt4716 = "Hariyama @ Coba Berry  
Ability: Thick Fat  
Tera Type: &
EVs: 136 Atk / 236 Def / 136 SpD  
Adamant Nature  
- Payback  
- Close Combat  
- Ice Punch  
- Bullet Punch  

";
$tt4726 = "Metagross @ Occa Berry  
Ability: Clear Body  
Tera Type: &
EVs: 80 HP / 156 Atk / 96 Def / 176 Spe  
Adamant Nature  
- Meteor Mash  
- Zen Headbutt  
- Ice Punch  
- Rock Tomb  

";
$tt4736 = "Dragonite @ Yache Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 116 Def / 140 SpA  
Rash Nature  
- Hidden Power [Bug]  
- Surf  
- Fire Blast  
- Extreme Speed  

";
$tt4746 = "Celebi @ Choice Scarf  
Ability: Natural Cure  
Tera Type: &
EVs: 140 Def / 172 SpA / 196 Spe  
Modest Nature  
IVs: 2 Atk / 30 Def  
- Grass Knot  
- Hidden Power [Ice]  
- Psychic  
- Earth Power  

";
$tt4757 = "Iron Thorns @ Air Balloon  
Ability: Quark Drive  
Tera Type: &
EVs: 248 HP / 140 Atk / 120 SpD  
Adamant Nature  
- Wild Charge  
- Ice Punch  
- Rock Blast  
- Substitute  

";
$tt4767 = "Abomasnow @ Weakness Policy  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Quiet Nature  
- Giga Drain  
- Blizzard  
- Aurora Veil  
- Ice Shard  

";
$tt4777 = "Tauros-Paldea-Aqua (M) @ Yache Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 144 Atk / 68 SpD / 44 Spe  
Adamant Nature  
- Substitute  
- Close Combat  
- Bulk Up  
- Raging Bull  

";
$tt4787 = "Lokix @ Assault Vest  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Axe Kick  
- First Impression  
- Sucker Punch  
- Lunge  

";
$tt4797 = "Farigiraf @ Petaya Berry  
Ability: Armor Tail  
Tera Type: &
EVs: 244 HP / 88 SpA / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Hyper Beam  
- Psychic  
- Trick Room  

";
$tt4808 = "Krookodile @ Iron Ball  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Counter  
- Bulk Up  
- Earthquake  
- Fling  

";
$tt4818 = "Arboliva @ Choice Specs  
Ability: Seed Sower  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Petal Dance  
- Hyper Beam  
- Dazzling Gleam  
- Earth Power  

";
$tt4829 = "Garganacl @ Life Orb  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 208 Atk / 52 SpD  
Adamant Nature  
- Heavy Slam  
- Salt Cure  
- Earthquake  
- Recover  

";
$tt4839 = "Pawmot @ Life Orb  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Mach Punch  
- Bulk Up  
- Double Shock  
- Play Rough  

";
$tt4849 = "Tsareena (F) @ Life Orb  
Ability: Queenly Majesty  
Tera Type: &
EVs: 252 HP / 64 Atk / 28 Def / 164 Spe  
Impish Nature  
- Play Rough  
- Power Whip  
- Charm  
- Synthesis  

";
$tt4859 = "Bronzong @ Weakness Policy  
Ability: Heatproof  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Relaxed Nature  
IVs: 0 Spe  
- Iron Defense  
- Body Press  
- Stored Power  
- Gyro Ball  

";
$tt4870 = "Bombirdier @ Assault Vest  
Ability: Rocky Payload  
Tera Type: &
EVs: 156 HP / 156 Atk / 4 SpD / 192 Spe  
Jolly Nature  
- Brave Bird  
- Knock Off  
- Stone Edge  
- Sucker Punch  

";
$tt4880 = "Clawitzer @ Choice Specs  
Ability: Mega Launcher  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Aura Sphere  
- Ice Beam  
- Dragon Pulse  
- Dark Pulse  

";
$tt4891 = "Kilowattrel @ Yache Berry  
Ability: Wind Power  
Tera Type: &
EVs: 252 HP / 56 Def / 200 SpD  
Timid Nature  
IVs: 0 Atk  
- Tailwind  
- Roost  
- Electro Ball  
- Feather Dance  

";
$tt4902 = "Orthworm @ Assault Vest  
Ability: Earth Eater  
Tera Type: &
EVs: 248 HP / 252 SpD  
Careful Nature  
- Metal Burst  
- Heavy Slam  
- Body Press  
- Earthquake  

";
$tt4912 = "Greninja @ Assault Vest  
Ability: Protean  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Brick Break  
- Waterfall  
- Ice Punch  
- Gunk Shot  

";
$tt4922 = "Toedscruel @ Sitrus Berry  
Ability: Mycelium Might  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Gentle Nature  
- Seed Bomb  
- Leech Seed  
- Mirror Coat  
- Acid Spray  

";
$tt4932 = "Lurantis @ Yache Berry  
Ability: Contrary  
Tera Type: &
EVs: 248 HP / 76 Atk / 184 Def  
Serious Nature  
- Leaf Storm  
- Worry Seed  
- Giga Drain  
- Brick Break  

";
$tt4942 = "Dachsbun @ Choice Band  
Ability: Well-Baked Body  
Tera Type: &
EVs: 248 HP / 252 Atk / 4 SpD / 4 Spe  
Adamant Nature  
- Ice Fang  
- Play Rough  
- Fire Fang  
- Body Press  

";
$tt4952 = "Gengar @ Air Balloon  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Hex  
- Acid Spray  
- Taunt  

";
$tt4963 = "Espathra @ Petaya Berry  
Ability: Speed Boost  
Tera Type: &
EVs: 244 HP / 224 Def / 28 SpA / 12 Spe  
Modest Nature  
IVs: 0 Atk  
- Lumina Crash  
- Protect  
- Substitute  
- Hyper Beam  

";
$tt4974 = "Brute Bonnet @ Assault Vest  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 164 Atk / 92 SpD  
Adamant Nature  
- Payback  
- Sucker Punch  
- Bullet Seed  
- Stomping Tantrum  

";
$tt4984 = "Quagsire @ Mental Herb  
Ability: Unaware  
Tera Type: &
EVs: 248 HP / 176 Def / 84 SpD  
Impish Nature  
- Counter  
- Toxic  
- Earthquake  
- Recover  

";
$tt4994 = "Revavroom @ Air Balloon  
Ability: Filter  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Adamant Nature  
- Spin Out  
- Shift Gear  
- Gunk Shot  
- Taunt  

";
$tt41004 = "Tentacruel @ Leftovers  
Ability: Rain Dish  
Tera Type: &
EVs: 128 HP / 128 SpA / 252 Spe  
Timid Nature  
- Substitute  
- Toxic  
- Dive  
- Brine  

";
$tt41014 = "Golisopod @ Expert Belt  
Ability: Emergency Exit  
Tera Type: &
EVs: 248 HP / 80 Def / 180 SpD  
Impish Nature  
- Swords Dance  
- Sucker Punch  
- Leech Life  
- Close Combat  

";
$tt41024 = "Tyranitar @ Roseli Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 152 HP / 112 Atk / 244 Spe  
Adamant Nature  
- Rock Tomb  
- Stomping Tantrum  
- Crunch  
- Heavy Slam  

";
$tt41034 = "Cloyster @ Chople Berry  
Ability: Skill Link  
Tera Type: &
EVs: 120 HP / 156 Atk / 232 Spe  
Lax Nature  
- Shell Smash  
- Rock Blast  
- Icicle Spear  
- Hydro Pump  

";
$tt41044 = "Toxtricity @ Assault Vest  
Ability: Punk Rock  
Tera Type: &
EVs: 192 HP / 156 SpA / 152 SpD / 8 Spe  
Modest Nature  
- Overdrive  
- Hex  
- Acid Spray  
- Nuzzle  

";
$tt41054 = "Articuno-Galar @ Metronome  
Ability: Competitive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Freezing Glare  
- Recover  
- U-turn  
- Reflect  

";
$tt41064 = "Gallade @ Sitrus Berry  
Ability: Steadfast  
Tera Type: &
EVs: 248 HP / 84 Atk / 148 Def / 28 Spe  
Adamant Nature  
- Bulk Up  
- Encore  
- Close Combat  
- Zen Headbutt  

";
$tt41074 = "Dragonite @ Charti Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 96 HP / 160 Atk / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Outrage  
- Superpower  
- Brick Break  

";
$tt41084 = "Infernape @ Custap Berry  
Ability: Blaze  
Tera Type: &
EVs: 20 Atk / 208 Def / 84 SpA / 196 Spe  
Naive Nature  
- Endure  
- Overheat  
- Close Combat  
- Swords Dance  

";
$tt41094 = "Farigiraf @ Choice Scarf  
Ability: Cud Chew  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Trick  
- Twin Beam  
- Shadow Ball  
- Charge Beam  

";
$tt41105 = "Zygarde-10% @ Liechi Berry  
Ability: Power Construct  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Dragon Tail  
- Thousand Waves  
- Bind  

";
$tt41115 = "Guzzlord @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 96 Def / 160 SpD  
Adamant Nature  
- Knock Off  
- Dragon Tail  
- Drain Punch  
- Outrage  

";
$tt41125 = "Comfey @ Mirror Herb  
Ability: Flower Veil  
Tera Type: &
EVs: 216 HP / 252 Atk / 40 Spe  
Adamant Nature  
- Knock Off  
- Swagger  
- Acrobatics  
- Synthesis  

";
$tt41135 = "Wigglytuff @ Choice Band  
Ability: Frisk  
Tera Type: &
EVs: 252 Atk / 128 Def / 128 SpD  
Adamant Nature  
- Double-Edge  
- Knock Off  
- Play Rough  
- Dynamic Punch  

";
$tt41145 = "Hoopa @ Choice Band  
Ability: Magician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Zen Headbutt  
- Knock Off  
- Phantom Force  
- Drain Punch  

";
$tt41155 = "Koffing @ Eviolite  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Pain Split  
- Sludge Bomb  
- Infestation  

";
$tt41166 = "Volcarona (F) @ Expert Belt  
Ability: Flame Body  
Tera Type: &
EVs: 240 HP / 52 SpD / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Quiver Dance  
- Bug Buzz  
- Mystical Fire  
- Roost  

";
$tt41177 = "Ninetales @ Eject Pack  
Ability: Drought  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Foul Play  
- Solar Beam  
- Encore  

";
$tt41188 = "Spectrier @ Weakness Policy  
Ability: Grim Neigh  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Shadow Ball  
- Taunt  
- Calm Mind  
- Will-O-Wisp  

";
$tt41199 = "Zarude @ Float Stone  
Ability: Leaf Guard  
Tera Type: &
EVs: 252 HP / 252 SpD  
Careful Nature  
- Fling  
- Jungle Healing  
- Knock Off  
- Rock Tomb  

";
$tt41209 = "Oricorio-Pau @ Kee Berry  
Ability: Dancer  
Tera Type: &
EVs: 248 HP / 56 Def / 76 SpA / 56 SpD / 72 Spe  
Modest Nature  
IVs: 0 Atk  
- Quiver Dance  
- Hurricane  
- Revelation Dance  
- Roost  

";
$tt41220 = "Oricorio-Pau @ Life Orb  
Ability: Dancer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Quiver Dance  
- Hurricane  
- Revelation Dance  
- Protect  

";
$tt41231 = "Oricorio-Pau @ Flying Gem  
Ability: Dancer  
Tera Type: &
EVs: 168 HP / 252 Atk / 88 Spe  
Adamant Nature  
- Swords Dance  
- Acrobatics  
- Tailwind  
- Substitute  

";
$tt41241 = "Oricorio-Sensu @ Flying Gem  
Ability: Dancer  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Acrobatics  
- Roost  
- U-turn  

";
$tt41251 = "Charizard @ Charizardite X  
Ability: Blaze  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Rock Tomb  
- Flare Blitz  
- Sunny Day  

";
$tt41261 = "(Tyranitar) @ Tyranitarite  
Ability: Sand Stream  
Tera Type: &
EVs: 48 HP / 28 Atk / 252 SpA / 180 Spe  
Lonely Nature  
- Rock Tomb  
- Dark Pulse  
- Earth Power  
- Flamethrower  

";
$tt41271 = "ichigo (Jynx) (F) @ Wide Lens  
Ability: Dry Skin  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Lovely Kiss  
- Substitute  
- Dream Eater  
- Fake Tears  

";

$tt41292 = "Bronzong @ Mental Herb  
Ability: Levitate  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 16 Def / 240 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Iron Defense  
- Toxic  
- Signal Beam  

";
$tt41304 = "Nuzleaf @ Lum Berry  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk / 30 SpA / 30 Spe  
- Sunny Day  
- Solar Beam  
- Hidden Power [Fire]  
- Dark Pulse  

";
$tt41315 = "Chesnaught) @ Assault Vest  
Ability: Overgrow  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Careful Nature  
- Superpower  
- Seed Bomb  
- Thunder Punch  
- Drain Punch  

";
$tt41325 = "(Heracross) @ Custap Berry  
Ability: Guts  
Tera Type: &
EVs: 248 HP / 236 Atk / 24 Spe  
Adamant Nature  
- Bulk Up  
- Endure  
- Low Kick  
- Megahorn  

";
$tt41335 = "(Amoonguss) @ Kee Berry  
Ability: Effect Spore  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Spore  
- Synthesis  
- Giga Drain  
- Clear Smog  

";
$tt41346 = "(Gengar) @ Gengarite  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Taunt  
- Shadow Ball  
- Sludge Wave  
- Focus Blast  

";
$tt41357 = "(Celebi) @ Colbur Berry  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 80 SpA / 160 SpD / 16 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Recover  
- Leaf Storm  
- Dazzling Gleam  

";
$tt41368 = "(Scolipede) @ Insect Plate  
Ability: Speed Boost  
Tera Type: &
EVs: 206 HP / 182 Atk / 120 Spe  
Jolly Nature  
- Protect  
- Swords Dance  
- Megahorn  
- Iron Defense  

";
$tt41378 = "(Shiftry) @ Life Orb  
Ability: Early Bird  
Shiny: Yes  
Happiness: 69  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Seed Bomb  
- Knock Off  
- Sucker Punch  

";
$tt41390 = "(Lanturn) @ Choice Specs  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 HP / 140 SpA / 116 SpD  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hydro Pump  
- Ice Beam  
- Surf  

";
$tt41401 = "(Aromatisse) @ Sitrus Berry  
Ability: Aroma Veil  
Tera Type: &
EVs: 252 HP / 40 Def / 216 SpD  
Calm Nature  
IVs: 0 Atk  
- Charm  
- Rain Dance  
- Moonblast  
- Rest  

";

$tt41446 = "(Mr. Mime) @ Choice Specs  
Ability: Filter  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Trick  
- Psyshock  
- Dazzling Gleam  
- Thunderbolt  

";
$tt41457 = "(Jirachi) @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 248 HP / 64 Atk / 84 Def / 68 SpA / 44 Spe  
Quiet Nature  
- Calm Mind  
- Thunderbolt  
- Hidden Power [Fighting]  
- Icy Wind  

";
$tt41467 = "Victreebel @ Leftovers  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 2 Atk / 30 SpA  
- Toxic  
- Encore  
- Hidden Power [Grass]  
- Synthesis  

";
$tt41478 = "(Lapras) (F) @ Petaya Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 72 HP / 248 SpA / 188 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA  
- Substitute  
- Icy Wind  
- Hidden Power [Grass]  
- Thunderbolt  

";
$tt41489 = "(Steelix) @ Leppa Berry  
Ability: Rock Head  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Torment  
- Protect  
- Earthquake  
- Tera Blast

";
$tt41500 = "(Clefable) @ Leppa Berry  
Ability: Cute Charm  
Tera Type: &
EVs: 252 HP / 140 Def / 36 SpA / 80 Spe  
Modest Nature  
IVs: 0 Atk  
- Rest  
- Calm Mind  
- Ice Beam  
- Encore  

";
$tt41512 = "Politoed @ Expert Belt  
Ability: Water Absorb  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 108 Def / 140 SpA / 12 Spe  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Toxic  
- Encore  
- Icy Wind  

";
$tt41524 = "(Heatran) @ Choice Scarf  
Ability: Flash Fire  
Shiny: Yes  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA  
- Overheat  
- Earth Power  
- Hidden Power [Grass]  
- Flash Cannon  

";
$tt41536 = "(Kangaskhan) @ Wide Lens  
Ability: Scrappy  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Jolly Nature  
- Protect  
- Disable  
- Substitute  
- Return  

";
$tt41547 = "(Yanmega) @ Life Orb  
Ability: Speed Boost  
Shiny: Yes  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA  
- Protect  
- Air Slash  
- Bug Buzz  
- Hidden Power [Grass]  

";
$tt41559 = "(Blissey) (F) @ Mail  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Calm Mind  
- Ice Beam  
- Grass Knot  

";
$tt41570 = "Rotom-Mow @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Shadow Ball  
- Leaf Storm  
- Thunderbolt  
- Signal Beam  

";
$tt41581 = "Jolteon @ Metronome  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Magnet Rise  
- Toxic  
- Thunderbolt  
- Fake Tears  

";
$tt41592 = "(Shaymin) @ Tanga Berry  
Ability: Natural Cure  
Tera Type: &
EVs: 8 HP / 252 SpA / 8 SpD / 240 Spe  
Modest Nature  
- Seed Flare  
- Air Slash  
- Quick Attack  
- Leech Seed  

";
$tt41602 = "(Bronzong) @ Mail  
Ability: Heatproof  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 196 SpD / 60 Spe  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Calm Mind  
- Extrasensory  
- Toxic  

";
$tt41614 = "(Dragonite) @ Expert Belt  
Ability: Inner Focus  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 100 Atk / 20 Def / 88 SpA / 48 Spe  
Naughty Nature  
- Fly  
- Extreme Speed  
- Surf  
- Outrage  

";
$tt41625 = "(Azelf) @ Colbur Berry  
Ability: Levitate  
Shiny: Yes  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Psychic  
- Fire Blast  
- Grass Knot  

";
$tt41637 = "(Quagsire) @ Chesto Berry  
Ability: Water Absorb  
Shiny: Yes  
Happiness: 0  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Rest  
- Curse  
- Amnesia  
- Frustration  

";
$tt41649 = "Houndoom @ Passho Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Dark Pulse  
- Overheat  
- Sucker Punch  
- Taunt  

";
$tt41659 = "Mesprit @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 184 HP / 112 SpA / 4 SpD / 208 Spe  
Modest Nature  
IVs: 0 Atk  
- Rest  
- Trick  
- Psychic  
- Thunderbolt  

";
$tt41670 = "(Silvally-Water) @ Water Memory  
Ability: RKS System  
Tera Type: &
EVs: 248 HP / 28 Atk / 176 Def / 56 Spe  
Impish Nature  
- Swords Dance  
- Laser Focus  
- Multi-Attack  
- Protect  

";
$tt41680 = "(Rillaboom) (F) @ Lum Berry  
Ability: Grassy Surge  
Tera Type: &
EVs: 248 HP / 100 Atk / 124 SpD / 36 Spe  
Adamant Nature  
- Grassy Glide  
- Knock Off  
- Wood Hammer  
- High Horsepower  

";
$tt41690 = "Kyurem @ Maranga Berry  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 136 Def / 68 SpD / 72 Spe  
Calm Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Earth Power  
- Noble Roar  
- Roost  

";
$tt41701 = "Hatterene (F) @ Babiri Berry  
Ability: Magic Bounce  
Tera Type: &
EVs: 248 HP / 164 Def / 96 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Psyshock  
- Mystical Fire  
- Dazzling Gleam  

";
$tt41712 = "Tapu Lele @ Petaya Berry  
Ability: Psychic Surge  
Tera Type: &
EVs: 248 HP / 120 SpA / 140 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Taunt  
- Psyshock  
- Moonblast  

";
$tt41723 = "Naganadel @ Choice Scarf  
Ability: Beast Boost  
Tera Type: &
EVs: 192 SpA / 144 SpD / 172 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Dragon Pulse  
- Sludge Bomb  
- Flamethrower  

";
$tt41734 = "Venusaur @ Sitrus Berry  
Ability: Overgrow  
Tera Type: &
EVs: 248 HP / 236 Def / 24 Spe  
Bold Nature  
IVs: 0 Atk  
- Giga Drain  
- Synthesis  
- Charm  
- Sludge Bomb  

";
$tt41745 = "(Latias) (F) @ Haban Berry  
Ability: Levitate  
Tera Type: &
EVs: 120 HP / 252 Def / 104 SpA / 32 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Toxic  
- Draco Meteor  
- Icy Wind  

";
$tt41756 = "(Victini) @ Passho Berry  
Ability: Victory Star  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Adamant Nature  
- V-create  
- Work Up  
- Bolt Strike  
- Quick Attack  

";
$tt41766 = "(Victini) @ Weakness Policy  
Ability: Victory Star  
Tera Type: &
EVs: 152 HP / 176 Atk / 28 Def / 112 SpA / 40 Spe  
Brave Nature  
- Work Up  
- V-create  
- Bolt Strike  
- Shadow Ball  

";
$tt41776 = "Iron Valiant @ Heavy-Duty Boots  
Ability: Quark Drive  
Tera Type: &
EVs: 124 HP / 252 SpA / 132 Spe  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Vacuum Wave  
- Hex  
- Hypnosis  

";
$tt41787 = "Scizor @ Mental Herb  
Ability: Technician  
Tera Type: &
EVs: 180 HP / 252 Atk / 76 Spe  
Adamant Nature  
- Swords Dance  
- Bullet Punch  
- Tera Blast  
- Knock Off  

";
$tt41797 = "Sableye @ Air Balloon  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 104 Def / 152 SpD  
Impish Nature  
- Will-O-Wisp  
- Recover  
- Knock Off  
- Encore  

";
$tt41807 = "Raging Bolt @ Magnet  
Ability: Protosynthesis  
Tera Type: &
EVs: 108 HP / 152 SpA / 248 Spe  
Timid Nature  
IVs: 20 Atk  
- Thunderbolt  
- Draco Meteor  
- Weather Ball  
- Thunderclap  

";
$tt41818 = "Ursaluna-Bloodmoon @ Assault Vest  
Ability: Minds Eye  
Tera Type: &
EVs: 64 HP / 68 SpA / 252 SpD / 124 Spe  
Modest Nature  
IVs: 0 Atk  
- Blood Moon  
- Earth Power  
- Vacuum Wave  
- Hyper Voice  

";
$tt41829 = "Chien-Pao @ Life Orb  
Ability: Sword of Ruin  
Tera Type: &
EVs: 160 HP / 252 Atk / 4 SpD / 92 Spe  
Adamant Nature  
- Crunch  
- Psychic Fangs  
- Icicle Crash  
- Taunt  

";
$tt41839 = "Uxie @ Sitrus Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 116 Def / 144 SpD  
Careful Nature  
- Future Sight  
- Thunder Wave  
- U-turn  
- Knock Off  

";
$tt41849 = "Empoleon @ Wacan Berry  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Atk / 144 Def / 108 SpD  
Careful Nature  
- Stealth Rock  
- Flip Turn  
- Earthquake  
- Roost  

";
$tt41859 = "Noivern @ Heavy-Duty Boots  
Ability: Frisk  
Tera Type: &
EVs: 68 HP / 252 SpA / 188 Spe  
Modest Nature  
IVs: 0 Atk  
- Hurricane  
- Draco Meteor  
- Focus Blast  
- Roost  

";
$tt41870 = "Archaludon @ Assault Vest  
Ability: Stamina  
Tera Type: &
EVs: 204 HP / 252 SpA / 52 Spe  
Modest Nature  
IVs: 0 Atk  
- Body Press  
- Draco Meteor  
- Electro Shot  
- Flash Cannon  

";
$tt41881 = "Latios (M) @ Eject Pack  
Ability: Levitate  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Luster Purge  
- Psyshock  
- Aura Sphere  

";
$tt41892 = "Moltres @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 248 HP / 228 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Flamethrower  
- Tera Blast  
- Sleep Talk  
- Roost  

";
$tt41903 = "Blastoise @ Red Card  
Ability: Torrent  
Tera Type: &
EVs: 248 HP / 108 Def / 96 SpA / 56 SpD  
Calm Nature  
- Surf  
- Yawn  
- Rapid Spin  
- Flip Turn  

";
$tt41913 = "Chesnaught @ Rocky Helmet  
Ability: Bulletproof  
Tera Type: &
EVs: 248 HP / 92 Def / 92 SpD / 76 Spe  
Impish Nature  
IVs: 0 Atk  
- Spikes  
- Leaf Storm  
- Spiky Shield  
- Leech Seed  

";
$tt41924 = "Muk @ Black Sludge  
Ability: Poison Touch  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Poison Jab  
- Knock Off  
- Toxic  
- Haze  

Greninja  
Ability: Battle Bond  
Tera Type: &
EVs: 96 HP / 252 Atk / 160 Spe  
Jolly Nature  
- Acrobatics  
- Low Kick  
- Night Slash  
- Swords Dance  

";
$tt41944 = "Machamp @ Lum Berry  
Ability: No Guard  
Tera Type: &
EVs: 200 HP / 248 Atk / 16 SpD / 44 Spe  
Adamant Nature  
- Bullet Punch  
- Dynamic Punch  
- Knock Off  
- Stone Edge  

";
$tt41954 = "Staraptor @ Sharp Beak  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Brave Bird  
- Close Combat  
- Roost  
- U-turn  

";
$tt41964 = "Vaporeon @ Weakness Policy  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 228 Def / 32 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Stored Power  
- Surf  
- Wish  

";
$tt41975 = "Annihilape @ Choice Scarf  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 Atk / 64 Def / 192 Spe  
Adamant Nature  
- Close Combat  
- Rage Fist  
- U-turn  
- Drain Punch  

";
$tt41985 = "Golem-Alola @ Custap Berry  
Ability: Galvanize  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- Endure  
- Explosion  
- Earthquake  
- Body Slam  

";
$tt41995 = "Landorus (M) @ Choice Scarf  
Ability: Sheer Force  
Tera Type: &
EVs: 128 Atk / 252 SpA / 128 Spe  
Hasty Nature  
- Earth Power  
- Psychic  
- U-turn  
- Crunch  

";
$tt42005 = "Samurott-Hisui @ Chople Berry  
Ability: Sharpness  
Tera Type: &
EVs: 252 Atk / 60 Def / 196 Spe  
Adamant Nature  
- Sucker Punch  
- Ceaseless Edge  
- Aerial Ace  
- Swords Dance  

";
$tt42015 = "Weavile @ Big Nugget  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fling  
- Ice Shard  
- Low Kick  
- Swords Dance  

";
$tt42025 = "Tyranitar @ Chople Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 168 Atk / 180 Def / 160 Spe  
Adamant Nature  
- Rock Polish  
- Earthquake  
- Stone Edge  
- Crunch  

";
$tt42035 = "Gallade (M) @ Galladite  
Ability: Steadfast  
Tera Type: &
EVs: 248 HP / 12 Atk / 44 SpD / 204 Spe  
Careful Nature  
- Close Combat  
- Bulk Up  
- Encore  
- Stone Edge  

";
$tt42045 = "Cinccino @ Leftovers  
Ability: Cute Charm  
Tera Type: &
EVs: 180 HP / 252 Def / 76 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Charm  
- Hyper Voice  
- Rest  

";
$tt42056 = "Tyranitar (F) @ Chesto Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Rock Slide  
- Crunch  
- Rest  

";
$tt42066 = "Tyranitar @ Chople Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 248 HP / 48 Atk / 208 Def / 4 SpD  
Adamant Nature  
- Taunt  
- Thunder Wave  
- Crunch  
- Stone Edge  

";
$tt42076 = "Shiftry @ Focus Sash  
Ability: Wind Rider  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Tailwind  
- Knock Off  
- Explosion  
- Leaf Blade  

";
$tt42086 = "Latias (F) @ Electric Gem  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder  
- Draco Meteor  
- Psychic  
- Energy Ball  

";
$tt42097 = "Rotom-Wash @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Volt Switch  
- Thunder Wave  
- Hex  

";
$tt42108 = "Darkrai @ Bright Powder  
Ability: Bad Dreams  
Tera Type: &
EVs: 200 HP / 100 Def / 32 SpA / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder Wave  
- Dark Pulse  
- Rest  
- Snore  

";
$tt42119 = "Articuno @ Mail  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Haze  
- Toxic  
- Gust  

";
$tt42130 = "Slowbro-Galar @ Assault Vest  
Ability: Regenerator  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 36 SpA / 224 SpD  
Modest Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Fire Blast  
- Ice Beam  
- Hydro Pump  

";
$tt42142 = "Shellos @ Eviolite  
Ability: Storm Drain  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Sassy Nature  
- Body Slam  
- Recover  
- Stealth Rock  
- Earth Power  

";
$tt42152 = "Slowbro-Galar @ Rocky Helmet  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
- Slack Off  
- Shell Side Arm  
- Light Screen  
- Yawn  

";
$tt42162 = "Zoroark-Hisui @ Salac Berry  
Ability: Illusion  
Tera Type: &
EVs: 56 HP / 252 SpA / 4 SpD / 196 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Shadow Ball  
- Focus Blast  
- Endure  

";
$tt42173 = "Shellos @ Eviolite  
Ability: Sticky Hold  
Tera Type: &
EVs: 248 HP / 184 Def / 76 SpD  
Bold Nature  
IVs: 0 Atk  
- Recover  
- Stealth Rock  
- Scald  
- Yawn  

";
$tt42184 = "Ogerpon-Wellspring (F) @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Encore  
- U-turn  
- Knock Off  
- Play Rough  

";
$tt42194 = "Diancie @ Assault Vest  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Brave Nature  
- Nature Power  
- Metronome  
- Spikes  
- Encore  

";
$tt42204 = "Blastoise @ White Herb  
Ability: Torrent  
Tera Type: &
EVs: 120 HP / 120 Atk / 252 SpA / 16 Spe  
Quiet Nature  
- Earthquake  
- Scald  
- Shell Smash  
- Water Spout  

";
$tt42214 = "Comfey @ Life Orb  
Ability: Triage  
Tera Type: &
EVs: 236 HP / 252 SpA / 20 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Draining Kiss  
- Stored Power  
- Substitute  

";
$tt42225 = "Darkrai @ Blunder Policy  
Ability: Bad Dreams  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Focus Blast  
- Nasty Plot  
- Sludge Bomb  

";
$tt42236 = "Kartana @ Choice Scarf  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Knock Off  
- Leaf Blade  
- Sacred Sword  
- Smart Strike  

";
$tt42246 = "Slowking-Galar @ Rocky Helmet  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 212 Def / 48 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Iron Defense  
- Slack Off  
- Stored Power  

";
$tt42257 = "Zapdos @ Life Orb  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Agility  
- Heat Wave  
- Hurricane  
- Roost  

";
$tt42268 = "Rotom-Wash @ Yache Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 92 Def / 168 SpD  
Bold Nature  
IVs: 0 Atk  
- Hydro Pump  
- Volt Switch  
- Will-O-Wisp  
- Pain Split  

";
$tt42279 = "Xurkitree @ Choice Scarf  
Ability: Beast Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Fling  
- Tail Glow  
- Discharge  
- Volt Switch  

";
$tt42289 = "Lugia @ Flying Gem  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Curse  
- Acrobatics  
- Dive  
- Dragon Tail  

";
$tt42299 = "Lugia @ Eject Pack  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Charge Beam  
- Psycho Boost  
- Aeroblast  
- Defog  

";
$tt42310 = "Shaymin-Sky @ Loaded Dice  
Ability: Serene Grace  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Bullet Seed  
- Tera Blast  
- Play Rough  

";
$tt42320 = "Groudon @ Eject Pack  
Ability: Drought  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Overheat  
- Thunder Wave  
- Solar Beam  

";
$tt42331 = "Groudon @ Soft Sand  
Ability: Drought  
Tera Type: &
EVs: 148 Atk / 108 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Dig  
- Smack Down  
- Facade  

";
$tt42341 = "Kyurem-White @ Red Card  
Ability: Turboblaze  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Icicle Spear  
- Dragon Tail  
- Scale Shot  

";
$tt42351 = "Necrozma-Dawn-Wings @ Loaded Dice  
Ability: Prism Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Photon Geyser  
- Knock Off  
- Rock Blast  

";
$tt42361 = "Necrozma-Dusk-Mane @ Light Ball  
Ability: Prism Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Calm Mind  
- Expanding Force  
- Flash Cannon  
- Fling  

";
$tt42371 = "Zygarde-10% @ Liechi Berry  
Ability: Power Construct  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Coil  
- Dragon Tail  
- Lands Wrath  

";
$tt42381 = "Rayquaza @ Flame Orb  
Ability: Air Lock  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Ascent  
- Defog  
- Sky Drop  
- Tailwind  

";
$tt42391 = "Yveltal @ Bright Powder  
Ability: Dark Aura  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Defog  
- Fly  
- Phantom Force  
- U-turn  

";
$tt42401 = "Slowbro-Galar @ Focus Band  
Ability: Quick Draw  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
- Nasty Plot  
- Psychic  
- Fire Blast  
- Shell Side Arm  

";
$tt42411 = "Exploud @ Throat Spray  
Ability: Soundproof  
Tera Type: &
EVs: 192 HP / 252 SpA / 64 Spe  
Modest Nature  
IVs: 0 Atk  
- Boomburst  
- Roar  
- Fire Blast  
- Focus Blast  

";
$tt42422 = "Tapu Bulu @ Maranga Berry  
Ability: Telepathy  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Swords Dance  
- Horn Leech  
- Substitute  
- Focus Punch  

";
$tt42432 = "Iron Thorns @ Choice Specs  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Power Gem  
- Thunderbolt  
- Ice Beam  
- Flamethrower  

";
$tt42443 = "Iron Thorns @ Choice Band  
Ability: Quark Drive  
Tera Type: &
EVs: 240 HP / 252 Atk / 16 Spe  
Adamant Nature  
- Stone Edge  
- Supercell Slam  
- Low Kick  
- Ice Punch  

";
$tt42453 = "Iron Thorns @ Loaded Dice  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Rock Blast  
- Supercell Slam  
- Ice Punch  

";
$tt42463 = "Carnivine @ Choice Band  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Brave Nature  
- Power Whip  
- Knock Off  
- Sleep Powder  
- Tera Blast  

";
$tt42473 = "Carnivine @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Energy Ball  
- Grass Knot  
- Sleep Powder  
- Tera Blast  

";
$tt42484 = "Lugia @ Throat Spray  
Ability: Multiscale  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic Noise  
- Hurricane  
- Rain Dance  
- Hydro Pump  

";
$tt42495 = "Golisopod @ Light Ball  
Ability: Emergency Exit  
Tera Type: &
EVs: 252 Atk / 252 SpD / 4 Spe  
Adamant Nature  
- Fling  
- Aqua Jet  
- First Impression  
- Sucker Punch  

";
$tt42505 = "Cherrim @ Choice Specs  
Ability: Flower Gift  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Energy Ball  
- Grass Knot  
- Tera Blast  
- Pollen Puff  

";
$tt42516 = "Cherrim @ Loaded Dice  
Ability: Flower Gift  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Bullet Seed  
- Tera Blast  
- Healing Wish  

";
$tt42526 = "Iron Boulder @ Power Herb  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 20 Atk  
- Meteor Beam  
- Psychic  
- Taunt  
- Tera Blast  

";
$tt42537 = "Enamorus-Therian (F) @ Fairy Gem  
Ability: Overcoat  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Iron Defense  
- Disarming Voice  
- Misty Explosion  

";
$tt42548 = "Morpeko @ Mirror Herb  
Ability: Hunger Switch  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Aura Wheel  
- Swagger  
- Knock Off  
- Baton Pass  

";
$tt42558 = "Zamazenta @ Choice Band  
Ability: Dauntless Shield  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Body Press  
- Wild Charge  
- Ice Fang  
- Heavy Slam  

";
$tt42568 = "Kingler @ Quick Claw  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Swords Dance  
- Liquidation  
- Knock Off  
- Superpower  

";
$tt42578 = "Rotom-Wash @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 96 Def / 116 SpA / 48 Spe  
Bold Nature  
- Thunderbolt  
- Hydro Pump  
- Will-O-Wisp  
- Nasty Plot  

";
$tt42588 = "Muk-Alola @ Aguav Berry  
Ability: Gluttony  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Snarl  
- Acid Spray  
- Recycle  
- Acid Armor  

";
$tt42599 = "Revavroom @ Air Balloon  
Ability: Filter  
Tera Type: &
EVs: 252 Atk / 224 Def / 32 Spe  
Adamant Nature  
- Shift Gear  
- Spin Out  
- Gunk Shot  
- Magnet Rise  

";
$tt42609 = "Polteageist @ Kasib Berry  
Ability: Cursed Body  
Tera Type: &
EVs: 248 HP / 84 SpD / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Shell Smash  
- Will-O-Wisp  
- Shadow Ball  
- Strength Sap  

";
$tt42620 = "Bellossom @ Mental Herb  
Ability: Chlorophyll  
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpA  
Bold Nature  
IVs: 0 Atk  
- Sleep Powder  
- Quiver Dance  
- Strength Sap  
- Petal Dance  

";
$tt42631 = "Brute Bigot (Brute Bonnet) @ Loaded Dice  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Spore  
- Bullet Seed  
- Sucker Punch  
- Trailblaze  

";
$tt42641 = "h&m dressing room (Weezing) @ Black Sludge  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Clear Smog  
- Sludge Wave  
- Acid Spray  

";
$tt42652 = "Greedent @ Chople Berry  
Ability: Cheek Pouch  
Tera Type: &
EVs: 252 HP / 60 Atk / 196 Def  
Adamant Nature  
- Counter  
- Earthquake  
- Belly Drum  
- Giga Impact  

";
$tt42662 = "Tauros-Paldea-Aqua (M) @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 252 Def / 4 Spe  
Adamant Nature  
- Bulk Up  
- Wave Crash  
- Close Combat  
- Wild Charge  

";
$tt42672 = "Mamoswine @ Chople Berry  
Ability: Thick Fat  
Tera Type: &
EVs: 240 HP / 52 Def / 216 SpD  
Careful Nature  
- Avalanche  
- Ice Shard  
- Earthquake  
- Heavy Slam  

";
$tt42682 = "Torterra @ White Herb  
Ability: Overgrow  
Tera Type: &
EVs: 152 HP / 252 Atk / 104 Spe  
Adamant Nature  
- Wood Hammer  
- Headlong Rush  
- Heavy Slam  
- Shell Smash  

";
$tt42692 = "Tentacruel @ Sitrus Berry  
Ability: Liquid Ooze  
Tera Type: &
EVs: 224 HP / 248 Def / 36 SpA  
Bold Nature  
IVs: 0 Atk  
- Acid Armor  
- Acid Spray  
- Rest  
- Surf  

";
$tt42703 = "Milotic @ Wacan Berry  
Ability: Marvel Scale  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Mirror Coat  
- Recover  

";
$tt42714 = "Darmanitan-Galar @ Booster Energy  
Ability: Zen Mode  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Icicle Crash  
- Taunt  
- U-turn  
- Flare Blitz  

";
$tt42724 = "Munkidori (M) @ Throat Spray  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Sludge Bomb  
- Focus Blast  
- Parting Shot  

";
$tt42735 = "Gyarados @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 80 HP / 252 Atk / 176 Spe  
Adamant Nature  
- Dragon Dance  
- Bounce  
- Dive  
- Taunt  

";
$tt42745 = "Tapu Bulu @ Choice Band  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Wood Hammer  

";
$tt42752 = "Tapu Bulu @ Choice Specs  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Energy Ball  
- Dazzling Gleam  
- Focus Blast  
- Hidden Power [Ice]  

";
$tt42763 = "Tapu Bulu @ Grassy Seed  
Ability: Grassy Surge  
Tera Type: &
EVs: 248 HP / 136 SpA / 124 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Stored Power  
- Synthesis  
- Dazzling Gleam  

";
$tt42774 = "Wobbuffet @ Eject Button  
Ability: Shadow Tag  
Tera Type: &
EVs: 69 HP / 187 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Encore  
- Safeguard  
- Tickle  
- Destiny Bond  

";
$tt42785 = "Wobbuffet @ Leftovers  
Ability: Shadow Tag  
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe  
Calm Nature  
IVs: 0 Atk  
- Charm  
- Amnesia  
- Safeguard  
- Destiny Bond  

";
$tt42796 = "Tapu Lele @ Choice Scarf  
Ability: Telepathy  
Tera Type: &
EVs: 56 HP / 12 Def / 236 SpA / 12 SpD / 192 Spe  
Modest Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Psyshock  
- Grass Knot  
- Natures Madness  

";
$tt42807 = "Kingler @ Choice Band  
Ability: Hyper Cutter  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Crabhammer  
- Hammer Arm  
- Knock Off  
- High Horsepower  

";
$tt42817 = "Kingler @ Choice Scarf  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- High Horsepower  
- Stomping Tantrum  
- X-Scissor  

";
$tt42827 = "Kingler @ Leftovers  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Harden  
- Amnesia  
- Knock Off  
- Rest  

";
$tt42837 = "Kingler @ Leftovers  
Ability: Shell Armor  
Tera Type: &
EVs: 248 HP / 4 Atk / 200 SpD / 56 Spe  
Adamant Nature  
- Agility  
- Dive  
- Dig  
- Attract  

";
$tt42847 = "Kingler @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Protect  
- Rain Dance  

";
$tt42858 = "Kingler @ Leftovers  
Ability: Hyper Cutter  
Tera Type: &
EVs: 248 HP / 252 SpD  
Adamant Nature  
- Curse  
- Amnesia  
- Protect  
- Dive  

";
$tt42868 = "Kingler @ Starf Berry  
Ability: Hyper Cutter  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Substitute  
- Dive  
- Knock Off  
- Crabhammer  

";
$tt42878 = "Kingler @ Icium Z  
Ability: Shell Armor  
Tera Type: &
EVs: 144 HP / 112 Atk / 252 Spe  
Naive Nature  
- Haze  
- Whirlpool  
- Substitute  
- Knock Off  

";
$tt42888 = "Kingler @ Leftovers  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Attract  
- Knock Off  
- Liquidation  

";
$tt42898 = "Kingler @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Agility  
- Swords Dance  
- Liquidation  
- Body Slam  

";
$tt42908 = "Kingler @ Maranga Berry  
Ability: Shell Armor  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Relaxed Nature  
- Rest  
- Sleep Talk  
- Scald  
- Knock Off  

";
$tt42918 = "Kingler @ Leftovers  
Ability: Hyper Cutter  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA  
Naughty Nature  
- Bide  
- Knock Off  
- Whirlpool  
- Dig  

";
$tt42928 = "Kingler @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Knock Off  
- Protect  
- Quash  

";
$tt42938 = "Drampa @ Choice Specs  
Ability: Berserk  
Tera Type: &
EVs: 100 HP / 200 SpA / 208 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Fire Blast  
- Hyper Voice  
- Defog  

";
$tt42949 = "Blacephalon @ Life Orb  
Ability: Beast Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Shadow Ball  
- Quash  
- Encore  

";
$tt42960 = "Raikou @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Quash  
- Volt Switch  
- Scald  
- Roar  

";
$tt42971 = "Sableye @ Leftovers  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Quash  
- Encore  
- Disable  
- Night Shade  

";
$tt42982 = "Entei @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Quash  
- Sacred Fire  
- Extreme Speed  
- Toxic  

";
$tt42992 = "Shedinja @ Safety Goggles  
Ability: Wonder Guard  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Mud-Slap  
- Endure  
- Toxic  
- Sand Attack  

";
$tt43003 = "Suicune @ Metronome  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Quash  
- Bulldoze  
- Mirror Coat  
- Brine  

";
$tt43013 = "Suicune @ Water Gem  
Ability: Pressure  
Tera Type: &
EVs: 128 HP / 248 SpA / 132 Spe  
Modest Nature  
- Calm Mind  
- Hydro Pump  
- Ice Beam  
- Trailblaze  

";
$tt43023 = "Tornadus @ Kings Rock  
Ability: Defiant    
Tera Type: &
EVs: 4 HP / 204 Atk / 44 Def / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- Hammer Arm  
- Fling  
- Protect  

";
$tt43033 = "Delphox @ Focus Sash  
Ability: Blaze    
Tera Type: &
EVs: 52 HP / 204 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Expanding Force  
- Heat Wave  
- Nasty Plot  
- Protect  

";
$tt43044 = "Regice @ Life Orb  
Ability: Ice Body    
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Thunderbolt  
- Tera Blast  
- Protect  

";
$tt43055 = "Exeggutor @ Life Orb  
Ability: Chlorophyll    
Tera Type: &
EVs: 220 HP / 4 Def / 196 SpA / 4 SpD / 84 Spe  
Modest Nature  
IVs: 0 Atk  
- Sleep Powder  
- Expanding Force  
- Leaf Storm  
- Sunny Day  

";
$tt43066 = "Cobalion @ Covert Cloak  
Ability: Justified    
Tera Type: &
EVs: 84 HP / 4 Atk / 164 Def / 4 SpD / 252 Spe  
Jolly Nature  
- Body Press  
- Heavy Slam  
- Iron Defense  
- Protect  

";
$tt43076 = "Pincurchin (M) @ Assault Vest  
Ability: Electric Surge  
Tera Type: &
EVs: 252 HP / 6 Def / 252 SpD  
Relaxed Nature  
IVs: 26 Spe  
- Sucker Punch  
- Discharge  
- Electroweb  
- Scald  

";
$tt43087 = "Iron Leaves @ Clear Amulet  
Ability: Quark Drive  
Tera Type: &
EVs: 156 Atk / 102 Def / 252 Spe  
Jolly Nature  
- Psyblade  
- Leaf Blade  
- Electric Terrain  
- Sacred Sword  

";
$tt43097 = "Bruxish @ Choice Scarf  
Ability: Dazzling   
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Wave Crash  
- Psychic Fangs  
- Icy Wind  
- Flip Turn  

";
$tt43107 = "Cobalion @ Assault Vest  
Ability: Justified    
Tera Type: &
EVs: 252 HP / 3 Atk / 252 Def / 3 SpA  
Impish Nature  
- Body Press  
- Heavy Slam  
- Volt Switch  
- Upper Hand  



";
$tt43119 = "Lugia @ Choice Specs  
Ability: Multiscale  
Tera Type: &
EVs: 252 HP / 112 SpA / 144 Spe  
Timid Nature  
IVs: 0 Atk  
- Aeroblast  
- Ice Beam  
- Chilling Water  
- Dragon Pulse  

";
$tt43130 = "Xerneas @ Power Herb  
Ability: Fairy Aura 
Level: 90   
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Geomancy  
- Hidden Power [Ghost]  
- Echoed Voice  
- Swift  

";
$tt43141 = "Lucario @ Lucarionite  
Ability: Justified  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Iron Tail  
- Aura Sphere  
- Vacuum Wave  
- Tera Blast  

";
$tt43151 = "Manaphy @ Leftovers  
Ability: Hydration  
Tera Type: &
EVs: 84 HP / 252 SpA / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Rain Dance  
- Tail Glow  
- Aqua Ring  
- Surf  

";
$tt43162 = "Tatsugiri @ Expert Belt  
Ability: Storm Drain  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Soak  
- Tera Blast  
- Surf  
- Draco Meteor  

";
$tt43173 = "Gliscor @ Red Card  
Ability: Sand Veil  
Tera Type: &
EVs: 252 HP / 184 Def / 72 Spe  
Impish Nature  
- Substitute  
- Swords Dance  
- Sandstorm  
- Earthquake  

";
$tt43183 = "Deoxys-Attack @ Fighting Gem  
Ability: Pressure  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Substitute  
- Focus Punch  
- Psyshock  
- Hidden Power [Rock]  

";
$tt43193 = "Zygarde @ Choice Scarf  
Ability: Aura Break  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Thousand Arrows  
- Dragon Pulse  
- Dragon Tail  
- Superpower  

";
$tt43203 = "Corviknight @ Power Herb  
Ability: Mirror Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Substitute  
- Bulk Up  
- Sky Attack  
- U-turn

";
$tt43213 = "Darmanitan-Galar @ Assault Vest  
Ability: Gorilla Tactics  
Tera Type: &
EVs: 252 Atk / 252 Spe  
Adamant Nature  
IVs: 0 Atk  
- Encore  
- Bulk Up
- Substitute
- Yawn

";
$tt43224 = "Golurk @ Expert Belt  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Poltergeist  
- Earthquake  
- Power-Up Punch  
- Rock Polish  

";
$tt43234 = "Iron Treads @ Steel Gem  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Electric Terrain  
- Steel Roller  
- Rollout  
- Substitute  

";
$tt43244 = "Shiinotic @ Focus Sash  
Ability: Effect Spore  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Spore  
- Moonblast  
- Solar Beam  
- Strength Sap  

";
$tt43255 = "Starmie @ Weakness Policy  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 140 SpA / 116 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Psyshock  
- Blizzard  
- Spotlight  

";
$tt43266 = "Ariados @ Focus Sash  
Ability: Insomnia  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Sticky Web  
- Baton Pass  
- Infestation  
- Bug Buzz  

";
$tt43277 = "Pheromosa @ Buginium Z  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- U-turn  
- Substitute  
- Icy Wind  
- Drill Run  

";
$tt43287 = "Krookodile @ Leftovers  
Ability: Moxie  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Power Trip  
- Earthquake  
- Sand Attack  

";
$tt43297 = "Tyranitar @ Assault Vest  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Quirky Nature  
- Counter  
- Crunch  
- Pursuit  
- Outrage  

";
$tt43307 = "Medicham @ Psychium Z  
Ability: Pure Power  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Hasty Nature  
- Acupressure  
- Psych Up  
- High Jump Kick  
- Psychic  

";
$tt43317 = "Victini @ Leftovers  
Ability: Victory Star  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Substitute  
- Swagger  
- Psych Up  
- Bolt Strike  

";
$tt43327 = "Jumpluff @ Flying Gem  
Ability: Infiltrator  
Shiny: Yes  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Encore  
- Synthesis  
- Acrobatics  
- U-turn  

";
$tt43338 = "Fraxure @ Eviolite  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Taunt  
- Outrage  
- Superpower  

";
$tt43348 = "Klang @ Eviolite  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 156 Def / 100 SpD  
Impish Nature  
- Volt Switch  
- Gear Grind  
- Rest  
- Sleep Talk  

";
$tt43358 = "Beheeyem @ Psychium Z  
Ability: Analytic  
Tera Type: &
EVs: 248 HP / 236 Def / 16 SpA / 8 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Psychic  
- Signal Beam  
- Recover  

";
$tt43369 = "Marowak @ Thick Club  
Ability: Rock Head  
Tera Type: &
EVs: 248 HP / 248 SpD / 12 Spe  
Careful Nature  
- Stealth Rock  
- Bonemerang  
- Stone Edge  
- Double-Edge  

";
$tt43379 = "Volcarona @ Flyinium Z  
Ability: Swarm  
Tera Type: &
EVs: 132 HP / 56 Def / 124 SpA / 196 Spe  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Quiver Dance  
- Hurricane  
- Hidden Power [Ground]  

";
$tt43390 = "Zapdos-Galar @ Choice Band  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Blaze Kick  
- Brave Bird  
- U-turn  
- Tailwind  

";
$tt43400 = "Lilligant-Hisui @ Leftovers  
Ability: Hustle  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Entrainment  
- Substitute  
- Leech Seed  
- Aromatherapy  

";
$tt43411 = "Kartana @ Liechi Berry  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Endure  
- Leaf Blade  
- Smart Strike  
- Sacred Sword

";
$tt43421 = "Cresselia (F) @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
IVs: 0 Atk  
- Rest  
- Psycho Shift  
- Sleep Talk  
- Ice Beam  

";
$tt43432 = "Delibird @ Choice Band  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Brave Bird  
- Ice Spinner  
- Drill Run  
- Tera Blast  

";
$tt43442 = "Scyther @ Liechi Berry  
Ability: Swarm  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Acrobatics  
- Lunge  
- Close Combat  

";
$tt43452 = "Garchomp @ Garchompite  
Ability: Rough Skin  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Facade  
- Stomping Tantrum  
- Toxic  
- Stealth Rock  

";
$tt43462 = "Blissey (F) @ Blunder Policy  
Ability: Serene Grace  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Blizzard  
- Fire Blast  
- Thunder  
- Soft-Boiled  

";
$tt43473 = "Golisopod @ Adrenaline Orb  
Ability: Emergency Exit  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Leech Life  
- Liquidation  
- Swords Dance  
- Iron Defense  

";
$tt43483 = "Porygon-Z @ Iron Ball  
Ability: Analytic  
Tera Type: &
EVs: 252 Def / 252 SpA  
Relaxed Nature  
IVs: 0 Atk  
- Tri Attack  
- Nasty Plot  
- Trick  
- Trick Room  

";
$tt43494 = "Arctovish @ Leftovers  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Hail  
- Fishious Rend  
- Icicle Crash  
- Aurora Veil  

";
$tt43504 = "Sableye @ Sablenite  
Ability: Stall  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Skill Swap  
- Knock Off  
- Recover  
- Will-O-Wisp  

";
$tt43514 = "PIKACHU_WRLD (Pikachu-World) (M) @ Light Ball  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Fake Out  
- Volt Tackle  
- Volt Switch  
- Tera Blast  

Delphox  
Ability: Magician  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Flame Charge  
- Overheat  
- Wish  
- Protect  

";
$tt43534 = "Hippopotas @ Eviolite  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Slack Off  
- Stone Edge  
- Curse  
- High Horsepower  

";
$tt43544 = "Vikavolt @ Assault Vest  
Ability: Levitate  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 SpD  
Modest Nature  
IVs: 0 Atk  
- Volt Switch  
- Bug Buzz  
- Thunderbolt  
- Energy Ball  

";
$tt43555 = "Electrode-Hisui @ Red Card  
Ability: Static  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Electric Terrain  
- Leech Seed  
- Volt Switch  
- Explosion  

";
$tt43565 = "Aerodactyl @ Aerodactylite  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Psychic Fangs  
- Stone Edge  
- Aqua Tail  

";
$tt43575 = "Slowbro-Galar @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 252 Def / 4 SpA / 252 SpD  
Quiet Nature  
- Fire Blast  
- Future Sight  
- Grass Knot  
- Shell Side Arm  

";
$tt43585 = "Espathra @ Choice Specs  
Ability: Opportunist  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Lumina Crash  
- Dazzling Gleam  

";
$tt43594 = "Archeops @ Leftovers  
Ability: Defeatist  
Tera Type: &
EVs: 252 HP / 252 Def  
Bold Nature  
IVs: 0 Atk  
- Sandstorm  
- Roost  
- Toxic  
- Protect  

";
$tt43605 = "Gallade (M) @ Mirror Herb  
Ability: Sharpness  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Psycho Cut  
- Sacred Sword  
- Encore  
- Recycle  

";
$tt43615 = "Xerneas @ Lansat Berry  
Ability: Fairy Aura  
Level: 90  
Tera Type: &
EVs: 152 HP / 104 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Dazzling Gleam  
- Snore

";
$tt43626 = "Shaymin-Sky @ Grass Gem  
Ability: Serene Grace  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Swords Dance  
- Bullet Seed  
- Tera Blast  
- Last Resort

";
$tt43636 = "Dragalge @ Assault Vest  
Ability: Adaptability  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Dragon Pulse  
- Thunderbolt  
- Hydro Pump  
- Sludge Bomb  

";
$tt43647 = "Amoonguss @ Rocky Helmet  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 224 Def / 36 SpA  
Bold Nature  
IVs: 0 Atk  
- Pollen Puff  
- Sludge Bomb  
- Foul Play  
- Spore  

";
$tt43658 = "Garchomp @ Rocky Helmet  
Ability: Rough Skin  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Endure  
- Earthquake  
- Dragon Tail  
- Spikes  

";
$tt43668 = "Tapu Bulu @ Coba Berry  
Ability: Grassy Surge  
Happiness: 0  
Tera Type: &
EVs: 156 HP / 72 Atk / 252 Def / 28 Spe  
Adamant Nature  
- Swords Dance  
- Horn Leech  
- Frustration  
- Superpower  

";
$tt43679 = "Regidrago @ Razor Claw  
Ability: Dragons Maw  
Tera Type: &
EVs: 216 Atk / 104 Def / 36 SpD / 152 Spe  
Adamant Nature  
- Focus Energy  
- Dragon Dance  
- Draco Meteor  
- Earthquake  

";
$tt43689 = "Raikou @ Scope Lens  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 160 Def / 84 SpA / 16 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA  
- Thunderbolt  
- Hidden Power [Grass]  
- Rest  
- Calm Mind  

";
$tt43700 = "Dragonite @ Never-Melt Ice  
Ability: Inner Focus  
Tera Type: &
EVs: 60 Atk / 252 SpA / 196 Spe  
Lonely Nature  
- Aerial Ace  
- Earthquake  
- Ice Beam  
- Dragon Dance  

";
$tt43710 = "Alakazam @ Twisted Spoon  
Ability: Synchronize  
Tera Type: &
EVs: 120 HP / 252 Def / 12 SpA / 124 Spe  
Bold Nature  
IVs: 0 Atk  
- Psychic  
- Encore  
- Counter  
- Calm Mind  

";
$tt43721 = "Swampert @ Float Stone  
Ability: Torrent  
Tera Type: &
EVs: 196 HP / 252 SpA / 60 SpD  
Quiet Nature  
- Hydro Pump  
- Stealth Rock  
- Ice Beam  
- Flip Turn  

";
$tt43731 = "Hoopa-Unbound @ Weakness Policy  
Ability: Magician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Wonder Room  
- Gunk Shot  
- Zen Headbutt  
- Hyperspace Fury  

";
$tt43741 = "Hoopa-Unbound @ Roseli Berry  
Ability: Magician  
Tera Type: &
EVs: 4 Atk / 252 SpD / 252 Spe  
Jolly Nature  
- Wonder Room  
- Hyperspace Fury  
- Zen Headbutt  
- Drain Punch  

";
$tt43751 = "Archaludon @ Scope Lens  
Ability: Stamina  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Sleep Talk  
- Rest  
- Focus Energy  

";
$tt43762 = "Sinistcha-Masterpiece @ Sitrus Berry  
Ability: Hospitality  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 180 Def / 76 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Matcha Gotcha  
- Nasty Plot  
- Trick Room  
- Life Dew  

";
$tt43774 = "Kyurem @ Assault Vest  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 128 HP / 252 SpA / 128 SpD  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Earth Power  
- Freeze-Dry  
- Flash Cannon  

";
$tt43786 = "Ninetales-Alola (F) @ Light Clay  
Ability: Snow Warning  
Shiny: Yes  
Tera Type: &
EVs: 92 HP / 164 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Aurora Veil  
- Blizzard  
- Encore  
- Protect  

";
$tt43798 = "Glimmora @ Power Herb  
Ability: Toxic Debris  
Tera Type: &
EVs: 148 HP / 252 SpA / 108 Spe  
Modest Nature  
IVs: 0 Atk  
- Meteor Beam  
- Earth Power  
- Sludge Bomb  
- Spiky Shield  

";
$tt43809 = "Excadrill @ Clear Amulet  
Ability: Sand Rush  
Tera Type: &
EVs: 12 HP / 244 Atk / 252 Spe  
Adamant Nature  
- Iron Head  
- High Horsepower  
- Swords Dance  
- Protect  

";
$tt43819 = "Mew @ Covert Cloak  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 88 SpD / 168 Spe  
Calm Nature  
IVs: 0 Atk  
- Coaching  
- Pollen Puff  
- Will-O-Wisp  
- Tailwind  

";
$tt43830 = "Iron Moth @ Power Herb  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Sludge Wave  
- Meteor Beam  
- Protect  

";
$tt43841 = "Corviknight @ Maranga Berry  
Ability: Mirror Armor  
Tera Type: &
EVs: 248 HP / 52 Def / 208 SpD  
Calm Nature  
- Brave Bird  
- Bulk Up  
- Body Press  
- Roost  

";
$tt43851 = "Blaziken @ Clear Amulet  
Ability: Speed Boost  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Blaze Kick  
- Swords Dance  
- Close Combat  
- Protect  

";
$tt43861 = "Entei @ Assault Vest  
Ability: Inner Focus  
Tera Type: &
EVs: 228 HP / 252 Atk / 28 Spe  
Adamant Nature  
- Sacred Fire  
- Stomping Tantrum  
- Extreme Speed  
- Snarl  

";
$tt43871 = "Raging Bolt @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 20 Atk  
- Thunderclap  
- Tera Blast  
- Calm Mind  
- Protect  

";
$tt43882 = "Suicune @ Safety Goggles  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 172 Def / 84 SpD  
Calm Nature  
IVs: 0 Atk  
- Scald  
- Snarl  
- Roar  
- Protect  

";
$tt43895 = "Archaludon @ Leftovers  
Ability: Stamina  
Tera Type: &
EVs: 252 HP / 20 SpA / 236 SpD  
Modest Nature  
IVs: 0 Atk  
- Electro Shot  
- Flash Cannon  
- Body Press  
- Protect  

";
$tt43906 = "Porygon2 @ Eviolite  
Ability: Download  
Tera Type: &
EVs: 252 HP / 92 Def / 164 SpD  
Sassy Nature  
IVs: 0 Spe  
- Tera Blast  
- Ice Beam  
- Trick Room  
- Recover  

";
$tt43917 = "Pelipper @ Damp Rock  
Ability: Drizzle  
Tera Type: &
EVs: 252 HP / 16 Def / 240 SpD  
Bold Nature  
IVs: 0 Atk  
- Hurricane  
- Weather Ball  
- Wide Guard  
- Helping Hand  

";
$tt43928 = "Dragonite @ Choice Band  
Ability: Inner Focus  
Tera Type: &
EVs: 156 HP / 252 Atk / 100 Spe  
Adamant Nature  
- Extreme Speed  
- Low Kick  
- Aerial Ace  
- Stomping Tantrum  

";
$tt43938 = "Deoxys-Speed @ Covert Cloak  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 140 Def / 100 SpD / 16 Spe  
Timid Nature  
IVs: 0 Atk  
- Psycho Boost  
- Taunt  
- Stealth Rock  
- Spikes  

";
$tt43949 = "Dugtrio @ Focus Sash  
Ability: Arena Trap  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
IVs: 0 HP  
- Stealth Rock  
- Endeavor  
- Sucker Punch  
- Protect  

";
$tt43960 = "Suicune @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Substitute  
- Protect  
- Calm Mind  

";
$tt43971 = "Heracross @ Choice Band  
Ability: Swarm  
Tera Type: &
EVs: 96 HP / 16 Atk / 252 SpD / 144 Spe  
Adamant Nature  
- Megahorn  
- Close Combat  
- Earthquake  
- Stone Edge  

";
$tt43981 = "Raikou @ Choice Specs  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 64 Def / 192 SpA / 252 Spe  
Rash Nature  
IVs: 30 HP / 2 Atk / 30 Def / 30 SpA / 30 SpD  
- Thunderbolt  
- Aura Sphere  
- Shadow Ball  
- Hidden Power [Flying]  

";
$tt43993 = "Tapu Bulu @ Mental Herb  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Wood Hammer  
- Leech Seed  
- Substitute  
- Swords Dance  

";
$tt44003 = "Entei @ Weakness Policy  
Ability: Inner Focus  
Tera Type: &
EVs: 16 HP / 24 Atk / 252 Def / 216 Spe  
Adamant Nature  
- Sacred Fire  
- Will-O-Wisp  
- Flare Blitz  
- Extreme Speed  

";
$tt44013 = "Hariyama @ Toxic Orb  
Ability: Guts  
Tera Type: &
EVs: 40 Atk / 236 Def / 136 SpD / 96 Spe  
Adamant Nature  
- Close Combat  
- Ice Punch  
- Bullet Punch  
- Fake Out  

";
$tt44023 = "Ribombee @ Covert Cloak  
Ability: Shield Dust  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Sticky Web  
- Moonblast  
- Bug Buzz  
- Pounce  

";
$tt44033 = "Walrein @ Mystic Water  
Ability: Thick Fat  
Tera Type: &
EVs: 32 HP / 224 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Ice Beam  
- Encore  
- Icy Wind  

";
$tt44044 = "Medicham @ Medichamite  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Bulk Up  
- Trailblaze  
- Close Combat  
- Psycho Cut  

";
$tt44054 = "Medicham @ Covert Cloak  
Ability: Pure Power  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Drain Punch  
- Trailblaze  
- Recover  
- Bulk Up  

Medicham  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Jump Kick  
- Thief  
- Mind Reader  
- Dynamic Punch  

";
$tt44074 = "Medicham @ Blunder Policy  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dynamic Punch  
- Acupressure  
- Baton Pass  
- Zen Headbutt  

";
$tt44084 = "Seismitoad @ Expert Belt  
Ability: Water Absorb  
Tera Type: &
EVs: 172 HP / 252 SpA / 4 SpD / 80 Spe  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Hydro Pump  
- Earth Power  
- Hidden Power [Fire]  

";
$tt44095 = "Alakazam @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 44 Atk / 212 SpA / 252 Spe  
Naive Nature  
- Psychic  
- Fire Punch  
- Charge Beam  
- Focus Punch  

";
$tt44105 = "Gliscor @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 108 HP / 252 Atk / 148 Spe  
Adamant Nature  
- Acrobatics  
- Fling  
- Swords Dance  
- Bulldoze  

";
$tt44115 = "Jirachi @ Colbur Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 244 HP / 12 Atk / 252 Spe  
Jolly Nature  
- Stealth Rock  
- Healing Wish  
- Meteor Mash  
- U-turn  

";
$tt44125 = "Yanmega @ Focus Sash  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Leech Life  
- Reversal  
- Hypnosis  

";
$tt44135 = "Blissey (F) @ Iron Ball  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Fling  
- Seismic Toss  
- Soft-Boiled  
- Thunder Wave  

";
$tt44145 = "Zacian @ Metronome  
Ability: Intrepid Sword  
Level: 90  
Tera Type: &
EVs: 84 Atk / 252 SpA / 172 Spe  
Hasty Nature  
- Work Up  
- Moonblast  
- Crunch  
- Dig  

";
$tt44156 = "Zacian-Crowned @ Rusted Sword  
Ability: Intrepid Sword  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Work Up  
- Steel Beam  

";
$tt44167 = "Zacian-Crowned @ Rusted Sword  
Ability: Intrepid Sword  
Tera Type: &
EVs: 69 SpA  
Jolly Nature  
- Howl  
- Behemoth Blade  
- Retaliate  
- Revenge  

";
$tt44177 = "Yveltal @ Flying Gem  
Ability: Dark Aura  
Tera Type: &
EVs: 92 Atk / 200 Spe  
Quirky Nature  
IVs: 3 HP  
- Substitute  
- Disable  
- Acrobatics  
- Thief  

";
$tt44187 = "Yveltal @ Metronome  
Ability: Dark Aura  
Tera Type: &  
EVs: 1 HP / 1 Atk / 1 Def / 1 SpA / 1 SpD / 1 Spe  
IVs: 0 HP / 0 Atk / 15 Def / 28 SpA / 15 SpD  
- Oblivion Wing  

";
$tt44193 = "Yveltal @ Choice Scarf  
Ability: Dark Aura  
Tera Type: &
EVs: 44 Atk / 12 Spe  
Docile Nature  
- Foul Play  
- U-turn  
- Defog  
- Lash Out  

";
$tt44203 = "Yveltal @ Expert Belt  
Ability: Dark Aura  
Tera Type: &
EVs: 252 Atk / 56 Def / 128 SpA / 72 Spe  
Gentle Nature  
IVs: 0 Atk  
- Psychic  
- Focus Blast  
- Shadow Ball  
- Heat Wave  

";
$tt44214 = "Eternatus @ Heat Rock  
Ability: Pressure  
Tera Type: &
EVs: 56 SpA / 92 Spe  
Timid Nature  
IVs: 0 HP / 0 Atk / 0 Def / 0 SpD  
- Sunny Day  
- Solar Beam  
- Flamethrower  
- Gravity  

";
$tt44225 = "Zekrom @ Wide Lens  
Ability: Teravolt  
Level: 90  
Tera Type: &
EVs: 112 Atk / 112 Spe  
- Substitute  
- Dragon Dance  
- Dragon Tail  
- Fly  

";
$tt44235 = "Groudon @ Choice Scarf  
Ability: Drought  
Level: 90  
Tera Type: &  
EVs: 252 Atk / 252 Spe  
Jolly Nature  
- Stomping Tantrum  
- Rock Blast  
- Heat Crash  
- Dragon Tail  

";
$tt44245 = "Kyogre @ Muscle Band  
Ability: Drizzle  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Liquidation  
- Body Slam  
- Tera Blast  
- Bulldoze  

";
$tt44255 = "Kyogre @ Splash Plate  
Ability: Drizzle  
Tera Type: &
EVs: 252 Atk / 116 SpA / 140 Spe  
Adamant Nature  
- Dive  
- Brine  
- Muddy Water  
- Rain Dance  

";
$tt44265 = "Ho-Oh @ Toxic Orb  
Ability: Regenerator  
Level: 90  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Curse  
- Facade  
- Fly  
- Nightmare  

";

$fb41 = "Togekiss @ Silk Scarf  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 132 Def / 108 SpA / 16 Spe  
Naughty Nature  
- Work Up  
- Extreme Speed  
- Drain Punch  
- Air Slash

";
$fb410 = "Celesteela @ Weakness Policy  
Ability: Beast Boost  
Tera Type: &
EVs: 136 HP / 120 Atk / 252 Spe  
Adamant Nature  
- Flame Charge  
- Heavy Slam  
- Stone Edge  
- Acrobatics

";
$fb419 = "Starmie @ Heavy-Duty Boots  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 40 Def / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Rapid Spin  
- Teleport  
- Recover  

";
$fb430 = "Salamence @ Heavy-Duty Boots  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 88 Def / 172 SpD  
Sassy Nature  
- Roost  
- Psychic Fangs  
- Hurricane  
- Draco Meteor  

";
$fb440 = "Weavile @ Choice Band  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Return  
- Pursuit  
- Icy Wind  
- Brick Break  

";
$fb450 = "Great Tusk @ Toxic Orb  
Ability: Protosynthesis  
Tera Type: &
EVs: 132 HP / 184 Def / 192 Spe  
Impish Nature  
- Body Press  
- Rapid Spin  
- Taunt  
- Ice Spinner  

";
$fb460 = "Heatran @ Sitrus Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Sassy Nature  
- Rock Blast  
- Lava Plume  
- Heavy Slam  
- Toxic  

";
$fb470 = "Rotom-Wash @ Ring Target  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Thunder Wave  
- Trick  
- Hydro Pump  

";
$fb481 = "Munkidori @ Heavy-Duty Boots  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Psychic Noise  
- Grass Knot  
- U-turn  
- Protect  

";
$fb491 = "Vespiquen @ Custap Berry  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Hurricane  
- Laser Focus  
- Endure  

";
$fb4102 = "Vespiquen @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Attack Order  
- Taunt  
- Spite  
- Heal Order  

";
$fb4112 = "Vespiquen @ Choice Band  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Attak Order  
- Dual Wingbeat  
- Pursuit  
- U-turn  

";
$fb4122 = "Gallade @ Roseli Berry  
Ability: Sharpness  
Tera Type: &
EVs: 76 HP / 252 Atk / 180 Spe  
Adamant Nature  
- Trick Room  
- X-Scissor  
- Psycho Cut  
- Sacred Sword  

";
$fb4132 = "Scream Tail @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Encore  
- Wish  
- Protect  
- Perish Song  

";
$fb4143 = "Clefable @ Rocky Helmet  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
IVs: 14 Spe  
- Stealth Rock  
- Knock Off  
- Heal Bell  
- Soft-Boiled  

";
$fb4154 = "Clefable @ Leftovers  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Moonblast  
- Moonlight  
- Chilling Water  
- Knock Off  

";
$fb4164 = "Hafberene @ Custap Berry  
Ability: Magic Bounce  
Tera Type: &
EVs: 240 HP / 140 Def / 40 SpA / 88 SpD  
Calm Nature  
- Psychic  
- Dazzling Gleam  
- Nuzzle  
- Healing Wish  

";
$fb4174 = "Hafberene @ Grassy Seed  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 60 Def / 196 Spe  
Bold Nature  
IVs: 0 Atk  
- Agility  
- Calm Mind  
- Stored Power  
- Draining Kiss  

";
$fb4185 = "Dragonite @ Expert Belt  
Ability: Multiscale  
Tera Type: &
EVs: 112 Atk / 252 SpA / 144 Spe  
Rash Nature  
- Ice Beam  
- Thunderbolt  
- Low Kick  
- Earthquake  

";
$fb4195 = "Dragonite @ Heavy-Duty Boots  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
IVs: 0 Atk  
- Dragon Dance  
- Encore  
- Tera Blast  
- Roost  

";
$fb4206 = "Landorus-Therian @ Red Card  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Earth Power  
- Stealth Rock  
- Taunt  

";
$fb4217 = "Iron Valiant @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Moonblast  
- Psyshock  
- Vacuum Wave  

";
$fb4228 = "Kingambit @ Mental Herb  
Ability: Supreme Overlord  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Swords Dance  
- Sucker Punch  
- Kowtow Cleave  
- Iron Head  

";
$fb4238 = "Scizor @ Sitrus Berry  
Ability: Technician  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Adamant Nature  
- Swords Dance  
- Bullet Punch  
- Close Combat  
- Thief  

";
$fb4248 = "Landorus-Therian @ Light Ball  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Stealth Rock  
- Earthquake  
- U-turn  
- Fling  

";
$fb4258 = "Greninja-Bond @ Life Orb  
Ability: Bafble Bond  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Dark Pulse  
- Hydro Pump  
- Ice Beam  
- Gunk Shot  

";
$fb4268 = "Aerodactyl @ Choice Band  
Ability: Rock Head  
Tera Type: &
EVs: 124 HP / 252 Atk / 132 Spe  
Adamant Nature  
- Rock Slide  
- Double-Edge  
- Tera Blast 
- Earthquake  

";
$fb4278 = "Misdreavus @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 176 Def / 80 SpD  
Calm Nature  
IVs: 0 Atk  
- Mean Look  
- Perish Song  
- Taunt  
- Protect  

";
$fb4289 = "Celebi @ Leftovers  
Ability: Natural Cure  
Happiness: 0  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 3 Atk / 30 SpA  
- Leech Seed  
- Swords Dance  
- Hidden Power [Electric]  
- Baton Pass  

";
$fb4301 = "Zapdos @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 68 Atk / 188 SpA / 252 Spe  
Hasty Nature  
- Substitute  
- Thunderbolt  
- Drill Peck  
- Roar  

";
$fb4311 = "Blastoise @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Rapid Spin  
- Seismic Toss  
- Toxic  
- Refresh  

";
$fb4322 = "Glalie @ Leftovers  
Ability: Inner Focus  
Tera Type: &
EVs: 136 HP / 252 Atk / 120 Spe  
Lonely Nature  
- Taunt  
- Spikes  
- Ice Beam  
- Explosion  

";
$fb4332 = "Zapdos @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 136 Spe  
Jolly Nature  
- Drill Peck  
- Tera Blast  
- Sleep Talk  
- Rest  

";
$fb4342 = "Charjabug @ Eviolite  
Ability: Bafbery  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Sticky Web  
- Thunder Wave  
- Mud-Slap  
- String Shot  

";
$fb4354 = "Iron Valiant @ Mirror Herb  
Ability: Quark Drive  
Tera Type: &
EVs: 60 HP / 252 Atk / 196 Spe  
Jolly Nature  
- Low Kick  
- Ice Punch  
- Psycho Cut  
- Agility  

";
$fb4364 = "Clodsire @ Payapa Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 160 Atk / 56 Def / 36 SpD / 8 Spe  
Adamant Nature  
- Earthquake  
- Poison Jab  
- Megahorn  
- Gunk Shot  

";
$fb4374 = "Mesprit @ Assault Vest  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 240 SpD / 16 Spe  
Calm Nature  
- Future Sight  
- Drain Punch  
- Knock Off  
- U-turn  

";
$fb4384 = "Slither Wing @ Assault Vest  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 48 SpD / 208 Spe  
Jolly Nature  
- U-turn  
- Close Combat  
- Wild Charge  
- High Horsepower  

";
$fb4394 = "Clefable @ Ganlon Berry  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Seismic Toss  
- Encore  
- Thunder Wave  
- Soft-Boiled  

";
$fb4405 = "Gardevoir @ Assault Vest  
Ability: Trace  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hyper Beam  
- Hyper Voice  
- Will-O-Wisp  
- Encore  

";
$fb4416 = "Gholdengo @ Berry Juice  
Ability: Good as Gold  
Tera Type: &
EVs: 88 HP / 4 Atk / 236 Def / 88 SpA / 92 Spe  
Lax Nature  
IVs: 0 Atk  
- Hex  
- Thunder Wave  
- Substitute  
- Rest  

";
$fb4427 = "Landorus-Therian @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 8 HP / 12 Atk / 88 Def / 232 SpA / 168 Spe  
Rash Nature  
- Rock Tomb  
- Earthquake  
- Grass Knot  
- Hidden Power [Ice]  

";
$fb4437 = "Jirachi @ Weakness Policy  
Ability: Serene Grace  
Tera Type: &
EVs: 32 HP / 24 Atk / 160 SpA / 96 SpD / 196 Spe  
Calm Nature  
- Iron Head  
- Icy Wind  
- Hidden Power [Ground]  
- Skill Swap  

";
$fb4447 = "Thundurus @ Electrium Z  
Ability: Prankster  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder  
- Sludge Wave  
- Hidden Power [Ice]  
- Charge  

";
$fb4458 = "Iron Moth @ Air Balloon  
Ability: Quark Drive  
Tera Type: &
EVs: 76 Def / 252 SpA / 180 Spe  
Modest Nature  
- Acid Spray  
- Sludge Wave  
- Overheat  
- Lunge  

";
$fb4468 = "Manaphy @ Waterium Z  
Ability: Hydration  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Bubble Beam  
- Energy Ball  
- Acid Armor  
- Tail Glow  

";
$fb4479 = "Blacephalon @ Life Orb  
Ability: Beast Boost  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Fire Blast  
- Shadow Ball  
- Substitute  
- Pain Split  

";
$fb4490 = "Espeon @ Leftovers  
Ability: Synchronize  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
- Psychic  
- Body Slam  
- Baton Pass  
- Calm Mind  

";
$fb4500 = "Jolteon @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
IVs: 2 Atk / 30 SpA  
- Thunderbolt  
- Hidden Power [Grass]  
- Toxic  
- Baton Pass  

";
$fb4511 = "Wailord @ Leftovers  
Ability: Water Veil  
Tera Type: &
EVs: 4 Atk / 252 Def / 252 SpA  
Relaxed Nature  
- Surf  
- Self-Destruct  
- Roar  
- Protect  

";
$fb4521 = "Sharpedo @ Liechi Berry  
Ability: Speed Boost  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Endure  
- Waterfall  
- Crunch  
- Destiny Bond  

";
$fb4531 = "Crawdaunt @ Life Orb  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 6 SpA / 252 Spe  
Naughty Nature  
- Aqua Jet  
- Ice Beam  
- Knock Off  
- Sludge Bomb  

";
$fb4541 = "Raichu @ Focus Sash  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Fake Out  
- Nuzzle  
- Volt Switch  
- Grass Knot  

";
$fb4551 = "Cresselia @ Flame Orb  
Ability: Levitate  
Tera Type: &
EVs: 216 HP / 96 Def / 20 SpD / 176 Spe  
Calm Nature  
IVs: 0 Atk  
- Psychic  
- Psycho Shift  
- Sleep Talk  
- Rest  

";
$fb4562 = "Mothim @ Choice Band  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- U-turn  
- Aerial Ace  
- Lunge  
- Energy Ball  

";
$fb4572 = "Infernape @ Leftovers  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Encore  
- Substitute  
- Focus Punch  

";
$fb4582 = "Dodrio @ Wiki Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Thrash  
- Brave Bird  
- Swords Dance  
- Steel Wing  

";
$fb4592 = "Umbreon @ Leftovers  
Ability: Synchronize  
Tera Type: &
EVs: 244 HP / 36 Def / 220 SpD  
Sassy Nature  
- Curse  
- Moonlight  
- Payback  
- Stored Power  

";
$fb4602 = "Starmie @ Light Clay  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
- Reflect  
- Light Screen  
- Rapid Spin  
- Ice Beam  

";
$fb4612 = "Ambipom @ Liechi Berry  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double Hit  
- Focus Punch  
- Substitute  
- Thief  

";
$fb4622 = "Steelix @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Rock Polish  
- Iron Tail  
- Thunder Fang  
- Drill Run  

";
$fb4632 = "Glaceon @ Leftovers  
Ability: Snow Cloak  
Tera Type: &
EVs: 252 HP / 136 Def / 24 SpD / 96 Spe  
Bold Nature  
IVs: 0 Atk  
- Wish  
- Freeze-Dry  
- Protect  
- Yawn  

";
$fb4643 = "Probopass @ Chople Berry  
Ability: Magnet Pull  
Tera Type: &
EVs: 4 HP / 252 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Stealth Rock  
- Body Press  
- Volt Switch  
- Earth Power  

";
$fb4654 = "Lucario @ Life Orb  
Ability: Justified  
Tera Type: &
EVs: 20 Atk / 236 SpA / 252 Spe  
Naive Nature  
- High Jump Kick  
- Meteor Mash  
- Hidden Power [Grass]  
- Dark Pulse  

";
$fb4664 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Focus Blast  
- Ice Beam  
- Agility  

";
$fb4675 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Focus Blast  
- Ice Beam  
- Substitute  

";
$fb4686 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Scald  
- Focus Blast  
- Ice Beam  
- Superpower  

";
$fb4696 = "Gardevoir @ Leftovers  
Ability: Trace  
Tera Type: &
EVs: 44 HP / 212 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Hypnosis  
- Substitute  
- Calm Mind  

";
$fb4707 = "Clefable @ Leftovers  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 164 Def / 92 SpD  
Calm Nature  
IVs: 0 Atk  
- Stored Power  
- Charge Beam  
- Cosmic Power  
- Moonlight  

";
$fb4718 = "Heatran @ Life Orb  
Ability: Flame Body  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Magma Storm  
- Explosion  
- Earth Power  
- Taunt  

";
$fb4728 = "Espeon @ Leftovers  
Ability: Magic Bounce  
Tera Type: &
EVs: 216 HP / 252 Def / 12 SpD / 28 Spe  
Bold Nature  
IVs: 0 Atk  
- Stored Power  
- Morning Sun  
- Calm Mind  
- Curse  

";
$fb4739 = "Darmanitan-Galar @ Clear Amulet  
Ability: Zen Mode  
Tera Type: &
EVs: 92 Atk / 224 Def / 192 Spe  
Adamant Nature  
- Icicle Crash  
- Flare Blitz  
- Encore  
- Will-O-Wisp  

";
$fb4749 = "Darmanitan-Galar @ Covert Cloak  
Ability: Gorilla Tactics  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Icicle Crash  
- Flare Blitz  
- Encore  
- U-turn  

";
$fb4759 = "Darmanitan-Galar @ Heavy-Duty Boots  
Ability: Zen Mode  
Tera Type: &
EVs: 116 Atk / 140 Def / 252 Spe  
Jolly Nature  
- Icicle Crash  
- Flare Blitz  
- Encore  
- U-turn  

";
$fb4769 = "Hafberene @ Utility Umbrella  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
IVs: 0 Atk  
- Psyshock  
- Trick Room  
- Healing Wish  
- Draining Kiss  

";
$fb4780 = "Polteageist @ Salac Berry  
Ability: Weak Armor  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Shadow Ball  
- Teatime  

";
$fb4791 = "Metagross @ Leftovers  
Ability: Clear Body  
Tera Type: &
EVs: 200 HP / 252 SpA / 56 Spe  
Mild Nature  
- Meteor Mash  
- Psychic  
- Hidden Power [Grass]  
- Explosion  

";
$fb4801 = "Jolteon @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Toxic  
- Substitute  
- Protect  

";
$fb4812 = "Wailord @ Choice Band  
Ability: Water Veil  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 SpD  
Brave Nature  
- Double-Edge  
- Earthquake  
- Self-Destruct  
- Surf  

";
$fb4822 = "Gardevoir @ Gardevoirite  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Will-O-Wisp  
- Vacuum Wave  
- Calm Mind  

";
$fb4833 = "Gardevoir @ Gardevoirite  
Ability: Trace  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Hyper Beam  
- Vacuum Wave  
- Protect  
- Calm Mind  

";
$fb4844 = "Primarina @ Leftovers  
Ability: Liquid Voice  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Psychic Noise  
- Moonblast  
- Encore  
- Protect  

";
$fb4855 = "Meloetta @ Assault Vest  
Ability: Serene Grace  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Relic Song  
- Close Combat  
- Knock Off  
- Triple Axel  

";
$fb4865 = "Dragonite @ Metronome  
Ability: Multiscale  
Tera Type: &
EVs: 104 HP / 252 Atk / 152 Spe  
Naughty Nature  
- Extreme Speed  
- Earthquake  
- Hurricane  
- Dragon Dance  

";
$fb4875 = "Dragapult @ Choice Band  
Ability: Infiltrator  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Darts  
- Sucker Punch  
- Will-O-Wisp  
- U-turn  

";
$fb4885 = "Blaziken @ Focus Sash  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Reversal  
- Earthquake  
- Swords Dance  
- Endure  

";
$fb4895 = "Primarina @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Draining Kiss  
- Calm Mind  
- Reflect  

";
$fb4906 = "Zarude @ Choice Scarf  
Ability: Leaf Guard  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Darkest Lariat  
- Power Whip  
- Close Combat  
- Rock Slide  

";
$fb4916 = "Dragapult @ Weakness Policy  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 128 Def / 12 SpA / 16 SpD / 100 Spe  
Timid Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Hex  
- Draco Meteor  
- Disable  

";
$fb4927 = "Spectrier @ Salac Berry  
Ability: Grim Neigh  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Draining Kiss  
- Endure  
- Nasty Plot  

";
$fb4938 = "Heatran @ Rocky Helmet  
Ability: Flame Body  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Magma Storm  
- Earth Power  
- Lava Plume  
- Stealth Rock  

";
$fb4949 = "Quaquaval @ Maranga Berry  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 44 Atk / 100 SpD / 112 Spe  
Adamant Nature  
- Aqua Step  
- Knock Off  
- Roost  
- Bulk Up  

";
$fb4959 = "Mesprit @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 196 Def / 60 Spe  
Bold Nature  
IVs: 0 Atk  
- Psychic  
- Encore  
- Healing Wish  
- Thunder Wave  

";
$fb4970 = "Metagross @ Leftovers  
Ability: Clear Body  
Tera Type: &
EVs: 164 HP / 252 SpA / 92 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Psychic  
- Ice Punch  
- Hidden Power [Fire]  
- Agility  

";
$fb4981 = "Dragonite @ Leftovers  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 108 Atk / 20 SpA / 120 SpD / 8 Spe  
Lonely Nature  
- Dragon Claw  
- Hidden Power [Flying]  
- Earthquake  
- Agility  

";
$fb4991 = "Skeledirge @ Passho Berry  
Ability: Unaware  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Modest Nature  
IVs: 0 Atk  
- Torch Song  
- Belch  
- Encore  
- Slack Off  

";
$fb41002 = "Ribombee @ Focus Sash  
Ability: Shield Dust  
Tera Type: &
EVs: 16 HP / 172 Def / 252 SpA / 68 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Psychic  
- Stun Spore  
- Sticky Web  

";
$fb41013 = "Articuno-Galar @ Choice Specs  
Ability: Competitive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hurricane  
- Psyshock  
- Freezing Glare  
- Shadow Ball  

";
$fb41024 = "Iron Bundle @ Petaya Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Timid Nature  
- Substitute  
- Whirlpool  
- Thief  
- Ice Beam  

";
$fb41034 = "Lucario @ Lucarionite  
Ability: Justified  
Tera Type: &
EVs: 128 Atk / 128 SpA / 252 Spe  
Naive Nature  
- Work Up  
- Focus Blast  
- Iron Tail  
- Stone Edge  

";
$fb41044 = "Palkia @ Room Service  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 216 Atk / 40 SpA  
Quiet Nature  
IVs: 0 Spe  
- Trick Room  
- Hydro Pump  
- Outrage  
- Fire Blast  

";
$fb41055 = "Dialga-Origin @ Adamant Crystal  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Bulk Up  
- Scale Shot  
- Iron Head  
- Bulldoze  

";
$fb41065 = "Dialga-Origin @ Adamant Crystal  
Ability: Pressure  
Level: 90  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Trick Room  
- Flash Cannon  
- Dragon Pulse  
- Tera Blast  

";
$fb41077 = "Zekrom @ Icium Z  
Ability: Teravolt  
Level: 90  
Tera Type: &
EVs: 72 Atk / 184 SpA / 252 Spe  
Lonely Nature  
- Scale Shot  
- Haze  
- Charge Beam  
- Draco Meteor  

";
$fb41088 = "Enamorus @ Throat Spray  
Ability: Contrary  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Alluring Voice  
- Iron Defense  
- Calm Mind  
- Healing Wish  

";
$fb41099 = "Enamorus @ Choice Scarf  
Ability: Contrary  
Happiness: 82  
Tera Type: &
EVs: 71 HP / 9 Atk / 234 Def / 2 SpA / 84 SpD / 110 Spe  
Modest Nature  
- Grassy Terrain  
- Springtide Storm  
- Outrage  
- Focus Blast  

";
$fb41110 = "Articuno-Galar @ Choice Band  
Ability: Competitive  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- U-turn  
- Brave Bird  
- Psycho Cut  
- Future Sight  

";
$fb41120 = "Cobalion @ Assault Vest  
Ability: Justified  
Tera Type: &
EVs: 104 HP / 152 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Focus Blast  
- Vacuum Wave  

";
$fb41129 = "Hoopa-Unbound @ Roseli Berry  
Ability: Magician  
Tera Type: &
EVs: 4 Atk / 252 SpD / 252 Spe  
Jolly Nature  
- Wonder Room  
- Hyperspace Fury  
- Zen Headbufb  
- Drain Punch  

";
$fb41139 = "Aurorus @ Rock Gem
Ability: Snow Warning  
Shiny: Yes  
Tera Type: &
EVs: 56 HP / 16 Def / 252 SpA / 136 SpD / 48 Spe  
Calm Nature  
IVs: 0 Atk  
- Protect  
- Ancient Power  
- Blizzard  
- Earth Power  

";
$fb41150 = "Sharpedo @ Liechi Berry  
Ability: Speed Boost  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Endure  
- Waterfall  
- Crunch  
- Destiny Bond  

";
$fb41160 = "Crawdaunt @ Life Orb  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 6 SpA / 252 Spe  
Naughty Nature  
- Aqua Jet  
- Ice Beam  
- Knock Off  
- Sludge Bomb  

";
$fb41170 = "Raichu @ Focus Sash  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Fake Out  
- Nuzzle  
- Volt Switch  
- Grass Knot  

";
$fb41180 = "Cresselia @ Flame Orb  
Ability: Levitate  
Tera Type: &
EVs: 216 HP / 96 Def / 20 SpD / 176 Spe  
Calm Nature  
IVs: 0 Atk  
- Psychic  
- Psycho Shift  
- Sleep Talk  
- Rest  

";
$fb41191 = "Mothim @ Choice Band  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- U-turn  
- Aerial Ace  
- Lunge  
- Energy Ball  

";
$fb41201 = "Infernape @ Leftovers  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Encore  
- Substitute  
- Focus Punch  

";
$fb41211 = "Dodrio @ Wiki Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Thrash  
- Brave Bird  
- Swords Dance  
- Steel Wing  

";
$fb41221 = "Umbreon @ Leftovers  
Ability: Synchronize  
Tera Type: &
EVs: 244 HP / 36 Def / 220 SpD  
Sassy Nature  
- Curse  
- Moonlight  
- Payback  
- Stored Power  

";
$fb41231 = "Starmie @ Light Clay  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
- Reflect  
- Light Screen  
- Rapid Spin  
- Ice Beam  

";
$fb41241 = "Ambipom @ Liechi Berry  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double Hit  
- Focus Punch  
- Substitute  
- Thief  

";
$fb41251 = "Steelix @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Rock Polish  
- Iron Tail  
- Thunder Fang  
- Drill Run  

";
$fb41261 = "Glaceon @ Leftovers  
Ability: Snow Cloak  
Tera Type: &
EVs: 252 HP / 136 Def / 24 SpD / 96 Spe  
Bold Nature  
IVs: 0 Atk  
- Wish  
- Freeze-Dry  
- Protect  
- Yawn  

";
$fb41272 = "Probopass @ Chople Berry  
Ability: Magnet Pull  
Tera Type: &
EVs: 4 HP / 252 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Stealth Rock  
- Body Press  
- Volt Switch  
- Earth Power  

";
$fb41283 = "Lucario @ Life Orb  
Ability: Justified  
Tera Type: &
EVs: 20 Atk / 236 SpA / 252 Spe  
Naive Nature  
- High Jump Kick  
- Meteor Mash  
- Hidden Power [Grass]  
- Dark Pulse  

";
$fb41293 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Focus Blast  
- Ice Beam  
- Agility  

";
$fb41304 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Focus Blast  
- Ice Beam  
- Substitute  

";
$fb41315 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Scald  
- Focus Blast  
- Ice Beam  
- Superpower  

";
$fb41325 = "Gardevoir @ Leftovers  
Ability: Trace  
Tera Type: &
EVs: 44 HP / 212 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Hypnosis  
- Substitute  
- Calm Mind  

";
$fb41336 = "Clefable @ Leftovers  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 164 Def / 92 SpD  
Calm Nature  
IVs: 0 Atk  
- Stored Power  
- Charge Beam  
- Cosmic Power  
- Moonlight  

";
$fb41347 = "Heatran @ Life Orb  
Ability: Flame Body  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Magma Storm  
- Explosion  
- Earth Power  
- Taunt  

";
$fb41357 = "Espeon @ Leftovers  
Ability: Magic Bounce  
Tera Type: &
EVs: 216 HP / 252 Def / 12 SpD / 28 Spe  
Bold Nature  
IVs: 0 Atk  
- Stored Power  
- Morning Sun  
- Calm Mind  
- Curse  

";
$fb41368 = "Darmanitan-Galar @ Clear Amulet  
Ability: Zen Mode  
Tera Type: &
EVs: 92 Atk / 224 Def / 192 Spe  
Adamant Nature  
- Icicle Crash  
- Flare Blitz  
- Encore  
- Will-O-Wisp  

";
$fb41378 = "Darmanitan-Galar @ Covert Cloak  
Ability: Gorilla Tactics  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Icicle Crash  
- Flare Blitz  
- Encore  
- U-turn  

";
$fb41388 = "Darmanitan-Galar @ Heavy-Duty Boots  
Ability: Zen Mode  
Tera Type: &
EVs: 116 Atk / 140 Def / 252 Spe  
Jolly Nature  
- Icicle Crash  
- Flare Blitz  
- Encore  
- U-turn  

";
$fb41398 = "Dragonite @ Never-Melt Ice  
Ability: Inner Focus  
Tera Type: &
EVs: 60 Atk / 252 SpA / 196 Spe  
Lonely Nature  
- Aerial Ace  
- Earthquake  
- Ice Beam  
- Dragon Dance  

";
$fb41408 = "Alakazam @ Twisted Spoon  
Ability: Synchronize  
Tera Type: &
EVs: 120 HP / 252 Def / 12 SpA / 124 Spe  
Bold Nature  
IVs: 0 Atk  
- Psychic  
- Encore  
- Counter  
- Calm Mind  

";
$fb41419 = "Drowzee @ Eviolite  
Ability: Forewarn  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Seismic Toss  
- Encore  
- Poison Gas  
- Protect  

";
$fb41430 = "Uxie @ Normalium Z  
Ability: Levitate  
Tera Type: &
EVs: 8 HP / 252 SpA / 248 Spe  
Modest Nature  
IVs: 0 Atk  
- Mystical Power  
- Draining Kiss  
- Encore  
- Pain Split  

";
$fb41441 = "Skuntank @ Rocky Helmet  
Ability: Aftermath  
Tera Type: &
EVs: 248 HP / 80 Atk / 88 Def / 80 SpD / 12 Spe  
Impish Nature  
- Gunk Shot  
- Sucker Punch  
- Knock Off  
- Toxic  

";
$fb41451 = "Infernape @ Choice Specs  
Ability: Blaze  
Tera Type: &
EVs: 64 Def / 192 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Vacuum Wave  
- Aura Sphere  
- Flamethrower  
- Switcheroo  

";
$fb41462 = "Rhyperior @ Assault Vest  
Ability: Solid Rock  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def  
Adamant Nature  
- Iron Head  
- Tera Blast  
- Ice Punch  
- Crunch  

";
$fb41472 = "Serperior @ Choice Band  
Ability: Overgrow  
Tera Type: &
EVs: 24 HP / 252 Atk / 232 Spe  
Jolly Nature  
- Knock Off  
- Petal Blizzard  
- Iron Tail  
- Tera Blast  

";
$fb41482 = "Spectrier @ Colbur Berry  
Ability: Grim Neigh  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Draining Kiss  
- Shadow Ball  
- Nasty Plot  
- Substitute  

";
$fb41493 = "Tinkaton @ Sitrus Berry  
Ability: Mold Breaker  
Tera Type: &
EVs: 248 HP / 60 SpD / 200 Spe  
Careful Nature  
- Encore  
- Gigaton Hammer  
- Knock Off  
- Thunder Wave  

";
$fb41503 = "Jirachi @ Occa Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Wish  
- Psyshock  
- Thunder Wave  

";
$fb41514 = "Starmie @ Expert Belt  
Ability: Natural Cure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Psyshock  
- Thunderbolt  
- Rapid Spin  

";
$fb41525 = "Politoed @ Damp Rock  
Ability: Drizzle  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 2 Atk / 30 SpA  
- Scald  
- Hidden Power [Grass]  
- Encore  
- Haze  

";
$fb41536 = "Thundurus-Therian @ Life Orb  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Thunder  
- Dark Pulse  
- U-turn  
- Hidden Power [Ground]  

";
$fb41546 = "Garchomp @ Rocky Helmet  
Ability: Rough Skin  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Earthquake  
- Dragon Tail  
- Protect  
- Stealth Rock  

";
$fb41556 = "Ampharos @ Shuca Berry  
Ability: Static  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 2 Atk / 30 Def  
- Cofbon Guard  
- Discharge  
- Hidden Power [Ice]  
- Volt Switch  

";
$fb41567 = "Miltank @ Leftovers  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Return  
- Toxic  
- Milk Drink  
- Earthquake  

";
$fb41577 = "Latias @ Electric Gem  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder  
- Draco Meteor  
- Psychic  
- Energy Ball  

";
$fb41588 = "Magneton @ Magnet  
Ability: Magnet Pull  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Thunderbolt  
- Hidden Power [Fire]  
- Toxic  
- Protect  

";
$fb41599 = "Slowbro @ Leftovers  
Ability: Oblivious  
Tera Type: &
EVs: 252 HP / 80 Def / 176 SpA  
Bold Nature  
IVs: 0 Atk  
- Protect  
- Psychic  
- Ice Beam  
- Surf  

";
$fb41610 = "Flaaffy @ Leftovers  
Ability: Static  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Seismic Toss  
- Rest  
- Sleep Talk  

";
$fb41621 = "Metagross @ Liechi Berry  
Ability: Clear Body  
Tera Type: &
EVs: 224 HP / 252 Atk / 32 Spe  
Adamant Nature  
- Endure  
- Agility  
- Earthquake  
- Meteor Mash  

";
$fb41631 = "Hitmonlee @ Salac Berry  
Ability: Limber  
Tera Type: &
EVs: 252 Atk / 100 SpD / 156 Spe  
Adamant Nature  
- Reversal  
- Tera Blast
- Endure  
- Bulk Up  

";
$fb41641 = "Miltank @ Leftovers  
Ability: Thick Fat  
Tera Type: &
EVs: 220 HP / 192 Atk / 96 Def  
Impish Nature  
- Curse  
- Body Slam  
- Milk Drink  
- Heal Bell  

";
$fb41651 = "Flygon @ Salac Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 40 SpA / 216 Spe  
Naive Nature  
- Substitute  
- Earthquake  
- Rock Slide  
- Hidden Power [Grass]  

";
$fb41661 = "Clefable @ Sitrus Berry  
Ability: Magic Guard  
Tera Type: &
EVs: 244 HP / 12 Atk / 176 Def / 76 SpD  
Careful Nature  
- Focus Punch  
- Substitute  
- Thunder Wave  
- Seismic Toss  

";
$fb41671 = "Chatot @ Throat Spray  
Ability: Big Pecks  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Chafber  
- Encore  
- Protect  
- Tailwind  

";
$fb41682 = "Heliolisk @ Throat Spray  
Ability: Dry Skin  
Tera Type: &
EVs: 60 HP / 144 SpA / 112 SpD / 192 Spe  
Timid Nature  
IVs: 0 Atk  
- Parabolic Charge  
- Glare  
- Ally Switch  
- Hyper Voice  

";
$fb41693 = "Helioptile @ Eviolite  
Ability: Dry Skin  
Tera Type: &
EVs: 128 HP / 240 SpA / 4 SpD / 136 Spe  
Serious Nature  
IVs: 0 Atk  
- Parabolic Charge  
- Charge Beam  
- Tera Blast  
- Glare  

";
$fb41704 = "Helioptile @ Throat Spray  
Ability: Dry Skin  
Tera Type: &
EVs: 228 HP / 252 SpA / 4 SpD / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Snore  
- Flash  
- Rest  

";
$fb41715 = "Hoopa-Unbound @ Throat Spray  
Ability: Magician  
Tera Type: &
EVs: 184 HP / 252 SpA / 72 Spe  
Modest Nature  
IVs: 0 Atk  
- Snore  
- Thunder Wave  
- Rest  
- Substitute  

";
$fb41726 = "Delphox @ Throat Spray  
Ability: Magician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Burning Jealousy  
- Snore  
- Rest  
- Calm Mind  

";
$fb41737 = "Klefki @ Throat Spray  
Ability: Magician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Draining Kiss  
- Snore  
- Rest  
- Defog  

";
$fb41748 = "Florges @ Heavy-Duty Boots  
Ability: Flower Veil  
Tera Type: &
EVs: 248 HP / 236 Def / 24 Spe  
Bold Nature  
IVs: 0 Atk  
- Moonblast  
- Toxic  
- Aromatherapy  
- Synthesis  

";
$fb41759 = "Zygarde-10% @ Leftovers  
Ability: Aura Break  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Thousand Waves  
- Skifber Smack  
- Substitute  
- Protect  

";
$fb41769 = "Feraligatr @ Lum Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Ice Punch  
- Flip Turn  
- Dragon Dance  

";
$fb41779 = "Tsareena @ Light Ball  
Ability: Queenly Majesty  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Stomp  
- Fling  
- Synthesis  
- Teeter Dance  

";
$fb41789 = "Snorlax @ Chesto Berry  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 116 Def / 116 SpD / 24 Spe  
Adamant Nature  
- Last Resort  
- Block  
- Curse  
- Rest  

";
$fb41799 = "Regidrago @ Razor Claw  
Ability: Dragon's Maw  
Tera Type: &
EVs: 216 Atk / 104 Def / 36 SpD / 152 Spe  
Adamant Nature  
- Focus Energy  
- Dragon Dance  
- Outrage  
- Earthquake  

";
$fb41809 = "Zygarde-10% @ Dragonium Z  
Ability: Aura Break  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Thousand Arrows  
- Outrage  
- Glare  
- Dragon Dance  

";
$fb41819 = "Zygarde @ Ice Gem  
Ability: Aura Break  
Tera Type: &
EVs: 4 Atk / 40 Def / 196 SpA / 16 SpD / 252 Spe  
Naive Nature  
IVs: 30 Atk  
- Hidden Power [Ice]  
- Haze  
- Draco Meteor  
- Thousand Waves  

";
$fb41830 = "Latios @ Haban Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Scale Shot  
- Outrage  
- Recover  

";
$fb41840 = "Cryogonal @ Heavy-Duty Boots  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
- Recover  
- Rapid Spin  
- Haze  
- Bind  

";
$fb41850 = "Cryogonal @ Grip Claw  
Ability: floats  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
- Bind  
- Haze  
- Recover  
- Freeze-Dry  

";
$fb41860 = "Meltan @ Grassy Seed  
Ability: Magnet Pull  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
IVs: 0 Atk  
- Toxic  
- Iron Defense  
- Rest  
- Sleep Talk  

";
$fb41872 = "Persian-Alola @ Throat Spray  
Ability: Fur Coat  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Dark Pulse  
- Burning Jealousy  
- Hidden Power [Poison]  
- Roar  

";
$fb41883 = "Persian @ Throat Spray  
Ability: Technician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Tera Blast  
- Shadow Ball  
- Covet  
- Roar  

";
$fb41893 = "Venomoth @ Throat Spray  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Bug Buzz  
- Psychic Noise  
- Thief  
- Protect  

";
$fb41903 = "Iron Moth @ Throat Spray  
Ability: Quark Drive  
Tera Type: &
EVs: 80 HP / 24 Def / 140 SpA / 68 SpD / 196 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Bug Buzz  
- Morning Sun  
- Sunny Day  

";
$fb41914 = "Ogerpon-Wellspring @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 172 Def / 84 SpD  
Impish Nature  
- Leech Seed  
- Sleep Talk  
- Quick Afback  
- Rest  

";
$fb41924 = "Persian @ Throat Spray  
Ability: Technician  
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe  
Modest Nature  
- Tera Blast  
- Shadow Ball  
- Thief  
- Roar  

";
$fb41934 = "Meloetta @ Throat Spray  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Snore  
- Psyshock  
- Rest  
- Thunder Wave  

";
$fb41945 = "Loudred @ Eviolite  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 52 Def / 4 SpA / 200 SpD  
Calm Nature  
IVs: 0 Atk  
- Tera Blast  
- Toxic  
- Teeter Dance  
- Protect  

";
$fb41956 = "Pecharunt @ Sitrus Berry  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 252 HP / 20 Def / 4 SpA / 232 SpD  
Bold Nature  
IVs: 0 Atk  
- Tera Blast  
- Recover  
- Parting Shot  
- Poison Gas  

";
$fb41967 = "Salazzle @ Leftovers  
Ability: Corrosion  
Tera Type: &
EVs: 80 HP / 196 SpA / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Protect  
- Poison Gas  
- Substitute  

";
$fb41978 = "Muk-Alola @ Poisonium Z  
Ability: Poison Touch  
Tera Type: &
EVs: 248 HP / 76 Def / 184 SpD  
Careful Nature  
- Knock Off  
- Pain Split  
- Protect  
- Poison Gas  

";
$fb41988 = "Luvdisc @ Heavy-Duty Boots  
Ability: Swift Swim  
Tera Type: &
EVs: 81 HP / 85 Def / 85 SpA / 85 SpD / 85 Spe  
IVs: 0 Atk  
- Endeavor  
- Substitute  
- Whirlpool  
- Surf  

";
$fb41998 = "Latias @ Soul Dew  
Ability: Levitate  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Psyshock  
- Roost  
- Calm Mind  

";
$fb42009 = "Toucannon @ Heavy-Duty Boots  
Ability: Skill Link  
Tera Type: &
EVs: 108 HP / 44 Atk / 104 SpA / 252 SpD  
Sassy Nature  
- Boomburst  
- Bullet Seed  
- Roost  
- U-turn  

";
$fb42019 = "Piloswine @ Never-Melt Ice  
Ability: Oblivious  
Tera Type: &
EVs: 168 HP / 228 Atk / 88 SpA / 24 Spe  
Brave Nature  
- Ice Beam  
- Earthquake  
- Mud Shot  
- Blizzard  

";
$fb42029 = "Cloyster @ White Herb  
Ability: Skill Link  
Tera Type: &
EVs: 112 Atk / 144 SpA / 252 Spe  
Naughty Nature  
- Icicle Spear  
- Hydro Pump  
- Hidden Power [Grass]  
- Shell Smash  

";
$fb42039 = "Cloyster @ Loaded Dice  
Ability: Shell Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Icicle Spear  
- Rock Blast  
- Rapid Spin  
- Shell Smash  

";
$fb42049 = "Ferrothorn @ Colbur Berry  
Ability: Iron Barbs  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Body Press  
- Thunder Wave  
- Spikes  
- Sleep Talk  

";
$fb42060 = "Slowking-Galar @ Covert Cloak  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Scald  
- Chilly Reception  
- Slack Off  

";
$fb42071 = "Mawile @ Mawilite  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Seismic Toss  
- Power-Up Punch  
- Protect  
- Swords Dance  

";
$fb42081 = "Skeledirge @ Electric Seed  
Ability: Blaze  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Torch Song  
- Will-O-Wisp  
- Slack Off  
- Hex  

";
$fb42092 = "Talonflame @ Flyinium Z  
Ability: Gale Wings  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Brave Bird  
- Flare Blitz  
- Steel Wing  
- Swords Dance  

";
$fb42102 = "Tapu Fini @ Leftovers  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Taunt  
- Moonblast  

";
$fb42113 = "Dragonite @ Throat Spray  
Ability: Multiscale  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Quiet Nature  
- Dragon Tail  
- Roar  
- Roost  
- Hurricane  

";
$fb42123 = "Venusaur @ Throat Spray  
Ability: Overgrow  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Frenzy Plant  
- Sludge Bomb  
- Roar  
- Synthesis  

";
$fb42134 = "Blastoise @ Throat Spray  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Hydro Pump  
- Hidden Power [Fire]  
- Roar  
- Rapid Spin  

";
$fb42144 = "Garganacl @ Chesto Berry  
Ability: Clear Body  
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpD / 108 Spe  
Jolly Nature  
- Salt Cure  
- Tera Blast  
- Protect  
- Rest  

";
$fb42154 = "Zygarde @ Life Orb  
Ability: Aura Break  
Tera Type: &
EVs: 244 HP / 12 Atk / 252 SpD  
Careful Nature  
- Land's Wrath  
- Glare  
- Brick Break  
- Extreme Speed  

";
$fb42164 = "Lunatone @ Icium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 8 SpD / 248 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Blizzard  
- Meteor Beam  
- Substitute  

";
$fb42175 = "Gigalith @ Power Herb  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Meteor Beam  
- Hidden Power [Ice]  
- Earth Power  
- Stealth Rock  

";
$fb42186 = "Aerodactyl @ Power Herb  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Meteor Beam  
- Defog  
- Roost  
- Substitute  

";
$fb42197 = "Cyclizar @ Choice Band  
Ability: Regenerator  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Rapid Spin  
- Sleep Talk  

";
$fb42205 = "Meowscarada @ Heavy-Duty Boots  
Ability: Overgrow  
Tera Type: &
EVs: 56 HP / 252 Atk / 200 Spe  
Jolly Nature  
- Knock Off  
- Flower Trick  
- U-turn  
- Protect  

";
$fb42215 = "Quaquaval @ Covert Cloak  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 188 SpD / 68 Spe  
Jolly Nature  
- Aqua Step  
- Taunt  
- Roost  
- Bulk Up  

";
$fb42225 = "Mamoswine @ Loaded Dice  
Ability: Thick Fat  
Tera Type: &
EVs: 60 HP / 252 Atk / 196 Spe  
Adamant Nature  
- Earthquake  
- Icicle Spear  
- Rock Blast  
- Trailblaze  

";
$fb42235 = "Mesprit @ Heavy-Duty Boots  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 228 SpD / 28 Spe  
Careful Nature  
- Knock Off  
- Encore  
- Stealth Rock  
- U-turn  

";
$fb42245 = "Sceptile @ Flying Gem  
Ability: Unburden  
Tera Type: &
EVs: 160 HP / 252 Atk / 96 Spe  
Adamant Nature  
- Seed Bomb  
- Drain Punch  
- Acrobatics  
- Swords Dance  

";
$fb42255 = "Hydreigon @ Earth Plate  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Earth Power  
- Thunder Wave  
- Stealth Rock  

";
$fb42266 = "Kangaskhan @ Assault Vest  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Return  
- Dig  
- Sucker Punch  
- Fake Out  

";
$fb42276 = "Kangaskhan @ Leftovers  
Ability: Early Bird  
Tera Type: &
EVs: 216 HP / 136 Atk / 56 SpD / 100 Spe  
Adamant Nature  
- Return  
- Rest  
- Shadow Ball  
- Rage  

";
$fb42286 = "Hitmonlee @ Lum Berry  
Ability: Limber  
Tera Type: &
EVs: 252 Atk / 16 Def / 240 Spe  
Jolly Nature  
- Bulk Up  
- Brick Break  
- Tera Blast
- Mach Punch  

";
$fb42296 = "Salamence @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 120 Atk / 252 SpA / 136 Spe  
Mild Nature  
- Dragon Claw  
- Brick Break  
- Crunch  
- Dragon Dance  

";
$fb42306 = "Raikou @ Choice Band  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Naughty Nature  
- Tera Blast
- Double-Edge  
- Thunderbolt  
- Quick Afback  

";
$fb42316 = "Hippowdon @ Mirror Herb  
Ability: Sand Stream  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Careful Nature  
- High Horsepower  
- Stone Edge  
- Amnesia  
- Slack Off  

";
$fb42326 = "Primarina @ Leftovers  
Ability: Liquid Voice  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Psychic Noise  
- Rest  
- Sleep Talk  

";
$fb42337 = "Primarina @ Throat Spray  
Ability: Liquid Voice  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Moonblast  
- Encore  
- Protect  

";
$fb42348 = "Primarina @ Light Clay  
Ability: Liquid Voice  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Moonblast  
- Alluring Voice  
- Reflect  
- Flip Turn  

";
$fb42358 = "Primarina @ Light Clay  
Ability: Liquid Voice  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Moonblast  
- Alluring Voice  
- Light Screen  
- Flip Turn  

";
$fb42368 = "Primarina @ Assault Vest  
Ability: Torrent  
Tera Type: &
EVs: 88 HP / 252 Def / 168 Spe  
Bold Nature  
IVs: 0 Atk  
- Chilling Water  
- Draining Kiss  
- Flip Turn  
- Whirlpool  

";
$fb42379 = "Raging Bolt @ Life Orb  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 20 Atk  
- Calm Mind  
- Solar Beam  
- Thunder  
- Weather Ball  

";
$fb42390 = "Raging Bolt @ Power Herb  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 20 Atk  
- Thunderclap  
- Solar Beam  
- Thunder  
- Weather Ball  

";
$fb42401 = "Raging Bolt @ Terrain Extender  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 20 Atk  
- Electric Terrain  
- Rising Voltage  
- Thunderclap  
- Dragon Pulse  

";
$fb42412 = "Moltres-Galar @ Heavy-Duty Boots  
Ability: Berserk  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Fiery Wrath  
- Hurricane  
- Tera Blast  

";
$fb42423 = "Gliscor @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Toxic  
- Spikes  
- Protect  
- Brick Break  

";
$fb42433 = "Glimmora @ Life Orb  
Ability: Toxic Debris  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Earth Power  
- Power Gem  
- Rock Polish  

";
$fb42444 = "Amoonguss @ Life Orb  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 188 Atk / 68 SpD  
Sassy Nature  
- Spore  
- Stomping Tantrum  
- Giga Drain  
- Sludge Bomb  

";
$fb42454 = "Bronzong @ Heavy-Duty Boots  
Ability: Heatproof  
Tera Type: &
EVs: 252 HP / 60 Def / 196 SpD  
Sassy Nature  
IVs: 0 Spe  
- Stealth Rock  
- Body Press  
- Iron Defense  
- Gyro Ball  

";
$fb42465 = "Ceruledge @ Assault Vest  
Ability: Flash Fire  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Shadow Sneak  
- Bifber Blade  
- Close Combat  
- Flame Charge  

";
$fb42475 = "Clodsire @ Mental Herb  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Earthquake  
- Toxic  
- Recover  
- Spikes  

";
$fb42485 = "Scizor @ Mirror Herb  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Swords Dance  
- Acrobatics  
- Bullet Punch  
- U-turn  

";
$fb42495 = "Annihilape @ Choice Scarf  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 36 Atk / 220 Spe  
Adamant Nature  
- U-turn  
- Rage Fist  
- Close Combat  
- Final Gambit  

";
$fb42505 = "Dondozo @ Covert Cloak  
Ability: Unaware  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Careful Nature  
- Wave Crash  
- Curse  
- Rest  

";
$fb42514 = "Ceruledge @ Covert Cloak  
Ability: Flash Fire  
Tera Type: &
EVs: 240 HP / 20 Atk / 12 Def / 96 SpD / 140 Spe  
Adamant Nature  
- Bulk Up  
- Taunt  
- Bifber Blade  
- Shadow Sneak  

";
$fb42524 = "Charizard @ Charizardite X  
Ability: Blaze  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Blast Burn  
- Dragon Pulse  
- Focus Blast

";
$fb42534 = "Emboar @ Fightinium Z  
Ability: Blaze  
Tera Type: &
EVs: 232 HP / 16 Def / 252 SpD / 8 Spe  
Impish Nature  
- Yawn  
- Protect  
- Focus Punch  
- Flame Charge

";
$fb42543 = "Gyarados @ Gyaradosite  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Bide  
- Dragon Dance  
- Stone Edge  
- Waterfall

";
$fb42552 = "Articuno @ Flying Gem
Ability: Pressure  
Tera Type: &
EVs: 164 HP / 32 Def / 252 SpA / 60 Spe  
Modest Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Hurricane  
- Icy Wind  
- Rest  

";
$fb42562 = "Charizard @ Charizardite X  
Ability: Blaze  
Tera Type: &
EVs: 20 Atk / 236 Def / 252 Spe  
Jolly Nature  
- Protect  
- Flame Charge  
- Flare Blitz  
- Outrage  

";
$fb42571 = "Ferrothorn @ Sitrus Berry  
Ability: Iron Barbs  
Tera Type: &
EVs: 252 HP / 52 Atk / 204 SpA  
Quiet Nature  
IVs: 30 Atk / 1 Spe  
- Gyro Ball  
- Giga Drain  
- Hidden Power [Ice]  
- Magnet Rise  

";
$fb42581 = "Chesnaught @ Grassium Z  
Ability: Bulletproof  
Tera Type: &
EVs: 252 HP / 28 Atk / 228 Spe  
Adamant Nature  
- Belly Drum  
- Poison Jab  
- Wood Hammer  
- Drain Punch  

";
$fb42590 = "Marowak-Alola @ Thick Club  
Ability: Rock Head  
Tera Type: &
EVs: 252 HP / 228 Atk / 28 Def  
Impish Nature  
- Flare Blitz  
- Shadow Bone  
- Counter  
- Stone Edge  

";
$fb42599 = "Empoleon @ Water Gem
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 80 SpD / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Icy Wind  
- Confide  
- Rest  
- Scald  

";
$fb42609 = "Necrozma @ Assault Vest  
Ability: Prism Armor  
Tera Type: &
EVs: 252 HP / 56 SpA / 92 SpD / 108 Spe  
Calm Nature  
- Power Gem  
- Prismatic Laser  
- Rock Tomb  
- Psychic

";
$fb42618 = "Manaphy @ Salac Berry  
Ability: Hydration  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tail Glow  
- Surf  
- Hyper Beam  
- Charm

";
$fb42628 = "Togekiss @ Choice Band  
Ability: Hustle  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Extreme Speed  
- Giga Impact  
- Fly  
- Drain Punch

";
$fb42637 = "Dragonite @ Metronome  
Ability: Multiscale  
Happiness: 69  
Tera Type: &
EVs: 92 HP / 252 Atk / 68 SpA / 96 Spe  
Naughty Nature  
- Outrage  
- Rock Tomb  
- Thunderbolt  
- Extreme Speed

";
$fb42647 = "Bronzong @ Mental Herb  
Ability: Levitate  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 16 Def / 240 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Iron Defense  
- Toxic  
- Signal Beam

";
$fb42658 = "Exploud @ Custap Berry  
Ability: Soundproof  
Shiny: Yes  
Tera Type: &
EVs: 244 HP / 252 SpA / 12 Spe  
Modest Nature  
IVs: 0 Atk  
- Endure  
- Boomburst  
- Counter  
- Taunt

";
$fb42669 = "Blissey @ Mental Herb  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Soft-Boiled  
- Toxic  
- Water Pulse

";
$fb42679 = "Cobalion @ Choice Specs  
Ability: Justified  
Tera Type: &
EVs: 36 HP / 236 SpA / 236 Spe  
Timid Nature  
IVs: 0 Atk / 30 Def  
- Focus Blast  
- Flash Cannon  
- Volt Switch  
- Hidden Power [Ice]  

";
$fb42689 = "Dragonite @ Lum Berry  
Ability: Multiscale  
Happiness: 69  
Tera Type: &
EVs: 56 HP / 248 Atk / 204 Spe  
Adamant Nature  
- Dragon Dance  
- Outrage  
- Fire Punch  
- Tailwind  

";
$fb42699 = "Manaphy @ Custap Berry  
Ability: Hydration  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 16 SpA / 72 SpD / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Rest  
- Tail Glow  
- Acid Armor  
- Scald  

";
$fb42710 = "Luxray @ Choice Specs  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
- Thunderbolt  
- Hidden Power [Poison]  
- Thunder  
- Double Kick

";
$fb42719 = "Throh @ Chesto Berry  
Ability: Mold Breaker  
Tera Type: &
EVs: 216 HP / 120 Atk / 172 Def  
Impish Nature  
IVs: 0 SpA / 16 Spe  
- Storm Throw  
- Earthquake  
- Bulk Up  
- Rest

";
$fb42729 = "Hitmonlee @ Normal Gem  
Ability: Unburden  
Tera Type: &
EVs: 116 Atk / 184 Def / 208 Spe  
Adamant Nature  
- Fake Out  
- High Jump Kick  
- Bulk Up  
- Laser Focus

";
$fb42738 = "Jirachi @ Shuca Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 148 HP / 108 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Flash Cannon  
- Icy Wind  
- Calm Mind  

";
$fb42748 = "Incineroar @ Chople Berry  
Ability: Intimidate  
Tera Type: &
EVs: 48 HP / 252 Def / 208 Spe  
Impish Nature  
- Flare Blitz  
- Will-O-Wisp  
- Bulk Up  
- Flame Charge  

";
$fb42757 = "Cloyster @ Chople Berry  
Ability: Skill Link  
Tera Type: &
EVs: 120 HP / 156 Atk / 232 Spe  
Lax Nature  
- Icicle Spear  
- Rock Blast  
- Hydro Pump  
- Shell Smash

";
$fb42766 = "Machamp @ Rocky Helmet
Ability: No Guard
Tera Type: &
EVs: 248 HP / 4 Atk / 252 Def / 4 Spe
Impish Nature
- Dynamic Punch
- Stone Edge
- Rock Tomb
- Ice Punch

";
$fb42775 = "Flygon @ Rocky Helmet
Ability: Levitate
Tera Type: &
EVs: 248 HP / 252 Def / 4 SpD
Impish Nature
- Rest
- Sleep Talk
- Dragon Tail
- U-turn

";
$fb42785 = "Dragonite @ Expert Belt  
Ability: Multiscale  
Tera Type: &
EVs: 112 Atk / 252 SpA / 144 Spe  
Rash Nature  
- Ice Beam  
- Thunderbolt  
- Low Kick  
- Earthquake  

";
$fb42795 = "Clefable @ Leftovers  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Moonblast  
- Moonlight  
- Chilling Water  
- Knock Off  

";
$fb42805 = "Hafberene @ Custap Berry  
Ability: Magic Bounce  
Tera Type: &
EVs: 240 HP / 140 Def / 40 SpA / 88 SpD  
Calm Nature  
- Psychic  
- Dazzling Gleam  
- Nuzzle  
- Healing Wish  

";
$fb42815 = "Hafberene @ Grassy Seed  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 60 Def / 196 Spe  
Bold Nature  
IVs: 0 Atk  
- Agility  
- Calm Mind  
- Stored Power  
- Draining Kiss  

";
$fb42826 = "Dragonite @ Expert Belt  
Ability: Multiscale  
Tera Type: &
EVs: 112 Atk / 252 SpA / 144 Spe  
Rash Nature  
- Ice Beam  
- Thunderbolt  
- Low Kick  
- Earthquake  

";
$fb42836 = "0 atk ivs Dragonite @ Heavy-Duty Boots  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
IVs: 0 Atk  
- Dragon Dance  
- Encore  
- Tera Blast  
- Roost  

";
$fb42847 = "Landorus-Therian @ Red Card  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Earth Power  
- Stealth Rock  
- Taunt  

";
$fb42858 = "Iron Valiant @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Moonblast  
- Psyshock  
- Vacuum Wave  

";
$fb42869 = "Kingambit @ Mental Herb  
Ability: Supreme Overlord  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Swords Dance  
- Sucker Punch  
- Kowtow Cleave  
- Iron Head  

";
$fb42879 = "Scizor @ Sitrus Berry  
Ability: Technician  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Adamant Nature  
- Swords Dance  
- Bullet Punch  
- Close Combat  
- Thief  

";
$fb42889 = "Landorus-Therian @ Light Ball  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
- Stealth Rock  
- Earthquake  
- U-turn  
- Fling  

";
$fb42899 = "Greninja @ Life Orb  
Ability: Bafble Bond  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Dark Pulse  
- Hydro Pump  
- Ice Beam  
- Gunk Shot  

";
$fb42909 = "Gholdengo @ Heavy-Duty Boots  
Ability: Good as Gold  
Tera Type: &
EVs: 252 HP / 188 Def / 68 Spe  
Bold Nature  
IVs: 0 Atk  
- Nasty Plot  
- Hex  
- Dazzling Gleam  
- Recover  

";
$fb42920 = "Gallade @ Roseli Berry
Ability: Sharpness
Tera Type: &
EVs: 76 HP / 252 Atk / 180 Spe
Adamant Nature
- Trick Room
- Psycho Cut
- X-Scissor
- Sacred Sword

";
$fb42930 = "Vileplume @ Black Sludge  
Ability: Effect Spore  
Tera Type: &
EVs: 192 HP / 252 Atk / 64 Spe  
Adamant Nature  
- Drain Punch  
- Seed Bomb  
- Synthesis  
- Swords Dance 

";
$fb42939 = "Quaquaval @ Heavy-Duty Boots  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 60 Atk / 196 Spe  
Adamant Nature  
- Aqua Step  
- Knock Off  
- Roost  
- Bulk Up  

";
$fb42949 = "Mamoswine @ Life Orb  
Ability: Thick Fat  
Tera Type: &
EVs: 192 Atk / 64 SpA / 252 Spe  
Naive Nature  
- Earthquake  
- Icicle Crash  
- Freeze-Dry  
- Substitute  

";
$fb42959 = "Torterra @ Leftovers  
Ability: Shell Armor  
Tera Type: &
EVs: 152 HP / 184 Atk / 4 Def / 168 Spe  
Adamant Nature  
- Block  
- Worry Seed  
- Earthquake  
- Stone Edge  

";
$fb42968 = "Meowscarada @ Heavy-Duty Boots  
Ability: Protean  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Jolly Nature  
- Knock Off  
- Triple Axel  
- Low Kick  
- U-turn

";
$fb42978 = "Archaludon @ Weakness Policy  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpA  
Rash Nature  
- Rock Tomb  
- Iron Defense  
- Draco Meteor  
- Hyper Beam

";
$fb42988 = "Archaludon @ Razor Claw  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Focus Energy  
- Earthquake  
- Draco Meteor
- Hard Press

";
$fb42998 = "Archaludon @ Custap Berry
Ability: Sturdy
Tera Type: &
EVs: 200 Atk / 252 SpA / 56 Spe
Rash Nature
- Draco Meteor
- Flash Cannon
- Rock Tomb
- Endure

";
$fb43008 = "Clodsire @ Payapa Berry
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 160 Atk / 56 Def / 36 SpD / 8 Spe
Adamant Nature
- Earthquake
- Poison Jab
- Megahorn
- Gunk Shot

";
$fb43018 = "Diancie @ Leftovers
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Relaxed Nature
IVs: 0 Atk / 0 Spe
- Iron Defense
- Trick Room
- Body Press
- Moonblast

";
$fb43029 = "Kingambit @ Life Orb
Ability: Supreme Overlord
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Quiet Nature
IVs: 0 Atk / 0 Spe
- Dark Pulse
- Focus Blast
- Steel Beam
- Grass Knot

";
$fb43040 = "Rillaboom @ Liechi Berry  
Ability: Overgrow  
Tera Type: &
EVs: 132 HP / 252 Atk / 12 Def / 112 Spe  
Adamant Nature  
- Substitute  
- Grassy Glide  
- Wood Hammer  
- Knock Off

";
$fb43049 = "Necrozma @ Aguav Berry  
Ability: Prism Armor  
Tera Type: &
EVs: 248 HP / 204 Def / 28 SpA / 20 SpD / 8 Spe  
Modest Nature  
- Substitute  
- Calm Mind  
- Photon Geyser  
- Prismatic Laser

";
$fb43058 = "Urshifu @ Sitrus Berry  
Ability: Unseen Fist  
Tera Type: &
EVs: 132 HP / 20 Atk / 136 SpD / 220 Spe  
Adamant Nature  
- Substitute  
- Bulk Up  
- Wicked Blow  
- Sucker Punch

";
$fb43067 = "Zeraora @ Chesto Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 100 Atk / 112 SpD / 48 Spe  
Adamant Nature  
- Bulk Up  
- Plasma Fists  
- Play Rough  
- Rest

";
$fb43076 = "Zacian @ Liechi Berry  
Ability: Intrepid Sword  
Level: 85  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Tail Slap  
- Reversal  
- Wild Charge

";
$fb43087 = "Heatran @ Passho Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 112 HP / 196 SpA / 4 SpD / 196 Spe  
Modest Nature  
IVs: 0 Atk  
- Overheat  
- Earth Power  
- Flash Cannon  
- Taunt

";
$fb43097 = "Necrozma @ Mental Herb  
Ability: Prism Armor  
Tera Type: &
EVs: 152 HP / 100 Atk / 152 SpD / 104 Spe  
Careful Nature  
- Dragon Dance  
- Photon Geyser  
- Outrage  
- Iron Head

";
$fb43106 = "Toxtricity-Low-Key @ Chilan Berry  
Ability: Punk Rock  
Tera Type: &
EVs: 252 SpA / 24 SpD / 232 Spe  
Mild Nature  
- Overdrive  
- Boomburst  
- Sludge Wave  
- Drain Punch

";
$fb43115 = "Clefable @ Choice Specs  
Ability: Unaware  
Tera Type: &
EVs: 180 HP / 212 Def / 80 SpA / 36 Spe  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Counter  
- Shadow Ball  
- Solar Beam

";
$fb43125 = "Necrozma @ Rocky Helmet  
Ability: Prism Armor  
Tera Type: &
EVs: 128 HP / 128 Atk / 252 Spe  
Adamant Nature  
- Protect  
- Swords Dance  
- Photon Geyser  
- Earthquake

";
$fb43134 = "Terrakion @ Rindo Berry  
Ability: Justified  
Shiny: Yes  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Rock Blast  
- Close Combat  
- Poison Jab

";
$fb43144 = "Guzzlord @ Focus Sash  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpD  
Adamant Nature  
- Knock Off  
- Earthquake  
- Outrage  
- Heavy Slam

";
$fb43153 = "Mismagius @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Pain Split  
- Will-O-Wisp  
- Shadow Ball  
- Taunt

";
$fb43163 = "Landorus-Therian @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- Stealth Rock  
- Earthquake  
- Hidden Power [Ice]  
- U-turn

";
$fb43172 = "Victini @ Assault Vest  
Ability: Victory Star  
Tera Type: &
EVs: 200 HP / 20 Atk / 252 SpD / 36 Spe  
Careful Nature  
- V-create  
- Power-Up Punch  
- Quick Afback  
- Bolt Strike

";
$fb43181 = "Tapu Fini @ Weakness Policy  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 76 Def / 124 SpA / 60 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Surf  
- Ice Beam  
- Nature's Madness

";
$fb43191 = "Lucario @ Lucarionite  
Ability: Inner Focus  
Shiny: Yes  
Tera Type: &
EVs: 148 Atk / 108 SpD / 252 Spe  
Jolly Nature  
- Protect  
- Close Combat  
- Blaze Kick  
- Iron Tail

";
$fb43201 = "Electrode @ Light Clay  
Ability: Static  
Tera Type: &
EVs: 248 HP / 44 Def / 216 Spe  
Jolly Nature  
- Reflect  
- Light Screen  
- Taunt  
- Explosion

";
$fb43210 = "Azumarill @ Assault Vest  
Ability: Huge Power  
Shiny: Yes  
Tera Type: &
EVs: 64 HP / 248 Atk / 116 Def / 28 SpD / 52 Spe  
Adamant Nature  
- Liquidation  
- Play Rough  
- Aqua Jet  
- Power-Up Punch

";

$tef43 = "Volcanion @ Weakness Policy  
Ability: Water Absorb  
Tera Type: &
EVs: 192 HP / 112 SpA / 204 Spe  
Modest Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Steam Eruption  
- Overheat  
- Confide  

";
$tef414 = "Ferrothorn @ Assault Vest  
Ability: Iron Barbs  
Tera Type: &
EVs: 224 HP / 216 Atk / 4 Def / 64 SpD  
Brave Nature  
IVs: 0 Spe  
- Acid Spray  
- Power Whip  
- Gyro Ball  
- Payback  

";
$tef425 = "Genesect @ Enigma Berry  
Ability: Download  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Magnet Bomb  
- Extreme Speed  
- Leech Life  
- Shift Gear  

";
$tef435 = "Electrode-Hisui @ Heavy-Duty Boots  
Ability: Aftermath  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Thunderbolt  
- Giga Drain  
- Tera Blast  

";
$tef446 = "Goodra @ Haban Berry  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 84 Def / 64 SpA / 108 Spe  
Modest Nature  
IVs: 0 Atk  
- Acid Spray  
- Draco Meteor  
- Acid Armor  
- Body Press  

";
$tef457 = "Goodra @ Enigma Berry  
Ability: Gooey  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Draco Meteor  
- Acid Spray  
- Mega Kick  
- Protect  

";
$tef467 = "Raboot @ Eviolite  
Ability: Libero  
Tera Type: &
EVs: 212 HP / 252 Atk / 44 Spe  
Adamant Nature  
- Gunk Shot  
- High Jump Kick  
- Flare Blitz  
- Sucker Punch  

";
$tef477 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Charm  
- Avalanche  
- Amnesia  
- Rest  

";
$tef487 = "Cottonee @ Eviolite  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Substitute  
- Taunt  

";
$tef498 = "Tornadus-Therian (M) @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Hurricane  
- Knock Off  
- Iron Tail  
- U-turn  

";
$tef4108 = "Gallade (M) @ Galladite  
Ability: Steadfast  
Tera Type: &
EVs: 16 HP / 252 Atk / 240 Spe  
Jolly Nature  
- Zen Headbutt  
- Close Combat  
- Poison Jab  
- Stone Edge  

";
$tef4118 = "Tyranitar @ Smooth Rock  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
- Stone Edge  
- Ice Beam  
- Pursuit  
- Stealth Rock  

";
$tef4128 = "Metagross @ Weakness Policy  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 232 Atk / 28 Def  
Adamant Nature  
- Meteor Mash  
- Earthquake  
- Bullet Punch  
- Cosmic Power  

";
$tef4138 = "Magmar @ Salac Berry  
Ability: Vital Spirit  
Tera Type: &
EVs: 4 HP / 252 Atk / 36 Def / 216 Spe  
Adamant Nature  
- Belly Drum  
- Substitute  
- Fire Punch  
- Dual Chop  

";
$tef4148 = "Slowbro @ Starf Berry  
Ability: Oblivious  
Tera Type: &
EVs: 216 HP / 172 Atk / 120 Def  
Relaxed Nature  
- Scald  
- Drain Punch  
- Belly Drum  
- Substitute  

";
$tef4158 = "Rotom-Heat @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 120 Def / 8 SpA / 132 SpD  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Swagger  
- Thunderbolt  
- Substitute  

";
$tef4169 = "Dragapult @ Salac Berry  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Endure  
- Disable  
- Rest  
- Outrage  

";
$tef4179 = "Rotom-Heat @ Passho Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 140 Def / 12 SpA / 100 SpD / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Eerie Impulse  
- Thunderbolt  
- Rest  

";
$tef4190 = "Raging Bolt @ Leftovers  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Tera Blast  
- Eerie Impulse  
- Substitute  
- Protect  

";
$tef4201 = "Hoopa-Unbound @ Heavy-Duty Boots  
Ability: Magician  
Tera Type: &
EVs: 248 HP / 44 Atk / 40 Def / 84 SpA / 92 Spe  
Lonely Nature  
- Knock Off  
- Psychic  
- Drain Punch  
- Gunk Shot  

";
$tef4211 = "Excadrill @ Air Balloon  
Ability: Sand Rush  
Tera Type: &
EVs: 248 Atk / 8 SpD / 252 Spe  
Jolly Nature  
- Rapid Spin  
- Rest  
- Substitute  
- Sandstorm  

";
$tef4221 = "Excadrill @ Air Balloon  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Horsepower  
- Iron Head  
- Rapid Spin  
- Protect  

";
$tef4231 = "Altaria @ Heavy-Duty Boots  
Ability: Cloud Nine  
Tera Type: &
EVs: 252 HP / 236 Def / 20 Spe  
Impish Nature  
- Brave Bird  
- Breaking Swipe  
- Will-O-Wisp  
- Roost  

";
$tef4241 = "Kingdra @ Heavy-Duty Boots  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Wave Crash  
- Scale Shot  
- Breaking Swipe  
- Dragon Dance  

";
$tef4251 = "Moltres-Galar @ Berry Juice  
Ability: Berserk  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Fiery Wrath  
- Air Slash  
- Rest  
- Sleep Talk  

";
$tef4262 = "Ampharos @ Ampharosite  
Ability: Static  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Volt Switch  
- Dragon Pulse  
- Sleep Talk  
- Rest  

";
$tef4273 = "Tentacruel @ Heavy-Duty Boots  
Ability: Liquid Ooze  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Scald  
- Sludge Bomb  
- Flip Turn  
- Rapid Spin  

";
$tef4283 = "Emboar @ Leftovers  
Ability: Reckless  
Tera Type: &
EVs: 48 HP / 80 Atk / 128 SpD / 252 Spe  
Jolly Nature  
- Flare Blitz  
- Drain Punch  
- Trailblaze  
- Bulk Up  

";
$tef4293 = "Tauros (M) @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Body Slam  
- Trailblaze  
- Toxic  
- Protect  

";
$tef4303 = "Metagross @ Choice Band  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Heavy Slam  
- Psychic Fangs  
- Knock Off  
- Dynamic Punch  

";
$tef4313 = "Metagross @ Metagrossite  
Ability: Clear Body  
Tera Type: &
EVs: 92 HP / 28 Atk / 136 SpD / 252 Spe  
Jolly Nature  
- Pursuit  
- Protect  
- Knock Off  
- Stealth Rock  

";
$tef4323 = "Clodsire @ Kee Berry  
Ability: Poison Point  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Relaxed Nature  
IVs: 0 Atk  
- Body Press  
- Acid Spray  
- Curse  
- Recover  

";
$tef4334 = "Lucario @ Leftovers  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Drain Punch  
- Extreme Speed  
- Protect  
- Bulk Up  

";
$tef4344 = "Keldeo @ Lagging Tail  
Ability: Justified  
Tera Type: &
EVs: 252 HP / 52 SpA / 204 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Aura Sphere  
- Baton Pass  
- Calm Mind  

";
$tef4355 = "Eiscue @ Rocky Helmet  
Ability: Ice Face  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Icicle Spear  
- Body Slam  
- Hail  
- Snowscape  

";
$tef4365 = "Gouging Fire @ Mental Herb  
Ability: Protosynthesis  
Tera Type: &
EVs: 240 HP / 40 Atk / 40 Def / 4 SpD / 184 Spe  
Adamant Nature  
- Outrage  
- Flare Blitz  
- Scale Shot  
- Sunny Day  

";
$tef4375 = "Gothitelle @ Leftovers  
Ability: Shadow Tag  
Tera Type: &
EVs: 68 HP / 28 Atk / 124 Def / 212 SpA / 32 SpD / 44 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic Noise  
- Protect  

";
$tef4384 = "Magcargo @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Lava Plume  
- Stealth Rock  
- Recover  
- Protect  

";
$tef4395 = "Crobat @ Sky Plate  
Ability: Infiltrator  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Brave Bird  
- U-turn  
- Taunt  
- Roost  

";
$tef4405 = "Gothitelle @ Booster Energy  
Ability: Shadow Tag  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
- Psychic  
- Focus Blast  
- Trick  
- Fake Out  

";
$tef4415 = "Heatmor @ Life Orb  
Ability: Flash Fire  
Tera Type: &
EVs: 85 HP / 85 Atk / 85 Def / 85 SpA / 85 SpD / 85 Spe  
- Superpower  
- Fire Blast  
- Sucker Punch  
- Giga Drain  

";
$tef4424 = "Stantler @ Choice Band  
Ability: Intimidate  
Tera Type: &
EVs: 81 HP / 85 Atk / 85 Def / 85 SpA / 85 SpD / 85 Spe  
- Jump Kick  
- Double-Edge  
- Megahorn  
- Earthquake  

";
$tef4433 = "Indeedee-F (F) @ Heavy-Duty Boots  
Ability: Synchronize  
Tera Type: &
EVs: 28 HP / 252 SpA / 228 Spe  
Modest Nature  
- Future Sight  
- Tera Blast  
- Baton Pass  
- Fake Out  

";
$tef4443 = "Clefable @ Leftovers  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Moonblast  
- Future Sight  
- Baton Pass  
- Soft-Boiled  

";
$tef4454 = "Clefable @ Leftovers  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
- Knock Off  
- Future Sight  
- Baton Pass  
- Soft-Boiled  

";
$tef4464 = "Clefable @ Throat Spray  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Alluring Voice  
- Protect  
- Baton Pass  
- Cosmic Power  

";
$tef4475 = "Mew @ Normalium Z  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Naive Nature  
- Baton Pass  
- Bulk Up  
- Future Sight  
- Giga Impact  

";
$tef4485 = "Klawf @ Eject Button  
Ability: Regenerator  
Tera Type: &
EVs: 100 HP / 108 Atk / 100 Def / 100 SpD / 100 Spe  
Adamant Nature  
- Stone Edge  
- Knock Off  
- Protect  
- Stealth Rock  

";
$tef4495 = "Keldeo @ Wacan Berry  
Ability: Justified  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Liquidation  
- Aqua Jet  
- Megahorn  

";
$tef4505 = "Nihilego @ Black Sludge  
Ability: Beast Boost  
Tera Type: &
EVs: 80 Def / 176 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Power Gem  
- Hex  
- Thunder Wave  
- Substitute  

";
$tef4516 = "Celesteela @ Chesto Berry  
Ability: Beast Boost  
Tera Type: &
EVs: 120 HP / 148 Atk / 80 SpD / 160 Spe  
Adamant Nature  
- Acrobatics  
- Earthquake  
- Rest  
- Autotomize  

";
$tef4526 = "Mew @ Custap Berry  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 136 Def / 64 SpA / 56 SpD / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Psyshock  
- Dazzling Gleam  
- Nasty Plot  
- Roost  

";
$tef4537 = "Alomomola @ Eject Button  
Ability: Regenerator  
Tera Type: &
EVs: 64 HP / 200 Def / 244 SpD  
Sassy Nature  
IVs: 0 Spe  
- Flip Turn  
- Aqua Jet  
- Alluring Voice  
- Healing Wish  

";
$tef4548 = "Gallade @ Life Orb  
Ability: Sharpness  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Agility  
- Triple Axel  
- Sacred Sword  
- Psycho Cut  

";
$tef4558 = "Great Tusk @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Close Combat  
- Knock Off  
- Rapid Spin  
- Scary Face  

";
$tef4568 = "Persian-Alola @ Sitrus Berry  
Ability: Fur Coat  
Tera Type: &
EVs: 32 HP / 88 Def / 252 SpD / 136 Spe  
Jolly Nature  
- Foul Play  
- Knock Off  
- Toxic  
- Parting Shot  

";
$tef4578 = "Tinkaton (F) @ Eject Button  
Ability: Pickpocket  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Stealth Rock  
- Gigaton Hammer  
- Play Rough  
- Encore  

";
$tef4588 = "Blastoise @ Leftovers  
Ability: Torrent  
Tera Type: &
EVs: 248 HP / 108 Def / 152 SpA  
Bold Nature  
- Surf  
- Double-Edge  
- Shell Smash  
- Ice Beam  

";
$tef4598 = "Rotom-Wash @ Assault Vest  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 244 SpD / 12 Spe  
Calm Nature  
IVs: 0 Atk  
- Hydro Pump  
- Discharge  
- Volt Switch  
- Night Shade  

";
$tef4609 = "Dragalge @ Red Card  
Ability: Adaptability  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
- Draco Meteor  
- Dragon Tail  
- Flip Turn  
- Endure  

";
$tef4619 = "Great Tusk @ Focus Sash  
Ability: Protosynthesis  
Tera Type: &
EVs: 40 HP / 208 Atk / 8 Def / 252 Spe  
Jolly Nature  
- Close Combat  
- Endeavor  
- Rapid Spin  
- Roar  

";
$tef4629 = "Tinkaton (F) @ Custap Berry  
Ability: Pickpocket  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Gigaton Hammer  
- Endeavor  
- Stealth Rock  
- Endure  

";
$tef4639 = "Blastoise @ Choice Specs  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Water Spout  
- Rapid Spin  
- Dark Pulse  
- Surf  

";
$tef4649 = "Sceptile @ Sceptilite  
Ability: Overgrow  
Shiny: Yes  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Energy Ball  
- Dragon Pulse  
- Endeavor  
- Substitute  

";
$tef4661 = "Crobat @ Flying Gem  
Ability: Infiltrator  
Tera Type: &
EVs: 64 HP / 252 Atk / 192 Spe  
Jolly Nature  
- Brave Bird  
- Steel Wing  
- U-turn  
- Roost  

";
$tef4671 = "Starmie @ Colbur Berry  
Ability: Analytic  
Tera Type: &
EVs: 104 HP / 188 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Thunder  
- Dazzling Gleam  
- Recover  

";
$tef4682 = "Rotom-Heat @ Iapapa Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Calm Nature  
IVs: 0 Atk  
- Volt Switch  
- Hidden Power [Ice]  
- Defog  
- Toxic  

";
$tef4693 = "Iron Hands @ Shuca Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Serious Nature  
- Close Combat  
- Thunder Punch  
- Swords Dance  
- Volt Switch  

";
$tef4703 = "Iron Treads @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 32 HP / 252 Atk / 224 Spe  
Jolly Nature  
- Heavy Slam  
- Earthquake  
- Ice Spinner  
- Double-Edge  

";
$tef4713 = "Duraludon @ Eviolite  
Ability: Light Metal  
Tera Type: &
EVs: 100 HP / 24 Def / 168 SpA / 216 Spe  
Timid Nature  
- Draco Meteor  
- Brick Break  
- Thunder Wave  
- Stealth Rock  

";
$tef4723 = "Donphan @ Clear Amulet  
Ability: Sturdy  
Tera Type: &
EVs: 160 HP / 252 Atk / 4 Def / 92 Spe  
Adamant Nature  
- Earthquake  
- Ice Spinner  
- Ice Shard  
- Stealth Rock  

";
$tef4733 = "Nidoqueen @ Shuca Berry  
Ability: Poison Point  
Tera Type: &
EVs: 52 HP / 204 Atk / 252 SpD  
Adamant Nature  
- Poison Jab  
- Avalanche  
- Sucker Punch  
- Stealth Rock  

";
$tef4743 = "Blissey @ Assault Vest  
Ability: Serene Grace  
Tera Type: &
EVs: 80 HP / 252 Def / 176 SpD  
Calm Nature  
IVs: 0 Atk  
- Counter  
- Flamethrower  
- Seismic Toss  
- Shadow Ball  

";
$tef4754 = "Sylveon @ Grassy Seed  
Ability: Pixilate  
Tera Type: &
EVs: 248 HP / 120 Def / 140 SpA  
Modest Nature  
- Hyper Voice  
- Hyper Beam  
- Fake Tears  
- Quick Attack  

";
$tef4764 = "Bewear @ Custap Berry  
Ability: Fluffy  
Tera Type: &
EVs: 20 HP / 220 Atk / 252 Def / 16 Spe  
Adamant Nature  
- Close Combat  
- Swords Dance  
- Endure  
- Giga Impact  

";
$tef4774 = "Tapu Koko @ Electric Seed  
Ability: Electric Surge  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Reflect  
- Iron Defense  
- Roost  
- Acrobatics  

";
$tef4784 = "Empoleon @ Chople Berry  
Ability: Competitive  
Tera Type: &
EVs: 252 HP / 120 Def / 20 SpA / 116 Spe  
Bold Nature  
IVs: 0 Atk  
- Hydro Cannon  
- Grass Knot  
- Yawn  
- Protect  

";
$tef4795 = "Type: Null @ Eviolite  
Ability: Battle Armor  
Tera Type: &
EVs: 248 HP / 196 Def / 64 SpD  
Impish Nature  
- Iron Defense  
- Confide  
- Rest  
- Flame Charge  

";
$tef4805 = "Amoonguss @ Hondew Berry  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 68 Def / 96 SpA / 96 SpD  
Modest Nature  
IVs: 1 Atk / 30 SpA / 30 SpD  
- Sludge Bomb  
- Hidden Power [Ground]  
- Spore  
- Synthesis  

";
$tef4816 = "Guzzlord @ Enigma Berry  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 152 Def / 32 SpD / 72 Spe  
Adamant Nature  
- Knock Off  
- Hammer Arm  
- Protect  
- Dragon Tail  

";
$tef4826 = "Heatran @ Air Balloon  
Ability: Flash Fire  
Tera Type: &
EVs: 248 HP / 104 Def / 36 SpA / 120 Spe  
Modest Nature  
IVs: 0 Atk  
- Iron Defense  
- Body Press  
- Taunt  
- Flash Cannon  

";
$tef4837 = "Heatran @ Enigma Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Lava Plume  
- Dragon Pulse  
- Taunt  
- Stealth Rock  

";
$tef4848 = "Corviknight @ Custap Berry  
Ability: Mirror Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Reversal  
- Brave Bird  
- Iron Head  
- Endure  

";
$tef4858 = "Tapu Koko @ Electric Seed  
Ability: Electric Surge  
Tera Type: &
EVs: 180 HP / 232 Def / 96 Spe  
Timid Nature  
- Thunderbolt  
- Torment  
- Roost  
- Toxic  

";
$tef4868 = "Gyarados @ Choice Band  
Ability: Intimidate  
Tera Type: &
EVs: 12 HP / 252 Atk / 36 SpD / 208 Spe  
Adamant Nature  
- Waterfall  
- Avalanche  
- Power Whip  
- Iron Tail  

";
$tef4878 = "Sinistcha @ Power Herb  
Ability: Heatproof  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk  
- Solar Beam  
- Shadow Ball  
- Meteor Beam  
- Trick Room  

";
$tef4889 = "Hydrapple @ Power Herb  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Solar Beam  
- Yawn  
- Reflect  
- Nasty Plot  

";
$tef4900 = "Zangoose @ Salac Berry  
Ability: Immunity  
Tera Type: &
EVs: 112 HP / 252 Atk / 40 Def / 104 Spe  
Adamant Nature  
- Endure  
- Flail  
- Swords Dance  
- Close Combat  

";
$tef4910 = "Cradily @ Leftovers  
Ability: Suction Cups  
Tera Type: &
EVs: 220 HP / 180 Def / 36 SpD / 72 Spe  
Impish Nature  
IVs: 0 Atk  
- Barrier  
- Amnesia  
- Recover  
- Ingrain  

";
$tef4921 = "Zapdos @ Magnet  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 56 Def / 124 SpA / 96 Spe  
Modest Nature  
IVs: 2 Atk / 30 Def  
- Thunderbolt  
- Hidden Power [Ice]  
- Heat Wave  
- Shock Wave  

";
$tef4932 = "Arcanine @ Mawilite  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Play Rough  
- Iron Head  
- Return  
- Protect  

";
$tef4942 = "Espeon @ Weakness Policy  
Ability: Magic Bounce  
Tera Type: &
EVs: 136 HP / 216 Atk / 4 Def / 152 SpD  
Adamant Nature  
- Bite  
- Trailblaze  
- Quick Attack  
- Protect  

";
$tef4952 = "Phione @ Leftovers  
Ability: Hydration  
Tera Type: &
EVs: 192 HP / 16 Atk / 160 Def / 140 SpD  
Impish Nature  
IVs: 0 Spe  
- Knock Off  
- Whirlpool  
- Haze  
- Rest  

";
$tef4963 = "Klawf @ Covert Cloak  
Ability: Anger Shell  
Tera Type: &
EVs: 40 HP / 112 Atk / 88 Def / 252 SpA / 16 SpD  
Mild Nature  
- Earth Power  
- Rock Tomb  
- Endure  
- Skitter Smack  

";
$tef4973 = "Delphox @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 48 Def / 252 SpA / 208 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Future Sight  
- Blast Burn  
- Substitute  

";
$tef4984 = "Chi-Yu @ Petaya Berry  
Ability: Beads of Ruin  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Inferno  
- Tera Blast  
- Substitute  
- Protect  

";
$tef4995 = "Swadloon (F) @ Eviolite  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Iron Defense  
- Calm Mind  
- Synthesis  
- Toxic  

";
$tef41006 = "Furfrou-Dandy @ Normalium Z  
Ability: Fur Coat  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 76 SpD / 180 Spe  
Careful Nature  
- Tackle  
- Rest  
- Cotton Guard  
- Confide  

";
$tef41017 = "Swampert (M) @ Swampertite  
Ability: Damp  
Tera Type: &
EVs: 208 HP / 16 Atk / 36 SpA / 248 SpD  
Brave Nature  
- Toxic  
- Protect  
- Earthquake  
- Ice Beam  

";
$tef41027 = "Euphonos (Moltres) @ Aguav Berry  
Ability: Flame Body  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Burn Up  
- Will-O-Wisp  
- Roost  
- Air Slash  

";
$tef41038 = "Squirtle (M) @ Eviolite  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Mirror Coat  
- Counter  
- Protect  
- Scald  

";
$tef41049 = "Sawk @ Groundium Z  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Close Combat  
- Earthquake  
- Rock Tomb  
- Counter  

";
$tef41059 = "Gengar (F) @ Electrium Z  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder  
- Substitute  
- Clear Smog  
- Sludge Bomb  

";
$tef41070 = "Arcanine (M) @ Firium Z  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Will-O-Wisp  
- Flare Blitz  
- Extreme Speed  
- Outrage  

";
$tef41080 = "Togedemaru (M) @ Iapapa Berry  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Spiky Shield  
- Toxic  
- Zing Zap  
- Substitute  

";
$tef41090 = "Octillery @ Custap Berry  
Ability: Sniper  
Tera Type: &
EVs: 120 HP / 252 Def / 136 SpA  
Modest Nature  
IVs: 0 Atk  
- Acid Spray  
- Energy Ball  
- Hydro Pump  
- Fire Blast  

";
$tef41101 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 232 HP / 12 Atk / 92 Def / 172 SpD  
Relaxed Nature  
IVs: 19 Spe  
- Icicle Spear  
- Ice Shard  
- Rock Slide  
- Earthquake  

";
$tef41112 = "Entei @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Calm Mind  
- Substitute  
- Protect  

";
$tef41123 = "Raikou @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Calm Mind  
- Substitute  
- Protect  

";
$tef41134 = "Regirock @ Leftovers  
Ability: Clear Body  
Tera Type: &
EVs: 232 HP / 56 Def / 220 Spe  
Impish Nature  
- Iron Defense  
- Body Press  
- Rock Blast  
- Substitute  

";
$tef41144 = "Ampharos @ Power Herb  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Meteor Beam  
- Dazzling Gleam  
- Agility  

";
$tef41155 = "Bronzong @ Ability Shield  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 124 Def / 136 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Gyro Ball  
- Body Press  
- Iron Defense  
- Rest  

";
$tef41166 = "Excadrill @ Loaded Dice  
Ability: Mold Breaker  
Tera Type: &
EVs: 48 HP / 252 SpD / 208 Spe  
Adamant Nature  
- Swords Dance  
- Earthquake  
- Rock Blast  
- Rapid Spin  

";
$tef41176 = "Rotom-Wash @ Ability Shield  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 84 SpA / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Hydro Pump  
- Discharge  
- Will-O-Wisp  

";
$tef41187 = "Meloetta @ Rocky Helmet  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Thunder Wave  
- Teeter Dance  
- Rest  
- Snore  

";
$tef41198 = "Hitmontop (M) @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 48 Atk / 212 SpD  
Brave Nature  
IVs: 0 Spe  
- Substitute  
- Endeavor  
- Mach Punch  
- Sucker Punch  

";
$tef41209 = "Altaria @ Altarianite  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 116 Atk / 140 SpD  
Adamant Nature  
- Facade  
- Fire Blast  
- Roost  
- Defog  

";
$tef41219 = "Blaziken @ Razor Claw  
Ability: Speed Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Scorching Sands  
- Vacuum Wave  
- Focus Blast  

";
$tef41230 = "Ogerpon (F) @ Scope Lens  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Ivy Cudgel  
- Encore  
- Synthesis  
- Focus Energy  

";
$tef41240 = "Mew @ Scope Lens  
Ability: Synchronize  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Leaf Storm  
- Draco Meteor  
- Focus Energy  

";
$tef41251 = "Hatterene @ Leftovers  
Ability: Magic Bounce  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quirky Nature  
IVs: 0 Atk  
- Protect  
- Giga Drain  
- Tera Blast  
- Psyshock  

";
$tef41262 = "Cacturne @ Leftovers  
Ability: Sand Veil  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quirky Nature  
- Encore  
- Tera Blast  
- Throat Chop  
- Focus Blast  

";
$tef41272 = "Beartic @ Assault Vest  
Ability: Swift Swim  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quirky Nature  
- Facade  
- Earthquake  
- Ice Fang  
- Throat Chop  

";
$tef41282 = "Amoonguss @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quirky Nature  
- Bullet Seed  
- Sludge Bomb  
- Growth  
- Giga Drain  

";
$tef41292 = "Grafaiai @ Mago Berry  
Ability: Prankster  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quirky Nature  
- Taunt  
- Take Down  
- Toxic  
- Protect  

Incineroar  
Ability: Blaze  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quirky Nature  
- Swords Dance  
- Close Combat  
- Earthquake  
- Acrobatics  

";
$tef41312 = "Iron Valiant @ Choice Scarf  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Moonblast  
- Rest  
- Trick  

";
$tef41323 = "Metagross @ Metagrossite  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Rest  
- Swagger  
- Substitute  
- Protect  

";
$tef41334 = "Flaaffy @ Throat Spray  
Ability: Static  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Discharge  
- Roar  
- Rest  
- Sleep Talk  

";
$tef41345 = "Flaaffy @ Eviolite  
Ability: Static  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Toxic  
- Hidden Power [Ice]  
- Heal Bell  
- Volt Switch  

";
$tef41356 = "Illumise (F) @ Heavy-Duty Boots  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Power-Up Punch  
- Thunder Wave  
- Baton Pass  
- Encore  

";
$tef41366 = "Mawile @ Mawilite  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Power-Up Punch  
- Baton Pass  
- Stealth Rock  
- Protect  

";
$tef41376 = "Mawile @ Mawilite  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Power-Up Punch  
- Torment  
- Stealth Rock  
- Protect  

";
$tef41386 = "Mawile @ Mawilite  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Power-Up Punch  
- Baton Pass  
- Play Rough  
- Protect  

";
$tef41396 = "Mawile @ Mawilite  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Relaxed Nature  
- Power-Up Punch  
- Baton Pass  
- Draining Kiss  
- Protect  

";
$tef41406 = "Mawile @ Mawilite  
Ability: Sheer Force  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Power-Up Punch  
- Baton Pass  
- Foul Play  
- Protect  

";
$tef41416 = "Mawile @ Mawilite  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Power-Up Punch  
- Baton Pass  
- Dynamic Punch  
- Protect  

";
$tef41426 = "Mawile @ Mawilite  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Power-Up Punch  
- Baton Pass  
- Sucker Punch  
- Taunt  

";
$tef41436 = "Wyrdeer @ Darkinium Z  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Psyshield Bash  
- Sucker Punch  
- Toxic  
- Substitute  

";
$tef41446 = "Furret @ Heavy-Duty Boots  
Ability: Run Away  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Return  
- Power-Up Punch  
- Baton Pass  
- Protect  

";
$tef41456 = "Rampardos @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 20 HP / 128 Atk / 160 Def / 4 SpD / 196 Spe  
Adamant Nature  
- Body Slam  
- Trailblaze  
- Power-Up Punch  
- Protect  

";
$tef41466 = "Latios (M) @ Psychium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Psywave  
- Aura Sphere  
- Roost  
- Calm Mind  

";
$tef41477 = "Dudunsparce @ Leftovers  
Ability: Rattled  
Tera Type: &
EVs: 252 HP / 64 Atk / 4 Def / 188 Spe  
Adamant Nature  
- Headbutt  
- Baton Pass  
- Roost  
- Thunder Wave  

";
$tef41487 = "Blastoise @ Blastoisinite  
Ability: Torrent  
Tera Type: &
EVs: 1 Atk  
- Surf  
- Seismic Toss  
- Counter  
- Body Slam  

";
$tef41496 = "Exeggutor-Alola @ Custap Berry  
Ability: Frisk  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Wood Hammer  
- Superpower  
- Flamethrower  
- Endure  

";
$tef41506 = "Inteleon @ Scope Lens  
Ability: Sniper  
Tera Type: &
EVs: 136 HP / 4 Def / 128 SpA / 240 Spe  
Modest Nature  
- Hydro Cannon  
- Ice Beam  
- Focus Energy  
- Work Up  

";
$tef41516 = "Celesteela @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 248 HP / 92 Atk / 16 Def / 140 SpD / 12 Spe  
Careful Nature  
- Heavy Slam  
- Flamethrower  
- Energy Ball  
- Bulldoze  

";
$tef41526 = "Kyurem @ Choice Scarf  
Ability: Pressure  
Tera Type: &
EVs: 88 Def / 252 SpA / 168 Spe  
Timid Nature  
- Draco Meteor  
- Ice Beam  
- Icicle Spear  
- Earth Power  

";
$tef41536 = "Conkeldurr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 8 HP / 252 Atk / 104 Def / 144 Spe  
Adamant Nature  
- Close Combat  
- Poison Jab  
- Ice Punch  
- Focus Energy  

";
$tef41546 = "Ferrothorn @ Maranga Berry  
Ability: Iron Barbs  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Spe  
- Gyro Ball  
- Leech Seed  
- Confide  
- Rest  

";
$tef41557 = "Tapu Fini @ Choice Scarf  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 40 Def / 4 SpA / 216 Spe  
Timid Nature  
- Surf  
- Moonblast  
- Trick  
- Torment  

";
$tef41567 = "Salamence @ Choice Scarf  
Ability: Intimidate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Hasty Nature  
- Outrage  
- Fire Blast  
- Hurricane  
- Earthquake  

";
$tef41577 = "Vileplume @ Choice Specs  
Ability: Effect Spore  
Tera Type: &
EVs: 248 HP / 104 Def / 120 SpA / 36 SpD  
Quiet Nature  
IVs: 19 Spe  
- Sludge Wave  
- Moonblast  
- Petal Dance  
- Giga Drain  

";
$tef41588 = "Mawile @ Expert Belt  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 100 Atk / 144 Def / 16 Spe  
Adamant Nature  
- Play Rough  
- Iron Head  
- Counter  
- Taunt  

";
$tef41598 = "Toxicroak @ Life Orb  
Ability: Dry Skin  
Tera Type: &
EVs: 160 HP / 76 Atk / 96 Def / 176 Spe  
Adamant Nature  
- Knock Off  
- Gunk Shot  
- Low Kick  
- Bullet Punch  

";
$tef41608 = "Marowak @ Thick Club  
Ability: Battle Armor  
Tera Type: &
EVs: 128 HP / 140 Atk / 240 SpD  
Adamant Nature  
- Bonemerang  
- Smack Down  
- Swords Dance  
- Counter  

";
$tef41618 = "Polteageist @ Kasib Berry  
Ability: Cursed Body  
Tera Type: &
EVs: 248 HP / 84 SpD / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Shell Smash  
- Will-O-Wisp  
- Shadow Ball  
- Strength Sap  

";
$tef41629 = "Sceptile @ Loaded Dice  
Ability: Overgrow  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Bullet Seed  
- Scale Shot  
- Trailblaze  
- Swords Dance  

";
$tef41639 = "Bronzong @ Choice Band  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Gyro Ball  
- Zen Headbutt  
- Earthquake  
- Payback  

";
$tef41650 = "Cobalion @ Occa Berry  
Ability: Justified  
Tera Type: &
EVs: 248 HP / 224 Atk / 16 Def / 20 SpD  
Relaxed Nature  
IVs: 24 Spe  
- Metal Burst  
- Close Combat  
- Iron Head  
- Taunt  

";
$tef41661 = "Coalossal @ Power Herb  
Ability: Steam Engine  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Modest Nature  
- Meteor Beam  
- Power Gem  
- Flamethrower  
- Rapid Spin  

";
$tef41671 = "Octillery @ Assault Vest  
Ability: Sniper  
Tera Type: &
EVs: 252 HP / 204 Def / 52 SpA  
Modest Nature  
IVs: 0 Atk  
- Acid Spray  
- Energy Ball  
- Fire Blast  
- Ice Beam  

";
$tef41682 = "Maractus @ Loaded Dice  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Bullet Seed  
- Pin Missile  
- Sucker Punch  
- Sunny Day  

";
$tef41692 = "Tsareena @ Grassium Z  
Ability: Queenly Majesty  
Tera Type: &
EVs: 192 HP / 60 Atk / 56 Def / 200 Spe  
Adamant Nature  
- Substitute  
- Synthesis  
- Trop Kick  
- High Jump Kick  

";
$tef41702 = "Cloyster @ Waterium Z  
Ability: Shell Armor  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
- Withdraw  
- Whirlpool  
- Rest  
- Twineedle  

";
$tef41713 = "Cradily @ Rockium Z  
Ability: Storm Drain  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD  
Sassy Nature  
- Recover  
- Giga Drain  
- Stone Edge  
- Barrier  

";
$tef41724 = "Lunatone @ Rockium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 84 Def / 24 SpA / 64 SpD / 84 Spe  
Modest Nature  
IVs: 0 Atk  
- Power Gem  
- Earth Power  
- Icy Wind  
- Ice Beam  

";
$tef41735 = "Simisage @ Micle Berry  
Ability: Gluttony  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 HP / 0 Atk  
- Grass Whistle  
- Substitute  
- Energy Ball  
- Leech Seed  

";
$tef41746 = "Volcanion @ Weakness Policy  
Ability: Water Absorb  
Tera Type: &
EVs: 192 HP / 112 SpA / 204 Spe  
Modest Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Steam Eruption  
- Overheat  
- Confide  

";
$tef41757 = "Ferrothorn @ Assault Vest  
Ability: Iron Barbs  
Tera Type: &
EVs: 224 HP / 216 Atk / 4 Def / 64 SpD  
Brave Nature  
IVs: 0 Spe  
- Acid Spray  
- Power Whip  
- Gyro Ball  
- Payback  

";
$tef41768 = "Genesect @ Enigma Berry  
Ability: Download  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Magnet Bomb  
- Extreme Speed  
- Leech Life  
- Shift Gear  

";
$tef41778 = "Electrode-Hisui @ Heavy-Duty Boots  
Ability: Aftermath  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Thunderbolt  
- Giga Drain  
- Tera Blast  

";
$tef41789 = "Goodra @ Haban Berry  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 84 Def / 64 SpA / 108 Spe  
Modest Nature  
IVs: 0 Atk  
- Acid Spray  
- Draco Meteor  
- Acid Armor  
- Body Press  

";
$tef41800 = "Goodra @ Enigma Berry  
Ability: Gooey  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Draco Meteor  
- Acid Spray  
- Mega Kick  
- Protect  

";
$tef41810 = "Raboot @ Eviolite  
Ability: Libero  
Tera Type: &
EVs: 212 HP / 252 Atk / 44 Spe  
Adamant Nature  
- Gunk Shot  
- High Jump Kick  
- Flare Blitz  
- Sucker Punch  

";
$tef41820 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Charm  
- Avalanche  
- Amnesia  
- Rest  

";
$tef41830 = "Cottonee @ Eviolite  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Substitute  
- Taunt  

";
$tef41841 = "Tornadus-Therian (M) @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Hurricane  
- Knock Off  
- Iron Tail  
- U-turn  

";
$tef41851 = "Gallade (M) @ Galladite  
Ability: Steadfast  
Tera Type: &
EVs: 16 HP / 252 Atk / 240 Spe  
Jolly Nature  
- Zen Headbutt  
- Close Combat  
- Poison Jab  
- Stone Edge  

";
$tef41861 = "Tyranitar @ Smooth Rock  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
- Stone Edge  
- Ice Beam  
- Pursuit  
- Stealth Rock  

";
$tef41871 = "Metagross @ Weakness Policy  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 232 Atk / 28 Def  
Adamant Nature  
- Meteor Mash  
- Earthquake  
- Bullet Punch  
- Cosmic Power  

";
$tef41881 = "Magmar @ Salac Berry  
Ability: Vital Spirit  
Tera Type: &
EVs: 4 HP / 252 Atk / 36 Def / 216 Spe  
Adamant Nature  
- Belly Drum  
- Substitute  
- Fire Punch  
- Dual Chop  

";
$tef41891 = "Slowbro @ Starf Berry  
Ability: Oblivious  
Tera Type: &
EVs: 216 HP / 172 Atk / 120 Def  
Relaxed Nature  
- Scald  
- Drain Punch  
- Belly Drum  
- Substitute  

";
$tef41901 = "Rotom-Heat @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 120 Def / 8 SpA / 132 SpD  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Swagger  
- Thunderbolt  
- Substitute  

";
$tef41912 = "Dragapult @ Salac Berry  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Endure  
- Disable  
- Rest  
- Outrage  

";
$tef41922 = "Rotom-Heat @ Passho Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 140 Def / 12 SpA / 100 SpD / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Eerie Impulse  
- Thunderbolt  
- Rest  

";
$tef41933 = "Raging Bolt @ Leftovers  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Tera Blast  
- Eerie Impulse  
- Substitute  
- Protect  

";
$tef41944 = "Hoopa-Unbound @ Heavy-Duty Boots  
Ability: Magician  
Tera Type: &
EVs: 248 HP / 44 Atk / 40 Def / 84 SpA / 92 Spe  
Lonely Nature  
- Knock Off  
- Psychic  
- Drain Punch  
- Gunk Shot  

";
$tef41954 = "Excadrill @ Air Balloon  
Ability: Sand Rush  
Tera Type: &
EVs: 248 Atk / 8 SpD / 252 Spe  
Jolly Nature  
- Rapid Spin  
- Rest  
- Substitute  
- Sandstorm  

";
$tef41964 = "Excadrill @ Air Balloon  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Horsepower  
- Iron Head  
- Rapid Spin  
- Protect  

";
$tef41974 = "Altaria @ Heavy-Duty Boots  
Ability: Cloud Nine  
Tera Type: &
EVs: 252 HP / 236 Def / 20 Spe  
Impish Nature  
- Brave Bird  
- Breaking Swipe  
- Will-O-Wisp  
- Roost  

";
$tef41984 = "Kingdra @ Heavy-Duty Boots  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Wave Crash  
- Scale Shot  
- Breaking Swipe  
- Dragon Dance  

";
$tef41994 = "Articuno @ Sitrus Berry  
Ability: Snow Cloak  
Tera Type: &
EVs: 120 Def / 252 SpA / 136 Spe  
Bold Nature  
IVs: 0 Atk  
- Snowscape  
- Blizzard  
- Hurricane  
- Roost

";
$tef42005 = "Gyarados @ Mirror Herb  
Ability: Intimidate  
Shiny: Yes  
Tera Type: &
EVs: 124 HP / 112 Atk / 24 Def / 248 Spe  
Jolly Nature  
IVs: 0 SpA  
- Waterfall  
- Outrage  
- Dragon Dance  
- Taunt

";
$tef42017 = "Clefable @ Mental Herb  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Moonblast  
- Moonlight  
- Flamethrower  

";
$tef42028 = "Landorus-Therian @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Nasty Plot  
- Earth Power  
- Tera Blast  

";
$tef42039 = "Samurott-Hisui @ Heavy-Duty Boots  
Ability: Sharpness  
Happiness: 69  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Ceaseless Edge  
- Razor Shell  
- Aqua Jet  
- Sacred Sword  

";
$tef42050 = "Mew @ Rocky Helmet  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 148 SpA / 112 Spe  
Timid Nature  
- Spikes  
- Future Sight  
- Soft-Boiled  
- Sand Tomb  

";
$tef42060 = "Landorus-Therian (M) @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 12 Atk / 96 SpD / 152 Spe  
Careful Nature  
- Swords Dance  
- Earthquake  
- Knock Off  
- Rest  

";
$tef42070 = "Kartana @ Life Orb  
Ability: Beast Boost  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 19 Atk  
- Swords Dance  
- Leaf Blade  
- Knock Off  
- Synthesis  

";
$tef42081 = "Keldeo @ Weakness Policy  
Ability: Justified  
Tera Type: &
EVs: 168 HP / 200 Atk / 4 Def / 4 SpA / 132 Spe  
Mild Nature  
- Calm Mind  
- Taunt  
- Focus Blast  
- Poison Jab  

";
$tef42091 = "Vespiquen (F) @ Sitrus Berry  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 196 Def / 60 SpD / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Defend Order  
- Heal Order  
- Rest  
- Infestation  

";
$tef42102 = "Sylveon @ Life Orb  
Ability: Pixilate  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Modest Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Moonblast  
- Hyper Voice  

";
$tef42113 = "Tauros (Tauros-Paldea-Combat) (M) @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Stone Edge  
- Smart Strike  
- Swagger  

";
$tef42123 = "Ting-Lu @ Assault Vest  
Ability: Vessel of Ruin  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 84 SpA / 84 SpD / 84 Spe  
Quiet Nature  
- Throat Chop  
- Stone Edge  
- Body Press  
- Earth Power  

";
$tef42133 = "Deoxys-Speed @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 32 HP / 4 Def / 252 SpA / 220 Spe  
Modest Nature  
IVs: 0 Atk  
- Psycho Boost  
- Focus Blast  
- Dark Pulse  
- Nasty Plot  

";
$tef42144 = "Landorus-Therian (M) @ Life Orb  
Ability: Intimidate  
Tera Type: &
EVs: 232 HP / 32 Atk / 48 SpD / 196 Spe  
Naughty Nature  
- Stealth Rock  
- Earthquake  
- Hidden Power [Ice]  
- Defog  

";
$tef42154 = "Politoed @ Eject Button  
Ability: Drizzle  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Whirlpool  
- Encore  
- Perish Song  
- Protect  

";
$tef42165 = "Zangoose @ Salac Berry  
Ability: Immunity  
Tera Type: &
EVs: 52 HP / 252 Atk / 44 Def / 160 Spe  
Jolly Nature  
- Belly Drum  
- Substitute  
- Low Kick  
- Tera Blast  

";
$tef42175 = "Lilligant-Hisui (F) @ Coba Berry  
Ability: Chlorophyll  
Tera Type: &
EVs: 4 HP / 252 Def / 252 Spe  
Jolly Nature  
- Victory Dance  
- Giga Impact  
- Encore  
- Acrobatics  

";
$tef42185 = "Gallade (M) @ Galladite  
Ability: Justified  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Substitute  
- Disable  
- Low Sweep  
- Pain Split  

";
$tef42195 = "Blussy (Blissey) (F) @ Choice Scarf  
Ability: Serene Grace  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Serious Nature  
- Body Slam  
- Headbutt  
- Rock Slide  
- Metronome  

";
$tef42206 = "Scizor (F) @ Expert Belt  
Ability: Technician  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Aerial Ace  
- Bullet Punch  
- Quick Attack  
- Bug Bite  

";

$t943 = "Mamoswine @ Loaded Dice  
Ability: Thick Fat  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Icicle Spear  
- High Horsepower  
- Rock Blast  
- Trailblaze  

";
$t9413 = "Mamoswine @ Life Orb  
Ability: Oblivious  
Tera Type: &
EVs: 184 Atk / 16 Def / 120 SpA / 188 Spe  
Naughty Nature  
- High Horsepower  
- Freeze-Dry  
- Knock Off  
- Ice Shard  

";
$t9423 = "Dewgong @ Choice Band  
Ability: Thick Fat  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Liquidation  
- Triple Axel  
- Knock Off  
- Flip Turn  

";
$t9433 = "Dewgong @ Heavy-Duty Boots  
Ability: Thick Fat  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Sassy Nature  
- Fake Out  
- Knock Off  
- Swagger  
- Flip Turn  

";
$t9443 = "Bastiodon @ Leftovers  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
IVs: 0 Atk  
- Iron Defense  
- Body Press  
- Foul Play  
- Magic Coat  

";
$t9454 = "Goodra-Hisui @ Leftovers  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
- Curse  
- Ice Spinner  
- Thunder Punch  
- Substitute  

";
$t9464 = "Goodra-Hisui @ Steel Gem  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Curse  
- Gyro Ball  
- Rest  
- Dragon Tail  

";
$t9475 = "Bastiodon @ Maranga Berry  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Iron Defense  
- Body Press  
- Rest  
- Taunt  

";
$t9486 = "Arbok @ Black Glasses  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Coil  
- Knock Off  
- Sucker Punch  
- Pursuit  

";
$t9496 = "Golduck @ Choice Band  
Ability: Cloud Nine  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Flip Turn  
- Knock Off  
- Cross Chop  

";
$t94106 = "Snorlax @ Leftovers  
Ability: Immunity  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Curse  
- Ice Punch  
- Supercell Slam  
- Encore  

";
$t94116 = "Ampharos @ Ampharosite  
Ability: Static  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Rest  
- Sleep Talk  
- Supercell Slam  
- Dragon Tail  

";
$t94126 = "Ampharos @ Maranga Berry  
Ability: Static  
Tera Type: &
EVs: 248 HP / 160 Atk / 100 Def  
Careful Nature  
- Rest  
- Curse  
- Supercell Slam  
- Dragon Tail  

";
$t94136 = "Eelektross @ Iapapa Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Coil  
- Supercell Slam  
- Drain Punch  
- Light Screen  

";
$t94146 = "Florges-Yellow (F) @ Throat Spray  
Ability: Flower Veil  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Alluring Voice  
- Moonblast  
- Psychic Noise  
- Defog  

";
$t94157 = "Quaquaval @ Iapapa Berry  
Ability: Torrent  
Tera Type: &
EVs: 160 HP / 96 Atk / 252 Spe  
Jolly Nature  
- Flip Turn  
- Knock Off  
- Rapid Spin  
- Encore  

";
$t94167 = "Garbodor @ Assault Vest  
Ability: Stench  
Tera Type: &
EVs: 200 HP / 176 Atk / 128 Def / 4 SpA  
Brave Nature  
- Gunk Shot  
- Drain Punch  
- Acid Spray  
- Explosion  

";
$t94177 = "Gengar @ Leftovers  
Ability: Cursed Body  
Tera Type: &
EVs: 248 HP / 164 Def / 96 SpD  
Careful Nature  
- Curse  
- Poltergeist  
- Drain Punch  
- Protect  

";
$t94187 = "Iron Thorns @ Red Card  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Taunt  
- Thunder Wave  
- Volt Switch  
- Ice Beam  

";
$t94198 = "Iron Thorns @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 192 Atk / 64 SpD  
Adamant Nature  
- Supercell Slam  
- Charge  
- Breaking Swipe  
- Dig  

";
$t94208 = "Dewott @ Eviolite  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Liquidation  
- Return  
- Aqua Jet  

";
$t94218 = "Croconaw @ Eviolite  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Counter  
- Scald  
- Flip Turn  
- Flatter  

";
$t94228 = "Clauncher @ Eviolite  
Ability: Mega Launcher  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
- Water Pulse  
- Aura Sphere  
- Dark Pulse  
- Flip Turn  

";
$t94238 = "Golem-Alola @ Electric Seed  
Ability: Galvanize  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Electric Terrain  
- Return  
- Stone Edge  
- Autotomize  

";
$t94248 = "Miltank (F) @ Sitrus Berry  
Ability: Sap Sipper  
Tera Type: &
EVs: 156 HP / 132 Atk / 104 Def / 116 Spe  
Jolly Nature  
- Milk Drink  
- Ice Punch  
- Rock Tomb  
- Giga Impact  

";
$t94258 = "Mesprit @ Ice Gem  
Ability: Levitate  
Tera Type: &
EVs: 168 HP / 176 SpA / 164 Spe  
Timid Nature  
IVs: 0 Atk  
- Skill Swap  
- Blizzard  
- Calm Mind  
- Hidden Power [Ground]  

";
$t94269 = "Kecleon @ Assault Vest  
Ability: Protean  
Tera Type: &
EVs: 228 HP / 252 Atk / 28 SpD  
Adamant Nature  
- Sucker Punch  
- Shadow Sneak  
- Drain Punch  
- Rock Slide  

";
$t94279 = "Machamp @ Choice Scarf  
Ability: Steadfast  
Tera Type: &
EVs: 252 Atk / 28 Def / 228 Spe  
Adamant Nature  
- Close Combat  
- Counter  
- Ice Punch  
- Stone Edge  

";
$t94289 = "Malamar @ Choice Scarf  
Ability: Contrary  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Superpower  
- Knock Off  
- Rock Slide  
- Psycho Cut  

";
$t94299 = "Electrode @ Normal Gem  
Ability: Soundproof  
Tera Type: &
EVs: 80 HP / 228 SpA / 200 Spe  
Timid Nature  
IVs: 0 Atk  
- Hyper Beam  
- Hidden Power [Ground]  
- Substitute  
- Thunderbolt  

";
$t94310 = "Azelf @ Steel Gem  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Iron Tail  
- Zen Headbutt  
- Taunt  
- Substitute  

";
$t94320 = "Minior-Blue @ Rockium Z  
Ability: Shields Down  
Tera Type: &
EVs: 252 Atk / 16 SpD / 240 Spe  
Adamant Nature  
- Stone Edge  
- Substitute  
- Psych Up  
- Shell Smash  

";
$t94330 = "Leavanny @ Normalium Z  
Ability: Overcoat  
Tera Type: &
EVs: 56 HP / 200 SpD / 252 Spe  
Jolly Nature  
IVs: 0 Atk  
- Camouflage  
- Substitute  
- Synthesis  
- Toxic  

";
$t94341 = "Florges (F) @ Weakness Policy  
Ability: Symbiosis  
Tera Type: &
EVs: 248 HP / 12 SpA / 16 SpD / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Psychic  
- Moonblast  

";
$t94352 = "Cinccino @ Liechi Berry  
Ability: Skill Link  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Endure  
- Flail  
- Rock Blast  

";
$t94362 = "Weavile @ Micle Berry  
Ability: Pressure  
Tera Type: &
EVs: 64 HP / 252 Atk / 192 Spe  
Adamant Nature  
- Fake Out  
- Natural Gift  
- Ice Punch  
- Substitute  

";
$t94372 = "Alakazam @ Psychic Gem  
Ability: Inner Focus  
Tera Type: &
EVs: 140 Def / 124 SpA / 244 Spe  
Modest Nature  
IVs: 0 Atk  
- Future Sight  
- Skill Swap  
- Taunt  
- Shadow Ball  

";
$t94383 = "Darmanitan @ King's Rock  
Ability: Zen Mode  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Fling  
- Substitute  
- Overheat  
- Focus Blast  

";
$t94393 = "Smeargle @ Quick Claw  
Ability: Technician  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spore  
- Magic Coat  
- Imprison  
- Transform  

";
$t94404 = "Gumshoos @ Sitrus Berry  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Trailblaze  
- Double-Edge  
- Knock Off  
- Taunt  

";
$t94414 = "Passimian @ Big Root  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Bulk Up  
- Trailblaze  
- Drain Punch  
- Knock Off  

";
$t94424 = "Rampardos @ Sitrus Berry  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Head Smash  
- Trailblaze  
- Endeavor  
- Power-Up Punch  

";
$t94434 = "Rampardos @ Liechi Berry  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Protect  
- Head Smash  
- Pain Split  
- Dig  

";
$t94444 = "Swanna @ Throat Spray  
Ability: Big Pecks  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Hurricane  
- Hydro Pump  
- Alluring Voice  
- Trailblaze  

";
$t94454 = "Charmeleon @ Eviolite  
Ability: Blaze  
Tera Type: &
EVs: 248 HP / 192 Def / 68 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Dragon Breath  
- Inferno  

";
$t94465 = "Meowstic-F (F) @ Choice Specs  
Ability: Competitive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Dark Pulse  
- Signal Beam  
- Trick  

";
$t94476 = "Tropius @ Kee Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Roost  
- Air Slash  
- Giga Drain  

";
$t94487 = "Tropius @ Maranga Berry  
Ability: Harvest  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Curse  
- Roost  
- Fly  
- Dragon Tail  

";
$t94497 = "Rotom-Frost @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Shadow Ball  
- Blizzard  
- Thunder  

";
$t94508 = "Rotom-Fan @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Shadow Ball  
- Air Slash  
- Thunder  

";
$t94519 = "Scizor @ Lum Berry  
Ability: Swarm  
Tera Type: &
EVs: 80 HP / 212 Atk / 216 Spe  
Adamant Nature  
- X-Scissor  
- Swords Dance  
- Superpower  
- Rest  

";
$t94529 = "Slaking @ Leftovers  
Ability: Truant  
Tera Type: &
EVs: 252 HP / 236 SpD / 20 Spe  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Bulk Up  
- Amnesia  
- Taunt  

";
$t94540 = "Swampert @ Scope Lens  
Ability: Torrent  
Tera Type: &
EVs: 240 HP / 16 Atk / 252 SpD  
Sassy Nature  
- Hydro Cannon  
- Earthquake  
- Dynamic Punch  
- Superpower  

";
$t94550 = "Venusaur @ Leftovers  
Ability: Overgrow  
Tera Type: &
EVs: 152 HP / 176 SpA / 180 Spe  
Modest Nature  
IVs: 0 Atk  
- Energy Ball  
- Sludge Bomb  
- Rest  
- Frenzy Plant  

";
$t94561 = "Azelf @ Scope Lens  
Ability: Levitate  
Tera Type: &
EVs: 40 HP / 216 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Taunt  
- Calm Mind  
- Fire Blast  

";
$t94572 = "Gallade (M) @ Choice Band  
Ability: Sharpness  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Close Combat  
- Zen Headbutt  
- Leaf Blade  
- Fling  

";
$t94582 = "Hippowdon @ Leftovers  
Ability: Sand Stream  
Tera Type: &
EVs: 176 HP / 252 Atk / 80 SpD  
Adamant Nature  
- Rock Tomb  
- Earthquake  
- Rest  
- Curse  

";
$t94592 = "Sceptile @ Scope Lens  
Ability: Overgrow  
Tera Type: &
EVs: 80 HP / 252 Atk / 80 SpA / 96 Spe  
Lonely Nature  
- Leaf Blade  
- Focus Blast  
- Substitute  
- Frenzy Plant  

";
$t94602 = "Staraptor @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 112 HP / 252 Atk / 120 SpD / 24 Spe  
Adamant Nature  
- Protect  
- Substitute  
- Brave Bird  
- Close Combat  

";
$t94612 = "Tangrowth @ Leftovers  
Ability: Leaf Guard  
Tera Type: &
EVs: 240 HP / 168 SpA / 100 Spe  
Modest Nature  
IVs: 0 Atk  
- Energy Ball  
- Sunny Day  
- Rest  
- Focus Blast  

";
$t94623 = "Weavile @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 24 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Taunt  
- Protect  
- Substitute  
- Spite  

";
$t94634 = "Alakazam @ Lum Berry  
Ability: Synchronize  
Tera Type: &
EVs: 200 HP / 96 SpA / 212 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Focus Blast  
- Calm Mind  
- Encore  

";
$t94645 = "Ambipom @ Liechi Berry  
Ability: Technician  
Tera Type: &
EVs: 40 HP / 216 Atk / 252 Spe  
Adamant Nature  
- Taunt  
- Substitute  
- Rock Smash  
- Giga Impact  

";
$t94655 = "Armaldo @ Scope Lens  
Ability: Battle Armor  
Tera Type: &
EVs: 40 HP / 252 Atk / 76 SpD / 140 Spe  
Adamant Nature  
- Rock Blast  
- X-Scissor  
- Superpower  
- Rock Smash  

";
$t94665 = "Breloom @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 80 HP / 252 Atk / 176 Spe  
Adamant Nature  
- Protect  
- Substitute  
- Superpower  
- Seed Bomb  

";
$t94675 = "Entei @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 132 HP / 124 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flamethrower  
- Calm Mind  
- Rest  
- Substitute  

";
$t94686 = "Gastrodon @ Scope Lens  
Ability: Sticky Hold  
Tera Type: &
EVs: 152 HP / 168 SpA / 188 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Surf  
- Rest  
- Mirror Coat  

";
$t94697 = "Medicham @ Black Belt  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Protect  
- High Jump Kick  
- Rock Smash  
- Substitute  

";
$t94707 = "Moltres @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 72 HP / 252 SpA / 184 Spe  
Modest Nature  
IVs: 0 Atk  
- Fire Blast  
- Air Slash  
- Substitute  
- Rest  

";
$t94718 = "Umbreon @ Leftovers  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 32 Def / 228 Spe  
Timid Nature  
IVs: 0 Atk  
- Taunt  
- Rest  
- Charm  
- Toxic  

";
$t94729 = "Azumarill @ Lum Berry  
Ability: Huge Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Belly Drum  
- Encore  
- Waterfall  
- Superpower  

";
$t94739 = "Blissey (F) @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 200 HP / 248 Def / 60 Spe  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Soft-Boiled  
- Calm Mind  
- Ice Beam  

";
$t94750 = "Clefable @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 152 HP / 248 SpA / 8 SpD / 100 Spe  
Calm Nature  
IVs: 0 Atk  
- Seismic Toss  
- Soft-Boiled  
- Encore  
- Focus Blast  

";
$t94761 = "Clefable @ Chople Berry  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Encore  
- Soft-Boiled  
- Seismic Toss  

";
$t94772 = "Tyranitar @ Chople Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 240 HP / 16 Atk / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Taunt  
- Rock Slide  
- Crunch  

";
$t94782 = "Zapdos @ Scope Lens  
Ability: Pressure  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 30 HP / 2 Atk / 30 Def / 30 SpA / 30 SpD  
- Thunderbolt  
- Rest  
- Hidden Power [Flying]  
- Heat Wave  

";
$t94793 = "Infernape @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 32 HP / 224 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Encore  
- Focus Blast  
- Blast Burn  

";
$t94804 = "Raikou @ Scope Lens  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Rest  
- Aura Sphere  
- Calm Mind  

";
$t94815 = "Celebi @ Lum Berry  
Ability: Natural Cure  
Tera Type: &
EVs: 112 HP / 248 SpA / 148 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Leaf Storm  
- Calm Mind  
- Recover  

";
$t94826 = "Dragonite @ Leftovers  
Ability: Inner Focus  
Tera Type: &
EVs: 64 HP / 252 Atk / 192 Spe  
Adamant Nature  
- Thunder Wave  
- Dragon Dance  
- Outrage  
- Roost  

";
$t94836 = "Metagross @ Leftovers  
Ability: Clear Body  
Tera Type: &
EVs: 152 HP / 180 Atk / 176 Spe  
Adamant Nature  
- Bullet Punch  
- Meteor Mash  
- Substitute  
- Hammer Arm  

";
$t94846 = "Aerodactyl @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 152 HP / 104 SpD / 252 Spe  
Jolly Nature  
- Taunt  
- Roost  
- Substitute  
- Rock Slide  

";
$t94856 = "Hariyama @ Toxic Orb  
Ability: Guts  
Tera Type: &
EVs: 252 Atk / 156 SpD / 100 Spe  
Adamant Nature  
- Fake Out  
- Protect  
- Close Combat  
- Arm Thrust  

";
$t94866 = "Heatran @ Leftovers  
Ability: Flash Fire  
Tera Type: &
EVs: 64 HP / 240 SpA / 204 Spe  
Modest Nature  
IVs: 0 Atk  
- Taunt  
- Overheat  
- Flamethrower  
- Ancient Power  

";
$t94877 = "Kingdra @ Scope Lens  
Ability: Sniper  
Tera Type: &
EVs: 40 HP / 252 SpA / 64 SpD / 152 Spe  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Draco Meteor  
- Focus Energy  
- Rest  

";
$t94888 = "Suicune @ Leftovers  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 112 SpA / 144 Spe  
Bold Nature  
IVs: 0 Atk  
- Surf  
- Substitute  
- Rest  
- Reflect  

";
$t94900 = "Arcanine @ Scope Lens  
Ability: Intimidate  
Tera Type: &
EVs: 192 Atk / 252 SpA / 64 Spe  
Mild Nature  
- Flamethrower  
- Overheat  
- Rest  
- Extreme Speed  

";
$t94910 = "Bronzong @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Rest  
- Calm Mind  
- Extrasensory  
- Protect  

";
$t94921 = "Empoleon @ Scope Lens  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Hydro Cannon  
- Brine  
- Rest  

";
$t94932 = "Gyarados @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 32 HP / 252 Atk / 36 SpD / 188 Spe  
Adamant Nature  
- Taunt  
- Dragon Dance  
- Waterfall  
- Bounce  

";
$t94942 = "Heracross @ Toxic Orb  
Ability: Guts  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Protect  
- Close Combat  
- Megahorn  
- Bulk Up  

";
$t94952 = "Rotom-Wash @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Shadow Ball  
- Hydro Pump  
- Trick  

";
$t94963 = "Rotom-Heat @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 124 HP / 128 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Shadow Ball  
- Overheat  
- Trick  

";
$t94974 = "Rotom-Mow @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Shadow Ball  
- Leaf Storm  
- Thunder  

";
$t94985 = "Celebi @ Occa Berry  
Ability: Natural Cure  
Tera Type: &
EVs: 128 HP / 104 SpA / 248 SpD / 28 Spe  
Calm Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Substitute  
- Uproar  

";
$t94996 = "Typhlosion @ Liechi Berry  
Ability: Blaze  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Substitute  
- Reversal  
- Flare Blitz  
- Wild Charge  

";
$t941006 = "Mismagius @ Rockium Z  
Ability: Levitate  
Tera Type: &
EVs: 8 HP / 252 SpA / 12 SpD / 236 Spe  
Timid Nature  
IVs: 0 Atk  
- Power Gem  
- Calm Mind  
- Pain Split  
- Taunt  

";
$t941017 = "Azelf @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 12 HP / 252 Atk / 244 Spe  
Jolly Nature  
- Zen Headbutt  
- Play Rough  
- Knock Off  
- Iron Tail  

";
$t941027 = "Araquanid @ Wacan Berry  
Ability: Water Bubble  
Tera Type: &
EVs: 232 HP / 180 Atk / 28 SpD / 68 Spe  
Careful Nature  
- Lunge  
- Liquidation  
- Magic Coat  
- Mirror Coat  

";
$t941037 = "Marowak-Alola @ Thick Club  
Ability: Rock Head  
Tera Type: &
EVs: 248 HP / 172 Atk / 80 Def / 8 SpD  
Adamant Nature  
- Swords Dance  
- Toxic  
- Shadow Bone  
- Flare Blitz  

";
$t941047 = "Goodra-Hisui @ Chople Berry  
Ability: Gooey  
Tera Type: &
EVs: 252 HP / 100 Def / 144 SpA / 12 Spe  
Serious Nature  
IVs: 0 Atk  
- Draco Meteor  
- Flash Cannon  
- Fire Blast  
- Counter  

";
$t941058 = "Volcanion @ Assault Vest  
Ability: Water Absorb  
Tera Type: &
EVs: 32 HP / 208 Atk / 48 SpD / 220 Spe  
Jolly Nature  
- Flare Blitz  
- Liquidation  
- Flame Charge  
- Heavy Slam  

";
$t941068 = "Breloom @ Occa Berry  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 64 Atk / 100 Def / 96 Spe  
Jolly Nature  
- Rock Tomb  
- Spore  
- Superpower  
- Seed Bomb  

";
$t941078 = "Ninetales (F) @ Eject Button  
Ability: Drought  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hidden Power [Electric]  
- Flamethrower  
- Healing Wish  
- Sunny Day  

";
$t941089 = "Alomomola (F) @ Red Card  
Ability: Regenerator  
Tera Type: &
EVs: 4 Atk / 252 Def / 252 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Wish  
- Flip Turn  
- Scald  
- Acrobatics  

";
$t941100 = "Slowbro @ Weakness Policy  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 100 Def / 132 SpA / 28 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Trick Room  
- Flamethrower  
- Grass Knot  
- Ice Beam  

";
$t941111 = "Melmetal @ Shuca Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Def / 232 SpD / 24 Spe  
Impish Nature  
- Iron Defense  
- Body Press  
- Ice Punch  
- Rest  

";
$t941121 = "Blacephalon @ Life Orb  
Ability: Beast Boost  
Tera Type: &
EVs: 184 Atk / 108 SpA / 216 Spe  
Lonely Nature  
- Substitute  
- Fire Spin  
- Explosion  
- Shadow Ball  

";
$t941131 = "Eldegoss @ Eject Pack  
Ability: Regenerator  
Tera Type: &
EVs: 80 HP / 212 Def / 216 Spe  
Timid Nature  
- Leaf Storm  
- Pollen Puff  
- Rapid Spin  
- Sleep Powder  

";
$t941141 = "Azelf @ Expert Belt  
Ability: Levitate  
Tera Type: &
EVs: 108 Atk / 176 SpA / 224 Spe  
Naive Nature  
- Ice Punch  
- Flamethrower  
- Psychic  
- U-turn  

";
$t941151 = "Latios (M) @ Sea Incense  
Ability: Levitate  
Tera Type: &
EVs: 96 HP / 160 Atk / 252 Spe  
Jolly Nature  
- Flip Turn  
- Roost  
- Defog  
- Dive  

";
$t941161 = "Latios (M) @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Draco Meteor  
- Trick  
- Flip Turn  
- Thunder Wave  

";
$t941171 = "Latios (M) @ Latiosite  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Flip Turn  
- Last Resort  
- Recover  

";
$t941181 = "Vanilluxe @ Apicot Berry  
Ability: Snow Warning  
Tera Type: &
EVs: 88 Atk / 240 SpA / 180 Spe  
Hasty Nature  
- Substitute  
- Freeze-Dry  
- Natural Gift  
- Blizzard  

";
$t941191 = "Infernape @ Darkinium Z  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Hone Claws  
- Knock Off  
- Gunk Shot  
- Stone Edge  

";
$t941201 = "Scrafty @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Trailblaze  
- Knock Off  
- Drain Punch  

";
$t941211 = "Goodra @ Rocky Helmet  
Ability: Hydration  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Rest  
- Rain Dance  
- Knock Off  
- Dragon Tail  

";
$t941221 = "Seaking @ Choice Band  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Waterfall  
- Knock Off  
- Megahorn  
- Drill Run  

";
$t941231 = "Seaking @ Assault Vest  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Waterfall  
- Knock Off  
- Megahorn  
- Flip Turn  

";
$t941241 = "Basculin-White-Striped @ Eviolite  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- Flip Turn  
- Last Respects  
- Wave Crash  
- Tera Blast  

";
$t941251 = "Omastar @ Life Orb  
Ability: Weak Armor  
Tera Type: &
EVs: 80 HP / 132 Def / 176 SpA / 120 Spe  
Lax Nature  
- Shell Smash  
- Stone Edge  
- Ice Beam  
- Hydro Pump  

";
$t941261 = "Landorus-Therian (M) @ Kee Berry  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 68 Def / 100 SpA / 92 Spe  
Modest Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Sandsear Storm  
- Calm Mind  

";
$t941272 = "Runerigus @ Choice Band  
Ability: Wandering Spirit  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Brave Nature  
- Earthquake  
- Poltergeist  
- Stone Edge  
- Tera Blast  

";
$t941282 = "Deoxys-Attack @ Assault Vest  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Gentle Nature  
- Psychic Noise  
- Drain Punch  
- Knock Off  
- Charge Beam  

";
$t941292 = "Deoxys @ Weakness Policy  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 192 Def / 4 SpD / 60 Spe  
Modest Nature  
IVs: 0 Atk  
- Endure  
- Psychic Terrain  
- Expanding Force  
- Nasty Plot  

";
$t941303 = "Diggersby @ Mirror Herb  
Ability: Huge Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swagger  
- Foul Play  
- Last Resort  

";
$t941312 = "Flamigo @ Light Ball  
Ability: Scrappy  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Swords Dance  
- Fling  
- Acrobatics  
- Tera Blast  

";
$t941322 = "Liepard @ Bright Powder  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Swagger  
- Foul Play  
- Thunder Wave  
- Substitute  

";
$t941333 = "Dugtrio-Alola @ Mirror Herb  
Ability: Sand Veil  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swagger  
- Foul Play  
- Sandstorm  
- Iron Head  

";
$t941343 = "Bouffalant @ Choice Scarf  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Head Charge  
- Megahorn  
- Close Combat  
- Lash Out  

";
$t941353 = "Dolliv @ Eviolite  
Ability: Early Bird  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Earth Power  
- Tera Blast  

";
$t941364 = "Darumaka-Galar @ Eviolite  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Ice Punch  
- Substitute  
- Focus Punch  
- Encore  

";
$t941374 = "Darumaka-Galar @ Heavy-Duty Boots  
Ability: Hustle  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
- U-turn  
- Encore  
- Yawn  
- Fire Spin  

";
$t941384 = "Darumaka-Galar @ Eviolite  
Ability: Hustle  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Rest  
- Sleep Talk  
- Will-O-Wisp  
- Power-Up Punch  

";
$t941394 = "Darmanitan-Galar @ Petaya Berry  
Ability: Gorilla Tactics  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Sunny Day  
- Substitute  
- Fire Blast  
- Solar Beam  

";
$t941405 = "Staravia @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Adamant Nature  
- Roost  
- Defog  
- Brave Bird  
- U-turn  

";
$t941415 = "Meditite @ Choice Band  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Jump Kick  
- Zen Headbutt  
- Poison Jab  
- Tera Blast  

";
$t941425 = "Drakloak @ Eviolite  
Ability: Clear Body  
Tera Type: &
EVs: 176 HP / 252 Atk / 4 SpD / 76 Spe  
Adamant Nature  
- Dragon Dance  
- Phantom Force  
- Outrage  
- Dragon Tail  

";
$t941435 = "Boldore @ Eviolite  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
- Stealth Rock  
- Stone Edge  
- Toxic  
- Body Press  

";
$t941445 = "Duskull @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Calm Mind  
- Sleep Talk  
- Shadow Ball  

";
$t941456 = "Duskull @ Eviolite  
Ability: Frisk  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Toxic  
- Torment  
- Phantom Force  
- Pain Split  

";
$t941466 = "Cranidos @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Head Smash  
- Fire Punch  
- Superpower  
- Rock Polish  

";
$t941476 = "Cranidos @ Eviolite  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 60 SpD / 196 Spe  
Adamant Nature  
- Rock Polish  
- Head Smash  
- Dig  
- Power-Up Punch  

";
$t941486 = "Rufflet (M) @ Eviolite  
Ability: Hustle  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Bulk Up  
- Roost  
- Aerial Ace  
- Brave Bird  

";
$t941496 = "Vanillish @ Eviolite  
Ability: Ice Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Snowscape  
- Blizzard  
- Tera Blast  
- Aurora Veil  

";
$t941507 = "Duraludon @ Eviolite  
Ability: Heavy Metal  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Heavy Slam  
- Breaking Swipe  
- Thunder Wave  
- Swords Dance  

";
$t941517 = "Articuno @ Sitrus Berry  
Ability: Snow Cloak  
Tera Type: &
EVs: 120 Def / 252 SpA / 136 Spe  
Bold Nature  
IVs: 0 Atk  
- Snowscape  
- Blizzard  
- Hurricane  
- Roost  

";
$t941528 = "Bronzong @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Psychic Noise  
- Toxic  

";
$t941537 = "Vaporeon @ Chesto Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Signal Beam  
- Ice Beam  
- Rest  

";
$t941548 = "Latias @ Ring Target  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Energy Ball  
- Trick  
- Defog  
- Healing Wish  

";
$t941559 = "Gallade (M) @ Galladite  
Ability: Justified  
Happiness: 0  
Tera Type: &
EVs: 216 HP / 8 Atk / 4 Def / 200 SpA / 80 Spe  
Timid Nature  
- Substitute  
- Calm Mind  
- Stored Power  
- Drain Punch  

";
$t941570 = "Rotom-Fan @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Eerie Impulse  
- Protect  
- Trick  
- Rest  

";
$t941581 = "Rotom-Fan @ Assault Vest  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Electroweb  
- Night Shade  

";
$t941590 = "Pokestar Black Belt (M) @ Sticky Barb  
Ability: Huge Power  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Focus Punch  
- Substitute  
- Taunt  
- Protect  

";
$t941600 = "Pokestar Black Belt (M) @ Choice Band  
Ability: Huge Power  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Focus Punch  
- Sleep Talk  
- Rest  

";
$t941609 = "Pokestar Black Belt (M) @ Muscle Band  
Ability: Huge Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Jump Kick  
- Mach Punch  
- Taunt  
- Protect  

";
$t941619 = "Celesteela @ Mirror Herb  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Acrobatics  
- Swagger  
- Rest  
- Sleep Talk  

";
$t941629 = "Celesteela @ Mirror Herb  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Acrobatics  
- Swagger  
- Rest  
- Sleep Talk  

";
$t941639 = "Celesteela @ Mirror Herb  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Acrobatics  
- Swagger  
- Rest  
- Sleep Talk  

";
$t941649 = "Arctozolt @ Protective Pads  
Ability: Volt Absorb  
Tera Type: &
EVs: 36 HP / 48 Atk / 84 Def / 8 SpA / 84 SpD / 248 Spe  
Adamant Nature  
- Bolt Beak  
- Ice Fang  
- Freeze-Dry  
- Taunt  

";
$t941659 = "Necrozma @ Dragonium Z  
Ability: Prism Armor  
Tera Type: &
EVs: 164 HP / 108 Def / 48 SpA / 188 Spe  
Modest Nature  
- Knock Off  
- Dragon Pulse  
- Morning Sun  
- Calm Mind  

";
$t941669 = "Urshifu-Rapid-Strike @ Utility Umbrella  
Ability: Unseen Fist  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Adamant Nature  
- Surging Strikes  
- Drain Punch  
- Ice Spinner  
- U-turn  

";
$t941679 = "Arcanine-Hisui @ Covert Cloak  
Ability: Rock Head  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Flame Charge  
- Head Smash  
- Flare Blitz  
- Substitute  

";
$t941689 = "Zapdos-Galar @ Scope Lens  
Ability: Defiant  
Tera Type: &
EVs: 8 HP / 96 Atk / 164 SpD / 240 Spe  
Adamant Nature  
- Knock Off  
- Close Combat  
- Protect  
- Focus Energy  

";
$t941699 = "Iron Valiant @ Grassium Z  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Encore  
- Protect  
- Leaf Blade  
- Swords Dance  

";
$t941709 = "Iron Valiant @ Apicot Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Sleep Talk  
- Rest  
- Calm Mind  

";
$t941720 = "Iron Valiant @ Ganlon Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Sleep Talk  
- Rest  
- Calm Mind  

";
$t941731 = "Zapdos @ Electrium Z  
Ability: Pressure  
Tera Type: &
EVs: 100 HP / 100 Def / 100 SpA / 100 SpD / 108 Spe  
IVs: 0 Atk  
- Volt Switch  
- Toxic  

";
$t941739 = "Zapdos @ Manectite  
Ability: Pressure  
Tera Type: &
EVs: 124 HP / 40 Def / 92 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hidden Power [Ice]  
- Eerie Impulse  
- Protect  

";
$t941750 = "Celesteela @ Mirror Herb  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- Swagger  
- Rest  
- Sleep Talk  

";
$t941760 = "Celesteela @ Power Herb  
Ability: Beast Boost  
Tera Type: &
EVs: 116 HP / 16 Atk / 108 Def / 16 SpD / 252 Spe  
Hasty Nature  
IVs: 23 SpA  
- Flamethrower  
- Meteor Beam  
- Steel Roller  
- Ingrain  

";
$t941771 = "Celesteela @ Metronome  
Ability: Beast Boost  
Tera Type: &
EVs: 116 HP / 16 Atk / 108 Def / 16 SpD / 252 Spe  
Hasty Nature  
IVs: 0 Atk / 23 SpA  
- Air Slash  
- Giga Drain  
- Meteor Beam  
- Substitute  

";
$t941782 = "Blastoise @ Blastoisinite  
Ability: Torrent  
Tera Type: &
EVs: 184 HP / 252 SpA / 4 SpD / 68 Spe  
Modest Nature  
IVs: 0 Atk  
- Terrain Pulse  
- Haze  
- Protect  
- Shell Smash  

";
$t941793 = "Blastoise @ Icium Z  
Ability: Rain Dish  
Tera Type: &
EVs: 86 HP / 86 Atk / 86 Def / 86 SpA / 86 SpD / 78 Spe  
Quirky Nature  
- Hydro Pump  
- Flip Turn  
- Haze  
- Rapid Spin  

";
$t941803 = "Shaymin @ Rocky Helmet  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Seed Flare  
- Hidden Power [Fire]  
- Synthesis  
- Healing Wish  

";
$t941814 = "Shaymin @ Expert Belt  
Ability: Natural Cure  
Tera Type: &
EVs: 4 HP / 64 Def / 252 SpA / 188 Spe  
Modest Nature  
IVs: 0 Atk  
- Seed Flare  
- Tera Blast  
- Hidden Power [Fire]  
- Rest  

";
$t941825 = "Arboliva @ Occa Berry  
Ability: Seed Sower  
Tera Type: &
EVs: 240 HP / 204 Def / 52 SpD / 12 Spe  
Calm Nature  
IVs: 0 Atk  
- Strength Sap  
- Leech Seed  
- Earth Power  
- Giga Drain  

";
$t941836 = "Corviknight @ Expert Belt  
Ability: pressureunnerve  
Tera Type: &
EVs: 248 HP / 52 Atk / 56 Def / 32 SpD / 120 Spe  
Adamant Nature  
- Brave Bird  
- Iron Head  
- Iron Defense  
- Roost  

";
$t941846 = "Archaludon @ Sitrus Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Outrage  
- Heavy Slam  
- Body Press  
- Iron Defense  

";
$t941856 = "Rotom-Mow @ Enigma Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Sassy Nature  
- Leaf Storm  
- Will-O-Wisp  
- Poltergeist  
- Defog  

";
$t941866 = "Eelektross @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Coil  
- Drain Punch  
- Rest  
- Sleep Talk  

";
$t941876 = "Dewgong @ Assault Vest  
Ability: Thick Fat  
Tera Type: &
EVs: 85 HP / 85 Atk / 85 Def / 85 SpA / 85 SpD / 85 Spe  
- Surf  
- Triple Axel  
- Knock Off  
- Flip Turn  

";
$t941885 = "Torkoal @ Heavy-Duty Boots  
Ability: Drought  
Tera Type: &
EVs: 85 HP / 85 Atk / 85 Def / 85 SpA / 85 SpD / 85 Spe  
- Rapid Spin  
- Solar Beam  
- Yawn  
- Lava Plume  

";
$t941894 = "Blissey @ Leftovers  
Ability: Natural Cure  
Tera Type: &
EVs: 85 HP / 85 Def / 85 SpA / 85 SpD / 85 Spe  
IVs: 0 Atk  
- Thunder Wave  
- Soft-Boiled  
- Heal Bell  
- Seismic Toss  

";
$t941904 = "Iron Hands @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 132 HP / 124 Atk / 252 Def  
Impish Nature  
- Charge  
- Iron Defense  
- Supercell Slam  
- Body Press  

";
$t941914 = "Archaludon @ Choice Scarf  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- Earthquake  
- Draco Meteor  
- Outrage  
- Iron Head  

";
$t941924 = "Zapdos @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Eerie Impulse  
- Roost  
- Substitute  
- Protect  

";
$t941935 = "Sneasler @ Liechi Berry  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Endure  
- Reversal  
- Upper Hand  
- Gunk Shot  

";
$t941945 = "Sneasler @ Liechi Berry  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Endure  
- Reversal  
- Upper Hand  
- Shadow Claw  

";
$t941955 = "Sneasler @ Ghostium Z  
Ability: Poison Touch  
Tera Type: &
EVs: 8 Atk / 248 SpA / 252 Spe  
Hasty Nature  
- Dire Claw  
- Shadow Ball  
- Substitute  
- Protect  

";
$t941965 = "Delphox @ Mirror Herb  
Ability: Magician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Fire Spin  
- Metronome  
- Psychic  
- Encore  

";
$t941975 = "Gallade (M) @ Scope Lens  
Ability: Sharpness  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Adamant Nature  
- Sacred Sword  
- Psycho Cut  
- Night Slash  
- Agility  

";
$t941985 = "Amoonguss @ Choice Specs  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Giga Drain  
- Sludge Bomb  
- Tera Blast  
- Hidden Power [Fire]  

";
$t941996 = "Rotom-Mow @ Covert Cloak  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Leaf Storm  
- Volt Switch  
- Defog  
- Pain Split  

";
$t942007 = "Pincurchin @ Covert Cloak  
Ability: Electric Surge  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Rising Voltage  
- Chilling Water  
- Spikes  
- Recover  

";
$t942018 = "Coalossal @ Power Herb  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 100 SpA / 156 SpD  
Calm Nature  
- Overheat  
- Meteor Beam  
- Spikes  
- Rapid Spin  

";
$t942028 = "Suicune @ Leftovers  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 112 SpA / 144 Spe  
Bold Nature  
IVs: 0 Atk  
- Surf  
- Substitute  
- Rest  
- Reflect  

";
$t942040 = "Slaking @ Leftovers  
Ability: Truant  
Tera Type: &
EVs: 252 HP / 236 SpD / 20 Spe  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Bulk Up  
- Amnesia  
- Taunt  

";
$t942051 = "Alakazam @ Lum Berry  
Ability: Synchronize  
Tera Type: &
EVs: 200 HP / 96 SpA / 212 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Focus Blast  
- Calm Mind  
- Encore  

";
$t942062 = "Infernape @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 32 HP / 224 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Encore  
- Focus Blast  
- Blast Burn  

";
$t942073 = "Mew @ Darkinium Z  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Foul Play  
- Thunder Wave  
- Soft-Boiled  
- Curse  

";
$t942083 = "Honchkrow @ Darkinium Z  
Ability: Super Luck  
Tera Type: &
EVs: 248 HP / 160 Atk / 8 Def / 92 SpD  
Careful Nature  
- Foul Play  
- Roost  
- Thunder Wave  
- Curse  

";
$t942093 = "Regice @ Damp Rock  
Ability: Clear Body  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Hasty Nature  
- Explosion  
- Rain Dance  
- Ice Beam  
- Thunder Wave  

";
$t942103 = "Deoxys-Defense @ Weakness Policy  
Ability: Pressure  
Tera Type: &
EVs: 156 HP / 252 SpA / 100 Spe  
Modest Nature  
IVs: 0 Atk  
- Agility  
- Focus Blast  
- Shadow Ball  
- Nasty Plot  

";
$t942114 = "Dartrix (M) @ Eviolite  
Ability: Long Reach  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Careful Nature  
- Knock Off  
- Leaf Blade  
- Haze  
- Roost  

";
$t942124 = "Pawniard @ Eviolite  
Ability: Inner Focus  
Shiny: Yes  
Tera Type: &
EVs: 240 HP / 36 Atk / 232 SpD  
Adamant Nature  
- Knock Off  
- Sucker Punch  
- Pursuit  
- Swords Dance  

";
$t942135 = "Xatu @ Wacan Berry  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 220 SpA / 32 SpD / 4 Spe  
Mild Nature  
- Heat Wave  
- Quick Attack  
- Psychic  
- Roost  

Goodra  
Ability: Sap Sipper  
Tera Type: &
EVs: 104 HP / 252 Def / 152 SpA  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Life Dew  
- Ice Beam  
- Toxic  

";
$t942156 = "Nidoking (M) @ Shuca Berry  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Stealth Rock  
- Rock Slide  
- Earthquake  
- Sucker Punch  

";
$t942166 = "Whimsicott @ Leftovers  
Ability: Infiltrator  
Tera Type: &
EVs: 136 HP / 252 Def / 8 SpA / 112 Spe  
Bold Nature  
IVs: 0 Atk  
- Substitute  
- Leech Seed  
- Moonblast  
- Encore  

";
$t942177 = "Mismagius (F) @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 116 HP / 168 SpA / 224 Spe  
Timid Nature  
IVs: 0 Atk  
- Icy Wind  
- Will-O-Wisp  
- Psychic  
- Destiny Bond  

";
$t942188 = "Fraxure (F) @ Eviolite  
Ability: Rivalry  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Def  
Adamant Nature  
- Poison Jab  
- Stomping Tantrum  
- Taunt  
- Breaking Swipe  

";
$t942198 = "Torterra @ Mental Herb  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Stockpile  
- Body Press  
- Synthesis  
- Heavy Slam  

";
$t942208 = "Breloom (F) @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 204 HP / 208 Atk / 96 Spe  
Adamant Nature  
- Spore  
- Fling  
- Rock Tomb  
- Power-Up Punch  

";
$t942218 = "Gliscor @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Crabhammer  
- Fling  
- Torment  
- Protect  

";
$t942228 = "Slowbro @ Choice Specs  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Trick  
- Protect  
- Teleport  

";
$t942238 = "Slowbro @ Rocky Helmet  
Ability: Regenerator  
Tera Type: &
EVs: 60 HP / 232 Def / 216 SpA  
Bold Nature  
IVs: 0 Atk  
- Psyshock  
- Shadow Ball  
- Teleport  
- Nasty Plot  

";
$t942249 = "Metagross @ Choice Band  
Ability: Clear Body  
Tera Type: &
EVs: 240 HP / 176 Atk / 16 Def / 16 SpA / 56 SpD / 4 Spe  
Brave Nature  
IVs: 27 Spe  
- Trick  
- Steel Beam  
- Explosion  
- Earthquake  

";
$t942260 = "Rotom-Heat @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Substitute  
- Tera Blast  
- Discharge  
- Nasty Plot  

";
$t942271 = "Magmar @ Salac Berry  
Ability: Vital Spirit  
Tera Type: &
EVs: 4 HP / 252 Atk / 36 Def / 216 Spe  
Adamant Nature  
- Belly Drum  
- Substitute  
- Fire Punch  
- Dual Chop  

";
$t942281 = "Ceruledge @ Weakness Policy  
Ability: Weak Armor  
Tera Type: &
EVs: 168 HP / 88 Atk / 56 Def / 120 SpA / 4 SpD / 72 Spe  
Impish Nature  
- Bitter Blade  
- Stored Power  
- Endure  
- Substitute  

";
$t942291 = "Mandibuzz (F) @ Utility Umbrella  
Ability: Big Pecks  
Tera Type: &
EVs: 248 HP / 16 Atk / 244 Def  
Relaxed Nature  
IVs: 0 Spe  
- Brave Bird  
- Foul Play  
- U-turn  
- Roost  

";
$t942302 = "Garchomp (F) @ Leftovers  
Ability: Rough Skin  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Flamethrower  
- Whirlpool  
- Substitute  
- Toxic  

";
$t942314 = "Sneasler @ Weakness Policy  
Ability: Unburden  
Tera Type: &
EVs: 188 HP / 192 Atk / 36 Def / 92 Spe  
Adamant Nature  
- Reversal  
- Endure  
- Swords Dance  
- Upper Hand  

";
$t942324 = "Wo-Chien @ Leftovers  
Ability: Tablets of Ruin  
Tera Type: &
EVs: 248 HP / 20 Def / 92 SpA / 136 SpD / 12 Spe  
Calm Nature  
IVs: 0 Atk  
- Giga Drain  
- Mean Look  
- Growth  
- Tera Blast  

";
$t942335 = "Wo-Chien @ Leftovers  
Ability: Tablets of Ruin  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Knock Off  
- Mean Look  
- Substitute  
- Protect  

";
$t942345 = "Wo-Chien @ Leftovers  
Ability: Tablets of Ruin  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Giga Drain  
- Mean Look  
- Substitute  
- Protect  

";
$t942356 = "Terapagos @ Lum Berry  
Ability: Tera Shift  
Tera Type: &
EVs: 72 HP / 252 SpA / 184 Spe  
Modest Nature  
- Calm Mind  
- Rapid Spin  
- Tera Starstorm  
- Earth Power  

";
$t942366 = "Chesnaught @ Weakness Policy  
Ability: Bulletproof  
Tera Type: &
EVs: 252 Atk / 64 SpD / 192 Spe  
Adamant Nature  
- Trailblaze  
- Knock Off  
- Drain Punch  
- Bulk Up  

";
$t942376 = "Excadrill @ Expert Belt  
Ability: Sand Rush  
Tera Type: &
EVs: 252 Atk / 72 SpD / 184 Spe  
Jolly Nature  
- Rock Slide  
- Earthquake  
- Iron Head  
- Tera Blast  

";
$t942386 = "Latios (M) @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 80 Atk / 252 SpA / 176 Spe  
Hasty Nature  
- Dragon Dance  
- Earthquake  
- Psychic  
- Shadow Ball  

";
$t942396 = "Fezandipiti (M) @ Rocky Helmet  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 HP / 28 Def / 228 Spe  
Timid Nature  
- U-turn  
- Roost  
- Moonblast  
- Taunt  

";
$t942406 = "Fezandipiti (M) @ Heavy-Duty Boots  
Ability: Toxic Chain  
Tera Type: &
EVs: 188 HP / 68 Atk / 252 Spe  
Jolly Nature  
- Beat Up  
- Play Rough  
- Protect  
- Roost  

";
$t942416 = "Rillaboom @ Rocky Helmet  
Ability: Grassy Surge  
Tera Type: &
EVs: 236 HP / 16 Atk / 244 Def / 12 Spe  
Adamant Nature  
- Grassy Glide  
- Wood Hammer  
- Knock Off  
- U-turn  

";
$t942426 = "Manaphy @ Custap Berry  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Heart Swap  
- Surf  
- Ice Beam  
- Energy Ball  

";
$t942437 = "Mesprit @ Safety Goggles  
Ability: Levitate  
Tera Type: &
EVs: 28 HP / 252 Def / 12 SpA / 200 SpD / 16 Spe  
Bold Nature  
IVs: 0 Atk  
- Stealth Rock  
- Mystical Power  
- Pain Split  
- Thunder Wave  

";
$t942448 = "Sandy Shocks @ Assault Vest  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 228 SpA / 16 SpD / 12 Spe  
Calm Nature  
IVs: 0 Atk  
- Earth Power  
- Discharge  
- Mirror Coat  
- Power Gem  

";
$t942459 = "Pincurchin @ Terrain Extender  
Ability: Electric Surge  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Discharge  
- Scald  
- Spikes  
- Memento  

";
$t942470 = "Iron Jugulis @ Power Herb  
Ability: Quark Drive  
Tera Type: &
EVs: 8 HP / 4 Def / 252 SpA / 244 Spe  
Timid Nature  
IVs: 0 Atk  
- Air Slash  
- Earth Power  
- Taunt  
- Meteor Beam  

";
$t942481 = "Iron Thorns @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 56 HP / 252 Atk / 4 SpD / 196 Spe  
Jolly Nature  
- Rock Blast  
- Tera Blast  
- Fire Punch  
- Dragon Dance  

";
$t942491 = "Alakazam @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Encore  
- Disable  
- Protect  

";
$t942502 = "Deoxys-Speed @ Wise Glasses  
Ability: Pressure  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
IVs: 0 Atk  
- Psycho Boost  
- Nasty Plot  
- Dark Pulse  
- Focus Blast  

";
$t942513 = "Landorus-Therian (M) @ Rocky Helmet  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
- Stealth Rock  
- Earth Power  
- U-turn  
- Taunt  

";
$t942523 = "Tinkaton (F) @ Icium Z  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Play Rough  
- Knock Off  
- Ice Hammer  
- Encore  

";
$t942533 = "Tinkatuff (F) @ Icium Z  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Play Rough  
- Stealth Rock  
- Ice Hammer  
- Swords Dance  

";
$t942543 = "Zapdos-Galar @ Rockium Z  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Low Kick  
- Sandstorm  
- Bulk Up  
- Drill Peck  

";
$t942553 = "Latios (M) @ Rockium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Ice Beam  
- Sandstorm  
- Calm Mind  

";
$t942564 = "Scream Tail @ Rockium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Sandstorm  
- Wish  
- Protect  

";
$t942575 = "Scream Tail @ Rockium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Play Rough  
- Encore  
- Baton Pass  
- Sandstorm  

";
$t942585 = "Iron Crown @ Assault Vest  
Ability: Quark Drive  
Tera Type: &
EVs: 132 HP / 164 SpA / 212 Spe  
Modest Nature  
IVs: 20 Atk  
- Tachyon Cutter  
- Psychic Noise  
- Focus Blast  
- Volt Switch  

";
$t942596 = "Iron Crown @ Fightinium Z  
Ability: Quark Drive  
Tera Type: &
EVs: 152 HP / 60 Def / 140 SpA / 4 SpD / 152 Spe  
Modest Nature  
IVs: 20 Atk  
- Stored Power  
- Calm Mind  
- Agility  
- Quick Guard  

";
$t942607 = "Rotom-Heat @ Waterium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Hidden Power [Ice]  
- Rain Dance  
- Protect  

";
$t942618 = "Thundurus-Therian (M) @ Waterium Z  
Ability: Volt Absorb  
Tera Type: &
EVs: 56 HP / 252 SpA / 4 SpD / 196 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Hidden Power [Ice]  
- Rain Dance  
- Protect  

";
$t942629 = "Hydrapple @ Life Orb  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Brave Nature  
- Draco Meteor  
- Bullet Seed  
- Sucker Punch  
- Breaking Swipe  

";
$t942639 = "Tapu Koko @ Waterium Z  
Ability: Electric Surge  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Electro Ball  
- Thunder  
- Defog  
- Rain Dance  

";
$t942650 = "Jolteon @ Firium Z  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Electro Ball  
- Weather Ball  
- Hidden Power [Ice]  
- Sunny Day  

";
$t942661 = "Zapdos @ Icy Rock  
Ability: Pressure  
Tera Type: &
EVs: 12 HP / 36 Def / 252 SpA / 8 SpD / 200 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Weather Ball  
- Hail  
- Roost  

";
$t942672 = "Zapdos @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 88 Atk / 168 SpA / 252 Spe  
Naive Nature  
- Charge Beam  
- Fly  
- Weather Ball  
- Hail  

";
$t942682 = "Raging Bolt @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 120 HP / 220 SpA / 32 SpD / 136 Spe  
Modest Nature  
IVs: 20 Atk  
- Thunder Wave  
- Dragon Pulse  
- Thunderclap  
- Taunt  

";
$t942693 = "Jirachi @ Normalium Z  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP  
Relaxed Nature  
IVs: 1 HP / 0 Atk / 0 Def / 0 SpA / 0 SpD / 0 Spe  
- Happy Hour  
- Baton Pass  

";
$t942702 = "Banette @ Waterium Z  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Thunder  
- Destiny Bond  
- Rain Dance  

";
$t942713 = "Banette @ Waterium Z  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Thunder  
- Shadow Ball  
- Rain Dance  

";
$t942724 = "Banette @ Waterium Z  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Thunder  
- Destiny Bond  
- Rain Dance  

";
$t942735 = "Banette @ Banettite  
Ability: Cursed Body  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Poltergeist  
- Torment  
- Substitute  
- Protect  

";
$t942745 = "Floette-Eternal (F) @ Grassium Z  
Ability: Flower Veil  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Light of Ruin  
- Hidden Power [Fire]  
- Aromatherapy  
- Protect  

";

$o941 = "Tapu Koko @ Electric Seed  
Ability: Electric Surge  
Tera Type: &
EVs: 180 HP / 232 Def / 96 Spe  
Timid Nature  
- Thunderbolt  
- Torment  
- Roost  
- Toxic  

";
$o9411 = "Conkeldurr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 8 HP / 252 Atk / 104 Def / 144 Spe  
Adamant Nature  
- Close Combat  
- Poison Jab  
- Ice Punch  
- Focus Energy  

";
$o9421 = "Diggersby @ Life Orb  
Ability: Huge Power  
Shiny: Yes  
Tera Type: &
EVs: 16 HP / 248 Atk / 88 Def / 156 Spe  
Jolly Nature  
- Giga Impact  
- Earthquake  
- Gunk Shot  
- Quick Attack  

";
$o9432 = "Primarina @ Life Orb  
Ability: Torrent  
Tera Type: &
EVs: 248 HP / 168 Def / 40 SpA / 52 SpD  
Modest Nature  
- Hydro Cannon  
- Moonblast  
- Magic Coat  
- Encore  

";
$o9442 = "Regidrago @ Scope Lens  
Ability: Dragon's Maw  
Tera Type: &
EVs: 232 Atk / 172 Def / 104 Spe  
Adamant Nature  
- Outrage  
- Scale Shot  
- Dragon Dance  
- Focus Energy  

";
$o9452 = "Porygon-Z @ Normal Gem  
Ability: Adaptability  
Tera Type: &
EVs: 28 HP / 252 SpA / 228 Spe  
Modest Nature  
IVs: 0 Atk  
- Agility  
- Hyper Beam  
- Thunderbolt  
- Uproar  

";
$o9463 = "Keldeo @ Wacan Berry  
Ability: Justified  
Tera Type: &
EVs: 144 HP / 32 Def / 252 SpA / 80 Spe  
Modest Nature  
IVs: 0 Atk  
- Hydro Pump  
- Secret Sword  
- Icy Wind  
- Reflect  

";
$o9474 = "Iron Moth @ Assault Vest  
Ability: Quark Drive  
Tera Type: &
EVs: 244 HP / 252 Def / 8 SpA / 4 Spe  
- Lunge  
- Acid Spray  
- Overheat  
- Sludge Wave  

";
$o9483 = "Eldegoss @ Eject Pack  
Ability: Regenerator  
Tera Type: &
EVs: 80 HP / 212 Def / 216 Spe  
Timid Nature  
- Leaf Storm  
- Pollen Puff  
- Rapid Spin  
- Sleep Powder  

";
$o9493 = "Mesprit @ Custap Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Relaxed Nature  
IVs: 16 Spe  
- Ice Beam  
- Toxic  
- U-turn  
- Healing Wish  

";
$o94104 = "Togekiss @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Defog  
- Seismic Toss  
- Dazzling Gleam  
- Soft-Boiled  

";
$o94115 = "Hydreigon @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 204 Atk / 72 SpA / 232 Spe  
Lonely Nature  
- Draco Meteor  
- Head Smash  
- Crunch  
- U-turn  

";
$o94125 = "Swampert @ Custap Berry  
Ability: Torrent  
Tera Type: &
EVs: 108 Atk / 220 SpD / 180 Spe  
Jolly Nature  
- Waterfall  
- Stone Edge  
- Endeavor  
- Stealth Rock  

";
$o94135 = "Medicham @ Medichamite  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Drain Punch  
- Rock Slide  
- Fake Out  
- Foresight  

";
$o94145 = "Greninja @ Life Orb  
Ability: Protean  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Shadow Sneak  
- Gunk Shot  
- U-turn  
- Ice Punch  

";
$o94155 = "Landorus-Therian (M) @ Mental Herb  
Ability: Intimidate  
Tera Type: &
EVs: 232 Atk / 96 Def / 180 Spe  
Adamant Nature  
- Bulk Up  
- Taunt  
- Earthquake  
- Smack Down  

";
$o94165 = "Hypno @ Rocky Helmet  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Sassy Nature  
IVs: 0 Atk / 0 Spe  
- Trick Room  
- Encore  
- Disable  
- Night Shade  

";
$o94176 = "Lapras @ Life Orb  
Ability: Shell Armor  
Tera Type: &
EVs: 248 HP / 164 Atk / 76 Def / 20 SpA  
Brave Nature  
- Icicle Spear  
- Freeze-Dry  
- Avalanche  
- Liquidation  

";
$o94186 = "Scyther @ Choice Scarf  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dual Wingbeat  
- Bug Bite  
- Thief  
- Counter  

";
$o94196 = "Gothitelle @ Sitrus Berry  
Ability: Shadow Tag  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Torment  
- Protect  
- Psychic Noise  
- Thunderbolt  

";
$o94207 = "Sceptile @ White Herb  
Ability: Unburden  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpA  
Quiet Nature  
- Leaf Storm  
- Frenzy Plant  
- Scale Shot  
- Hyper Beam  

";
$o94217 = "Drifblim @ Sitrus Berry  
Ability: Unburden  
Tera Type: &
EVs: 180 HP / 232 Def / 96 SpD  
Careful Nature  
- Curse  
- Strength Sap  
- Substitute  
- Phantom Force  

";
$o94227 = "Grafaiai @ Normal Gem  
Ability: Unburden  
Tera Type: &
EVs: 248 HP / 120 Def / 140 SpD  
Impish Nature  
- Super Fang  
- Giga Impact  
- Poison Fang  
- Substitute  

";
$o94237 = "Sandy Shocks @ Blunder Policy  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Brave Nature  
- Gravity  
- Stomping Tantrum  
- Screech  
- Zap Cannon  

";

$yr43 = "Rotom @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Hex  
- Reflect  
- Will-O-Wisp  
- Volt Switch  

";
$yr414 = "Xurkitree @ Choice Scarf  
Ability: Beast Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Dazzling Gleam  
- Energy Ball  
- Volt Switch  

";
$yr425 = "Sandy Shocks @ Light Clay  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scorching Sands  
- Spikes  
- Reflect  
- Light Screen  

";
$yr436 = "Lickilicky @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Giga Impact  
- Focus Punch  
- Knock Off  
- Substitute  

";
$yr446 = "Lickilicky @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Double-Edge  
- Hammer Arm  
- Thief  
- Protect  

";
$yr456 = "Tapu Fini @ Berserk Gene  
Ability: Misty Surge  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Knock Off  
- Draining Kiss  
- Stored Power  
- Calm Mind  

";
$yr466 = "Tapu Fini @ Berserk Gene  
Ability: Misty Surge  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Waterfall  
- Play Rough  
- Knock Off  
- Protect  

";
$yr476 = "Sneasler @ Berserk Gene  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 16 Atk / 240 SpD  
Adamant Nature  
- Reversal  
- Acrobatics  
- Substitute  
- Rest  

";
$yr486 = "Gyarados @ Throat Spray  
Ability: Intimidate  
Tera Type: &
EVs: 44 HP / 252 SpA / 4 SpD / 208 Spe  
Modest Nature  
IVs: 0 Atk  
- Scald  
- Fire Blast  
- Roar  
- Protect  

";
$yr497 = "Mudsdale @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- High Horsepower  
- Stealth Rock  
- Sleep Talk  
- Protect  

";
$yr4107 = "Hoopa-Unbound @ Assault Vest  
Ability: Magician  
Tera Type: &
EVs: 248 HP / 56 Atk / 12 Def / 44 SpA / 24 SpD / 124 Spe  
Lonely Nature  
- Knock Off  
- Gunk Shot  
- Fire Punch  
- Psychic  

";
$yr4117 = "Persian @ Choice Specs  
Ability: Technician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Hyper Beam  
- Icy Wind  
- Water Pulse  
- Petal Dance  

";
$yr4128 = "Kyurem-Black @ Berserk Gene  
Ability: Teravolt  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Lonely Nature  
IVs: 5 HP / 0 Def  
- Outrage  
- Sleep Talk  
- Ancient Power  
- Hidden Power [Ice]  

";
$yr4139 = "Celebi @ Leftovers  
Ability: Natural Cure  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 24 SpD / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Leech Seed  
- Recover  
- Substitute  
- Reflect  

";
$yr4151 = "Celebi @ Choice Scarf  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 156 Def / 100 SpA  
Modest Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Earth Power  
- Giga Drain  
- Trick  

";
$yr4162 = "Celebi @ Leftovers  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 104 Def / 152 Spe  
Bold Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Curse  
- Leech Seed  
- Rest  

";
$yr4173 = "Grimmsnarl (M) @ Babiri Berry  
Ability: Prankster  
Tera Type: &
EVs: 200 HP / 212 Atk / 96 Def  
Relaxed Nature  
- Burning Jealousy  
- Stomping Tantrum  
- Sucker Punch  
- Fake Out  

";
$yr4183 = "Ludicolo @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Seed Bomb  
- Waterfall  
- Dynamic Punch  
- Thief  

";
$yr4193 = "Vikavolt @ Charti Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Sticky Web  
- Air Slash  
- Roost  
- Iron Defense  

";
$yr4204 = "Indeedee-F (F) @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tera Blast  
- Protect  
- Baton Pass  
- Calm Mind  

";
$yr4215 = "Cresselia @ Covert Cloak  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 120 Def / 136 Spe  
Bold Nature  
IVs: 0 Atk  
- Stored Power  
- Aurora Beam  
- Lunar Blessing  
- Calm Mind  

";
$yr4226 = "Kingdra @ Choice Specs  
Ability: Sniper  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Timid Nature  
IVs: 0 Atk  
- Aurora Beam  
- Sleep Talk  

";
$yr4235 = "Slowbro-Galar @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Gunk Shot  
- Drain Punch  
- Brutal Swing  
- Protect  

";
$yr4245 = "Thievul @ Berserk Gene  
Ability: Unburden  
Tera Type: &
EVs: 208 HP / 252 Atk / 48 Spe  
Adamant Nature  
- Crunch  
- Play Rough  
- Acrobatics  
- Thief  

";
$yr4255 = "Rotom-Mow @ Heavy-Duty Boots  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Leaf Storm  
- Volt Switch  
- Defog  
- Pain Split  

";
$yr4266 = "Sandy Shocks @ Choice Scarf  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flash Cannon  
- Earth Power  
- Thunder Wave  
- Volt Switch  

";
$yr4277 = "Raging Bolt @ Magnet  
Ability: Protosynthesis  
Tera Type: &
EVs: 112 Def / 252 SpA / 144 Spe  
Modest Nature  
IVs: 20 Atk  
- Thunderbolt  
- Dragon Pulse  
- Thunderclap  
- Calm Mind  

";
$yr4288 = "Pawmot @ Life Orb  
Ability: Natural Cure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Volt Switch  
- Revival Blessing  
- Rest  

";
$yr4298 = "Stunfisk @ Shuca Berry  
Ability: Static  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Earth Power  
- Scald  
- Pain Split  
- Stealth Rock  

";
$yr4309 = "Magnezone @ Custap Berry  
Ability: Sturdy  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Volt Switch  
- Flash Cannon  
- Steel Beam  
- Endure  

";
$yr4320 = "Klefki @ Rocky Helmet  
Ability: Magician  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Toxic  
- Defog  
- Magnet Rise  

";
$yr4331 = "Infernape @ Life Orb  
Ability: Blaze  
Tera Type: &
EVs: 252 Atk / 36 SpA / 220 Spe  
Naughty Nature  
- Blast Burn  
- Gunk Shot  
- Substitute  
- Fake Out  

";
$yr4341 = "Slowking-Galar @ Expert Belt  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Chilly Reception  
- Sludge Bomb  
- Ice Beam  
- Future Sight  

";
$yr4352 = "Volcarona @ Mental Herb  
Ability: Swarm  
Tera Type: &
EVs: 212 HP / 80 Def / 216 Spe  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Overheat  
- Safeguard  
- Quiver Dance  

";
$yr4363 = "Cradily @ Wiki Berry  
Ability: Storm Drain  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Power Whip  
- Stone Edge  
- Earthquake  
- Swords Dance  

";
$yr4373 = "Kyurem @ Persim Berry  
Ability: Pressure  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Outrage  
- Substitute  
- Roost  
- Dragon Dance  

";
$yr4383 = "Tapu Koko @ Electric Seed  
Ability: Electric Surge  
Tera Type: &
EVs: 180 HP / 232 Def / 96 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Torment  
- Roost  
- Protect  

";
$yr4394 = "Granbull @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpD / 108 Spe  
Adamant Nature  
- Play Rough  
- Toxic  
- Heal Bell  
- Protect  

";
$yr4404 = "Slowbro @ Heavy-Duty Boots  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Future Sight  
- Slack Off  
- Telekinesis  

";
$yr4415 = "Altaria (F) @ Maranga Berry  
Ability: Cloud Nine  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Cotton Guard  
- Dragon Dance  
- Roost  
- Acrobatics  

";
$yr4426 = "Blissey (F) @ Heavy-Duty Boots  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Seismic Toss  
- Thunder Wave  
- Copycat  
- Soft-Boiled  

";
$yr4436 = "Magneton @ Eviolite  
Ability: Magnet Pull  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Hidden Power [Fire]  
- Volt Switch  
- Flash Cannon  
- Thunderbolt  

";
$yr4447 = "Rotom-Frost @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Blizzard  
- Will-O-Wisp  
- Pain Split  

Raichu-Alola  
Ability: Surge Surfer  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Agility  
- Psychic Terrain  
- Expanding Force  

";
$yr4468 = "Thundurus-Therian (M) @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 108 HP / 252 SpA / 148 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Psychic  
- Protect  
- Agility  

";
$yr4479 = "Togedemaru @ Weakness Policy  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Agility  
- Iron Head  
- Reversal  
- Spiky Shield  

";
$yr4489 = "Luxray @ Heavy-Duty Boots  
Ability: Guts  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Wild Charge  
- Sleep Talk  
- Rest  
- Trailblaze  

";
$yr4499 = "Sinistcha @ Grassium Z  
Ability: Heatproof  
Tera Type: &
EVs: 136 HP / 120 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Matcha Gotcha  
- Scald  
- Protect  
- Calm Mind  

";
$yr4510 = "Mr. Rime @ Mirror Herb  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swagger  
- Triple Axel  
- Zen Headbutt  
- Drain Punch  

";
$yr4520 = "Mr. Rime @ Light Clay  
Ability: Screen Cleaner  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Reflect  
- Light Screen  
- Healing Wish  
- Taunt  

";
$yr4531 = "Mr. Rime @ Ice Gem  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Baton Pass  
- Freeze-Dry  
- Psychic  

";
$yr4542 = "Mr. Rime @ Kee Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpA  
Modest Nature  
IVs: 0 Atk  
- Psychic Terrain  
- Expanding Force  
- Nasty Plot  
- Slack Off  

";
$yr4553 = "Mr. Rime @ Light Ball  
Ability: Screen Cleaner  
Tera Type: &
EVs: 248 HP / 100 Def / 60 SpA / 100 Spe  
Modest Nature  
- Fake Out  
- Freeze-Dry  
- Fling  
- Encore  

";
$yr4563 = "Mr. Rime @ Kee Berry  
Ability: Screen Cleaner  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Encore  
- Slack Off  
- Freeze-Dry  

";
$yr4574 = "Mr. Rime @ Heavy-Duty Boots  
Ability: Screen Cleaner  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
- Thunder Wave  
- Rapid Spin  
- Teeter Dance  
- Future Sight  

";
$yr4584 = "Mr. Rime @ Loaded Dice  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Icicle Spear  
- Swagger  
- Psych Up  
- Protect  

";
$yr4594 = "Mr. Rime @ Choice Band  
Ability: Screen Cleaner  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Zen Headbutt  
- Triple Axel  
- Drain Punch  
- Icicle Spear  

";
$yr4604 = "Mr. Rime @ King's Rock  
Ability: Tangled Feet  
Tera Type: &
EVs: 248 HP / 160 Def / 100 Spe  
Adamant Nature  
- Thunder Wave  
- Teeter Dance  
- Icicle Spear  
- Slack Off  

";
$yr4614 = "Mr. Rime @ Choice Scarf  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Trick  
- Slack Off  
- Thunder Wave  
- Psychic  

";
$yr4625 = "Mr. Rime @ Heavy-Duty Boots  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Ice Beam  
- Psychic  
- Focus Blast  

";
$yr4636 = "Mr. Rime @ Leftovers  
Ability: Ice Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hail  
- Nasty Plot  
- Blizzard  
- Protect  

";
$yr4647 = "Mr. Rime @ Fighting Gem  
Ability: Ice Body  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Substitute  
- Snowscape  
- Focus Punch  
- Thief  

";
$yr4657 = "Mr. Rime @ Liechi Berry  
Ability: Screen Cleaner  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Quiet Nature  
- Metronome  
- Slack Off  
- Substitute  
- Calm Mind  

";
$yr4667 = "Mr. Rime @ Leftovers  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Thunder Wave  
- Freeze-Dry  
- Focus Blast  

";
$yr4678 = "Mr. Rime @ Salac Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Substitute  
- Stored Power  
- Tera Blast  

";
$yr4689 = "Mr. Rime @ Heavy-Duty Boots  
Ability: Ice Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Rapid Spin  
- Hail  
- Blizzard  
- Future Sight  

";
$yr4699 = "Mr. Rime @ Never-Melt Ice  
Ability: Ice Body  
Tera Type: &
EVs: 248 HP / 112 Def / 140 SpA / 8 Spe  
Modest Nature  
IVs: 0 Atk  
- Snowscape  
- Blizzard  
- Slack Off  
- Calm Mind  

";
$yr4710 = "Mr. Rime @ Twisted Spoon  
Ability: Screen Cleaner  
Tera Type: &
EVs: 88 HP / 68 Def / 176 SpA / 176 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Future Sight  
- Charge Beam  
- Thunder Wave  

";
$yr4721 = "Mr. Rime @ Psychic Gem  
Ability: Screen Cleaner  
Tera Type: &
EVs: 96 HP / 232 SpA / 180 Spe  
Modest Nature  
- Rapid Spin  
- Future Sight  
- Ice Beam  
- Healing Wish  

";
$yr4731 = "Mr. Rime @ Zoom Lens  
Ability: Ice Body  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe  
Modest Nature  
IVs: 0 Atk  
- Charge Beam  
- Blizzard  
- Slack Off  
- Snowscape  

";
$yr4742 = "Mr. Rime @ Figy Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Taunt  
- Thunder Wave  
- Ice Beam  
- Future Sight  

";
$yr4753 = "Mr. Rime @ Figy Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 156 HP / 252 SpA / 100 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Future Sight  
- Slack Off  
- Substitute  


";
$yr4765 = "Stunfisk-Galar @ Dark Gem  
Ability: Mimicry  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Curse  
- Stomping Tantrum  
- Sucker Punch  
- Dig  

";
$yr4775 = "Stunfisk-Galar @ Choice Specs  
Ability: Mimicry  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Steel Beam  
- Earth Power  
- Scald  
- Terrain Pulse  

";
$yr4786 = "Stunfisk-Galar @ Chesto Berry  
Ability: Mimicry  
Tera Type: &
EVs: 188 HP / 68 Atk / 252 Spe  
Adamant Nature  
- Thunder Wave  
- Bulldoze  
- Rock Slide  
- Rest  

";
$yr4796 = "Stunfisk-Galar @ Rocky Helmet  
Ability: Mimicry  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Rest  
- Sleep Talk  
- Bounce  
- Dig  

";
$yr4806 = "Stunfisk @ Electric Gem  
Ability: Static  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Charge  
- Thunderbolt  
- Earth Power  
- Pain Split  

";
$yr4817 = "Stunfisk @ Leftovers  
Ability: Static  
Tera Type: &
EVs: 184 HP / 252 Atk / 32 Def / 40 SpD  
Adamant Nature  
- Curse  
- Confide  
- Dig  
- Bounce  

";
$yr4827 = "Stunfisk @ Choice Specs  
Ability: Static  
Tera Type: &
EVs: 240 HP / 252 SpA / 16 Spe  
Modest Nature  
IVs: 0 Atk  
- Eruption  
- Thunder  
- Sludge Bomb  
- Scald  

";
$yr4838 = "Stunfisk @ Petaya Berry  
Ability: Limber  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Tera Blast  
- Substitute  
- Pain Split  
- Endeavor  

";
$yr4849 = "Stunfisk @ Bright Powder  
Ability: Sand Veil  
Tera Type: &
EVs: 252 Def / 252 SpD  
Relaxed Nature  
IVs: 0 Atk  
- Sandstorm  
- Toxic  
- Infestation  
- Pain Split  

";
$yr4860 = "Stunfisk @ Water Gem  
Ability: Static  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Magnet Rise  
- Scald  
- Earth Power  
- Discharge  

";
$yr4871 = "Stunfisk @ Quick Claw  
Ability: Static  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Thunderbolt  
- Earth Power  
- Endeavor  

";
$yr4882 = "Grovyle @ Bright Powder  
Ability: Overgrow  
Tera Type: &
EVs: 248 SpA / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Endeavor  
- Toxic  
- Leaf Storm  

";
$yr4893 = "Vigoroth @ Bright Powder  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Knock Off  
- Thunder Wave  
- Endeavor  

";
$yr4903 = "Aipom @ Bright Powder  
Ability: Pickup  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Taunt  
- Thunder Wave  
- Endeavor  

";
$yr4914 = "Ambipom @ King's Rock  
Ability: Skill Link  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Tail Slap  
- Triple Axel  
- Substitute  
- Knock Off  

";
$yr4924 = "Chatot @ Bright Powder  
Ability: Big Pecks  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Nasty Plot  
- Boomburst  
- Synchronoise  

";
$yr4935 = "Mr. Rime @ Bright Powder  
Ability: Ice Body  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Hail  
- Blizzard  
- Slack Off  

";
$yr4946 = "Mr. Rime @ Ice Gem  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Protect  
- Ice Beam  
- Charge Beam  
- Thief  

";
$yr4956 = "Mr. Rime @ Figy Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Swagger  
- Slack Off  
- Future Sight  

";
$yr4967 = "Mr. Rime @ Berserk Gene  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Triple Axel  
- Substitute  
- Drain Punch  
- Zen Headbutt  

";
$yr4977 = "Chatot @ Berserk Gene  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naughty Nature  
- Sky Attack  
- Roost  
- Return  
- Tera Blast  

";
$yr4987 = "Spinda @ Berserk Gene  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Return  
- Low Kick  
- Sucker Punch  
- Wish  

";
$yr4997 = "Mr. Rime @ Heavy-Duty Boots  
Ability: Screen Cleaner  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Rapid Spin  
- Nasty Plot  
- Psychic  
- Focus Blast  

";
$yr41007 = "Mr. Rime @ Red Card  
Ability: Ice Body  
Tera Type: &
EVs: 248 HP / 80 SpA / 180 Spe  
Modest Nature  
IVs: 0 Atk  
- Iron Defense  
- Calm Mind  
- Slack Off  
- Freeze-Dry  

";
$yr41018 = "Poliwrath @ Leftovers  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Mind Reader  
- Bulk Up  
- Dynamic Punch  
- Hypnosis  

";
$yr41028 = "Pumpkaboo @ Choice Band  
Ability: Frisk  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA  
Brave Nature  
- Poltergeist  
- Shadow Sneak  
- Seed Bomb  
- Tera Blast  

";
$yr41038 = "Pumpkaboo-Super @ Eviolite  
Ability: Insomnia  
Tera Type: &
EVs: 248 HP / 116 Def / 144 SpD  
Careful Nature  
- Synthesis  
- Curse  
- Tera Blast  
- Poltergeist  

";
$yr41048 = "Pumpkaboo-Small @ Ghost Gem  
Ability: Pickup  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Leech Seed  
- Toxic  
- Protect  
- Poltergeist  

";
$yr41058 = "Eelektrik @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD  
Relaxed Nature  
- Super Fang  
- U-turn  
- Discharge  
- Knock Off  

";
$yr41068 = "Eelektrik @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 28 Atk / 128 Def / 100 SpD  
Adamant Nature  
- Rest  
- Sleep Talk  
- Coil  
- Knock Off  

";
$yr41078 = "Eelektrik @ Electric Gem  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Acid Spray  
- Thunder  
- Protect  
- Giga Drain  

";
$yr41089 = "Timburr @ Fighting Gem  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Substitute  
- Focus Punch  
- Knock Off  
- Thief  

";
$yr41099 = "Cleffa @ Choice Scarf  
Ability: Magic Guard  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Trick  
- Soft-Boiled  
- Heal Pulse  
- Substitute  

";
$yr41110 = "Slowpoke-Galar @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 184 HP / 72 Atk / 252 SpD  
Careful Nature  
- Curse  
- Slack Off  
- Zen Headbutt  
- Dig  

";
$yr41120 = "Slowpoke-Galar @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Slack Off  
- Curse  
- Stored Power  

";
$yr41131 = "Slowpoke-Galar @ Lagging Tail  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Trick  
- Slack Off  
- Psychic  
- Yawn  

";
$yr41142 = "Slowpoke-Galar @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 116 Def / 144 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Slack Off  
- Psychic  
- Fire Blast  

";
$yr41153 = "Slowpoke-Galar @ Choice Band  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Zen Headbutt  
- Trick  
- Iron Tail  
- Bulldoze  

";
$yr41163 = "Slowpoke-Galar @ Rocky Helmet  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Slack Off  
- Thunder Wave  
- Ice Beam  

";
$yr41174 = "Slowpoke-Galar @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Bold Nature  
IVs: 0 Atk  
- Substitute  
- Yawn  
- Whirlpool  
- Protect  

";
$yr41185 = "Slowpoke-Galar @ Custap Berry  
Ability: Gluttony  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Belly Drum  
- Zen Headbutt  
- Avalanche  
- Dig  

";
$yr41195 = "Slowpoke-Galar @ Custap Berry  
Ability: Gluttony  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Belch  
- Psychic  

";
$yr41206 = "Slowpoke @ Light Clay  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Reflect  
- Light Screen  
- Yawn  
- Teleport  

";
$yr41217 = "Slowpoke @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Belly Drum  
- Slack Off  
- Protect  
- Liquidation  

";
$yr41227 = "Slowpoke @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Zap Cannon  
- Slack Off  
- Light Screen  
- Scald  

";
$yr41238 = "Wigglytuff @ Electric Gem  
Ability: Frisk  
Tera Type: &
EVs: 96 HP / 80 Def / 248 SpA / 80 SpD / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Gravity  
- Zap Cannon  
- Teleport  
- Wish  

";
$yr41249 = "Porygon @ Eviolite  
Ability: Analytic  
Tera Type: &
EVs: 248 HP / 248 SpA / 12 Spe  
Modest Nature  
IVs: 0 Atk  
- Zap Cannon  
- Recover  
- Gravity  
- Blizzard  

";
$yr41260 = "Porygon @ Eviolite  
Ability: Analytic  
Tera Type: &
EVs: 252 HP / 140 Def / 116 SpD  
Calm Nature  
IVs: 0 Atk  
- Gravity  
- Zap Cannon  
- Recover  
- Teleport  

";
$yr41271 = "Plusle @ Choice Specs  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder  
- Volt Switch  
- Grass Knot  
- Switcheroo  

";
$yr41282 = "Plusle @ Leftovers  
Ability: Plus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Protect  
- Charge Beam  
- Thunder  

";
$yr41293 = "Plusle @ Electric Gem  
Ability: Plus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Mild Nature  
- Nasty Plot  
- Trailblaze  
- Thunderbolt  
- Alluring Voice  

";
$yr41303 = "Plusle @ Petaya Berry  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Substitute  
- Nuzzle  
- Endeavor  
- Thunder  

";
$yr41313 = "Plusle @ Focus Sash  
Ability: Plus  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Hasty Nature  
- Counter  
- Nuzzle  
- Endeavor  
- Discharge  

";
$yr41323 = "Minun @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Wish  
- Protect  
- Nuzzle  
- Seismic Toss  

";
$yr41333 = "Minun @ Leftovers  
Ability: Minus  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Toxic  
- Protect  
- Charge Beam  
- Baton Pass  

";
$yr41344 = "Minun @ Starf Berry  
Ability: Minus  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Agility  
- Nasty Plot  
- Baton Pass  
- Substitute  

";
$yr41355 = "Minun @ Leftovers  
Ability: Minus  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Jolly Nature  
- Agility  
- Nuzzle  
- Protect  
- Baton Pass  

";
$yr41365 = "Plusle @ Mirror Herb  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Protect  
- Swagger  
- Last Resort  

";
$yr41375 = "Plusle @ Mirror Herb  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Entrainment  
- Discharge  
- Thunder  
- Tera Blast  

";
$yr41386 = "Plusle @ Leftovers  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Toxic  
- Protect  
- Super Fang  
- Magnet Rise  

";
$yr41397 = "Minun @ Kee Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
- Wish  
- Protect  
- Nuzzle  
- Seismic Toss  

";
$yr41407 = "Plusle @ Starf Berry  
Ability: Plus  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Discharge  
- Seismic Toss  

";
$yr41418 = "Drowzee @ Eviolite  
Ability: Forewarn  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Sassy Nature  
IVs: 0 Atk  
- Trick Room  
- Encore  
- Disable  
- Rest  

";
$yr41429 = "Spritzee @ Eviolite  
Ability: Aroma Veil  
Tera Type: &
EVs: 248 HP / 172 Def / 88 SpD  
Sassy Nature  
IVs: 0 Atk  
- Trick Room  
- Encore  
- Disable  
- Wish  

";
$yr41440 = "Spritzee @ Eviolite  
Ability: Aroma Veil  
Tera Type: &
EVs: 248 HP / 196 Def / 64 SpA  
Bold Nature  
IVs: 0 Atk  
- Wish  
- Protect  
- Calm Mind  
- Moonblast  

";
$yr41451 = "Spritzee @ Eviolite  
Ability: Aroma Veil  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Wish  
- Protect  
- Moonblast  

";
$yr41462 = "Dewott @ Light Ball  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 28 Def / 96 SpA / 132 Spe  
Modest Nature  
- Fling  
- Encore  
- Flip Turn  
- Scald  

";
$yr41472 = "Snover @ Eviolite  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Blizzard  
- Grass Whistle  

";
$yr41483 = "Snover @ Eviolite  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Blizzard  
- Growth  

";
$yr41494 = "Snover @ Eviolite  
Ability: Soundproof  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Adamant Nature  
- Curse  
- Synthesis  
- Icicle Spear  
- Bullet Seed  

";
$yr41504 = "Snover @ Bright Powder  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
- Substitute  
- Leech Seed  
- Trailblaze  
- Blizzard  

";
$yr41514 = "Abomasnow @ Loaded Dice  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Swords Dance  
- Icicle Spear  
- Bullet Seed  
- Ice Shard  

";
$yr41524 = "Larvesta @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
- U-turn  
- Morning Sun  
- Will-O-Wisp  
- Fire Spin  

";
$yr41534 = "Larvesta @ Eviolite  
Ability: Flame Body  
Tera Type: &
EVs: 248 HP / 40 Def / 120 SpA / 100 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Morning Sun  
- Will-O-Wisp  
- Flamethrower  

";
$yr41545 = "Larvesta @ Fire Gem  
Ability: Flame Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Calm Mind  
- Overheat  
- Trailblaze  
- Tera Blast  

";
$yr41555 = "Larvesta @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 248 HP / 216 Def / 44 SpD  
Bold Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Morning Sun  
- Fire Spin  
- Struggle Bug  

";
$yr41566 = "Anorith @ Heavy-Duty Boots  
Ability: Battle Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Rapid Spin  
- Stealth Rock  
- Protect  

";
$yr41576 = "Palpitoad @ Eviolite  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 156 SpA / 104 SpD  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Scald  
- Infestation  
- Earth Power  

";
$yr41587 = "Palpitoad @ Eviolite  
Ability: Swift Swim  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Bold Nature  
IVs: 0 Atk  
- Infestation  
- Protect  
- Aqua Ring  
- Scald  

";
$yr41598 = "Tympole @ Life Orb  
Ability: Swift Swim  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Rain Dance  
- Hydro Pump  
- Weather Ball  
- Tera Blast  

";
$yr41609 = "Frogadier @ Eviolite  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Hydro Pump  
- U-turn  
- Spikes  
- Taunt  

";
$yr41619 = "Skiploom @ Flying Gem  
Ability: Infiltrator  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Acrobatics  
- Trailblaze  
- Baton Pass  

";
$yr41629 = "Skiploom @ Heavy-Duty Boots  
Ability: Leaf Guard  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Stun Spore  
- Synthesis  
- U-turn  
- Encore  

";
$yr41639 = "Skiploom @ Eviolite  
Ability: Infiltrator  
Tera Type: &
EVs: 248 HP / 196 Def / 64 SpD  
Careful Nature  
- Amnesia  
- Curse  
- Synthesis  
- Bounce  

";
$yr41649 = "Corphish @ Scope Lens  
Ability: Adaptability  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Protect  
- Crabhammer  
- Night Slash  

";
$yr41659 = "Corphish @ Eviolite  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Crabhammer  
- Knock Off  
- Protect  

";
$yr41669 = "Panpour @ Choice Specs  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Ice Beam  
- Tera Blast  
- Grass Knot  

";
$yr41680 = "Pansage @ Leftovers  
Ability: Gluttony  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Protect  
- Substitute  
- Toxic  

";
$yr41690 = "Pansear @ Heavy-Duty Boots  
Ability: Gluttony  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Fire Blast  
- Grass Knot  
- Protect  

";
$yr41701 = "Minun @ Electric Gem  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Thunderbolt  
- Grass Knot  
- Alluring Voice  

";
$yr41712 = "Minun @ Leftovers  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Super Fang  
- Encore  
- Discharge  

";
$yr41723 = "Minun @ Electric Gem  
Ability: Minus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Nasty Plot  
- Protect  
- Thunderbolt  
- Covet  

";
$yr41733 = "Minun @ Choice Scarf  
Ability: Minus  
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Switcheroo  
- Volt Switch  
- Endeavor  
- Super Fang  

";
$yr41744 = "Minun @ Choice Specs  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Switcheroo  
- Volt Switch  
- Signal Beam  

";
$yr41755 = "Minun @ Maranga Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Calm Nature  
IVs: 0 Atk  
- Wish  
- Protect  
- Discharge  
- Defense Curl  

";
$yr41766 = "Minun @ Blunder Policy  
Ability: Volt Absorb  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe  
Modest Nature  
- Thunder  
- Sing  
- Dynamic Punch  
- Encore  

";
$yr41776 = "Tauros (M) @ Damp Rock  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
IVs: 0 Atk  
- Rain Dance  
- Work Up  
- Whirlpool  
- Tera Blast  

";
$yr41787 = "Deerling-Summer @ Eviolite  
Ability: Serene Grace  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Impish Nature  
- Body Slam  
- Synthesis  
- Leech Seed  
- Aromatherapy  

";
$yr41797 = "Deerling @ Eviolite  
Ability: Serene Grace  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Careful Nature  
- Body Slam  
- Synthesis  
- Dig  
- Bullet Seed  

";
$yr41807 = "Deerling-Autumn @ Grassy Seed  
Ability: Sap Sipper  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Bold Nature  
IVs: 0 Atk  
- Agility  
- Grassy Terrain  
- Work Up  
- Baton Pass  

";
$yr41818 = "Deerling-Winter @ Eviolite  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Work Up  
- Trailblaze  
- Synthesis  
- Last Resort  

";
$yr41828 = "Barbaracle @ Water Gem  
Ability: Pickpocket  
Tera Type: &
EVs: 200 Atk / 96 SpA / 212 Spe  
Naughty Nature  
- Shell Smash  
- Stone Edge  
- Scald  
- Protect  

";
$yr41838 = "Binacle @ Eviolite  
Ability: Tough Claws  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Shell Smash  
- Stone Edge  
- Liquidation  
- X-Scissor  

";
$yr41848 = "Binacle @ Eviolite  
Ability: Tough Claws  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Swords Dance  
- Protect  
- Dig  
- Liquidation  

";
$yr41858 = "Binacle @ Lansat Berry  
Ability: Sniper  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Substitute  
- Protect  
- Dig  
- Stone Edge  

";
$yr41868 = "Binacle @ Choice Scarf  
Ability: Pickpocket  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Switcheroo  
- Endeavor  
- Stealth Rock  
- Scald  

";
$yr41879 = "Binacle @ Eviolite  
Ability: Tough Claws  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Stealth Rock  
- Infestation  
- Protect  

";
$yr41890 = "Binacle @ Eviolite  
Ability: Tough Claws  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Rest  
- Sleep Talk  
- Swords Dance  
- Liquidation  

";
$yr41900 = "Barbaracle @ Rock Gem  
Ability: Pickpocket  
Tera Type: &
EVs: 252 Atk / 104 SpD / 152 Spe  
Adamant Nature  
- Shell Smash  
- Stone Edge  
- Dig  
- Substitute  

";
$yr41910 = "Barbaracle @ Choice Scarf  
Ability: Tough Claws  
Tera Type: &
EVs: 152 HP / 100 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Switcheroo  
- Liquidation  
- Fling  
- Thief  

";
$yr41920 = "Barbaracle @ Light Ball  
Ability: Tough Claws  
Tera Type: &
EVs: 248 HP / 72 Atk / 108 SpD / 80 Spe  
Impish Nature  
- Stealth Rock  
- Dive  
- Fling  
- Clamp  

";
$yr41930 = "Barbaracle @ Power Herb  
Ability: Pickpocket  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Substitute  
- Taunt  
- Meteor Beam  
- Clamp  

";
$yr41940 = "Barbaracle @ Rindo Berry  
Ability: Tough Claws  
Tera Type: &
EVs: 144 HP / 252 Atk / 112 Spe  
Adamant Nature  
- Shell Smash  
- Liquidation  
- X-Scissor  
- Thief  

";
$yr41950 = "Tangela @ Eviolite  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Giga Drain  
- Leech Seed  
- Protect  
- Sleep Powder  

";
$yr41961 = "Mantyke @ Eviolite  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Scald  
- Amnesia  
- Toxic  
- Rest  

";
$yr41972 = "Onix @ Eviolite  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Protect  
- Rest  
- Toxic  
- Rock Tomb  

";
$yr41982 = "Magnemite @ Eviolite  
Ability: Magnet Pull  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe  
Modest Nature  
IVs: 0 Atk  
- Protect  
- Thunder Wave  
- Thunderbolt  
- Teleport  

";
$yr41993 = "Crabrawler @ Eviolite  
Ability: Iron Fist  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Close Combat  
- Ice Punch  
- Gunk Shot  
- Knock Off  

";
$yr42003 = "Crabrawler @ Fighting Gem  
Ability: Hyper Cutter  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Substitute  
- Focus Punch  
- Protect  
- Dig  

";
$yr42013 = "Crabrawler @ Water Gem  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Close Combat  
- Liquidation  
- Thief  
- Protect  

";

$been41 = "Snorlax @ Toxic Orb  
Ability: Immunity  
Tera Type: &
EVs: 48 Atk / 184 Def / 32 SpD / 244 Spe  
Jolly Nature  
- Fling  
- Return  
- Fire Punch  
- Rest  

";
$been411 = "Whimsicott (F) @ Leftovers  
Ability: Prankster  
Level: 98  
Shiny: Yes  
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe  
Timid Nature  
IVs: 30 HP / 0 Atk / 30 Def / 30 SpA / 30 SpD  
- Cotton Guard  
- Toxic  
- Taunt  
- Hidden Power [Flying]  

";
$been424 = "Gothitelle @ Kasib Berry  
Ability: Shadow Tag  
Tera Type: &
EVs: 252 HP / 64 Def / 64 SpD / 128 Spe  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Imprison  
- Rest  
- Shadow Ball  

";
$been435 = "Porygon-Z @ Normalium Z  
Ability: Adaptability  
Tera Type: &
EVs: 212 Def / 80 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Hidden Power [Rock]  
- Pain Split  
- Hyper Beam  
- Conversion  

";
$been446 = "Regigigas @ Kee Berry  
Ability: Slow Start  
Tera Type: &
EVs: 252 HP / 168 Def / 88 SpD  
Bold Nature  
- Thunder Wave  
- Knock Off  
- Rest  
- Block  

";
$been456 = "Snorlax @ Covert Cloak  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 84 Atk / 172 Def  
Impish Nature  
- Rest  
- Block  
- Curse  
- Darkest Lariat  

";
$been466 = "Wooper @ Eviolite  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Spikes  
- Scald  
- Counter  
- Recover  

";
$been477 = "Typhlosion @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 248 HP / 200 Def / 28 SpA / 32 Spe  
Lax Nature  
- Reversal  
- Substitute  
- Blast Burn  
- Defense Curl  

";
$been487 = "Arcanine @ White Herb  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 144 Def / 100 SpD / 12 Spe  
Calm Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Morning Sun  
- Flamethrower  
- Hidden Power [Ice]  

";
$been498 = "Purugly @ Normal Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fake Out  
- Substitute  
- Flail  
- Return  

";
$been4108 = "Charizard @ Charizardite X  
Ability: Blaze  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Blast Burn  
- Dragon Pulse  
- Focus Blast  

";
$been4119 = "Gyarados @ Gyaradosite  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Bide  
- Dragon Dance  
- Stone Edge  
- Waterfall  

";
$been4129 = "Marowak-Alola @ Shuca Berry  
Ability: Lightning Rod  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Counter  
- Iron Defense  
- Seismic Toss  
- Rest  

";
$been4140 = "Gyarados (M) @ Gyaradosite  
Ability: Intimidate  
Tera Type: &
EVs: 96 Atk / 196 SpD / 216 Spe  
Gentle Nature  
- Earthquake  
- Outrage  
- Stone Edge  
- Dragon Dance  

";
$been4150 = "Dunsparce @ Eviolite  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Glare  
- Pain Split  
- Ice Spinner  
- Body Slam  

";
$been4160 = "Garganacl @ Toxic Orb  
Ability: Purifying Salt  
Tera Type: &
EVs: 252 HP / 4 Atk / 48 Def / 204 SpD  
Impish Nature  
- Salt Cure  
- Recover  
- Fling  
- Body Press  

";
$been4170 = "Ceruledge @ Iapapa Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Taunt  
- Curse  
- Fire Spin  
- Protect  

";
$been4181 = "Gligar @ Eviolite  
Ability: Immunity  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Rock Polish  
- Roost  
- Harden  
- Earthquake  

";
$been4191 = "Gligar @ Eviolite  
Ability: Immunity  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Torment  
- Roost  
- Curse  
- Earthquake  

";
$been4201 = "Swellow @ Jaboca Berry  
Ability: Scrappy  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Endure  
- Substitute  
- Endeavor  
- Boomburst  

";
$been4212 = "Swellow @ Rowap Berry  
Ability: Scrappy  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Endure  
- Substitute  
- Endeavor  
- Boomburst  

";
$been4223 = "Metagross @ Metagrossite  
Ability: Tough Claws  
Tera Type: &
EVs: 252 HP / 96 Atk / 28 Def / 88 SpA / 20 SpD / 24 Spe  
Relaxed Nature  
- Meteor Mash  
- Thunder Punch  
- Grass Knot  
- Bullet Punch  

";
$been4233 = "Zygarde @ Yache Berry  
Ability: Aura Break  
Tera Type: &
EVs: 240 HP / 16 Atk / 136 Def / 100 SpD / 16 Spe  
Impish Nature  
- Camouflage  
- Coil  
- Thousand Arrows  
- Rest  

";
$been4243 = "Sceptile @ Flame Orb  
Ability: Unburden  
Tera Type: &
EVs: 120 HP / 252 Def / 136 Spe  
Timid Nature  
- Fling  
- Leech Seed  
- Synthesis  
- Seismic Toss  



";
$been4255 = "Virizion @ Fighting Gem  
Ability: Justified  
Tera Type: &
EVs: 32 HP / 252 Atk / 56 SpD / 168 Spe  
Adamant Nature  
- Swords Dance  
- Leaf Blade  
- Close Combat  
- Quick Attack  

";
$been4265 = "Metagross @ Choice Scarf  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 188 SpD / 68 Spe  
Careful Nature  
- Meteor Mash  
- Rest  
- Cosmic Power  
- Trick  

";
$been4275 = "Gardevoir @ Gardevoirite  
Ability: Trace  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Protect  
- Disable  
- Pain Split  
- Hyper Voice  

";
$been4287 = "Urshifu @ Covert Cloak  
Ability: Unseen Fist  
Tera Type: &
EVs: 240 Atk / 28 SpD / 240 Spe  
Jolly Nature  
- Swords Dance  
- Throat Chop  
- Drain Punch  
- Trailblaze  

";
$been4297 = "Urshifu @ Choice Band  
Ability: Unseen Fist  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Assurance  
- Low Sweep  
- Ice Punch  
- Tera Blast  

";
$been4307 = "Snorlax @ Toxic Orb  
Ability: Immunity  
Tera Type: &
EVs: 48 Atk / 184 Def / 32 SpD / 244 Spe  
Jolly Nature  
- Fling  
- Return  
- Fire Punch  
- Rest  

";
$been4317 = "Minior @ Heavy-Duty Boots  
Ability: Shields Down  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
- U-turn  
- Endeavor  
- Scorching Sands  
- Power Gem  

";
$been4327 = "Claydol @ Weakness Policy  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 16 Def / 64 SpA / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Cosmic Power  
- Stored Power  
- Earth Power  
- Rest  

";
$been4338 = "Garganacl @ Maranga Berry  
Ability: Purifying Salt  
Tera Type: &
EVs: 248 HP / 20 Def / 236 SpD / 4 Spe  
Careful Nature  
- Salt Cure  
- Earthquake  
- Curse  
- Recover  

";
$been4348 = "Manaphy @ Mental Herb  
Ability: Hydration  
Tera Type: &
EVs: 248 HP / 244 SpA / 16 Spe  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Ice Beam  
- Substitute  
- Tail Glow  

";
$been4359 = "Clefairy @ Fairium Z  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Charm  
- Soft-Boiled  
- Moonblast  
- Protect  

";
$been4370 = "Ninetales @ Heavy-Duty Boots  
Ability: Drought  
Tera Type: &
EVs: 152 Atk / 140 SpA / 216 Spe  
Hasty Nature  
- Flare Blitz  
- Laser Focus  
- Overheat  
- Substitute  

";
$been4380 = "Ninetales @ Fire Gem  
Ability: Drought  
Tera Type: &
EVs: 152 Atk / 140 SpA / 216 Spe  
Hasty Nature  
- Flare Blitz  
- Laser Focus  
- Overheat  
- Substitute  

";
$been4390 = "Ninetales @ Berserk Gene  
Ability: Drought  
Tera Type: &
EVs: 152 Atk / 140 SpA / 216 Spe  
Hasty Nature  
- Flare Blitz  
- Laser Focus  
- Overheat  
- Substitute  

";
$been4400 = "Rotom-Frost @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Charge Beam  
- Blizzard  
- Substitute  
- Protect  

";
$been4411 = "Mesprit @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Ice Beam  
- Charge Beam  
- Substitute  

";
$been4422 = "Noibat @ Haban Berry  
Ability: Frisk  
Tera Type: &
EVs: 28 HP / 252 Atk / 228 Spe  
Adamant Nature  
- Switcheroo  
- Outrage  
- Protect  
- Agility  

";
$been4432 = "Feraligatr @ Clear Amulet  
Ability: Torrent  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Liquidation  
- Psychic Fangs  
- Trailblaze  
- Swords Dance  

";
$been4442 = "Uxie @ Colbur Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
- Drain Punch  
- Thunder Wave  
- Encore  
- U-turn  

";
$been4452 = "Goodra @ Choice Scarf  
Ability: Sap Sipper  
Tera Type: &
EVs: 24 HP / 252 SpA / 232 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Fire Blast  
- Surf  
- Dragon Pulse  

";
$been4463 = "Brambleghast @ Heavy-Duty Boots  
Ability: Wind Rider  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Poltergeist  
- Leech Seed  
- Spikes  
- Rapid Spin  

";
$been4473 = "Kilowattrel @ Chilan Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 16 Def / 252 SpA / 240 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hurricane  
- Charge Beam  
- Substitute  

";
$been4484 = "Revavroom @ Eject Pack  
Ability: Filter  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Gunk Shot  
- High Horsepower  
- Overheat  
- Thief  

";
$been4494 = "Pecharunt @ Air Balloon  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 176 HP / 80 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Malignant Chain  
- Defense Curl  
- Recover  
- Parting Shot  



";
$been4507 = "Gholdengo @ Lum Berry  
Ability: Good as Gold  
Tera Type: &
EVs: 100 HP / 100 Def / 100 SpA / 208 Spe  
Timid Nature  
- Hex  
- Light Screen  
- Fling  
- Thunder Wave  

";
$been4517 = "Iron Leaves @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Leaf Blade  
- Close Combat  
- Swords Dance  
- Protect  

";
$been4527 = "Armarouge @ Power Herb  
Ability: Weak Armor  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Armor Cannon  
- Psychic  
- Meteor Beam  
- Protect  

";
$been4538 = "Kangaskhan (F) @ Kangaskhanite  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Headbutt  
- Sucker Punch  
- Mud-Slap  
- Substitute  

";
$been4548 = "Kangaskhan (F) @ Kangaskhanite  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Return  
- Mud-Slap  
- Protect  
- Substitute  

";
$been4558 = "Kommo-o @ Coba Berry  
Ability: Bulletproof  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Close Combat  
- Toxic  
- Stealth Rock  
- Roar  

";
$been4568 = "Dunsparce @ Eviolite  
Ability: Serene Grace  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 100 SpA / 160 SpD  
Calm Nature  
IVs: 0 Atk  
- Calm Mind  
- Roost  
- Stealth Rock  
- Hyper Voice  

";
$been4580 = "Snorlax @ Dark Gem  
Ability: Immunity  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Giga Impact  
- Protect  
- Pursuit  
- Sweet Kiss  

";
$been4590 = "Wyrdeer @ Eject Pack  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Psychic Noise  
- Thunderbolt  
- Skill Swap  
- Protect  

";
$been4601 = "Shroodle @ Eviolite  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Foul Play  
- Toxic  
- Baton Pass  
- Protect  

";
$been4612 = "Fezandipiti (M) @ Black Sludge  
Ability: Toxic Chain  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 172 SpA / 84 SpD  
Jolly Nature  
- Tail Slap  
- Moonblast  
- Roost  
- Protect  

";
$been4622 = "Fezandipiti (M) @ Loaded Dice  
Ability: Toxic Chain  
Tera Type: &
EVs: 84 HP / 84 Atk / 84 Def / 172 SpA / 84 SpD  
Jolly Nature  
- Tail Slap  
- Moonblast  
- Roost  
- Protect  

";
$been4632 = "Blissey (F) @ Iron Ball  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Seismic Toss  
- Trick  
- Soft-Boiled  
- Teleport  

";
$been4643 = "Golem-Alola @ Choice Band  
Ability: Galvanize  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Giga Impact  
- Flail  
- Tackle  
- Dig  

";
$been4653 = "Gouging Fire @ Maranga Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Adamant Nature  
- Flare Blitz  
- Outrage  
- Thunder Fang  
- Morning Sun  

";
$been4663 = "Iron Valiant @ Roseli Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 180 HP / 104 Atk / 116 SpD / 108 Spe  
Adamant Nature  
- Close Combat  
- Spirit Break  
- Poison Jab  
- Moonblast  

";
$been4673 = "Iron Valiant @ Weakness Policy  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Reflect  
- Encore  
- Spirit Break  
- Close Combat  

";
$been4683 = "Kangaskhan (F) @ Kangaskhanite  
Ability: Scrappy  
Tera Type: &
EVs: 200 HP / 156 Def / 152 Spe  
Impish Nature  
- Wish  
- Protect  
- Headbutt  
- Body Slam  

";
$been4693 = "Landorus-Therian @ Red Card  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Stealth Rock  
- Earthquake  
- U-turn  
- Taunt  

";
$been4703 = "Iron Crown @ Choice Scarf  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Tachyon Cutter  
- Psychic  
- Focus Blast  
- Volt Switch  

";
$been4714 = "Mismagius @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Draining Kiss  
- Substitute  
- Nasty Plot  

";
$been4725 = "Garchomp @ Life Orb  
Ability: Rough Skin  
Tera Type: &
EVs: 32 HP / 252 SpA / 224 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Surf  
- Toxic  
- Spikes  

";
$been4736 = "Cofagrigus @ Leftovers  
Ability: Mummy  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Phantom Force  
- Toxic  
- Substitute  
- Protect  

";
$been4746 = "Hoopa-Unbound @ Choice Band  
Ability: Magician  
Tera Type: &
EVs: 252 Atk / 216 SpA / 40 Spe  
Naughty Nature  
- Phantom Force  
- Facade  
- Future Sight  
- Hidden Power [Flying]  



";
$been4758 = "Iron Crown @ Weakness Policy  
Ability: Quark Drive  
Tera Type: &
EVs: 16 SpA / 240 SpD / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Tachyon Cutter  
- Psychic  
- Calm Mind  
- Iron Defense  

";
$been4769 = "Jirachi @ Weakness Policy  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
- Iron Head  
- Fire Punch  
- Wish  
- Protect  

";
$been4779 = "Articuno @ Weakness Policy  
Ability: Snow Cloak  
Tera Type: &
EVs: 112 HP / 144 Def / 252 SpA  
Relaxed Nature  
- Freeze-Dry  
- Air Slash  
- U-turn  
- Agility  

";
$been4789 = "Hydrapple @ Weakness Policy  
Ability: Sticky Hold  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Giga Drain  
- Fickle Beam  
- Protect  
- Substitute  

";
$been4800 = "Grafaiai @ Assault Vest  
Ability: Poison Touch  
Tera Type: &
EVs: 248 HP / 156 Atk / 24 SpD / 68 Spe  
Jolly Nature  
- Gunk Shot  
- Knock Off  
- Double-Edge  
- U-turn  

";
$been4810 = "Breloom @ Toxic Orb  
Ability: Poison Heal  
Tera Type: &
EVs: 88 HP / 108 Atk / 52 Def / 8 SpD / 252 Spe  
Adamant Nature  
- Low Kick  
- Refresh  
- Protect  
- Bulk Up  

";
$been4820 = "Flareon @ Toxic Orb  
Ability: Guts  
Tera Type: &
EVs: 112 HP / 252 Atk / 4 SpD / 140 Spe  
Adamant Nature  
- Flare Blitz  
- Facade  
- Heal Bell  
- Quick Attack  

";
$been4830 = "Volcanion @ Maranga Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Flamethrower  
- Steam Eruption  
- Sleep Talk  
- Rest  

";
$been4841 = "Iron Crown @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 96 HP / 252 SpA / 160 Spe  
Modest Nature  
- Tachyon Cutter  
- Body Slam  
- Substitute  
- Protect  

";
$been4851 = "Hydrapple @ Heavy-Duty Boots  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Relaxed Nature  
- Giga Drain  
- Grassy Terrain  
- Dragon Tail  
- Protect  

";
$been4861 = "Hydrapple @ Choice Band  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Dragon Tail  
- Sleep Talk  

";
$been4869 = "Pangoro @ Choice Band  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Circle Throw  
- Knock Off  
- Sleep Talk  

";
$been4878 = "Pangoro @ Fightinium Z  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Circle Throw  
- Sleep Talk  
- Rest  
- Bulk Up  

";
$been4888 = "Finizen @ Wise Glasses  
Ability: Water Veil  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Boomburst  
- Icy Wind  
- Protect  

";
$been4899 = "Paras @ Eviolite  
Ability: Dry Skin  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Knock Off  
- Leech Seed  
- Substitute  
- Spore  

";
$been4909 = "Paras @ Eviolite  
Ability: Dry Skin  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Leech Life  
- Leech Seed  
- Spore  
- Aromatherapy  

";
$been4919 = "Paras @ Choice Band  
Ability: Damp  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Leech Life  
- Knock Off  
- Pursuit  
- Seed Bomb  

";
$been4929 = "Paras @ Heavy-Duty Boots  
Ability: Dry Skin  
Tera Type: &
EVs: 252 HP / 4 Atk / 212 SpD / 40 Spe  
Careful Nature  
- Knock Off  
- Aromatherapy  
- Spore  
- Protect  

";
$been4939 = "Tangela @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 212 HP / 88 Def / 84 SpA / 124 Spe  
Lax Nature  
- Leaf Storm  
- Knock Off  
- Headbutt  
- Stun Spore  

";
$been4949 = "Porygon-Z @ Leftovers  
Ability: Adaptability  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Headbutt  
- Iron Tail  
- Substitute  
- Thunder Wave  

";
$been4959 = "Dragonite @ Leftovers  
Ability: Multiscale  
Tera Type: &
EVs: 140 HP / 220 Atk / 148 Spe  
Adamant Nature  
- Headbutt  
- Thunder Wave  
- Substitute  
- Dragon Dance  

";
$been4969 = "Garganacl @ Passho Berry  
Ability: Purifying Salt  
Tera Type: &
EVs: 196 HP / 36 Atk / 232 SpD / 44 Spe  
Jolly Nature  
- Salt Cure  
- Earthquake  
- Recover  
- Curse  

";
$been4979 = "Phione @ Waterium Z  
Ability: Hydration  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Ice Beam  
- Alluring Voice  
- Take Heart  

";
$been4990 = "Rotom-Wash @ Waterium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Thunderbolt  
- Protect  
- Nasty Plot  



";
$been41003 = "Arbok @ Metronome  
Ability: Shed Skin  
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe  
Adamant Nature  
- Headbutt  
- Glare  
- Substitute  
- Gunk Shot  

";
$been41013 = "Roaring Moon @ Throat Spray  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpA  
Lonely Nature  
- Knock Off  
- Roar  
- Draco Meteor  
- Protect  

";
$been41023 = "Kyurem-Black @ Throat Spray  
Ability: Teravolt  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Earth Power  
- Roar  
- Protect  

";
$been41034 = "Kyurem-Black @ Throat Spray  
Ability: Teravolt  
Tera Type: &
EVs: 160 Atk / 252 SpA / 96 Spe  
Mild Nature  
- Draco Meteor  
- Icicle Spear  
- Roar  
- Dragon Dance  

";
$been41044 = "Kyurem-Black @ Throat Spray  
Ability: Teravolt  
Tera Type: &
EVs: 160 Atk / 252 SpA / 96 Spe  
Mild Nature  
- Draco Meteor  
- Fusion Bolt  
- Roar  
- Dragon Dance  

";
$been41054 = "Glaceon @ Throat Spray  
Ability: Snow Cloak  
Tera Type: &
EVs: 236 HP / 80 Def / 176 SpA / 16 Spe  
Modest Nature  
IVs: 0 Atk  
- Ice Beam  
- Alluring Voice  
- Wish  
- Protect  

";
$been41065 = "Moltres-Galar @ Throat Spray  
Ability: Berserk  
Tera Type: &
EVs: 28 HP / 252 SpA / 4 SpD / 224 Spe  
Modest Nature  
IVs: 0 Atk  
- Fiery Wrath  
- Air Slash  
- Hyper Voice  
- Agility  

";
$been41076 = "Mew @ Throat Spray  
Ability: Synchronize  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hyper Beam  
- Hyper Voice  
- Hypnosis  
- Soft-Boiled  

";
$been41087 = "Mew @ Fightinium Z  
Ability: Synchronize  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Giga Impact  
- Protect  
- Detect  
- Swords Dance  

";
$been41097 = "Mew @ Throat Spray  
Ability: Synchronize  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Thunder  
- Alluring Voice  
- Meteor Beam  

";
$been41108 = "Flamigo @ Leftovers  
Ability: Scrappy  
Tera Type: &
EVs: 44 HP / 136 Atk / 76 SpD / 252 Spe  
Naughty Nature  
- Close Combat  
- Wide Guard  
- Detect  
- Protect  

";
$been41118 = "Primarina @ Throat Spray  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Hydro Pump  
- Moonblast  
- Ice Beam  
- Perish Song  

";
$been41129 = "Togekiss @ Throat Spray  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 100 SpA / 156 SpD  
Calm Nature  
IVs: 0 Atk  
- Air Slash  
- Growl  
- Thunder Wave  
- Roost  

";
$been41140 = "Charizard @ Throat Spray  
Ability: Blaze  
Tera Type: &
EVs: 64 HP / 188 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Fire Blast  
- Hidden Power [Ice]  
- Growl  
- Roost  

";
$been41151 = "Mew @ Throat Spray  
Ability: Synchronize  
Tera Type: &
EVs: 68 HP / 40 Def / 208 SpA / 4 SpD / 188 Spe  
Modest Nature  
IVs: 0 Atk  
- Flamethrower  
- Ice Beam  
- Heal Bell  
- Soft-Boiled  

";
$been41162 = "Magnezone @ Throat Spray  
Ability: Analytic  
Tera Type: &
EVs: 136 HP / 52 Def / 60 SpA / 112 SpD / 148 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hidden Power [Fire]  
- Supersonic  
- Protect  

";
$been41173 = "Rillaboom @ Normalium Z  
Ability: Grassy Surge  
Tera Type: &
EVs: 16 HP / 240 Def / 252 Spe  
Jolly Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Body Press  
- Growl  

";
$been41184 = "Lilligant (F) @ Electric Seed  
Ability: Own Tempo  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Grass Knot  
- Hidden Power [Fire]  
- Synthesis  
- Quiver Dance  

";
$been41195 = "Pokestar Monster @ Metronome  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Confusion  

";
$been41204 = "Pokestar Monster @ Darkinium Z  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Confusion  

";
$been41213 = "Pokestar Monster @ Choice Specs  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Confusion  

";
$been41222 = "Clodsire @ Icium Z  
Ability: Poison Point  
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 52 SpD / 156 Spe  
Sassy Nature  
- Dig  
- Toxic  
- Haze  
- Recover  

";
$been41232 = "Genesect @ Throat Spray  
Ability: Download  
Tera Type: &
EVs: 10 HP / 10 Atk / 215 Def / 11 SpA / 252 SpD / 10 Spe  
IVs: 8 HP / 12 Atk / 7 Def / 30 SpA / 8 SpD  
- Bug Buzz  
- Flash Cannon  
- Flamethrower  
- Ice Beam  

";
$been41242 = "Hydreigon @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 100 HP / 100 Atk / 84 Def / 100 SpA / 84 SpD / 40 Spe  
IVs: 22 Def  
- Headbutt  
- Thunder Wave  
- Draco Meteor  
- Roost  

";
$been41254 = "Iron Valiant @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Moonblast  
- Focus Blast  
- Thunderbolt  
- Calm Mind  

";
$been41265 = "Kingambit @ Wiki Berry  
Ability: Defiant  
Happiness: 0  
Tera Type: &
EVs: 67 HP / 67 Atk / 67 Def / 67 SpA / 67 SpD / 67 Spe  
Adamant Nature  
IVs: 8 HP / 8 Def / 8 SpA / 8 SpD / 8 Spe  
- Frustration  
- Flash Cannon  
- Focus Blast  
- Foul Play  

";

$ihatesice123 = "Tapu Koko @ Flame Orb
Ability: Electric Surge
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Jolly Nature
- Facade
- Volt Switch
- Nature's Madness
- Roost

";

$bf43 = "Houndoom @ Heavy-Duty Boots  
Ability: Flash Fire  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flamethrower  
- Dark Pulse  
- Sludge Bomb  
- Will-O-Wisp  

";
$bf414 = "Houndoom @ Firium Z  
Ability: Flash Fire  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Overheat  
- Dark Pulse  
- Sludge Bomb  
- Nasty Plot  

";
$bf425 = "Zoroark @ Heavy-Duty Boots  
Ability: Illusion  
Tera Type: &
EVs: 76 Atk / 180 SpA / 252 Spe  
Hasty Nature  
- Dark Pulse  
- Encore  
- Sucker Punch  
- Focus Blast  

";
$bf435 = "Latias (F) @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 184 Atk / 52 Def / 52 SpA / 220 SpD  
Mild Nature  
IVs: 21 HP / 28 Atk / 21 Def / 28 SpD / 21 Spe  
- Mist Ball  
- Mystical Fire  
- Sucker Punch  
- Dragon Dance  

";
$bf446 = "Magnezone @ Chesto Berry  
Ability: Magnet Pull  
Tera Type: &
EVs: 68 HP / 252 Atk / 188 Spe  
Adamant Nature  
- Iron Head  
- Thunder Wave  
- Rest  
- Iron Defense  

";
$bf456 = "Magnezone @ Metronome  
Ability: Magnet Pull  
Tera Type: &
EVs: 68 HP / 252 Atk / 188 Spe  
Naughty Nature  
- Iron Head  
- Thunder Wave  
- Thunder  
- Protect  

";
$bf466 = "Iron Treads @ Buginium Z  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- High Horsepower  
- Megahorn  
- Volt Switch  
- Rapid Spin  

";
$bf476 = "Iron Crown @ Mirror Herb  
Ability: Quark Drive  
Tera Type: &
EVs: 192 HP / 60 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Tachyon Cutter  
- Psychic  
- Tera Blast  
- Protect  

";
$bf487 = "Magneton @ Salac Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Charge Beam  
- Thunderbolt  
- Flash Cannon  

";
$bf498 = "Espeon @ Grassy Seed  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Morning Sun  
- Stored Power  
- Dazzling Gleam  

";
$bf4109 = "Comfey @ Grassy Seed  
Ability: Triage  
Tera Type: &
EVs: 252 HP / 192 Def / 64 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Draining Kiss  
- Stored Power  
- Taunt  

";
$bf4120 = "Wishiwashi @ Leftovers  
Ability: Schooling  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Protect  
- Scald  
- Ice Beam  
- U-turn  

";
$bf4130 = "Hattrem (F) @ Eviolite  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 244 Def / 12 Spe  
Bold Nature  
IVs: 0 Atk  
- Psychic  
- Rest  
- Sleep Talk  
- Aromatherapy  

Archeops  
Ability: Defeatist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Roost  
- Acrobatics  
- Earthquake  
- U-turn  

";
$bf4151 = "Perrserker @ Leftovers  
Ability: Steely Spirit  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Substitute  
- Swords Dance  
- Iron Head  
- Seed Bomb  

";
$bf4161 = "Manectric @ Ring Target  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Switcheroo  
- Thunderbolt  
- Volt Switch  
- Flamethrower  

";
$bf4172 = "Gallade (M) @ Assault Vest  
Ability: Justified  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Close Combat  
- Psycho Cut  
- Knock Off  
- Shadow Sneak  

";
$bf4182 = "Silvally-Dragon @ Dragon Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Swords Dance  
- Multi-Attack  
- Flame Charge  
- Grass Pledge  

";
$bf4192 = "Lycanroc @ Life Orb  
Ability: Sand Rush  
Tera Type: &
EVs: 244 Atk / 12 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Stone Edge  
- Close Combat  
- Accelerock  

";
$bf4202 = "Jellicent @ Choice Specs  
Ability: Water Absorb  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Water Spout  
- Shadow Ball  
- Hydro Pump  
- Trick  

";
$bf4213 = "Poliwrath @ Choice Scarf  
Ability: Water Absorb  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Liquidation  
- Darkest Lariat  
- Toxic  

";
$bf4223 = "Silvally-Rock @ Rock Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Defog  
- Ice Beam  
- Grass Pledge  
- Flamethrower  

";
$bf4234 = "Cradily @ Leftovers  
Ability: Storm Drain  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Recover  
- Swords Dance  
- Power Whip  
- Earthquake  

";
$bf4244 = "Cramorant @ Choice Specs  
Ability: Gulp Missile  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Hurricane  
- Surf  
- Ice Beam  

";
$bf4255 = "Archeops @ Choice Specs  
Ability: Defeatist  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Air Slash  
- Earth Power  
- Heat Wave  
- Switcheroo  

";
$bf4266 = "Drifblim @ Charti Berry  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Defog  
- Will-O-Wisp  
- Hex  
- Strength Sap  

";
$bf4277 = "Emolga @ Heavy-Duty Boots  
Ability: Motor Drive  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Roost  
- Toxic  
- Air Slash  
- Taunt  

";
$bf4288 = "Altaria @ Heavy-Duty Boots  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 120 SpD / 136 Spe  
Calm Nature  
IVs: 0 Atk  
- Defog  
- Roost  
- Flamethrower  
- Toxic  

";
$bf4299 = "Linoone-Galar @ Toxic Orb  
Ability: Quick Feet  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Protect  
- Knock Off  
- Facade  
- Trick  

";
$bf4309 = "Hitmonlee (M) @ Assault Vest  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Rapid Spin  
- High Jump Kick  
- Knock Off  
- Poison Jab  

";
$bf4319 = "Lilligant (F) @ Weakness Policy  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Quiver Dance  
- Sleep Powder  
- Giga Drain  
- Nature Power  

";
$bf4330 = "Ribombee @ Heavy-Duty Boots  
Ability: Shield Dust  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Quiver Dance  
- Moonblast  
- Aromatherapy  
- Roost  

";
$bf4341 = "Poliwrath @ Leftovers  
Ability: Water Absorb  
Tera Type: &
EVs: 60 HP / 232 Atk / 216 Spe  
Adamant Nature  
- Substitute  
- Toxic  
- Liquidation  
- Drain Punch  

";
$bf4351 = "Silvally-Water @ Water Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 HP / 120 Def / 136 Spe  
Jolly Nature  
- Defog  
- Multi-Attack  
- Flamethrower  
- U-turn  

";
$bf4361 = "Gallade (M) @ Muscle Band  
Ability: Justified  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Psycho Cut  
- Knock Off  
- Leaf Blade  

";
$bf4371 = "Shuckle @ Eject Pack  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Stealth Rock  
- Sticky Web  
- Shell Smash  
- Encore  

";
$bf4382 = "Espeon @ White Herb  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 SpA / 4 SpD  
Modest Nature  
- Copycat  
- Stored Power  
- Dazzling Gleam  
- Calm Mind  

";
$bf4392 = "Silvally-Ghost @ Ghost Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Multi-Attack  
- Flame Charge  
- Explosion  

";
$bf4402 = "Sandaconda @ Leftovers  
Ability: Shed Skin  
Tera Type: &
EVs: 36 HP / 252 Atk / 220 Spe  
Jolly Nature  
- Coil  
- Earthquake  
- Stone Edge  
- Scale Shot  

";
$bf4412 = "Leafeon @ Yache Berry  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Copycat  
- Leaf Blade  
- Knock Off  
- Swords Dance  

";
$bf4422 = "Charizard @ Sitrus Berry  
Ability: Blaze  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
IVs: 30 HP  
- Belly Drum  
- Acrobatics  
- Flame Charge  
- Earthquake  

";
$bf4433 = "Weezing @ Expert Belt  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Toxic Spikes  
- Sludge Bomb  
- Fire Blast  
- Thunder  

";
$bf4444 = "Ninjask @ Choice Band  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Dual Wingbeat  
- Leech Life  
- U-turn  
- Mimic  

";
$bf4454 = "Alcremie (F) @ Grassy Seed  
Ability: Aroma Veil  
Tera Type: &
EVs: 252 HP / 112 Def / 144 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Substitute  
- Draining Kiss  
- Stored Power  

";
$bf4465 = "Ninjask @ Grassy Seed  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Acrobatics  
- Leech Life  
- Protect  

";
$bf4475 = "Hitmonlee (M) @ Grassy Seed  
Ability: Unburden  
Tera Type: &
EVs: 48 HP / 252 Atk / 208 Spe  
Adamant Nature  
- Bulk Up  
- Close Combat  
- Knock Off  
- Stone Edge  

";
$bf4485 = "Liepard @ Damp Rock  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Rain Dance  
- Encore  
- Knock Off  
- U-turn  

";
$bf4495 = "Audino @ Eject Button  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Jolly Nature  
IVs: 0 Atk  
- Reflect  
- Light Screen  
- Encore  
- Healing Wish  

";
$bf4506 = "Tsareena (F) @ Bright Powder  
Ability: Queenly Majesty  
Tera Type: &
EVs: 252 HP / 56 Atk / 200 Spe  
Adamant Nature  
- Acupressure  
- Rest  
- Knock Off  
- Power Whip  

";
$bf4516 = "Vanilluxe @ Heavy-Duty Boots  
Ability: Snow Warning  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Freeze-Dry  
- Taunt  
- Toxic  

";
$bf4527 = "Cofagrigus @ Chesto Berry  
Ability: Mummy  
Tera Type: &
EVs: 248 HP / 240 Def / 20 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Rest  
- Shadow Ball  
- Toxic  

";
$bf4538 = "Raichu @ Wise Glasses  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Rising Voltage  
- Surf  
- Focus Blast  

";
$bf4549 = "Flapple @ Metronome  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Draco Meteor  
- Grav Apple  
- Dual Wingbeat  
- Sucker Punch  

";
$bf4559 = "Silvally-Poison @ Poison Memory  
Ability: RKS System  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Work Up  
- Multi-Attack  
- Flamethrower  
- Grass Pledge  

";
$bf4569 = "Hitmontop (M) @ Muscle Band  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Fake Out  
- Mach Punch  
- Close Combat  
- Triple Axel  

";
$bf4579 = "Trevenant @ Muscle Band  
Ability: Natural Cure  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Substitute  
- Poltergeist  
- Horn Leech  
- Drain Punch  

";
$bf4589 = "Scrafty @ Roseli Berry  
Ability: Moxie  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Close Combat  
- Knock Off  
- Poison Jab  

";
$bf4599 = "Silvally-Fairy @ Fairy Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Multi-Attack  
- Flame Charge  
- Rock Slide  

";
$bf4609 = "Uxie @ Kee Berry  
Ability: Levitate  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Substitute  
- Draining Kiss  
- Stored Power  

";
$bf4620 = "Gourgeist @ Weakness Policy  
Ability: Frisk  
Tera Type: &
EVs: 152 HP / 252 Atk / 104 Spe  
Adamant Nature  
- Flame Charge  
- Power Whip  
- Poltergeist  
- Synthesis  

";
$bf4630 = "Jellicent (F) @ Rindo Berry  
Ability: Cursed Body  
Tera Type: &
EVs: 248 HP / 196 Def / 64 Spe  
Bold Nature  
IVs: 0 Atk  
- Taunt  
- Recover  
- Hex  
- Will-O-Wisp  

";
$bf4641 = "Silvally-Steel @ Steel Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 HP / 96 SpD / 160 Spe  
Jolly Nature  
- Multi-Attack  
- Flamethrower  
- Defog  
- Parting Shot  

";
$bf4651 = "Weezing @ Eject Button  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 252 HP / 192 Def / 64 Spe  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Will-O-Wisp  
- Toxic Spikes  
- Pain Split  

";
$bf4662 = "Vanilluxe @ Icium Z  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Blizzard  
- Mist  
- Acid Armor  
- Protect  

";
$bf4673 = "Vanillish @ Eviolite  
Ability: Snow Cloak  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Blizzard  
- Protect  
- Hail  
- Aurora Veil  

";
$bf4684 = "Roserade @ Life Orb  
Ability: Technician  
Tera Type: &
EVs: 184 Atk / 72 SpA / 252 Spe  
Hasty Nature  
- Bullet Seed  
- Hidden Power [Fire]  
- Sludge Bomb  
- Aromatherapy  

";
$bf4694 = "Roserade @ Metronome  
Ability: Technician  
Tera Type: &
EVs: 96 HP / 252 Atk / 160 Spe  
Adamant Nature  
- Bullet Seed  
- Leech Seed  
- Substitute  
- Protect  

";
$bf4704 = "Roserade @ Flame Orb  
Ability: Natural Cure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Giga Drain  
- Hidden Power [Fire]  
- Spikes  
- Aromatherapy  

";
$bf4715 = "Vanilluxe @ Mirror Herb  
Ability: Snow Warning  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Weather Ball  
- Freeze-Dry  
- Protect  

";
$bf4726 = "Mew @ Rockium Z  
Ability: Synchronize  
Tera Type: &
EVs: 212 HP / 168 SpA / 128 Spe  
Mild Nature  
IVs: 0 Atk  
- Weather Ball  
- Foul Play  
- Soft-Boiled  
- Sandstorm  

";
$bf4737 = "Sneasler @ Choice Band  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- Reversal  
- Night Slash  
- Endure  
- Substitute  

";
$bf4747 = "Primarina @ Salac Berry  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Ice Beam  
- Substitute  
- Calm Mind  

";
$bf4758 = "Typhlosion @ Petaya Berry  
Ability: Blaze  
Tera Type: &
EVs: 248 HP / 200 Def / 28 SpA / 32 Spe  
Lax Nature  
- Reversal  
- Substitute  
- Blast Burn  
- Defense Curl  

";
$bf4768 = "Rhyperior @ Custap Berry  
Ability: Solid Rock  
Tera Type: &
EVs: 236 HP / 20 Atk / 252 SpD  
Sassy Nature  
- Earthquake  
- Rock Wrecker  
- Endure  
- Swords Dance  

";
$bf4778 = "Zapdos @ Kee Berry  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Hurricane  
- Toxic  
- Reflect  
- Roost  

";
$bf4789 = "Gengar @ Choice Specs  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Icy Wind  
- Encore  
- Disable  
- Trick  

";
$bf4800 = "Gengar @ Icium Z  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Icy Wind  
- Substitute  
- Encore  

";
$bf4811 = "Suicune @ Kee Berry  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Reflect  
- Rest  
- Scald  
- Calm Mind  

";
$bf4822 = "Simipour @ Fightinium Z  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Focus Blast  
- Grass Knot  
- Nasty Plot  

";
$bf4833 = "Jellicent @ Rindo Berry  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Hex  
- Will-O-Wisp  
- Recover  
- Trick  

";
$bf4844 = "Celebi @ Maranga Berry  
Ability: Natural Cure  
Tera Type: &
EVs: 16 HP / 64 SpA / 252 SpD / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Leaf Storm  
- Recover  
- Calm Mind  
- Psychic  

";
$bf4855 = "Porygon2 @ Eviolite  
Ability: Trace  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Atk  
- Ice Beam  
- Thunder  
- Trick Room  
- Recover  

";
$bf4866 = "Dugtrio (M) @ Focus Sash  
Ability: Arena Trap  
Tera Type: &
EVs: 240 HP / 16 SpD / 252 Spe  
Jolly Nature  
- Memento  
- Stealth Rock  
- Rock Tomb  
- Confide  

";
$bf4876 = "Wobbuffet (M) @ Red Card  
Ability: Shadow Tag  
Tera Type: &
EVs: 72 HP / 184 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Counter  
- Safeguard  
- Encore  
- Charm  

";
$bf4887 = "Gothitelle (M) @ Leftovers  
Ability: Shadow Tag  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Confide  
- Charm  
- Rest  
- Taunt  

";
$bf4898 = "Gothitelle (M) @ Leftovers  
Ability: Shadow Tag  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Flatter  
- Charm  
- Rest  
- Heal Pulse  

";
$bf4909 = "Gothitelle (M) @ Starf Berry  
Ability: Shadow Tag  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Fling  
- Recycle  
- Rest  
- Heal Pulse  

";
$bf4920 = "Gothitelle (M) @ Psychium Z  
Ability: Shadow Tag  
Tera Type: &
EVs: 96 HP / 24 Def / 252 SpA / 8 SpD / 128 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Substitute  
- Psych Up  
- Psychic  

";
$bf4931 = "Meloetta @ Pidgeotite  
Ability: Serene Grace  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Sing  
- Substitute  
- Hyper Voice  
- Psyshock  

";
$bf4942 = "Weavile @ Glalitite  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fake Out  
- Double-Edge  
- Ice Shard  
- Knock Off  

";
$bf4952 = "Victini @ Psychium Z  
Ability: Victory Star  
Tera Type: &
EVs: 212 HP / 148 Atk / 148 Spe  
Adamant Nature  
- V-create  
- Bolt Strike  
- Zen Headbutt  
- Light Screen  

";
$bf4962 = "Kyurem @ Petaya Berry  
Ability: Pressure  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
- Draco Meteor  
- Freeze-Dry  
- Substitute  
- Scale Shot  

";
$bf4972 = "Qwilfish-Hisui @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 88 HP / 252 Atk / 92 SpD / 76 Spe  
Adamant Nature  
- Throat Chop  
- Gunk Shot  
- Swords Dance  
- Aqua Jet  

";
$bf4982 = "Victini @ Psychium Z  
Ability: Victory Star  
Tera Type: &
EVs: 200 HP / 252 Atk / 56 Spe  
Adamant Nature  
- V-create  
- Bolt Strike  
- Light Screen  
- Celebrate  

";
$bf4992 = "Galvantula @ Heavy-Duty Boots  
Ability: Unnerve  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Energy Ball  
- Gastro Acid  
- Sticky Web  

";
$bf41003 = "Sneasler @ Covert Cloak  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Bulk Up  
- Aerial Ace  
- Quick Attack  

";
$bf41012 = "Enamorus @ Life Orb  
Ability: Contrary  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Moonblast  
- Earth Power  
- Tera Blast  
- Healing Wish  

";
$bf41022 = "Durant @ Steelium Z  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- First Impression  
- Superpower  
- Iron Head  
- Hone Claws  

";
$bf41032 = "Latias (F) @ Soul Dew  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Aura Sphere  
- Thunder Wave  
- Reflect Type  

";
$bf41043 = "Basculegion-F (F) @ Waterium Z  
Ability: Adaptability  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hex  
- Surf  
- Ice Beam  
- Shadow Ball  

";
$bf41054 = "Cyclizar @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 104 HP / 192 SpD / 212 Spe  
Jolly Nature  
- Dragon Tail  
- Knock Off  
- U-turn  
- Rapid Spin  

";
$bf41064 = "Dugtrio-Alola @ Adrenaline Orb  
Ability: Tangling Hair  
Tera Type: &
EVs: 16 HP / 252 Atk / 240 Spe  
Adamant Nature  
- Earthquake  
- Iron Head  
- Tera Blast  
- Swords Dance  

";
$bf41074 = "Bellibolt @ Weakness Policy  
Ability: Electromorphosis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Discharge  
- Hyper Voice  
- Parabolic Charge  
- Soak  

";
$bf41085 = "Perrserker @ Life Orb  
Ability: Steely Spirit  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- Fake Out  
- Iron Head  
- Helping Hand  
- Protect  

";
$bf41095 = "Meganium @ Leftovers  
Ability: Leaf Guard  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Dragon Tail  
- Reflect  
- Light Screen  
- Synthesis  

";
$bf41105 = "Moltres-Galar @ Choice Scarf  
Ability: Berserk  
Tera Type: &
EVs: 140 Def / 208 SpA / 160 Spe  
Modest Nature  
IVs: 0 Atk  
- Fiery Wrath  
- Hurricane  
- Foul Play  
- Air Slash  

";
$bf41116 = "Metagross @ Choice Band  
Ability: Clear Body  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Heavy Slam  
- Bullet Punch  
- Trick  
- Rest  

";
$bf41126 = "Carbink @ Shell Bell  
Ability: Sturdy  
Level: 1  
Tera Type: &
EVs: 1 HP / 2 Atk / 3 Def / 1 SpA / 2 SpD / 3 Spe  
Quirky Nature  
IVs: 3 HP / 1 Def / 3 SpA / 2 SpD / 1 Spe  
- Dazzling Gleam  
- Sand Tomb  
- Endeavor  
- Trick Room  

";
$bf41138 = "Kyurem @ Loaded Dice  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Icicle Spear  
- Scale Shot  
- Shadow Claw  
- Dragon Dance  

";
$bf41148 = "Drifblim @ Grassy Seed  
Ability: Unburden  
Tera Type: &
EVs: 252 Def / 40 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Strength Sap  
- Calm Mind  
- Shadow Ball  
- Tera Blast  

";
$bf41159 = "Cresselia (F) @ Covert Cloak  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Skill Swap  
- Ice Beam  
- Lunar Blessing  
- Protect  

";
$bf41170 = "Gothitelle @ Sitrus Berry  
Ability: Shadow Tag  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Sassy Nature  
- Protect  
- Fake Out  
- Heal Pulse  
- Psychic  

";
$bf41180 = "Golurk @ Light Clay  
Ability: No Guard  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Curse  
- Reflect  
- Protect  
- Dynamic Punch  

";
$bf41190 = "Bronzong @ Mental Herb  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Atk  
- Skill Swap  
- Trick Room  
- Hypnosis  
- Protect  

";
$bf41201 = "Clefable @ Safety Goggles  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Protect  
- Follow Me  
- Moonblast  
- Skill Swap  

";
$bf41212 = "Quaquaval @ Razor Claw  
Ability: Moxie  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Focus Energy  
- Aqua Step  
- Close Combat  
- Ice Spinner  

";
$bf41222 = "Moltres @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 248 HP / 232 Def / 28 Spe  
Relaxed Nature  
- Brave Bird  
- Flamethrower  
- Roar  
- Roost  

";
$bf41232 = "Xatu @ Sticky Barb  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Baton Pass  
- Roost  
- Trick  

";
$bf41243 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 24 Atk / 232 Spe  
Jolly Nature  
- Liquidation  
- Ice Punch  
- Substitute  
- Curse  

";
$bf41253 = "Feraligatr @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 24 Def / 232 Spe  
Jolly Nature  
- Liquidation  
- Ice Punch  
- Swords Dance  
- Dragon Dance  

";
$bf41263 = "Uxie @ Kasib Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
- Psychic  
- Encore  
- Thunder Wave  
- U-turn  

";
$bf41273 = "Goodra @ Roseli Berry  
Ability: Sap Sipper  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Scald  
- Fire Blast  
- Mud Shot  

";
$bf41284 = "Brambleghast @ Colbur Berry  
Ability: Wind Rider  
Tera Type: &
EVs: 252 HP / 120 Def / 136 Spe  
Jolly Nature  
- Power Whip  
- Poltergeist  
- Spikes  
- Rapid Spin  

";
$bf41294 = "Revavroom @ Rocky Helmet  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Spin Out  
- Gunk Shot  
- Temper Flare  
- Parting Shot  

";
$bf41304 = "Cacturne @ Black Glasses  
Ability: Water Absorb  
Tera Type: &
EVs: 136 HP / 252 Atk / 120 Spe  
Adamant Nature  
- Knock Off  
- Sucker Punch  
- Drain Punch  
- Swords Dance  

";
$bf41314 = "Necrozma @ Life Orb  
Ability: Prism Armor  
Tera Type: &
EVs: 80 Atk / 176 SpA / 252 Spe  
Rash Nature  
- Photon Geyser  
- Hyper Beam  
- Brick Break  
- Dragon Dance  

";
$bf41324 = "Heatran @ Weakness Policy  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Eruption  
- Flash Cannon  
- Solar Beam  
- Sunny Day  

";
$bf41335 = "Eiscue @ Petaya Berry  
Ability: Ice Face  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Soak  
- Freeze-Dry  
- Whirlpool  
- Substitute  

";
$bf41346 = "Eiscue @ Leftovers  
Ability: Ice Face  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Whirlpool  
- Snowscape  
- Hail  

";
$bf41357 = "Rillaboom @ Protective Pads  
Ability: Grassy Surge  
Tera Type: &
EVs: 232 HP / 252 Atk / 24 Spe  
Adamant Nature  
- Wood Hammer  
- Grassy Glide  
- Knock Off  
- U-turn  

Cutiefly  
Ability: Shield Dust  
Tera Type: &
EVs: 44 HP / 148 Atk / 252 SpD / 64 Spe  
Jolly Nature  
- Acrobatics  
- Protect  
- Stun Spore  
- Pounce  

";
$bf41377 = "Dachsbun @ Leppa Berry  
Ability: Aroma Veil  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Snarl  
- Growl  
- Baton Pass  
- Rest  

";
$bf41388 = "Enamorus (F) @ Choice Band  
Ability: Cute Charm  
Tera Type: &
EVs: 252 Atk / 252 Spe  
Jolly Nature  
- Iron Head  

";
$bf41395 = "Nymble @ Eviolite  
Ability: Swarm  
Tera Type: &
EVs: 252 HP / 236 SpA / 16 SpD / 4 Spe  
Quiet Nature  
- Bug Buzz  
- Sucker Punch  
- Substitute  
- Pounce  

";
$bf41405 = "Tatsugiri @ Haban Berry  
Ability: Commander  
Tera Type: &
EVs: 220 Atk / 36 Def / 252 Spe  
Jolly Nature  
- Outrage  

";
$bf41412 = "Zapdos @ Mental Herb  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 24 SpA / 140 SpD / 96 Spe  
Timid Nature  
- Thunderbolt  
- Toxic  
- Eerie Impulse  
- Roost  

";
$bf41422 = "Metagross @ Metronome  
Ability: Light Metal  
Tera Type: &
EVs: 248 HP / 84 Atk / 176 Def  
Impish Nature  
- Meteor Mash  
- Earthquake  
- Bullet Punch  
- Power-Up Punch  

";
$bf41432 = "Metagross @ Choice Band  
Ability: Light Metal  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Heavy Slam  
- Pursuit  
- Power-Up Punch  
- Trick  

";
$bf41442 = "Sneasler @ White Herb  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dire Claw  
- Low Kick  
- Shadow Claw  
- Bulk Up  

";
$bf41452 = "Haunter @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Protect  
- Encore  
- Disable  
- Shadow Ball  

";
$bf41463 = "Graveler-Alola @ Custap Berry  
Ability: Galvanize  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Endure  
- Flail  
- Stone Edge  
- Charge  

";
$bf41473 = "Diancie @ Custap Berry  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Stored Power  
- Endure  
- Rest  
- Calm Mind  

";
$bf41484 = "Rillaboom @ Miracle Seed  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 HP / 124 Atk / 76 SpD  
Adamant Nature  
- Fake Out  
- Wood Hammer  
- Grassy Glide  
- High Horsepower  

";
$bf41494 = "Hatterene @ Light Clay  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Heal Pulse  
- Trick Room  
- Expanding Force  
- Protect  

";
$bf41505 = "Magearna @ Fairium Z  
Ability: Soul-Heart  
Tera Type: &
EVs: 236 HP / 252 SpA / 20 Spe  
Modest Nature  
IVs: 0 Atk  
- Fleur Cannon  
- Thunder Wave  
- Heart Swap  
- Calm Mind  

";
$bf41516 = "Magearna @ Psychium Z  
Ability: Soul-Heart  
Tera Type: &
EVs: 248 HP / 80 SpA / 180 SpD  
Calm Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Pain Split  
- Substitute  
- Heart Swap  

";
$bf41527 = "Celesteela @ Leftovers  
Ability: Beast Boost  
Tera Type: &
EVs: 232 HP / 24 Def / 252 SpD  
Bold Nature  
IVs: 0 Atk  
- Leech Seed  
- Protect  
- Substitute  
- Autotomize  

";
$bf41538 = "Hoopa-Unbound @ Assault Vest  
Ability: Magician  
Tera Type: &
EVs: 252 HP / 8 Atk / 200 Def / 32 SpD / 16 Spe  
Careful Nature  
- Hyperspace Fury  
- Zen Headbutt  
- Gunk Shot  
- Dark Pulse  

";
$bf41548 = "Sylveon @ Fairy Feather  
Ability: Pixilate  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def  
Adamant Nature  
- Curse  
- Double-Edge  
- Quick Attack  
- Tera Blast  

";
$bf41558 = "Swampert @ Swampertite  
Ability: Torrent  
Tera Type: &
EVs: 32 HP / 252 Atk / 8 SpD / 216 Spe  
Adamant Nature  
- Earthquake  
- Waterfall  
- Substitute  
- Endure  

";
$bf41568 = "Charizard @ Life Orb  
Ability: Blaze  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Air Slash  
- Hurricane  
- Blast Burn  

";
$bf41579 = "Ursaluna-Bloodmoon (M) @ Custap Berry  
Ability: Mind's Eye  
Tera Type: &
EVs: 176 HP / 252 SpA / 80 Spe  
Modest Nature  
IVs: 0 Atk  
- Blood Moon  
- Earth Power  
- Moonlight  
- Taunt  

";
$bf41590 = "Tornadus-Therian (M) @ Heavy-Duty Boots  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 96 Atk / 32 Def / 128 Spe  
Jolly Nature  
- Superpower  
- Iron Tail  
- Defog  
- U-turn  

";
$bf41600 = "Sneasler (F) @ Black Sludge  
Ability: Poison Touch  
Tera Type: &
EVs: 8 HP / 252 Atk / 248 Spe  
Jolly Nature  
- Substitute  
- Dire Claw  
- Throat Chop  
- Close Combat  

";
$bf41610 = "Ting-Lu @ Custap Berry  
Ability: Vessel of Ruin  
Tera Type: &
EVs: 248 HP / 168 SpD / 92 Spe  
Careful Nature  
- Stealth Rock  
- Ruination  
- Spikes  
- Earthquake  

";
$bf41620 = "Tatsugiri (F) @ Custap Berry  
Ability: Storm Drain  
Tera Type: &
EVs: 212 Def / 252 SpA / 44 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Surf  
- Draco Meteor  
- Endure  

";
$bf41631 = "Drifblim (F) @ Sitrus Berry  
Ability: Unburden  
Tera Type: &
EVs: 12 HP / 212 Def / 88 SpA / 152 SpD / 44 Spe  
Modest Nature  
- Strength Sap  
- Will-O-Wisp  
- Shadow Ball  
- Knock Off  

";
$bf41641 = "Dragonite (F) @ Expert Belt  
Ability: Multiscale  
Tera Type: &
EVs: 88 HP / 252 Atk / 168 Spe  
Adamant Nature  
- Ice Spinner  
- Extreme Speed  
- Earthquake  
- Low Kick  

";
$bf41651 = "Volbeat @ Focus Sash  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Tailwind  
- Encore  
- Protect  
- Thunder Wave  

";
$bf41662 = "Samurott @ Clear Amulet  
Ability: Torrent  
Tera Type: &
EVs: 228 HP / 164 Atk / 28 Def / 60 SpD / 28 Spe  
Adamant Nature  
- Liquidation  
- Megahorn  
- Aqua Jet  
- Swords Dance  

";
$bf41672 = "Landorus-Therian @ Mental Herb  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 68 Atk / 4 Def / 12 SpD / 172 Spe  
Jolly Nature  
- Earthquake  
- Stomping Tantrum  
- Swords Dance  
- Protect  

";
$bf41682 = "Shiftry @ Life Orb  
Ability: Wind Rider  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Leaf Blade  
- Knock Off  
- Sucker Punch  
- Protect  

";
$bf41692 = "Hariyama @ Clear Amulet  
Ability: Guts  
Tera Type: &
EVs: 4 HP / 244 Atk / 4 Def / 68 SpD / 188 Spe  
Jolly Nature  
- Drain Punch  
- Heavy Slam  
- Fake Out  
- Protect  

";
$bf41702 = "Glimmet @ Power Herb  
Ability: Toxic Debris  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Meteor Beam  
- Sludge Bomb  
- Power Gem  
- Protect  

";
$bf41713 = "Sneasler @ Leftovers  
Ability: Poison Touch  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Jolly Nature  
- Quick Attack  
- Protect  
- Substitute  
- Swords Dance  

";
$bf41723 = "Golem-Alola @ Power Herb  
Ability: Galvanize  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Meteor Beam  
- Tera Blast  
- Hyper Beam  
- Substitute  

";
$bf41733 = "Garchomp @ Leftovers  
Ability: Rough Skin  
Tera Type: &
EVs: 56 HP / 252 Atk / 200 Spe  
Jolly Nature  
- Swords Dance  
- Earthquake  
- Stone Edge  
- Scale Shot  

";
$bf41743 = "Ogerpon (F) @ Protective Pads  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Ivy Cudgel  
- Synthesis  
- U-turn  

";
$bf41753 = "Arcanine-Hisui @ Choice Scarf  
Ability: Rock Head  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Head Smash  
- Flare Blitz  
- Close Combat  
- Stone Edge  

";
$bf41763 = "Thundurus (M) @ Heavy-Duty Boots  
Ability: Prankster  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Grass Knot  
- Taunt  
- Sludge Wave  

";
$bf41774 = "Quaquaval @ Eject Pack  
Ability: Moxie  
Tera Type: &
EVs: 248 HP / 200 Def / 60 Spe  
Impish Nature  
- Rapid Spin  
- Close Combat  
- Roost  
- Ice Spinner  

";
$bf41784 = "Bronzong @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
- Stealth Rock  
- Heavy Slam  
- Body Press  
- Iron Defense  

";

$swerve43 = "Ninetales-Alola @ Fairy Gem  
Ability: Snow Cloak  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Blizzard  
- Moonblast  
- Freeze-Dry  

";
$swerve414 = "Pupitar @ Choice Scarf  
Ability: Shed Skin  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Rock Slide  
- Earthquake  
- Outrage  
- Superpower  

";
$swerve424 = "Togedemaru @ Liechi Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 20 Def / 236 Spe  
Adamant Nature  
- Substitute  
- Nuzzle  
- Reversal  
- Zing Zap  

";
$swerve434 = "Nincada @ Eviolite  
Ability: Compound Eyes  
Tera Type: &
EVs: 252 HP / 252 Def  
Impish Nature  
- Dig  
- Toxic  
- Giga Drain  
- Leech Life  

";
$swerve444 = "Pyukumuku @ Sitrus Berry  
Ability: Unaware  
Tera Type: &
EVs: 248 HP / 104 Def / 156 SpD  
Bold Nature  
- Taunt  
- Bide  
- Recover  
- Toxic  

";
$swerve454 = "Pokestar Smeargle @ Salac Berry  
Ability: Own Tempo  
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spore  
- Imprison  
- Transform  
- Endure  

";
$swerve465 = "Poliwrath @ Choice Band  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Dig  
- Dive  
- Focus Punch  
- Counter  

";
$swerve475 = "Smeargle @ Chople Berry  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Freeze Shock  
- Protect  
- Transform  
- Counter  

";
$swerve485 = "Weavile @ Power Herb  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fake Out  
- Assist  
- Knock Off  
- Low Kick  

";
$swerve495 = "Slaking (M) @ Leftovers  
Ability: Truant  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Careful Nature  
- Encore  
- Stomping Tantrum  
- Double-Edge  
- Rest  

";
$swerve4105 = "Toxapex @ Shuca Berry  
Ability: Limber  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Iron Defense  
- Recover  
- Scald  
- Toxic  

";
$swerve4116 = "Togedemaru @ Steel Gem  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 28 Def / 228 Spe  
Adamant Nature  
- Nuzzle  
- Iron Head  
- Substitute  
- Encore  

";
$swerve4126 = "Shuckle @ Leftovers  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Atk / 224 Def / 28 SpD  
Sassy Nature  
- Acupressure  
- Infestation  
- Rest  
- Rock Blast  

";
$swerve4136 = "Tapu Lele @ Psychium Z  
Ability: Psychic Surge  
Tera Type: &
EVs: 248 HP / 68 SpA / 192 SpD  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Hidden Power [Rock]  
- Calm Mind  
- Magic Coat  

";
$swerve4147 = "Scrafty @ Figy Berry  
Ability: Shed Skin  
Tera Type: &
EVs: 248 HP / 92 Atk / 148 Def / 20 Spe  
Impish Nature  
- High Jump Kick  
- Knock Off  
- Bulk Up  
- Rest  

";
$swerve4157 = "Sceptile @ Sceptilite  
Ability: Overgrow
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Rash Nature  
IVs: 30 Atk  
- Hidden Power [Ice]  
- Frenzy Plant  
- Substitute  
- Bullet Seed  

";
$swerve4168 = "Thundurus @ Flying Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Fly  
- Thunder Punch  
- Bulk Up  
- Substitute  

";
$swerve4178 = "Riolu (M) @ Eviolite  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Serious Nature  
IVs: 0 Atk  
- Iron Defense  
- Substitute  
- Toxic  
- Rest  

";
$swerve4189 = "Primarina @ Fairy Gem  
Ability: Torrent  
Tera Type: &
EVs: 244 HP / 252 Def / 12 SpA  
Quiet Nature  
- Hydro Cannon  
- Moonblast  
- Baby-Doll Eyes  
- Aqua Jet  

";
$swerve4199 = "Stakataka @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 200 HP / 244 Atk / 64 SpD  
Brave Nature  
IVs: 0 Spe  
- Rock Blast  
- Stone Edge  
- Earthquake  
- Gyro Ball  

";
$swerve4210 = "Xurkitree @ Electric Gem  
Ability: Beast Boost  
Tera Type: &
EVs: 232 HP / 148 Def / 128 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder  
- Electroweb  
- Tail Glow  
- Charge  

";
$swerve4221 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Earthquake  
- Icicle Crash  
- Endeavor  
- Ice Shard  

";
$swerve4231 = "Simisear @ Liechi Berry  
Ability: Gluttony  
Tera Type: &
EVs: 252 Atk / 252 Spe  
Jolly Nature  
- Substitute  
- Flare Blitz  
- Rock Slide  
- Superpower  

";
$swerve4241 = "Unfezant (M) @ Aguav Berry  
Ability: Big Pecks  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
- Aerial Ace  
- Feather Dance  
- Roost  
- Taunt  

";
$swerve4251 = "Pikachu @ Pikanium Z  
Ability: Static  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Volt Tackle  
- Fake Out  
- Protect  
- Discharge  

";
$swerve4261 = "Palossand @ Iapapa Berry  
Ability: Water Compaction  
Tera Type: &
EVs: 4 HP / 252 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Iron Defense  
- Amnesia  
- Shore Up  
- Toxic  

";
$swerve4272 = "Ursaring @ Normal Gem  
Ability: Guts  
Tera Type: &
EVs: 64 Atk / 196 Def / 248 SpD  
Careful Nature  
- Laser Focus  
- Yawn  
- Protect  
- Double-Edge  

";
$swerve4282 = "Weezing @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Will-O-Wisp  
- Confide  
- Rest  
- Clear Smog  

";
$swerve4293 = "Omastar @ Rock Gem  
Ability: Weak Armor  
Shiny: Yes  
Tera Type: &
EVs: 24 HP / 252 SpA / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Shell Smash  
- Ancient Power  
- Hydro Pump  
- Earth Power  

";
$swerve4305 = "Simisage @ Petaya Berry  
Ability: Overgrow  
Shiny: Yes  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Grass Whistle  
- Nasty Plot  
- Grass Knot  

";
$swerve4317 = "Stoutland @ Normalium Z  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Work Up  
- Giga Impact  
- Crunch  
- Superpower  

";
$swerve4327 = "Delibird @ Light Ball  
Ability: Hustle  
Tera Type: &
EVs: 216 Def / 40 SpA / 252 Spe  
Timid Nature  
- Fling  
- Rest  
- Feather Dance  
- Air Slash  

";
$swerve4337 = "Heatran @ Normal Gem  
Ability: Flash Fire  
- Magma Storm  
- Taunt  
- Rock Tomb  
- Explosion  

";
$swerve4345 = "Bisharp @ Choice Scarf  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Foul Play  
- Pursuit  
- Sucker Punch  
- Stone Edge  

";
$swerve4355 = "Latios (M) @ Weakness Policy  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 100 Def / 80 SpA / 76 Spe  
Modest Nature  
- Reflect  
- Earthquake  
- Stored Power  
- Dragon Dance  

";
$swerve4365 = "Chandelure @ Air Balloon  
Ability: Flash Fire  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Timid Nature  
- Flame Charge  
- Flamethrower  
- Energy Ball  
- Hidden Power [Ground]  

";
$swerve4375 = "Vikavolt @ Quick Claw  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
- Toxic  
- Sky Drop  
- Protect  
- Roost  

";
$swerve4385 = "Snorlax @ Iapapa Berry  
Ability: Gluttony  
Tera Type: &
EVs: 192 HP / 252 Def / 64 SpD  
Impish Nature  
- Amnesia  
- Curse  
- Chip Away  
- Recycle  

";
$swerve4395 = "Ursaring @ Iapapa Berry  
Ability: Guts  
Tera Type: &
EVs: 252 HP / 124 Atk / 132 Def  
Adamant Nature  
- Yawn  
- Protect  
- Belly Drum  
- Double-Edge  

";
$swerve4405 = "Illumise (F) @ Eject Button  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 Def  
Relaxed Nature  
- Encore  
- Light Screen  
- Charm  
- U-turn  

";
$swerve4415 = "Overqwil @ Rocky Helmet  
Ability: Intimidate  
Tera Type: &
EVs: 240 HP / 16 Atk / 252 Def  
Adamant Nature  
- Barb Barrage  
- Crunch  
- Spikes  
- Pain Split  

";
$swerve4425 = "Feraligatr @ Assault Vest  
Ability: Torrent  
Tera Type: &
EVs: 248 HP / 216 Atk / 20 SpD / 24 Spe  
Adamant Nature  
- Flip Turn  
- Aqua Jet  
- Psychic Fangs  
- Ice Punch  

";
$swerve4435 = "Farigiraf @ Red Card  
Ability: Armor Tail  
Tera Type: &
EVs: 204 HP / 164 Def / 4 SpA / 108 SpD / 28 Spe  
Bold Nature  
IVs: 6 Atk  
- Foul Play  
- Psychic Noise  
- Trick Room  
- Helping Hand  

";
$swerve4446 = "Espathra @ Heavy-Duty Boots  
Ability: Speed Boost  
Tera Type: &
EVs: 24 Def / 252 SpA / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Foul Play  
- Lumina Crash  
- Dazzling Gleam  
- Substitute  

";
$swerve4457 = "Rhyperior @ Rindo Berry  
Ability: Lightning Rod  
Tera Type: &
EVs: 132 Atk / 144 Def / 232 Spe  
Jolly Nature  
- Rock Polish  
- Earthquake  
- Swords Dance  
- Body Press  

";
$swerve4467 = "Probopass @ Air Balloon  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Steel Beam  
- Earth Power  
- Stealth Rock  
- Taunt  

";
$swerve4478 = "Garchomp @ Poison Gem  
Ability: Rough Skin  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- Earthquake  
- Aqua Tail  
- Poison Jab  

";
$swerve4488 = "Haxorus (F) @ Kings Rock  
Ability: Rivalry  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fling  
- Stomping Tantrum  
- Outrage  
- Dragon Dance  

";
$swerve4498 = "Mesprit @ Eject Button  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 248 SpD / 12 Spe  
Calm Nature  
- Ice Beam  
- Toxic  
- Fire Punch  
- Healing Wish  

";
$swerve4508 = "Wo-Chien @ Miracle Seed  
Ability: Tablets of Ruin  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Giga Drain  
- Leaf Storm  
- Leech Seed  
- Protect  

";
$swerve4519 = "Garchomp @ Life Orb  
Ability: Rough Skin  
Tera Type: &
EVs: 64 HP / 252 SpA / 192 Spe  
Timid Nature  
IVs: 0 Atk  
- Stealth Rock  
- Earth Power  
- Surf  
- Draco Meteor  

";
$swerve4530 = "Crustle @ Rocky Helmet  
Ability: Shell Armor  
Shiny: Yes  
Tera Type: &
EVs: 112 HP / 212 Atk / 184 Def  
Brave Nature  
- Giga Impact  
- Counter  
- Rock Blast  
- Rock Wrecker  

";
$swerve4541 = "Torkoal @ Charcoal  
Ability: Drought  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Eruption  
- Solar Beam  
- Earth Power  
- Stealth Rock  

";
$swerve4552 = "Persian-Alola @ Rocky Helmet  
Ability: Fur Coat  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Hasty Nature  
- Fake Out  
- Parting Shot  
- Foul Play  
- Icy Wind  

";
$swerve4562 = "Whimsicott @ Choice Specs  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Moonblast  
- Energy Ball  
- Dazzling Gleam  
- Beat Up  

";
$swerve4572 = "Blacephalon @ Bright Powder  
Ability: Beast Boost  
Tera Type: &
EVs: 52 Def / 204 SpA / 252 Spe  
Timid Nature  
- Substitute  
- Pain Split  
- Mind Blown  
- Tera Blast  

";
$swerve4582 = "Iron Thorns @ Chople Berry  
Ability: Quark Drive  
Tera Type: &
EVs: 56 HP / 200 Atk / 252 Spe  
Adamant Nature  
- Dragon Dance  
- Supercell Slam  
- Rock Blast  
- Heavy Slam  

";
$swerve4592 = "Tornadus (M) @ Custap Berry  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Adamant Nature  
- Bulk Up  
- Leer  
- Substitute  
- Acrobatics  

";
$swerve4602 = "Dodrio @ Clear Amulet  
Ability: Tangled Feet  
Tera Type: &
EVs: 8 HP / 248 Def / 252 Spe  
Jolly Nature  
- Substitute  
- Uproar  
- Flail  
- Quick Attack  

";
$swerve4612 = "Conkeldurr @ Flame Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 116 HP / 160 Atk / 204 SpD / 28 Spe  
Adamant Nature  
- Hammer Arm  
- Bulk Up  
- Stone Edge  
- Earthquake  

";
$swerve4622 = "Palossand @ Light Ball  
Ability: Water Compaction  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Fling  
- Hex  
- Recycle  
- Shore Up  

";
$swerve4632 = "Kecleon @ White Herb  
Ability: Protean  
Tera Type: &
EVs: 252 HP / 140 Atk / 96 Def / 20 SpD  
Adamant Nature  
- Fling  
- Knock Off  
- Recover  
- Power-Up Punch  

";
$swerve4642 = "Happiny (F) @ White Herb  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Rest  
- Defense Curl  
- Fling  
- Seismic Toss  

";
$swerve4652 = "Klang @ Eviolite  
Ability: Plus  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Telekinesis  
- Zap Cannon  

";
$swerve4663 = "Raichu-Alola @ Electric Gem  
Ability: Surge Surfer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Telekinesis  
- Zap Cannon  
- Sing  
- Protect  

";
$swerve4674 = "Mismagius @ Iapapa Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Telekinesis  
- Zap Cannon  
- Inferno  
- Protect  

";
$swerve4685 = "Lampent @ Eviolite  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Protect  
- Pain Split  
- Telekinesis  
- Inferno  

";
$swerve4696 = "Farigiraf @ Electric Gem  
Ability: Sap Sipper  
Tera Type: &
EVs: 160 HP / 84 Def / 124 SpA / 140 Spe  
Modest Nature  
IVs: 0 Atk  
- Telekinesis  
- Zap Cannon  
- Calm Mind  
- Rest  

";
$swerve4707 = "Solrock @ Rock Gem  
Ability: Levitate  
Tera Type: &
EVs: 192 HP / 228 Atk / 76 Def / 12 Spe  
Adamant Nature  
- Telekinesis  
- Stone Edge  
- Hypnosis  
- Morning Sun  

";
$swerve4717 = "Ursaluna-Bloodmoon (M) @ Eject Button  
Ability: Mind's Eye  
Tera Type: &
EVs: 136 SpA / 124 SpD / 248 Spe  
Modest Nature  
IVs: 0 Atk  
- Blood Moon  

";
$swerve4725 = "Rhyperior @ Rindo Berry  
Ability: Lightning Rod  
Tera Type: &
EVs: 132 Atk / 144 Def / 232 Spe  
Jolly Nature  
- Rock Polish  
- Earthquake  
- Swords Dance  
- Body Press  

";
$swerve4735 = "Terrakion @ Air Balloon  
Ability: Justified  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Close Combat  
- Sacred Sword  
- Earthquake  
- Reflect  

";
$swerve4745 = "Squawkabilly-Blue @ Focus Sash  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Tailwind  
- Brave Bird  
- Taunt  
- Protect  

";
$swerve4755 = "Blastoise @ Mental Herb  
Ability: Torrent  
Tera Type: &
EVs: 48 HP / 252 SpA / 208 Spe  
Modest Nature  
IVs: 0 Atk  
- Shell Smash  
- Surf  
- Ice Beam  
- Dark Pulse  

";
$swerve4766 = "Mesprit @ Eject Button  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 248 SpD / 12 Spe  
Calm Nature  
- Ice Beam  
- Toxic  
- Fire Punch  
- Healing Wish  

";
$swerve4776 = "Stunfisk @ Eject Button  
Ability: Static  
Tera Type: &
EVs: 252 HP / 188 Def / 68 SpD  
Bold Nature  
IVs: 0 Atk  
- Discharge  
- Foul Play  
- Toxic  
- Stealth Rock  

Squawkabilly  
Ability: Intimidate  
Level: 50  
Tera Type: &
EVs: 124 HP / 52 Atk / 52 Def / 76 SpD / 204 Spe  
Jolly Nature  
- Helping Hand  
- Tailwind  
- Brave Bird  
- Parting Shot  

";
$swerve4798 = "Deoxys-Speed @ Life Orb  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def  
Adamant Nature  
- Knock Off  
- Extreme Speed  
- Zen Headbutt  
- Brick Break  

";
$swerve4808 = "Weavile @ Never-Melt Ice  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Hone Claws  
- Ice Shard  
- Knock Off  
- Triple Axel  

";
$swerve4818 = "Darmanitan-Galar @ Ganlon Berry  
Ability: Zen Mode  
Tera Type: &
EVs: 252 Def / 252 Spe  
Impish Nature  
- Iron Defense  
- Body Press  
- Reversal  
- Substitute  

";
$swerve4828 = "Urshifu @ Ganlon Berry  
Ability: Unseen Fist  
Tera Type: &
EVs: 8 Atk / 248 Def / 252 Spe  
Jolly Nature  
- Substitute  
- Bulk Up  
- Body Press  
- Reversal  

";
$swerve4838 = "Skarmory @ Starf Berry  
Ability: Weak Armor  
Tera Type: &
EVs: 96 Spe  
- Iron Defense  
- Body Press  
- Substitute  
- Reversal  

";
$swerve4847 = "Kyurem-Black @ Haban Berry  
Ability: Teravolt  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 248 SpA / 4 SpD / 8 Spe  
Modest Nature  
IVs: 0 Atk  
- Confide  
- Roost  
- Draco Meteor  
- Blizzard  

";
$swerve4859 = "Infernape @ Rocky Helmet  
Ability: Blaze  
Tera Type: &
EVs: 216 HP / 104 Atk / 188 Spe  
Adamant Nature  
- Stealth Rock  
- Encore  
- Will-O-Wisp  
- Close Combat  

";
$swerve4869 = "Registeel @ Normal Gem  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 172 Atk / 80 SpD / 8 Spe  
Careful Nature  
- Stealth Rock  
- Thunder Wave  
- Explosion  
- Seismic Toss  

";
$swerve4879 = "Aerodactyl (M) @ Aerodactylite  
Ability: Rock Head  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
- Aerial Ace  
- Ice Fang  
- Stone Edge  
- Earthquake  

";
$swerve4889 = "Victini @ Assault Vest  
Ability: Victory Star  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA  
Lonely Nature  
- Glaciate  
- V-create  
- Bolt Strike  
- Final Gambit  

";
$swerve4899 = "Fraxure @ Leftovers  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Swagger  
- Protect  
- Dual Chop  

";
$swerve4909 = "Florges-Orange (F) @ Metronome  
Ability: Flower Veil  
Tera Type: &
EVs: 252 HP / 196 Def / 60 Spe  
Modest Nature  
- Calm Mind  
- Moonblast  
- Copycat  
- Wish  

";
$swerve4919 = "Arcanine @ Leftovers  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 248 Def / 8 Spe  
Impish Nature  
- Will-O-Wisp  
- Morning Sun  
- Flare Blitz  
- Curse  

";
$swerve4929 = "Zeraora @ Sitrus Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 140 HP / 252 Atk / 116 Spe  
Adamant Nature  
- Plasma Fists  
- Acrobatics  
- Bulk Up  
- Substitute  

";
$swerve4939 = "Goodra-Hisui @ Choice Band  
Ability: Gooey  
Tera Type: &
EVs: 204 HP / 112 Atk / 64 Def / 8 SpD / 120 Spe  
Impish Nature  
- Heavy Slam  
- Outrage  
- Skitter Smack  
- Earthquake  

";
$swerve4949 = "Roaring Moon @ Normal Gem  
Ability: Protosynthesis  
Tera Type: &
EVs: 72 HP / 252 Atk / 184 Spe  
Jolly Nature  
- Knock Off  
- Double-Edge  
- Acrobatics  
- Stone Edge  

";
$swerve4959 = "Diglett @ Earth Plate  
Ability: Arena Trap  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dig  
- Double-Edge  
- Stomping Tantrum  
- Stone Edge  

";
$swerve4969 = "Sandy Shocks @ Weakness Policy  
Ability: Protosynthesis  
Tera Type: &
EVs: 40 HP / 176 Def / 40 SpA / 252 Spe  
Timid Nature  
- Iron Defense  
- Substitute  
- Earth Power  
- Thunderbolt  

";
$swerve4979 = "Latias (F) @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 56 Def / 252 SpA / 200 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Thunderbolt  
- Psychic  
- Refresh  

";
$swerve4990 = "Durant @ Choice Band  
Ability: Hustle  
Tera Type: &
EVs: 60 HP / 32 Atk / 232 SpD / 184 Spe  
Jolly Nature  
- Stone Edge  
- Iron Head  
- X-Scissor  
- Superpower  

";
$swerve41000 = "Pheromosa @ Ground Gem  
Ability: Beast Boost  
Tera Type: &
EVs: 200 HP / 4 Atk / 252 Def / 52 Spe  
Impish Nature  
- High Jump Kick  
- Electroweb  
- Lunge  
- Drill Run  

";
$swerve41010 = "Avalugg @ Flame Orb  
Ability: Ice Body  
Tera Type: &
EVs: 40 HP / 252 Atk / 180 SpD / 36 Spe  
Adamant Nature  
- Protect  
- Facade  
- Stone Edge  
- Hail  

";
$swerve41020 = "Dugtrio-Alola @ Muscle Band  
Ability: Tangling Hair  
Tera Type: &
EVs: 16 HP / 252 Atk / 240 Spe  
Adamant Nature  
- Earthquake  
- Rock Slide  
- Sucker Punch  
- Swords Dance  

";
$swerve41030 = "Smeargle @ Wide Lens  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Spore  
- Population Bomb  
- Shell Smash  
- Power Trip  

";
$swerve41040 = "Flygon @ Loaded Dice  
Ability: Levitate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Scale Shot  
- Earthquake  
- U-turn  
- Psychic Noise  

";
$swerve41050 = "Tauros-Paldea-Blaze (M) @ Eject Pack  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Bulk Up  
- Close Combat  
- Raging Bull  
- Rock Tomb  

";

$svm41 = "Hitmontop @ Chesto Berry  
Ability: Intimidate  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 172 Def / 88 SpD  
Impish Nature  
- Toxic  
- Rest  
- Thief  
- Rapid Spin  

";
$svm412 = "Dragonite @ Leftovers  
Ability: Multiscale  
Tera Type: &
EVs: 252 HP / 116 Def / 140 Spe  
Jolly Nature  
- Substitute  
- Dragon Dance  
- Roost  
- Fly  

";
$svm422 = "Diggersby @ Leftovers  
Ability: Huge Power  
Tera Type: &
EVs: 252 HP / 136 Atk / 120 SpD  
Careful Nature  
- Spikes  
- Protect  
- Return  
- Knock Off  

";
$svm432 = "Ditto @ Scope Lens  
Ability: Imposter  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def  
Impish Nature  
IVs: 30 Atk / 30 Def  
- Transform  

";
$svm440 = "Kingambit @ Assault Vest  
Ability: Defiant  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe  
Adamant Nature  
- Pursuit  
- Sucker Punch  
- Iron Head  
- Knock Off  

";
$svm450 = "Shaymin @ Wise Glasses  
Ability: Natural Cure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk / 30 SpA / 30 Spe  
- Seed Flare  
- Hidden Power [Fire]  
- Earth Power  
- Healing Wish  

";
$svm461 = "Farfetch’d @ Leftovers  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Pluck  
- Protect  
- Roost  

";
$svm471 = "Oricorio-Pa'u @ Flyinium Z  
Ability: Dancer  
Tera Type: &
EVs: 128 HP / 252 SpA / 4 SpD / 124 Spe  
Modest Nature  
- Quiver Dance  
- Hurricane  
- Mirror Move  
- Fly  

";
$svm481 = "Steenee (F) @ Eviolite  
Ability: Leaf Guard  
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD  
Impish Nature  
- Rapid Spin  
- Synthesis  
- Knock Off  
- Bullet Seed  

";
$svm491 = "Beautifly @ Heavy-Duty Boots  
Ability: Rivalry  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Iron Defense  
- Quiver Dance  
- Roost  
- Tera Blast  

";
$svm4101 = "Electivire @ Black Belt  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Bulk Up  
- Focus Punch  
- Protect  

";
$svm4111 = "Pidgeotto @ Figy Berry  
Ability: Tangled Feet  
Tera Type: &
EVs: 244 HP / 12 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Swagger  
- Toxic  
- Mirror Move  

";
$svm4122 = "Pidgeotto @ Eviolite  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Relaxed Nature  
- Defog  
- Roost  
- U-turn  
- Hurricane  

";
$svm4132 = "Pidgeotto @ Eviolite  
Ability: Keen Eye  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Roost  
- U-turn  
- Defog  
- Swagger  

";
$svm4142 = "Pidgeotto @ Eviolite  
Ability: Big Pecks  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Curse  
- Fly  
- Roost  
- Protect  

";
$svm4152 = "Arrokuda @ Eviolite  
Ability: Swift Swim  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Jolly Nature  
- Flip Turn  
- Whirlpool  
- Protect  
- Bounce  

";
$svm4162 = "Arrokuda @ Eviolite  
Ability: Swift Swim  
Tera Type: &
EVs: 252 HP / 76 Def / 176 SpD  
Impish Nature  
- Rest  
- Sleep Talk  
- Waterfall  
- Acupressure  

";
$svm4172 = "Arrokuda @ Eviolite  
Ability: Swift Swim  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Acupressure  
- Protect  
- Waterfall  
- Bounce  

";
$svm4182 = "Arrokuda @ Waterium Z  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Rain Dance  
- Waterfall  
- Close Combat  
- Poison Jab  

";
$svm4192 = "Igglybuff @ Eviolite  
Ability: Cute Charm  
Tera Type: &
EVs: 8 Atk / 248 Def / 252 SpD  
Careful Nature  
- Curse  
- Body Slam  
- Wish  
- Bounce  

";
$svm4202 = "Gallade (M) @ Galladite  
Ability: Justified  
Tera Type: &
EVs: 252 HP / 8 SpD / 248 Spe  
Careful Nature  
- Wish  
- Protect  
- Toxic  
- Knock Off  

";
$svm4212 = "Lotad @ Eviolite  
Ability: Swift Swim  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Synthesis  
- Leech Seed  
- Counter  

";
$svm4223 = "Lotad @ Choice Specs  
Ability: Swift Swim  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Scald  
- Energy Ball  
- Ice Beam  
- Hidden Power [Fire]  

";
$svm4234 = "Bagon @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Outrage  
- Fire Fang  
- Iron Head  

";
$svm4244 = "Snorlax @ Custap Berry  
Ability: Thick Fat  
Tera Type: &
EVs: 232 HP / 204 Atk / 72 Def  
Adamant Nature  
- Body Slam  
- Pursuit  
- Fire Blast  
- Endure  

";
$svm4254 = "Landorus-Therian (M) @ Yache Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 128 Atk / 128 Def  
Adamant Nature  
- Sleep Talk  
- U-turn  
- Earthquake  
- Rest  

";
$svm4264 = "Zeraora @ Choice Scarf  
Ability: Volt Absorb  
Tera Type: &
EVs: 32 HP / 248 Atk / 228 Spe  
Adamant Nature  
- Knock Off  
- Plasma Fists  
- Play Rough  
- Blaze Kick  

";
$svm4274 = "Desmond Benjamin (Kangaskhan) (F) @ Rocky Helmet  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 248 Def / 8 Spe  
Impish Nature  
- Wish  
- Protect  
- Ice Punch  
- Roar  

";
$svm4284 = "Landorus (M) @ Leftovers  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 128 Def / 128 Spe  
Jolly Nature  
- Earthquake  
- U-turn  
- Toxic  
- Stealth Rock  

";
$svm4294 = "Latios (M) @ Eject Pack  
Ability: Levitate  
Tera Type: &
EVs: 96 HP / 252 SpA / 160 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Mystical Fire  
- Draco Meteor  
- Roost  

";
$svm4305 = "Smeargle @ Choice Scarf  
Ability: Technician  
Shiny: Yes  
Tera Type: &
EVs: 168 HP / 248 Def / 92 Spe  
Timid Nature  
- Healing Wish  
- Spore  
- Switcheroo  
- Mortal Spin  

";
$svm4316 = "Togekiss @ Kebia Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 212 Def / 4 SpA / 40 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunder Wave  
- Air Slash  
- Psychic  
- Roost  

";
$svm4327 = "Uxie @ Sitrus Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Calm Nature  
- Knock Off  
- Stealth Rock  
- Yawn  
- Magic Coat  

";
$svm4337 = "Scizor @ Muscle Band  
Ability: Technician  
Tera Type: &
EVs: 144 HP / 252 Atk / 112 Spe  
Adamant Nature  
- Swords Dance  
- Roost  
- Bullet Punch  
- Knock Off  

";
$svm4347 = "antheart💔😢 (Wigglytuff) @ Babiri Berry  
Ability: Frisk  
Shiny: Yes  
Tera Type: &
EVs: 104 HP / 252 Def / 152 SpA  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Fire Blast  
- Thunder Wave  
- Alluring Voice  

";
$svm4359 = "Quaran (Hypno) (M) @ Leftovers  
Ability: Insomnia  
Tera Type: &
EVs: 128 HP / 128 Def / 252 Spe  
Timid Nature  
IVs: 3 Spe  
- Psychic  
- Nasty Plot  
- Thunder Wave  
- Synchronoise  

";
$svm4370 = "Ursaring @ Rocky Helmet  
Ability: Guts  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Impish Nature  
IVs: 0 Atk  
- Counter  
- Seismic Toss  
- Taunt  
- Rest  

";
$svm4381 = "Ursaring @ Custap Berry  
Ability: Guts  
Tera Type: &
EVs: 104 HP / 248 Atk / 156 Spe  
Adamant Nature  
- Endure  
- Swords Dance  
- Giga Impact  
- Crunch  

";
$svm4391 = "Hariyama @ Choice Band  
Ability: Thick Fat  
Tera Type: &
EVs: 72 HP / 180 Atk / 56 Def / 60 SpD / 140 Spe  
Adamant Nature  
- Close Combat  
- Rock Slide  
- Fire Punch  
- Brick Break  

";
$svm4401 = "Luigi Mangione (Breloom) (M) @ Fighting Gem  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 36 Atk / 204 SpD / 20 Spe  
Careful Nature  
- Bulk Up  
- Superpower  
- Bullet Seed  
- Mach Punch  

";
$svm4411 = "Fezandipiti (M) @ Weakness Policy  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Heat Wave  
- Play Rough  
- Roost  
- U-turn  

";
$svm4421 = "Ting-Lu @ Chople Berry  
Ability: Vessel of Ruin  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Stealth Rock  
- Ruination  
- Spikes  
- Throat Chop  

";
$svm4431 = "Latios (M) @ Latiosite  
Ability: Levitate  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Mystical Fire  
- Ice Beam  
- Luster Purge  

";
$svm4442 = "Tornadus-Therian @ Wise Glasses  
Ability: Regenerator  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Timid Nature  
- Hurricane  
- Tera Blast  
- Toxic  
- Air Slash  

";
$svm4452 = "Diancie @ Diancite  
Ability: Clear Body  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Moonblast  
- Mystical Fire  
- Encore  

";
$svm4463 = "Okidogi (M) @ Choice Scarf  
Ability: Toxic Chain  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Gunk Shot  
- Knock Off  
- Ice Punch  

";
$svm4473 = "Iron Bundle @ Sea Incense  
Ability: Quark Drive  
Tera Type: &
EVs: 84 Def / 252 SpA / 172 Spe  
Rash Nature  
- Hydro Pump  
- Freeze-Dry  
- Flip Turn  
- Encore  

";
$svm4483 = "Avalugg-Hisui @ Custap Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Mountain Gale  
- Earthquake  
- Stealth Rock  
- Endure  

";
$svm4493 = "Celesteela @ Rocky Helmet  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 100 Atk / 156 SpD  
Adamant Nature  
- Heavy Slam  
- Seed Bomb  
- Stomping Tantrum  
- Protect  

";
$svm4503 = "Taillow @ Focus Sash  
Ability: Guts  
Level: 1  
Tera Type: &
EVs: 69 HP / 69 Atk / 69 Def / 69 SpD / 69 Spe  
Serious Nature  
- Endeavor  
- Protect  
- Fly  
- Quick Attack  

";
$svm4514 = "Clefairy @ Focus Sash  
Ability: Cute Charm  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Endeavor  
- Recycle  
- Fling  
- Soft-Boiled  

";
$svm4524 = "Iron Jugulis @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 60 HP / 4 Def / 252 SpA / 4 SpD / 188 Spe  
Timid Nature  
IVs: 0 Atk  
- Tailwind  
- Snarl  
- Air Slash  
- Protect  

";
$svm4535 = "Zeraora @ Covert Cloak  
Ability: Volt Absorb  
Tera Type: &
EVs: 116 HP / 4 Atk / 4 Def / 188 SpD / 196 Spe  
Jolly Nature  
- Plasma Fists  
- Play Rough  
- Snarl  
- Coaching  

";
$svm4545 = "Flutter Mane @ Focus Sash  
Ability: Protosynthesis  
Level: 95  
Tera Type: &
EVs: 68 HP / 252 SpA / 188 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Thunderbolt  
- Icy Wind  
- Protect  

";
$svm4557 = "Wyrdeer @ Mental Herb  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 132 Def / 4 SpA / 116 SpD / 4 Spe  
Calm Nature  
IVs: 0 Atk  
- Psychic  
- Thunderbolt  
- Disable  
- Trick Room  

";
$svm4568 = "Great Tusk @ Eject Pack  
Ability: Protosynthesis  
Tera Type: &
EVs: 140 Atk / 120 SpD / 248 Spe  
Jolly Nature  
- Roar  
- Headlong Rush  
- Temper Flare  
- Protect  

";
$svm4578 = "Riolu @ Focus Sash  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
- Coaching  
- Follow Me  
- Sunny Day  
- Copycat  

";
$svm4588 = "Charizard @ Charizardite Y  
Ability: Blaze  
Tera Type: &
EVs: 140 HP / 28 Def / 4 SpA / 100 SpD / 236 Spe  
Timid Nature  
IVs: 0 Atk  
- Tailwind  
- Heat Wave  
- Air Slash  
- Protect  

";
$svm4599 = "Lapras @ Sitrus Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Sassy Nature  
- Icy Wind  
- Ice Shard  
- Freeze-Dry  
- Roar  

";
$svm4609 = "Tauros @ Focus Sash  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double-Edge  
- Icy Wind  
- Endeavor  
- Protect  

";
$svm4619 = "Celebi @ Leftovers  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 220 Def / 36 Spe  
Impish Nature  
- Stealth Rock  
- Leaf Storm  
- Leech Seed  
- U-turn  

";
$svm4629 = "Landorus-Therian (M) @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- U-turn  
- Earthquake  
- Stone Edge  
- Stealth Rock  

";
$svm4639 = "Garchomp @ Adrenaline Orb  
Ability: Rough Skin  
Tera Type: &
EVs: 224 HP / 252 Atk / 32 Spe  
Adamant Nature  
- Swords Dance  
- Earthquake  
- Scale Shot  
- Liquidation  

";
$svm4649 = "Magnezone @ Electrium Z  
Ability: Analytic  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Protect  
- Electroweb  
- Magnet Rise  
- Hidden Power [Steel]  

";
$svm4660 = "Audino @ Sitrus Berry  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD  
Relaxed Nature  
- Body Slam  
- Flamethrower  
- Trick Room  
- Iron Tail  

";
$svm4670 = "Alomomola @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Aqua Ring  
- Scald  

";
$svm4681 = "Volbeat (M) @ Custap Berry  
Ability: Swarm  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Encore  
- Endure  
- Tail Glow  

";
$svm4692 = "Snorlax @ Metronome  
Ability: Immunity  
Tera Type: &
EVs: 100 HP / 132 Atk / 80 SpA / 196 SpD  
Brave Nature  
- Body Slam  
- Fire Blast  
- Rest  
- Sleep Talk  

";
$svm4702 = "Toxtricity @ Choice Scarf  
Ability: Punk Rock  
Shiny: Yes  
Tera Type: &
EVs: 124 SpA / 144 SpD / 240 Spe  
Timid Nature  
- Volt Switch  
- Boomburst  
- Sludge Wave  
- Nuzzle  

";
$svm4713 = "Infernape @ Expert Belt  
Ability: Blaze  
Tera Type: &
EVs: 128 Atk / 204 SpA / 176 Spe  
Lonely Nature  
- U-turn  
- Gunk Shot  
- Overheat  
- Grass Knot  

";
$svm4723 = "Cofagrigus @ Red Card  
Ability: Mummy  
Tera Type: &
EVs: 252 HP / 128 SpA / 128 SpD  
Calm Nature  
IVs: 0 Atk  
- Calm Mind  
- Shadow Ball  
- Toxic  
- Pain Split  

";
$svm4734 = "Articuno @ Lum Berry  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Haze  
- Roost  
- Defog  

";
$svm4745 = "Zeraora @ Salac Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 36 HP / 252 Atk / 220 Spe  
Adamant Nature  
- Knock Off  
- Play Rough  
- Fire Punch  
- Endure  

";
$svm4755 = "Latios (M) @ Mental Herb  
Ability: Levitate  
Tera Type: &
EVs: 8 HP / 252 SpA / 248 Spe  
Timid Nature  
IVs: 0 Atk  
- Agility  
- Calm Mind  
- Dragon Pulse  
- Stored Power  

";
$svm4766 = "Staraptor @ Heavy-Duty Boots  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 64 Def / 192 Spe  
Jolly Nature  
- Defog  
- U-turn  
- Roost  
- Dual Wingbeat  

";
$svm4776 = "Kabutops @ Salac Berry  
Ability: Battle Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Endure  
- Flail  
- Waterfall  

";
$svm4786 = "Weavile @ King's Rock  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Hone Claws  
- Beat Up  
- Triple Axel  
- Dig  

";
$svm4796 = "Uxie @ Chesto Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
- Knock Off  
- Stealth Rock  
- Thunder  
- Rest  

";
$svm4806 = "Blastoise @ Blastoisinite  
Ability: Mega Launcher  
Shiny: Yes  
Tera Type: &
EVs: 248 HP / 224 Def / 36 Spe  
Bold Nature  
- Water Pulse  
- Aura Sphere  
- Rapid Spin  
- Flip Turn  

";
$svm4817 = "Dragonite @ Heavy-Duty Boots  
Ability: Multiscale  
Tera Type: &
EVs: 248 HP / 192 Def / 48 SpD / 20 Spe  
Bold Nature  
IVs: 0 Atk  
- Toxic  
- Flamethrower  
- Heal Bell  
- Roost  

";
$svm4828 = "Azelf @ Leftovers  
Ability: Levitate  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 148 Def / 108 SpD  
Calm Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Draining Kiss  
- Flamethrower  

";
$svm4840 = "Tapu Koko @ Shuca Berry  
Ability: Electric Surge  
Shiny: Yes  
Tera Type: &
EVs: 92 HP / 200 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Grass Knot  
- Roost  
- Light Screen  

";
$svm4852 = "Tapu Koko @ Expert Belt  
Ability: Electric Surge  
Shiny: Yes  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Timid Nature  
- U-turn  
- Thunderbolt  
- Grass Knot  
- Roost  

";
$svm4863 = "Uxie @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 148 SpD / 108 Spe  
Calm Nature  
- Knock Off  
- U-turn  
- Encore  
- Trick  

";
$svm4873 = "Wigglytuff @ Babiri Berry  
Ability: Frisk  
Shiny: Yes  
Tera Type: &
EVs: 252 Def / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Fire Blast  
- Thunder Wave  
- Wish  

";
$svm4885 = "Throh @ Leftovers  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Protect  
- Circle Throw  
- Knock Off  
- Ice Punch  

";
$svm4895 = "Tapu Koko @ Choice Scarf  
Ability: Electric Surge  
Shiny: Yes  
Tera Type: &
EVs: 44 HP / 252 SpA / 212 Spe  
Modest Nature  
- Thunderbolt  
- Dazzling Gleam  
- U-turn  
- Defog  

";
$svm4906 = "doctor K (Blastoise) (M) @ Blastoisinite  
Ability: Torrent  
Tera Type: &
EVs: 96 HP / 252 SpA / 160 Spe  
Modest Nature  
- Terrain Pulse  
- Water Pulse  
- Rapid Spin  
- Haze  

";
$svm4916 = "Landorus (M) @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Calm Mind  
- Sludge Wave  
- Gravity  

";
$svm4927 = "Kangaskhan (F) @ Choice Scarf  
Ability: Scrappy  
Tera Type: &
EVs: 252 Atk / 212 Def / 44 Spe  
Adamant Nature  
- Ice Punch  
- Drain Punch  
- Return  
- Wish  

";
$svm4937 = "Wigglytuff @ Custap Berry  
Ability: Frisk  
Tera Type: &
EVs: 252 Def / 196 SpD / 60 Spe  
Bold Nature  
IVs: 0 HP  
- Stealth Rock  
- Ice Beam  
- Endeavor  
- Copycat  

";
$svm4948 = "Exeggutor-Alola @ Custap Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Energy Ball  
- Flamethrower  
- Endure  

";
$svm4959 = "Exeggutor-Alola @ Eject Pack  
Ability: Frisk  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
- Leaf Storm  
- Draco Meteor  
- Synthesis  
- Thief  

";
$svm4969 = "Typhlosion-Hisui @ Fire Gem  
Ability: Frisk  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Hasty Nature  
- Overheat  
- Covet  
- Dig  
- Shadow Ball  

";
$svm4979 = "Trevenant @ Ghost Gem  
Ability: Frisk  
Tera Type: &
EVs: 216 HP / 252 Atk / 40 Spe  
Adamant Nature  
- Poltergeist  
- Thief  
- Substitute  
- Leech Seed  

";
$svm4989 = "Snorlax @ Normal Gem  
Ability: Thick Fat  
Tera Type: &
EVs: 80 HP / 168 Atk / 188 Def / 52 SpD / 20 Spe  
Adamant Nature  
- Rest  
- Double-Edge  
- Recycle  
- Sleep Talk  

";
$svm4999 = "Silvally (Silvally-Grass) @ Grass Memory  
Ability: RKS System  
Tera Type: &
EVs: 252 HP / 48 Def / 208 SpA  
Bold Nature  
IVs: 0 Atk  
- Metal Sound  
- Ice Beam  
- Air Slash  
- Flamethrower  

";
$svm41010 = "Celebi @ Grassium Z  
Ability: Natural Cure  
Tera Type: &
EVs: 184 HP / 72 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Hidden Power [Fire]  
- Charge Beam  
- Leaf Storm  

";
$svm41021 = "Cradily @ Meadow Plate  
Ability: Suction Cups  
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe  
Modest Nature  
IVs: 0 Atk  
- Sunny Day  
- Substitute  
- Synthesis  
- Solar Beam  

";
$svm41032 = "Aerodactyl @ Life Orb  
Ability: Unnerve  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Stone Edge  
- Ice Fang  
- Fire Blast  
- Earthquake  

";
$svm41042 = "Hoopa @ Sitrus Berry  
Ability: Magician  
Tera Type: &
EVs: 48 HP / 208 Def / 252 SpA  
Modest Nature  
- Focus Punch  
- Shadow Ball  
- Hidden Power [Ice]  
- Substitute  

";
$svm41052 = "Aromatisse @ Lum Berry  
Ability: Aroma Veil  
Tera Type: &
EVs: 248 HP / 144 Def / 116 SpA  
Modest Nature  
IVs: 0 Atk / 30 SpA / 30 Spe  
- Moonblast  
- Hidden Power [Fire]  
- Calm Mind  
- Wish  

";
$svm41063 = "Skarmory @ Mental Herb  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Whirlwind  
- Toxic  
- Stealth Rock  
- Spikes  

";
$svm41074 = "Thundurus (M) @ Magnet  
Ability: Prankster  
Tera Type: &
EVs: 60 Def / 252 SpA / 196 Spe  
Modest Nature  
IVs: 0 Atk / 30 Def  
- Thunderbolt  
- Hidden Power [Ice]  
- Taunt  
- Thunder Wave  

";
$svm41085 = "Rotom-Wash @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 72 SpA / 188 SpD  
Calm Nature  
IVs: 0 Atk  
- Rest  
- Sleep Talk  
- Charge Beam  
- Hydro Pump  

";
$svm41096 = "Kecleon @ Leftovers  
Ability: Protean  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Grass Knot  
- Recover  
- Stealth Rock  
- Shadow Sneak  

";
$svm41106 = "Eelektross @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Volt Switch  
- Giga Drain  
- Thunderbolt  
- Toxic  

";
$svm41117 = "Talonflame @ Liechi Berry  
Ability: Gale Wings  
Tera Type: &
EVs: 96 HP / 248 Atk / 164 Spe  
Adamant Nature  
- Brave Bird  
- Flare Blitz  
- Natural Gift  
- Acrobatics  

";
$svm41127 = "Mew @ Choice Scarf  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 132 SpA / 124 Spe  
Timid Nature  
IVs: 0 Atk / 30 Def  
- Transform  
- Trick  
- Psychic  
- Shadow Ball  

";
$svm41138 = "Absol @ Absolite  
Ability: Justified  
Tera Type: &
EVs: 108 Atk / 160 SpA / 240 Spe  
Hasty Nature  
- Flamethrower  
- Knock Off  
- Thunderbolt  
- Ice Beam  

";
$svm41148 = "Tangrowth @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 132 HP / 124 Atk / 252 SpD  
Careful Nature  
- Earthquake  
- Knock Off  
- Poison Jab  
- Power Whip  

";
$svm41158 = "Entei @ Power Herb  
Ability: Inner Focus  
Tera Type: &
EVs: 16 HP / 252 SpA / 240 Spe  
Mild Nature  
- Solar Beam  
- Sacred Fire  
- Extreme Speed  
- Will-O-Wisp  

";
$svm41168 = "Reuniclus @ Life Orb  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Psyshock  
- Focus Blast  
- Shadow Ball  
- Recover  

";
$svm41179 = "Volcarona @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Body Slam  
- U-turn  
- Will-O-Wisp  
- Morning Sun  

";
$svm41189 = "Hedwig (Zapdos) @ Rocky Helmet  
Ability: Pressure  
Shiny: Yes  
Tera Type: &
EVs: 240 HP / 228 Def / 40 SpA  
Quiet Nature  
- Drill Peck  
- Volt Switch  
- Hidden Power [Ice]  
- Roost  

";
$svm41200 = "Greninja @ Assault Vest  
Ability: Battle Bond  
Tera Type: &
EVs: 52 HP / 252 Atk / 4 SpD / 200 Spe  
Adamant Nature  
- Waterfall  
- Upper Hand  
- Night Slash  
- Gunk Shot  

";
$svm41210 = "Lopunny @ Lopunnite  
Ability: Limber  
Tera Type: &
EVs: 252 Atk / 92 Def / 4 SpD / 160 Spe  
Jolly Nature  
- Substitute  
- Iron Tail  
- Close Combat  
- U-turn  

";
$svm41220 = "Hypno @ Adrenaline Orb  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Thunder Wave  
- Shadow Ball  
- Nasty Plot  
- Rest  

";
$svm41231 = "Zweilous @ Eviolite  
Ability: Hustle  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Thunder Wave  
- Rest  
- Rain Dance  
- Torment  

";
$svm41242 = "Wigglytuff @ Mirror Herb  
Ability: Frisk  
Tera Type: &
EVs: 252 Atk / 88 Def / 100 SpD / 68 Spe  
Adamant Nature  
- Swagger  
- Punishment  
- Mega Kick  
- Drain Punch  

";
$svm41252 = "Snorlax @ Assault Vest  
Ability: Thick Fat  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpD  
Adamant Nature  
- Return  
- Pursuit  
- Earthquake  
- Fire Punch  

";
$svm41262 = "Terapagos @ Throat Spray  
Ability: Tera Shift  
Tera Type: &
EVs: 124 HP / 252 SpA / 132 Spe  
Modest Nature  
- Tera Starstorm  
- Flamethrower  
- Bug Buzz  
- Rapid Spin  

";
$svm41272 = "Darkrai @ Life Orb  
Ability: Bad Dreams  
Tera Type: &
EVs: 96 HP / 252 SpA / 160 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Ice Beam  
- Sludge Bomb  
- Focus Blast  

";
$svm41283 = "Metagross @ Protective Pads  
Ability: Clear Body  
Tera Type: &
EVs: 52 HP / 252 Atk / 204 Spe  
Adamant Nature  
- Heavy Slam  
- Earthquake  
- Ice Punch  
- Agility  

";
$svm41293 = "Amoonguss @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Calm Nature  
- Giga Drain  
- Clear Smog  
- Foul Play  
- Hidden Power [Fire]  

";
$svm41303 = "Excadrill @ Assault Vest  
Ability: Mold Breaker  
Tera Type: &
EVs: 80 HP / 176 Atk / 252 SpD  
Adamant Nature  
- Rapid Spin  
- Earthquake  
- Iron Head  
- Rock Slide  

";
$svm41313 = "Jirachi @ Choice Scarf  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 180 Atk / 76 Spe  
Adamant Nature  
- U-turn  
- Ice Punch  
- Meteor Mash  
- Healing Wish  

";
$svm41323 = "Aerodactyl @ Clear Amulet  
Ability: Pressure  
Tera Type: &
EVs: 44 HP / 252 Atk / 4 SpD / 208 Spe  
Jolly Nature  
- Dragon Dance  
- Dual Wingbeat  
- Earthquake  
- Ice Fang  

";
$svm41333 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpA  
Quiet Nature  
- Earthquake  
- Freeze-Dry  
- Earth Power  
- Stealth Rock  

";
$svm41343 = "Raging Bolt @ Heavy-Duty Boots  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 20 Atk  
- Thunderbolt  
- Volt Switch  
- Draco Meteor  
- Weather Ball  

";
$svm41354 = "Fezandipiti (M) @ Red Card  
Ability: Toxic Chain  
Tera Type: &
EVs: 180 HP / 56 Def / 20 SpA / 252 SpD  
Calm Nature  
- Roost  
- U-turn  
- Thief  
- Moonblast  

";
$svm41364 = "Hydrapple @ Chilan Berry  
Ability: Supersweet Syrup  
Tera Type: &
EVs: 248 HP / 48 SpA / 116 SpD / 96 Spe  
Modest Nature  
- Draco Meteor  
- Leaf Storm  
- Syrup Bomb  
- Protect  

";
$svm41374 = "Sneasler @ Assault Vest  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dire Claw  
- Close Combat  
- U-turn  
- Fake Out  

";
$svm41384 = "Gouging Fire @ Sablenite  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 184 SpD / 72 Spe  
Careful Nature  
- Flare Blitz  
- Fire Spin  
- Rest  
- Dragon Dance  

";
$svm41394 = "Salamence @ Sablenite  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 232 SpD / 24 Spe  
Careful Nature  
- Dual Wingbeat  
- Fire Spin  
- Rest  
- Dragon Dance  

";
$svm41404 = "Starmie @ Leftovers  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  
- Nightmare  
- Substitute  
- Recover  

";
$svm41415 = "Sableye @ Sablenite  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Will-O-Wisp  
- Recover  
- Calm Mind  

";
$svm41426 = "Stantler @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 172 Atk / 4 SpD / 80 Spe  
Adamant Nature  
- Return  
- Earthquake  
- Rest  
- Sleep Talk  

";
$svm41436 = "Grafaiai @ Heavy-Duty Boots  
Ability: Prankster  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double-Edge  
- Knock Off  
- Copycat  
- Swords Dance  

";
$svm41446 = "Dragonite @ Clear Amulet  
Ability: Multiscale  
Tera Type: &
EVs: 92 HP / 252 Atk / 164 Spe  
Adamant Nature  
- Extreme Speed  
- Tera Blast  
- Protect  
- Dragon Dance  

";
$svm41456 = "Krokorok @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 116 HP / 160 Atk / 232 Spe  
Adamant Nature  
- Stealth Rock  
- Earthquake  
- Knock Off  
- Dragon Tail  

";
$svm41466 = "Krokorok @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 28 HP / 252 Atk / 228 Spe  
Adamant Nature  
- Stealth Rock  
- Earthquake  
- Knock Off  
- Dragon Tail  

";
$svm41476 = "Iron Crown @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 84 Def / 172 SpA / 252 Spe  
Timid Nature  
- Calm Mind  
- Tachyon Cutter  
- Psyshock  
- Bulldoze  

";
$svm41486 = "Sinistcha @ Life Orb  
Ability: Heatproof  
Tera Type: &
EVs: 252 HP / 76 Def / 180 SpA  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Matcha Gotcha  
- Shadow Ball  
- Protect  
- Trick Room  

";
$svm41497 = "Darmanitan-Galar @ Choice Scarf  
Ability: Zen Mode  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Icicle Crash  
- Flare Blitz  
- Earthquake  
- U-turn

";
$svm41507 = "Dodrio @ Berserk Gene  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- Roost  
- Return  
- Jump Kick  

";
$svm41517 = "Pidgeotto @ Berserk Gene  
Ability: Tangled Feet  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Roost  
- Fly  
- Return  
- Brave Bird  

";
$svm41527 = "Mime Jr. @ Twisted Spoon  
Ability: Technician  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Psychic  
- Hidden Power [Fire]  

";
$svm41538 = "Kubfu @ Choice Scarf  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- U-turn  
- Close Combat  
- Iron Head  
- Ice Punch  

";
$svm41548 = "Swirlix @ Starf Berry  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Cotton Guard  
- Draining Kiss  
- Protect  

";
$svm41559 = "Graveler-Alola @ Eviolite  
Ability: Magnet Pull  
Happiness: 0  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Stealth Rock  
- Stone Edge  
- Toxic  
- Volt Switch  

";
$svm41570 = "Heatran @ Shuca Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
- Rock Tomb  
- Bulldoze  
- Earth Power  
- Protect  

";
$svm41580 = "Heatran @ Custap Berry  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 104 SpA / 152 SpD  
Calm Nature  
- Earth Power  
- Pounce  
- Endure  
- Body Press  

";
$svm41590 = "Heatran @ Assault Vest  
Ability: Flash Fire  
Tera Type: &
EVs: 196 Def / 60 SpA / 252 Spe  
Timid Nature  
- Bulldoze  
- Rock Tomb  
- Earth Power  
- Power Gem  

";
$svm41600 = "Iron Crown @ Assault Vest  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 72 Def / 12 SpA / 172 SpD  
Sassy Nature  
IVs: 20 Atk / 20 Spe  
- Tachyon Cutter  
- Psyshock  
- Focus Blast  
- Metal Burst  

";
$svm41611 = "Espathra @ Clear Amulet  
Ability: Speed Boost  
Tera Type: &
EVs: 240 HP / 252 SpD / 16 Spe  
Calm Nature  
IVs: 0 Atk  
- Stored Power  
- Feather Dance  
- Roost  
- Calm Mind  

";
$svm41622 = "Kyurem @ Chople Berry  
Ability: Pressure  
Tera Type: &
EVs: 228 HP / 240 Def / 40 SpA  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Freeze-Dry  
- Psychic  
- Reflect  

";
$svm41633 = "Tapu Fini @ Misty Seed  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 128 Def / 52 SpA / 24 SpD / 56 Spe  
Bold Nature  
IVs: 0 Atk  
- Hydro Pump  
- Rain Dance  
- Moonblast  
- Calm Mind  

";
$svm41644 = "Tapu Fini @ Misty Seed  
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 128 Def / 52 SpA / 24 SpD / 56 Spe  
Bold Nature  
- Waterfall  
- Rain Dance  
- Moonblast  
- Calm Mind  

";
$svm41654 = "Hypno @ Wiki Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Sassy Nature  
- Trick Room  
- Seismic Toss  
- Psychic  
- Disable  

";
$svm41664 = "Kommo-o @ Life Orb  
Ability: Overcoat  
Tera Type: &
EVs: 244 HP / 72 Atk / 24 SpA / 168 SpD  
Relaxed Nature  
- Clanging Scales  
- Thunder Punch  
- Protect  
- Close Combat  

";
$svm41674 = "Dracovish @ Quick Claw  
Ability: Strong Jaw  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Protect  
- Fishious Rend  
- Super Fang  
- Substitute  

";
$svm41684 = "Metagross @ Air Balloon  
Ability: Clear Body  
Tera Type: &
EVs: 248 HP / 60 Atk / 200 Def  
Impish Nature  
- Heavy Slam  
- Bullet Punch  
- Body Press  
- Iron Defense  

";
$svm41694 = "Indeedee (M) @ Terrain Extender  
Ability: Psychic Surge  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Expanding Force  
- Dazzling Gleam  
- Encore  
- Healing Wish  

";
$svm41705 = "Claydol @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Sand Tomb  
- Rest  
- Rapid Spin  
- Trick  

";
$svm41715 = "Lapras @ Kee Berry  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Body Press  
- Rest  
- Rain Dance  

";
$svm41726 = "Sliggoo @ Eviolite  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Body Slam  
- Curse  
- Rain Dance  
- Rest  

";
$svm41736 = "Sliggoo @ Eviolite  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Outrage  
- Curse  
- Rain Dance  
- Rest  

";
$svm41746 = "Sliggoo @ Choice Specs  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Thunder  
- Ice Beam  
- Hidden Power [Fire]  

";
$svm41757 = "Sliggoo @ Leftovers  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 232 SpA / 24 Spe  
Calm Nature  
IVs: 0 Atk  
- Dragon Pulse  
- Toxic  
- Substitute  
- Protect  

";
$svm41768 = "Sliggoo @ Eviolite  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Thunder  
- Toxic  
- Rain Dance  
- Rest  

";
$svm41779 = "Lapras @ Waterium Z  
Ability: Hydration  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Muddy Water  
- Thunder  
- Rest  
- Rain Dance  

";
$svm41790 = "Keldeo @ Waterium Z  
Ability: Justified  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Muddy Water  
- Secret Sword  
- Rain Dance  
- Protect  

";
$svm41801 = "Kyurem-Black @ Waterium Z  
Ability: Teravolt  
Tera Type: &
EVs: 112 HP / 44 Atk / 4 Def / 48 SpA / 8 SpD / 252 Spe  
Naive Nature  
IVs: 30 Atk  
- Hidden Power [Water]  
- Fusion Bolt  
- Icicle Spear  
- Rain Dance  

";
$svm41812 = "Palafin @ Waterium Z  
Ability: Zero to Hero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Hard Press  
- Close Combat  
- Substitute  
- Rain Dance  

";
$svm41822 = "Tyranitar @ Tyranitarite  
Ability: Sand Stream  
Tera Type: &
EVs: 4 HP / 4 Atk / 4 Def / 4 SpA / 4 SpD / 4 Spe  
Sassy Nature  
- Hard Press  
- Blizzard  
- Hone Claws  
- Iron Defense  

";
$svm41832 = "Tyranitar @ Tyranitarite  
Ability: Sand Stream  
Tera Type: &
EVs: 4 HP / 4 Atk / 4 Def / 4 SpA / 252 SpD / 184 Spe  
Careful Nature  
- Roar  
- Detect  
- Toxic  
- Assurance  

";
$svm41842 = "Kartana @ Galladite  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Sacred Sword  
- Leaf Blade  
- Substitute  
- Protect  

";
$svm41852 = "Annihilape @ Darkinium Z  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 116 Atk / 140 SpD  
Brave Nature  
IVs: 2 Spe  
- Rage Fist  
- Drain Punch  
- Protect  
- Bulk Up  

";
$svm41863 = "Annihilape @ Room Service  
Ability: Defiant  
Tera Type: &
EVs: 252 HP / 116 Atk / 140 SpD  
Brave Nature  
IVs: 2 Spe  
- Rage Fist  
- Drain Punch  
- Gunk Shot  
- Bulk Up  

";
$svm41874 = "Annihilape @ Choice Scarf  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Rage Fist  
- Seismic Toss  
- Toxic  
- Encore  

";
$svm41884 = "Gardevoir @ Babiri Berry  
Ability: Trace  
Tera Type: &
EVs: 252 HP / 168 Def / 88 Spe  
Bold Nature  
IVs: 0 Atk  
- Hypnosis  
- Calm Mind  
- Draining Kiss  
- Vacuum Wave  

";
$svm41895 = "Latias @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 160 Def / 96 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Draining Kiss  
- Roar  

";
$svm41906 = "Weezing-Galar @ Fairy Feather  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 208 HP / 252 SpA / 48 Spe  
Rash Nature  
- Strange Steam  
- Gunk Shot  
- Flamethrower  
- Defog  

";
$svm41916 = "Umbreon (M) @ Utility Umbrella  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Moonlight  
- Heal Bell  
- Sucker Punch  
- Foul Play  

";
$svm41926 = "Alomomola (M) @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 4 HP / 252 Def / 252 SpD  
Bold Nature  
IVs: 0 Atk  
- Wish  
- Refresh  
- Calm Mind  
- Shadow Ball  

";
$svm41937 = "Wo-Chien @ Normalium Z  
Ability: Tablets of Ruin  
Tera Type: &
EVs: 248 HP / 20 Def / 92 SpA / 136 SpD / 12 Spe  
Calm Nature  
- Giga Drain  
- Mean Look  
- Growth  
- Tera Blast  

";
$svm41947 = "Cinderace @ Leftovers  
Ability: Blaze  
Tera Type: &
EVs: 32 HP / 172 Atk / 52 SpD / 252 Spe  
Jolly Nature  
- Pyro Ball  
- Court Change  
- Substitute  
- Coaching  

";
$svm41957 = "Absol @ Absolite  
Ability: Pressure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Knock Off  
- Perish Song  
- Pursuit  
- Protect  

";
$svm41967 = "Honchkrow @ Heavy-Duty Boots  
Ability: Moxie  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Perish Song  
- Pursuit  
- Roost  
- Protect  

";
$svm41977 = "Swablu @ Eviolite  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Dragon Breath  
- Perish Song  
- Roost  
- Defog  

";
$svm41988 = "Altaria @ Dragonium Z  
Ability: Natural Cure  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Claw  
- Defog  
- Dragon Dance  
- Dual Wingbeat  

";
$svm41998 = "Sudowoodo @ Assault Vest  
Ability: Rock Head  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD  
Careful Nature  
- Head Smash  
- Wood Hammer  
- High Horsepower  
- Trailblaze  

";
$svm42008 = "Scizor @ Life Orb  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Bullet Punch  
- Trailblaze  
- Baton Pass  
- Roost  

";
$svm42018 = "Scizor @ Scizorite  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Bullet Punch  
- Trailblaze  
- Baton Pass  
- Roost  

";
$svm42028 = "Scizor @ Scizorite  
Ability: Light Metal  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Hard Press  
- Knock Off  
- Bullet Punch  
- Roost  

";
$svm42038 = "Scizor @ Scizorite  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Bullet Punch  
- Knock Off  
- Close Combat  
- Swords Dance  

";
$svm42048 = "Scizor @ Scizorite  
Ability: Technician  
Tera Type: &
EVs: 4 HP / 4 Atk / 4 Def / 4 SpA / 4 SpD / 252 Spe  
- Aerial Ace  
- Acrobatics  
- Air Slash  
- Defog  

";
$svm42057 = "Scizor @ Clear Amulet  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Bullet Punch  
- U-turn  
- Sleep Talk  
- Rest  

";
$svm42067 = "Araquanid @ Chesto Berry  
Ability: Water Bubble  
Tera Type: &
EVs: 252 HP / 224 Atk / 32 SpD  
Adamant Nature  
- Liquidation  
- Infestation  
- Leech Life  
- Rest  

";
$svm42077 = "Dedenne @ King's Rock  
Ability: Cheek Pouch  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Discharge  
- U-turn  
- Fling  
- Nuzzle  

";
$svm42087 = "Porygon-Z @ Power Herb  
Ability: Analytic  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Solar Beam  
- Hyper Beam  
- Charge Beam  
- Ice Beam  

";
$svm42098 = "Terapagos @ Chople Berry  
Ability: Tera Shift  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Tera Starstorm  
- Flamethrower  
- Roar  
- Rapid Spin  

";
$svm42108 = "Thundurus @ Heavy-Duty Boots  
Ability: Prankster  
Tera Type: &
EVs: 84 HP / 252 SpA / 172 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Weather Ball  
- Thunder Wave  
- Nasty Plot  

";
$svm42119 = "Ninetales-Alola @ Blunder Policy  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 44 Def / 140 SpA / 72 Spe  
Timid Nature  
IVs: 0 Atk  
- Blizzard  
- Draining Kiss  
- Toxic  
- Protect  

";
$svm42130 = "Kyurem-Black @ Rocky Helmet  
Ability: Teravolt  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Draco Meteor  
- Freeze-Dry  
- Reflect  
- Protect  

";
$svm42141 = "Grotle @ Choice Band  
Ability: Overgrow  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA  
Brave Nature  
- Seed Bomb  
- Heavy Slam  
- Tera Blast  
- Trailblaze  

";
$svm42151 = "Tapu Lele @ Fairium Z  
Ability: Psychic Surge  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Calm Nature  
IVs: 0 Atk  
- Aromatic Mist  
- Psychic  
- Rest  
- Sleep Talk  

";
$svm42162 = "Thievul @ Grassy Seed  
Ability: Unburden  
Tera Type: &
EVs: 24 Def / 252 SpA / 124 SpD / 108 Spe  
Modest Nature  
- Nasty Plot  
- Dark Pulse  
- Burning Jealousy  
- Grass Knot  

";
$svm42172 = "Thievul @ Choice Specs  
Ability: Stakeout  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Dark Pulse  
- Grass Knot  
- Psychic  
- U-turn  

";
$svm42182 = "Thievul @ Firium Z  
Ability: Stakeout  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Knock Off  
- Dark Pulse  
- Burning Jealousy  
- Protect  

";
$svm42192 = "Gengar @ Payapa Berry  
Ability: Levitate  
Tera Type: &
EVs: 28 HP / 252 Def / 104 SpA / 124 Spe  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Taunt  
- Shadow Ball  
- Hidden Power [Fire]  
- Icy Wind  

";
$svm42203 = "Kartana @ Protective Pads  
Ability: Beast Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Leaf Blade  
- Knock Off  
- Aerial Ace  
- Return  

";
$svm42213 = "Lucario @ Air Balloon  
Ability: Steadfast  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Flash Cannon  
- Focus Blast  
- Shadow Ball  

";
$svm42224 = "Blaziken @ Blazikenite  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Endure  
- Reversal  
- Flare Blitz  
- Bulk Up  

";
$svm42234 = "Togekiss @ Babiri Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 248 HP / 184 Def / 76 SpD  
Bold Nature  
IVs: 0 Atk  
- Air Slash  
- Follow Me  
- Helping Hand  
- Protect  

";
$svm42245 = "Latios (M) @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Psychic  
- Tailwind  
- Protect  

";
$svm42256 = "Kyurem-Black @ Haban Berry  
Ability: Teravolt  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Ice Beam  
- Earth Power  
- Protect  

";
$svm42267 = "Shaymin-Sky @ Life Orb  
Ability: Serene Grace  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Seed Flare  
- Air Slash  
- Tailwind  
- Protect  

";
$svm42278 = "Infernape @ Life Orb  
Ability: Blaze  
Tera Type: &
EVs: 136 Atk / 120 SpA / 252 Spe  
Naive Nature  
- Overheat  
- Close Combat  
- Feint  
- Fake Out  

";
$svm42288 = "Suicune @ Sitrus Berry  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 164 Def / 92 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Tailwind  
- Calm Mind  

";
$svm42299 = "Suicune @ Sitrus Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 164 Def / 92 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Tailwind  
- Calm Mind  

";
$svm42310 = "Whimsicott @ Occa Berry  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 60 Def / 196 SpD  
Bold Nature  
IVs: 0 Atk  
- Encore  
- Tailwind  
- Charm  
- Light Screen  

";
$svm42321 = "Hoopa-Unbound @ Choice Scarf  
Ability: Magician  
Tera Type: &
EVs: 4 HP / 84 Atk / 244 Def / 176 Spe  
Naive Nature  
- Hyperspace Fury  
- Hyperspace Hole  
- Gunk Shot  
- Trick  

";
$svm42331 = "Zygarde @ Life Orb  
Ability: Aura Break  
Tera Type: &
EVs: 72 HP / 184 Atk / 252 Spe  
Adamant Nature  
- Land's Wrath  
- Rock Slide  
- Protect  
- Dragon Dance  

";
$svm42341 = "Volcarona @ Coba Berry  
Ability: Flame Body  
Tera Type: &
EVs: 240 HP / 160 SpD / 108 Spe  
Modest Nature  
IVs: 0 Atk  
- Overheat  
- Bug Buzz  
- Rage Powder  
- Protect  

";
$svm42352 = "Blaziken @ Blazikenite  
Ability: Speed Boost  
Tera Type: &
EVs: 108 Atk / 148 SpA / 252 Spe  
Naive Nature  
- Overheat  
- Superpower  
- Rock Slide  
- Protect  

";
$svm42362 = "Tapu Fini @ Life Orb  
Ability: Misty Surge  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Moonblast  
- Icy Wind  
- Protect  

";
$svm42373 = "Landorus-Therian (M) @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 96 Atk / 32 SpD / 128 Spe  
Adamant Nature  
- Earthquake  
- Bulldoze  
- Rock Slide  
- Protect  

";
$svm42383 = "Cinderace @ Life Orb  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- High Jump Kick  
- Gunk Shot  
- Assurance  
- Protect  

";
$svm42393 = "Mew @ Power Herb  
Ability: Synchronize  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Expanding Force  
- Meteor Beam  
- Flamethrower  
- Fake Out  

";
$svm42403 = "Politoed @ Life Orb  
Ability: Drizzle  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Weather Ball  
- Icy Wind  
- Helping Hand  
- Protect  

";
$svm42414 = "Volcarona @ Charti Berry  
Ability: Flame Body  
Tera Type: &
EVs: 252 HP / 228 Def / 28 Spe  
Bold Nature  
IVs: 0 Atk  
- Overheat  
- Bug Buzz  
- Rage Powder  
- Protect  

";
$svm42425 = "Tapu Fini @ Weakness Policy  
Ability: Misty Surge  
Tera Type: &
EVs: 180 HP / 252 SpA / 76 Spe  
Modest Nature  
IVs: 0 Atk  
- Scald  
- Moonblast  
- Icy Wind  
- Protect  

";
$svm42436 = "Victini @ Colbur Berry  
Ability: Victory Star  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Blue Flare  
- Psychic  
- Helping Hand  
- Protect  

";
$svm42447 = "Cresselia (F) @ Aguav Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 20 Def / 236 Spe  
Bold Nature  
IVs: 0 Atk  
- Psyshock  
- Icy Wind  
- Moonlight  
- Calm Mind  

";
$svm42458 = "Suicune @ Wacan Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 112 SpA / 88 SpD / 56 Spe  
Calm Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Tailwind  
- Protect  

";
$svm42469 = "Blaziken @ Blazikenite  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Flare Blitz  
- Superpower  
- Rock Slide  
- Protect  

";
$svm42479 = "Tapu Koko @ Shuca Berry  
Ability: Electric Surge  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hidden Power [Ice]  
- Taunt  
- Protect  

";
$svm42490 = "Kyurem-Black @ Life Orb  
Ability: Teravolt  
Tera Type: &
EVs: 112 Atk / 144 SpA / 252 Spe  
Hasty Nature  
- Ice Beam  
- Fusion Bolt  
- Earth Power  
- Protect  

";
$svm42500 = "Landorus-Therian (M) @ Yache Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Sludge Bomb  
- Hidden Power [Ice]  
- Protect  

";
$svm42511 = "Electabuzz @ Eviolite  
Ability: Static  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Electroweb  
- Helping Hand  
- Follow Me  
- Protect  

";
$svm42522 = "Camerupt @ Cameruptite  
Ability: Solid Rock  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Eruption  
- Earth Power  
- Flamethrower  
- Protect  

";
$svm42533 = "Suicune @ Mental Herb  
Ability: Inner Focus  
Tera Type: &
EVs: 216 HP / 4 Def / 212 SpA / 20 SpD / 56 Spe  
Calm Nature  
IVs: 0 Atk  
- Tailwind  
- Scald  
- Icy Wind  
- Protect  

";
$svm42544 = "Incineroar @ Assault Vest  
Ability: Intimidate  
Tera Type: &
EVs: 76 HP / 244 Atk / 4 Def / 8 SpD / 176 Spe  
Jolly Nature  
- Fake Out  
- Darkest Lariat  
- Flare Blitz  
- Thunder Punch  

";
$svm42554 = "Whimsicott @ Mental Herb  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 248 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Moonblast  
- Tailwind  
- Encore  
- Charm  

";
$svm42565 = "Gyarados @ Gyaradosite  
Ability: Intimidate  
Tera Type: &
EVs: 56 HP / 252 Atk / 200 Spe  
Adamant Nature  
- Dragon Dance  
- Waterfall  
- Crunch  
- Bulldoze  

";
$svm42575 = "Tapu Fini @ Haban Berry 
Ability: Misty Surge  
Tera Type: &
EVs: 248 HP / 128 Def / 52 SpA / 24 SpD / 56 Spe  
Bold Nature  
IVs: 0 Atk  
- Hydro Pump  
- Rain Dance  
- Moonblast  
- Calm Mind  

";
$svm42586 = "Xurkitree @ Iapapa Berry  
Ability: Beast Boost  
Tera Type: &
EVs: 184 HP / 252 SpA / 72 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Dazzling Gleam  
- Tail Glow  
- Protect  

";
$svm42597 = "Sceptile @ Sceptilite  
Ability: Overgrow  
Tera Type: &
EVs: 20 HP / 252 SpA / 4 SpD / 232 Spe  
Timid Nature  
IVs: 0 Atk  
- Frenzy Plant  
- Dragon Pulse  
- Energy Ball  
- Substitute  

";
$svm42608 = "Pelipper @ Assault Vest  
Ability: Drizzle  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Hurricane  
- Scald  
- Hidden Power [Fire]  
- Ice Beam  

";
$svm42619 = "Suicune @ Wiki Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 92 Def / 108 SpD / 56 Spe  
Calm Nature  
IVs: 0 Atk  
- Scald  
- Snarl  
- Tailwind  
- Calm Mind  

";
$svm42630 = "Tapu Bulu @ Occa Berry  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 HP / 56 Atk / 116 SpD / 84 Spe  
Adamant Nature  
- Wood Hammer  
- Rock Slide  
- Swords Dance  
- Protect  

";
$svm42640 = "Krookodile @ Choice Scarf  
Ability: Anger Point  
Tera Type: &
EVs: 252 Atk / 8 SpD / 248 Spe  
Jolly Nature  
- Earthquake  
- Rock Slide  
- Brutal Swing  
- Power Trip  

";
$svm42650 = "Bruxish @ Choice Scarf  
Ability: Dazzling  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
IVs: 0 SpA  
- Frost Breath  
- Psychic Fangs  
- Liquidation  
- Trick Room  

";
$svm42661 = "Raichu-Alola @ Life Orb  
Ability: Surge Surfer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Fake Out  
- Thunderbolt  
- Grass Knot  
- Psychic  

";
$svm42671 = "Slowbro @ Slowbronite  
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Sassy Nature  
IVs: 0 Spe  
- Trick Room  
- Disable  
- Scald  
- Me First  

";
$svm42682 = "Nihilego @ Choice Scarf  
Ability: Beast Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Power Gem  
- Grass Knot  
- Sludge Bomb  
- Dazzling Gleam  

";
$svm42693 = "Zapdos @ Assault Vest  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Heat Wave  
- Thunderbolt  
- Extrasensory  
- Signal Beam  

";
$svm42704 = "Scrafty @ Rocky Helmet  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Payback  
- Drain Punch  
- Fake Out  
- Bulk Up  

";
$svm42714 = "Victini @ Air Balloon  
Ability: Victory Star  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Blue Flare  
- Psychic  
- Helping Hand  
- Protect  

";
$svm42725 = "Metagross @ Steel Gem  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Meteor Mash  
- Earthquake  
- Bullet Punch  
- Protect  

";
$svm42735 = "Infernape @ Fire Gem  
Ability: Blaze  
Tera Type: &
EVs: 88 Atk / 168 SpA / 252 Spe  
Naive Nature  
- Fake Out  
- Overheat  
- Close Combat  
- Feint  

";
$svm42745 = "Togekiss @ Wacan Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 180 Def / 76 SpD  
Calm Nature  
IVs: 0 Atk  
- Air Slash  
- Tailwind  
- Follow Me  
- Protect  

";
$svm42756 = "Arcanine @ Fire Gem  
Ability: Intimidate  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Overheat  
- Heat Wave  
- Helping Hand  
- Protect  

";
$svm42767 = "Darkrai @ Dark Gem  
Ability: Bad Dreams  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Protect  
- Hypnosis  
- Focus Blast  

";
$svm42778 = "Liepard @ Dark Gem  
Ability: Prankster  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Night Slash  
- Encore  
- Protect  
- Fake Out  

";
$svm42788 = "Metagross @ Berserk Gene  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Meteor Mash  
- Stomping Tantrum  
- Bullet Punch  
- Protect  

";
$svm42798 = "Kyurem-Black @ Berserk Gene  
Ability: Teravolt  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Lonely Nature  
IVs: 0 HP / 0 Def  
- Outrage  
- Roost  
- Noble Roar  
- Roar  

";
$svm42809 = "Tinkaton (F) @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Gigaton Hammer  
- Knock Off  
- Ice Hammer  
- Protect  

";
$svm42819 = "Tyranitar @ Rock Gem  
Ability: Sand Stream  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Rock Slide  
- Earthquake  
- Protect  
- Dragon Dance  

";
$svm42829 = "Ferrothorn @ Steel Gem  
Ability: Iron Barbs  
Tera Type: &
EVs: 216 HP / 252 Atk / 40 SpD  
Brave Nature  
IVs: 0 Spe  
- Power Whip  
- Gyro Ball  
- Leech Seed  
- Protect  

";
$svm42840 = "Kabutops @ Rock Gem  
Ability: Swift Swim  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Waterfall  
- Stone Edge  
- Protect  
- Rock Slide  

";
$svm42850 = "Magmar @ Eviolite  
Ability: Flame Body  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Heat Wave  
- Helping Hand  
- Follow Me  
- Protect  

";
$svm42861 = "Thundurus (M) @ Electric Gem  
Ability: Prankster  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Thunder Wave  
- Substitute  
- Protect  

";
$svm42872 = "Indeedee-F (F) @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Body Slam  
- Fake Out  
- Mystical Fire  
- Baton Pass  

";
$svm42882 = "Tandemaus @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Population Bomb  
- Thunder Wave  
- Protect  
- Baton Pass  

";
$svm42892 = "Tandemaus @ Berserk Gene  
Ability: Pickup  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Population Bomb  
- Thunder Wave  
- Protect  
- Baton Pass  

";
$svm42902 = "Ambipom @ Berserk Gene  
Ability: Pickup  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Return  
- Knock Off  
- Protect  
- Fake Out  

";
$svm42912 = "Tandemaus @ Eviolite  
Ability: Own Tempo  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Population Bomb  
- Crunch  
- Low Kick  
- Thunder Wave  

";
$svm42922 = "Tandemaus @ Starf Berry  
Ability: Pickup  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Population Bomb  
- Crunch  
- Thunder Wave  
- Substitute  

";
$svm42932 = "Tandemaus @ Clear Amulet  
Ability: Pickup  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Population Bomb  
- Encore  
- Baton Pass  
- Agility  

";
$svm42942 = "Tandemaus @ Normalium Z  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Double-Edge  
- Beat Up  
- Feint  
- Baton Pass  

";
$svm42952 = "Tandemaus @ Liechi Berry  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Super Fang  
- Agility  
- Substitute  
- Baton Pass  

";
$svm42963 = "Tandemaus @ Heavy-Duty Boots  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Population Bomb  
- Encore  
- U-turn  
- Protect  

";
$svm42973 = "Tandemaus @ Wide Lens  
Ability: Own Tempo  
Tera Type: &
EVs: 248 HP / 220 Atk / 8 SpD / 32 Spe  
Jolly Nature  
- Protect  
- Population Bomb  
- Thunder Wave  
- Encore  

";
$svm42983 = "Manaphy @ Berserk Gene  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 68 Atk / 100 Def / 52 SpA / 4 SpD / 32 Spe  
Brave Nature  
IVs: 30 Def / 23 SpA  
- Tera Blast  
- Rest  
- Rain Dance  
- Tail Glow  

";
$svm42994 = "Manaphy @ Berserk Gene  
Ability: Hydration  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Stored Power  
- Rest  
- Rain Dance  
- Calm Mind  

";
$svm43005 = "Manaphy @ Berserk Gene  
Ability: Hydration  
Tera Type: &
EVs: 4 HP / 252 SpD / 252 Spe  
Jolly Nature  
IVs: 0 HP / 0 Def / 0 SpA / 0 SpD  
- Liquidation  
- Baton Pass  
- Acid Armor  
- Calm Mind  

";
$svm43016 = "Tandemaus @ Air Balloon  
Ability: Run Away  
Tera Type: &
EVs: 11 HP / 11 Atk / 11 Def / 223 SpA / 252 Spe  
IVs: 0 Atk / 20 SpD  
- Baton Pass  
- Encore  
- Agility  
- Protect  

";
$svm43026 = "Darkrai @ Heavy-Duty Boots  
Ability: Bad Dreams  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Knock Off  
- Will-O-Wisp  
- Ice Beam  
- Protect  

";
$svm43036 = "Darkrai @ Heavy-Duty Boots  
Ability: Bad Dreams  
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe  
Jolly Nature  
- Knock Off  
- Will-O-Wisp  
- Icy Wind  
- Substitute  

";
$svm43046 = "Darkrai @ Firium Z  
Ability: Bad Dreams  
Tera Type: &
EVs: 200 HP / 52 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dark Pulse  
- Sludge Bomb  
- Will-O-Wisp  
- Calm Mind  

";
$svm43057 = "Tinkaton (F) @ Shuca Berry  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 HP / 56 Def / 200 Spe  
Jolly Nature  
- Gigaton Hammer  
- Knock Off  
- Encore  
- Thunder Wave  

";
$svm43067 = "Reuniclus @ Sticky Barb  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Relaxed Nature  
- Psychic  
- Knock Off  
- Recover  
- Calm Mind  

";
$svm43077 = "Relicanth @ Rockium Z  
Ability: Sturdy  
Tera Type: &
EVs: 128 HP / 252 Atk / 128 Def  
Adamant Nature  
IVs: 0 SpA  
- Yawn  
- Protect  
- Head Smash  
- Waterfall  

";
$svm43088 = "Mew @ Normalium Z  
Ability: Synchronize  
Tera Type: &
EVs: 252 Spe  
Timid Nature  
IVs: 1 Atk  
- Transform  
- Taunt  
- Soft-Boiled  
- Reflect  

";
$svm43099 = "Jynx @ Fightinium Z  
Ability: Dry Skin  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Lovely Kiss  
- Substitute  
- Ice Beam  
- Focus Blast  

";
$svm43110 = "Oranguru @ Fightinium Z  
Ability: Inner Focus  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Quiet Nature  
IVs: 0 Spe  
- Trick Room  
- Nasty Plot  
- Psychic  
- Focus Blast  

";
$svm43121 = "Infernape @ Choice Scarf  
Ability: Blaze  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Jolly Nature  
- Flare Blitz  
- U-turn  
- Close Combat  
- Gunk Shot  

";
$svm43131 = "Simisage @ Micle Berry  
Ability: Gluttony  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 HP / 0 Atk  
- Grass Whistle  
- Substitute  
- Energy Ball  
- Leech Seed  

";
$svm43142 = "Espeon @ Psychium Z  
Ability: Magic Bounce  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Future Sight  
- Morning Sun  
- Reflect  
- Calm Mind  

";
$svm43153 = "Minior @ Rockium Z  
Ability: Shields Down  
Shiny: Yes  
Tera Type: &
EVs: 164 HP / 124 Atk / 4 SpD / 216 Spe  
Jolly Nature  
- Substitute  
- Acrobatics  
- Shell Smash  
- Stone Edge  

";
$svm43164 = "Onix @ Eviolite  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Protect  
- Rest  
- Toxic  
- Rock Tomb  

";
$svm43174 = "Mantyke @ Eviolite  
Ability: Swift Swim  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Air Slash  
- Amnesia  
- Toxic  
- Rest  

";
$svm43185 = "Amoonguss @ Choice Band  
Ability: Effect Spore  
Tera Type: &
EVs: 252 HP / 184 Atk / 72 SpD  
Adamant Nature  
- Seed Bomb  
- Stomping Tantrum  
- Foul Play  
- Body Slam  

";
$svm43195 = "Girafarig @ Choice Specs  
Ability: Inner Focus  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Psychic  
- Thunderbolt  
- Energy Ball  

";
$svm43206 = "Zebstrika @ Electrium Z  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Overheat  
- Thunder  
- Hidden Power [Ice]  
- Charge  

";
$svm43217 = "Klang @ Eviolite  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 172 SpD / 84 Spe  
Careful Nature  
- Iron Defense  
- Rest  
- Confide  
- Bind  

";
$svm43227 = "Yanmega @ Buginium Z  
Ability: Tinted Lens  
Tera Type: &
EVs: 8 HP / 252 SpA / 248 Spe  
Modest Nature  
IVs: 0 Atk  
- Bug Buzz  
- Laser Focus  
- Substitute  
- Roost  

";
$svm43238 = "Gourgeist @ Ghostium Z  
Ability: Frisk  
Tera Type: &
EVs: 100 HP / 232 Atk / 56 SpD / 120 Spe  
Adamant Nature  
- Trick-or-Treat  
- Phantom Force  
- Bullet Seed  
- Substitute  

";
$svm43248 = "Clefable @ Psychium Z  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def  
Bold Nature  
IVs: 0 Atk  
- Counter  
- Magic Coat  
- Moonblast  
- Moonlight  

";
$svm43259 = "Ribombee @ Buginium Z  
Ability: Sweet Veil  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Hasty Nature  
IVs: 0 Atk  
- Quiver Dance  
- Moonblast  
- Pollen Puff  
- Roost  

";
$svm43270 = "Skarmory @ Flyinium Z  
Ability: Keen Eye  
Tera Type: &
EVs: 232 HP / 252 Atk / 24 Spe  
Adamant Nature  
- Brave Bird  
- Endure  
- Swords Dance  
- Rock Tomb  

";
$svm43280 = "Virizion @ Fightinium Z  
Ability: Justified  
Tera Type: &
EVs: 192 Def / 164 SpA / 152 Spe  
Timid Nature  
IVs: 0 Atk  
- Giga Drain  
- Focus Blast  
- Taunt  
- Calm Mind  

";
$svm43291 = "Seismitoad @ Chesto Berry  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Gastro Acid  
- Toxic  
- Confide  
- Rest  

";
$svm43302 = "Granbull @ Fairium Z  
Ability: Intimidate  
Tera Type: &
EVs: 28 HP / 224 Atk / 180 Def / 76 SpD  
Adamant Nature  
- Play Rough  
- Charm  
- Rest  
- Bulk Up  

";
$svm43312 = "Crobat @ Flyinium Z  
Ability: Infiltrator  
Tera Type: &
EVs: 80 HP / 252 Atk / 176 Spe  
Adamant Nature  
- Taunt  
- Roost  
- Brave Bird  
- Toxic  

";
$svm43322 = "Chesnaught @ Grassium Z  
Ability: Overgrow  
Tera Type: &
EVs: 248 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Wood Hammer  
- Bulk Up  
- Drain Punch  
- Toxic  

";
$svm43332 = "Altaria @ Altarianite  
Ability: Cloud Nine  
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe  
Bold Nature  
IVs: 0 Atk  
- Hyper Voice  
- Cotton Guard  
- Roost  
- Toxic  

";
$svm43343 = "Slowbro @ Slowbronite  
Ability: Oblivious  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Slack Off  
- Iron Defense  
- Foul Play  
- Amnesia  

";
$svm43354 = "Toxapex @ Psychium Z  
Ability: Merciless  
Tera Type: &
EVs: 248 HP / 116 Def / 144 SpD  
Bold Nature  
IVs: 0 Atk  
- Iron Defense  
- Recover  
- Light Screen  
- Scald  

";
$svm43365 = "Marowak-Alola @ Thick Club  
Ability: Lightning Rod  
Tera Type: &
EVs: 248 HP / 184 Atk / 68 Def / 8 Spe  
Adamant Nature  
- Flare Blitz  
- Shadow Bone  
- Swords Dance  
- Flame Charge  

";
$svm43375 = "Hoopa @ Ghostium Z  
Ability: Magician  
Tera Type: &
EVs: 248 HP / 24 SpA / 4 SpD / 232 Spe  
Modest Nature  
IVs: 0 Atk  
- Shadow Ball  
- Calm Mind  
- Substitute  

";
$svm43385 = "Komala @ Normalium Z  
Ability: Comatose  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Yawn  
- Swords Dance  
- Protect  
- Thrash  

";
$svm43395 = "Slurpuff @ Iapapa Berry  
Ability: Unburden  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Cotton Guard  
- Draining Kiss  
- Fake Tears  

";
$svm43406 = "Volbeat @ Normalium Z  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Infestation  
- Confide  
- Roost  
- Encore  

";
$svm43417 = "Shedinja @ Darkinium Z  
Ability: Wonder Guard  
Tera Type: &
EVs: 252 Atk / 252 Spe  
Adamant Nature  
- Hone Claws  
- X-Scissor  
- Night Slash  
- Toxic  

";
$svm43427 = "Pangoro @ Mago Berry  
Ability: Iron Fist  
Tera Type: &
EVs: 244 HP / 252 Atk / 8 Def / 4 Spe  
Adamant Nature  
- Drain Punch  
- Bulk Up  
- Taunt  
- Thunder Punch  
- Psychic  

";
$svm43438 = "Garbodor @ Assault Vest  
Ability: Weak Armor  
Tera Type: &
EVs: 220 HP / 192 Atk / 96 SpD  
Adamant Nature  
- Gunk Shot  
- Rock Blast  
- Giga Impact  
- Seed Bomb  

";
$svm43448 = "Conkeldurr @ Assault Vest  
Ability: Sheer Force  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Fire Punch  
- Rock Slide  
- Mach Punch  
- Earthquake  

";
$svm43458 = "Starmie @ Waterium Z  
Ability: Analytic  
Tera Type: &
EVs: 40 Def / 252 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Rain Dance  
- Substitute  
- Hydro Pump  
- Ice Beam  

";
$svm43469 = "Zygarde @ Dragonium Z  
Ability: Power Construct  
Tera Type: &
EVs: 144 HP / 68 Atk / 40 Def / 108 SpD / 148 Spe  
Careful Nature  
- Rest  
- Outrage  
- Bulldoze  
- Confide  

";
$svm43479 = "Zygarde @ Dragonium Z  
Ability: Power Construct  
Tera Type: &
EVs: 144 HP / 112 Atk / 40 Def / 28 SpD / 184 Spe  
Careful Nature  
- Rest  
- Outrage  
- Coil  
- Confide  

";
$svm43489 = "Suicune @ Waterium Z  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 16 Def / 96 SpA / 148 SpD  
Calm Nature  
IVs: 0 Atk  
- Rain Dance  
- Hydro Pump  
- Whirlpool  
- Mirror Coat  

";
$svm43500 = "Heracross @ Heracronite  
Ability: Guts  
Tera Type: &
EVs: 244 HP / 168 Def / 96 SpD  
Impish Nature  
IVs: 0 SpA  
- Close Combat  
- Bullet Seed  
- Pin Missile  
- Counter  

";
$svm43511 = "Avalugg @ Custap Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def  
Serious Nature  
- Mirror Coat  
- Avalanche  
- Earthquake  
- Superpower  

";
$svm43521 = "Rhyperior (M) @ Groundium Z  
Ability: Solid Rock  
Tera Type: &
EVs: 248 HP / 88 Atk / 172 Def  
Adamant Nature  
IVs: 0 SpA  
- Counter  
- Rock Wrecker  
- Earthquake  
- Curse  

";
$svm43532 = "Donphan @ Groundium Z  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 252 Spe  
Adamant Nature  
- Earthquake  
- Endeavor  
- Counter  
- Ice Shard  

";
$svm43542 = "Aurorus @ Air Balloon  
Ability: Refrigerate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Thunder Wave  
- Mirror Coat  
- Earth Power  

";
$svm43553 = "Aggron @ Aggronite  
Ability: Sturdy  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 12 Def / 244 SpD  
Relaxed Nature  
IVs: 0 SpA / 0 Spe  
- Protect  
- Heavy Slam  
- Metal Burst  
- Curse  

";
$svm43565 = "Celesteela @ Occa Berry  
Ability: Beast Boost  
Tera Type: &
EVs: 252 HP / 156 Atk / 100 SpA  
Brave Nature  
- Substitute  
- Earthquake  
- Flash Cannon  
- Hidden Power [Ice]  

";
$svm43575 = "Palossand @ Groundium Z  
Ability: Water Compaction  
Tera Type: &
EVs: 252 HP / 152 Def / 104 SpD  
Calm Nature  
IVs: 0 Atk  
- Amnesia  
- Earth Power  
- Shore Up  
- Iron Defense  

";
$svm43586 = "Kartana @ Fightinium Z  
Ability: Beast Boost  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Smart Strike  
- Iron Defense  
- Sacred Sword  
- Synthesis  

";
$svm43596 = "Milotic @ Maranga Berry  
Ability: Marvel Scale  
IVs: 0 Atk  
- Recover  
- Magic Coat  
- Taunt  
- Psych Up  
- Scald  

";
$svm43606 = "Magearna @ Steelium Z  
Ability: Soul-Heart  
Tera Type: &
EVs: 140 HP / 32 Def / 228 SpA / 108 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Flash Cannon  
- Aura Sphere  
- Pain Split  

";
$svm43617 = "Muk-Alola @ Aguav Berry  
Ability: Poison Touch  
- Snarl  
- Recycle  
- Belch  
- Toxic  

";
$svm43625 = "Gengar @ Fightinium Z  
Ability: Cursed Body  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Focus Blast  
- Hypnosis  
- Hex  
- Sludge Wave  

";
$svm43636 = "Mienshao @ Rockium Z  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 40 Def / 216 Spe  
Jolly Nature  
- Fake Out  
- Stone Edge  
- Bulk Up  
- High Jump Kick  

";
$svm43646 = "Latias (F) @ Latiasite  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Toxic  
- Protect  
- Draco Meteor  

";
$svm43657 = "PA-PA 🌩🌩🌩 (Magearna) @ Fairium Z  
Ability: Soul-Heart  
Tera Type: &
EVs: 252 HP / 252 Def  
Bold Nature  
IVs: 0 Atk  
- Trick Room  
- Fleur Cannon  
- Substitute  
- Hidden Power [Fire]  

";
$svm43668 = "Volcanion @ Choice Scarf  
Ability: Water Absorb  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Steam Eruption  
- Overheat  
- Hidden Power [Rock]  
- Sludge Wave  

";
$svm43679 = "Zygarde @ Groundium Z  
Ability: Power Construct  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Coil  
- Substitute  
- Thousand Arrows  
- Rest  

";
$svm43689 = "Mudsdale @ Assault Vest  
Ability: Stamina  
Tera Type: &
EVs: 124 HP / 132 Atk / 252 SpD  
Adamant Nature  
- Earthquake  
- Heavy Slam  
- Close Combat  
- Rock Slide  

";
$svm43699 = "Mew @ Fightinium Z  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 36 Def / 152 SpA / 72 SpD  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Psyshock  
- Focus Blast  
- Soft-Boiled  

";
$svm43710 = "Mawile @ Mawilite  
Ability: Hyper Cutter  
Tera Type: &
EVs: 252 Atk / 48 Def / 208 SpD  
Adamant Nature  
- Play Rough  
- Swords Dance  
- Foul Play  
- Taunt  

";
$svm43720 = "Reuniclus @ Iapapa Berry  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Iron Defense  
- Recover  
- Psyshock  

";
$svm43731 = "Tornadus (M) @ Normalium Z  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Hurricane  
- Rest  
- Sleep Talk  
- Substitute  

";
$svm43742 = "Exeggutor @ Iapapa Berry  
Ability: Harvest  
Tera Type: &
EVs: 244 HP / 40 Def / 224 SpD  
Calm Nature  
IVs: 0 Atk  
- Protect  
- Substitute  
- Leech Seed  
- Psywave  

";
$svm43753 = "Mudbray @ Berserk Gene  
Ability: Own Tempo  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- High Horsepower  
- Stone Edge  
- Close Combat  
- Protect  

";
$svm43763 = "Dragonite @ Haban Berry  
Ability: Inner Focus  
Tera Type: &
EVs: 252 HP / 52 SpD / 204 Spe  
Bold Nature  
IVs: 30 HP / 2 Atk / 30 Def / 30 SpA / 30 SpD  
- Draco Meteor  
- Hidden Power [Flying]  
- Tailwind  
- Protect  

";
$svm43774 = "Raikou @ Electric Gem  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 2 Atk  
- Thunderbolt  
- Hidden Power [Dragon]  
- Calm Mind  
- Protect  

";
$svm43785 = "Tauros (M) @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 1 HP  
- Return  
- Toxic  
- Protect  
- Substitute  

";
$svm43794 = "Whimsicott @ Life Orb  
Ability: Chlorophyll  
Tera Type: &
EVs: 176 HP / 252 SpA / 80 Spe  
Modest Nature  
- Moonblast  
- Giga Drain  
- Shadow Ball  
- Growth  

";
$svm43804 = "Walking Wake @ Assault Vest  
Ability: Protosynthesis  
Tera Type: &
EVs: 228 HP / 132 SpA / 148 Spe  
Timid Nature  
- Hydro Steam  
- Draco Meteor  
- Knock Off  
- Flip Turn  

";
$svm43814 = "Ninetales @ Heat Rock  
Ability: Drought  
Tera Type: &
EVs: 248 HP / 20 Def / 240 Spe  
Timid Nature  
- Weather Ball  
- Will-O-Wisp  
- Encore  
- Healing Wish  

";
$svm43824 = "Ninetales @ Choice Scarf  
Ability: Flash Fire  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Night Shade  
- Encore  
- Healing Wish  
- Reflect  

";
$svm43835 = "Celesteela @ Assault Vest  
Ability: Beast Boost  
Tera Type: &
EVs: 224 HP / 248 Atk / 36 Spe  
Adamant Nature  
- Heavy Slam  
- Earthquake  
- Flamethrower  
- Explosion  

";
$svm43845 = "Nihilego @ Focus Sash  
Ability: Beast Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Power Gem  
- Hidden Power [Fire]  
- Toxic Spikes  
- Stealth Rock  

";
$svm43856 = "Ceruledge @ Choice Band  
Ability: Flash Fire  
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe  
Adamant Nature  
- Bitter Blade  
- Solar Blade  
- Poltergeist  
- Shadow Sneak  

";
$svm43866 = "Weavile @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 168 Atk / 84 Def / 4 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Upper Hand  
- Ice Punch  
- Swords Dance  

";
$svm43876 = "Incineroar @ Heavy-Duty Boots  
Ability: Intimidate  
Tera Type: &
EVs: 156 HP / 100 Atk / 252 Spe  
Jolly Nature  
- Drain Punch  
- Knock Off  
- Will-O-Wisp  
- Parting Shot  

";
$svm43886 = "Blaziken @ Muscle Band  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Knock Off  
- Upper Hand  
- Swords Dance  

";
$svm43896 = "Lopunny @ Assault Vest  
Ability: Cute Charm  
Tera Type: &
EVs: 240 HP / 20 Atk / 32 SpA / 216 Spe  
Hasty Nature  
- Mirror Coat  
- Water Pulse  
- Return  
- Fake Out  

";
$svm43906 = "Lopunny @ Heavy-Duty Boots  
Ability: Limber  
Tera Type: &
EVs: 236 HP / 16 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Fake Out  
- Encore  
- Heal Bell  
- U-turn  

";
$svm43916 = "Abomasnow @ Weakness Policy  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe  
Bold Nature  
- Aurora Veil  
- Blizzard  
- Giga Drain  
- Ice Shard  

";
$svm43926 = "Abomasnow @ Weakness Policy  
Ability: Snow Warning  
Tera Type: &
EVs: 8 HP / 252 Def / 72 SpA / 176 Spe  
Bold Nature  
IVs: 0 Atk  
- Aurora Veil  
- Blizzard  
- Giga Drain  
- Leaf Storm  

";
$svm43937 = "Abomasnow @ Berserk Gene  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Wood Hammer  
- Ice Spinner  
- Stomping Tantrum  
- Ice Shard  

";
$svm43947 = "Abomasnow @ Abomasite  
Ability: Snow Warning  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Toxic  
- Hidden Power [Fire]  
- Protect  

";
$svm43958 = "Abomasnow @ Fightinium Z  
Ability: Snow Warning  
Tera Type: &
EVs: 252 Atk / 8 SpD / 248 Spe  
Adamant Nature  
- Icicle Spear  
- Trailblaze  
- Focus Punch  
- Swords Dance  

";
$svm43968 = "Abomasnow @ Mirror Herb  
Ability: Snow Warning  
Tera Type: &
EVs: 100 HP / 12 Atk / 100 Def / 116 SpA / 100 SpD / 80 Spe  
Brave Nature  
- Giga Drain  
- Blizzard  
- Trailblaze  
- Ice Spinner  

";
$svm43978 = "Victini @ Darkinium Z  
Ability: Victory Star  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Baton Pass  
- Encore  
- Fling  
- Power-Up Punch  

";
$svm43988 = "Walking Wake @ Dragonium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Draco Meteor  
- Scald  
- Flip Turn  
- Protect  

";
$svm43998 = "Garganacl @ Assault Vest  
Ability: Purifying Salt  
Tera Type: &
EVs: 252 HP / 160 Atk / 96 Def  
Adamant Nature  
- Salt Cure  
- Heavy Slam  
- Earthquake  
- Avalanche  

";
$svm44008 = "Walking Wake @ Waterium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Hydro Pump  
- Flamethrower  
- Knock Off  
- Protect  

";
$svm44018 = "Walking Wake @ Leftovers  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Naive Nature  
- Knock Off  
- Whirlpool  
- Substitute  
- Protect  

";
$svm44028 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Naive Nature  
IVs: 0 Atk  
- Dragon Pulse  
- Whirlpool  
- Substitute  
- Protect  

";
$svm44039 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 96 HP / 160 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Weather Ball  
- Mud Shot  
- Noble Roar  
- Protect  

";
$svm44050 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Adamant Nature  
- Liquidation  
- Knock Off  
- Protect  
- Dragon Dance  

";
$svm44060 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Adamant Nature  
- Dragon Rush  
- Substitute  
- Protect  
- Dragon Dance  

";
$svm44070 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Outrage  
- Sleep Talk  
- Rest  
- Dragon Dance  

";
$svm44080 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
- Scald  
- Knock Off  
- Sleep Talk  
- Rest  

";
$svm44090 = "Walking Wake @ Heavy-Duty Boots  
Ability: Protosynthesis  
Tera Type: &
EVs: 168 HP / 84 Atk / 84 Def / 84 SpA / 88 SpD  
Timid Nature  
- Dragon Rush  
- Hydro Steam  
- Flamethrower  
- Hone Claws  

";
$svm44100 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 196 HP / 252 Def / 60 Spe  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Dragon Cheer  
- Roar  
- Protect  

";
$svm44111 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 128 Atk / 252 SpD / 128 Spe  
Careful Nature  
- Breaking Swipe  
- Liquidation  
- Dragon Dance  
- Protect  

";
$svm44121 = "Walking Wake @ Heavy-Duty Boots  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Agility  
- Rest  
- Sleep Talk  
- Hydro Steam  

";
$svm44132 = "Walking Wake @ Air Balloon  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Naive Nature  
- Whirlpool  
- Breaking Swipe  
- Rest  
- Protect  

";
$svm44142 = "Walking Wake @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 84 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Whirlpool  
- Knock Off  
- Breaking Swipe  
- Dragon Dance  

";
$svm44152 = "Walking Wake @ Weakness Policy  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 4 Atk / 44 Def / 200 SpA / 8 Spe  
- Body Slam  
- Aqua Jet  
- Mud Shot  
- Hydro Pump  

";
$svm44161 = "Walking Wake @ Darkinium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Waterfall  
- Crunch  
- Protect  
- Dragon Dance  

";
$svm44171 = "Walking Wake @ Choice Band  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Knock Off  
- Flip Turn  
- Liquidation  
- Dragon Claw  

";
$svm44181 = "Walking Wake @ Chesto Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 28 HP / 228 Def / 60 SpA / 192 Spe  
Bold Nature  
IVs: 0 Atk  
- Hydro Steam  
- Flamethrower  
- Rest  
- Sunny Day  

";
$svm44192 = "Walking Wake @ Maranga Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 168 HP / 252 Def / 88 SpA  
Bold Nature  
IVs: 0 Atk  
- Hydro Steam  
- Flamethrower  
- Rest  
- Sleep Talk  

";
$svm44203 = "Walking Wake @ Life Orb  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Surf  

";
$svm44211 = "Walking Wake @ Sticky Barb  
Ability: Protosynthesis  
Tera Type: &
EVs: 204 HP / 52 SpA / 252 Spe  
Timid Nature  
- Scald  
- Knock Off  
- Flip Turn  
- Flamethrower  

";
$svm44221 = "Walking Wake @ Dragonium Z  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Draco Meteor  
- Flamethrower  
- Agility  

";
$svm44232 = "Walking Wake @ Rocky Helmet  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Breaking Swipe  
- Rest  
- Sleep Talk  
- Dragon Dance  

";
$svm44242 = "Walking Wake @ Aguav Berry  
Ability: Protosynthesis  
Tera Type: &
EVs: 84 HP / 168 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Whirlpool  
- Scary Face  
- Protect  

";
$svm44253 = "Landorus (M) @ Choice Specs  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Sandsear Storm  
- Sleep Talk  

";
$svm44262 = "Landorus (M) @ Choice Scarf  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Sandsear Storm  
- Sleep Talk  

";
$svm44271 = "Landorus (M) @ Leftovers  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Sandsear Storm  
- Rest  
- Sleep Talk  
- Protect  

";
$svm44282 = "Thundurus (M) @ Choice Specs  
Ability: Prankster  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Wildbolt Storm  
- Sleep Talk  

";
$svm44291 = "Thundurus (M) @ Choice Scarf  
Ability: Prankster  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Wildbolt Storm  
- Sleep Talk  

";
$svm44300 = "Thundurus (M) @ Leftovers  
Ability: Prankster  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Wildbolt Storm  
- Rest  
- Sleep Talk  
- Protect  

";
$svm44311 = "Tornadus (M) @ Leftovers  
Ability: Prankster  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Bleakwind Storm  
- Rest  
- Sleep Talk  
- Protect  

";
$svm44322 = "Tornadus-Therian (M) @ Leftovers  
Ability: Regenerator  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Bleakwind Storm  
- Rest  
- Sleep Talk  
- Protect  

";
$svm44333 = "Salamence @ Salamencite  
Ability: Intimidate  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk / 30 Def  
- Hyper Voice  
- Flamethrower  
- Hidden Power [Ice]  
- Protect  

";
$svm44344 = "Ninetales-Alola @ Light Clay  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Helping Hand  
- Blizzard  
- Protect  
- Aurora Veil  

";
$svm44355 = "Kyurem @ Assault Vest  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 96 SpA / 180 Spe  
Modest Nature  
IVs: 0 Atk  
- Flash Cannon  
- Blizzard  
- Earth Power  
- Glaciate  

";
$svm44366 = "Raging Bolt @ Assault Vest  
Ability: Protosynthesis  
Tera Type: &
EVs: 132 HP / 140 Def / 100 SpA / 60 SpD / 76 Spe  
Modest Nature  
IVs: 20 Atk  
- Thunderclap  
- Draco Meteor  
- Electroweb  
- Snarl  

";
$svm44377 = "Iron Crown @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 52 HP / 252 SpA / 204 Spe  
Modest Nature  
IVs: 20 Atk  
- Tachyon Cutter  
- Psychic Noise  
- Focus Blast  
- Calm Mind  

";
$svm44388 = "Dedenne @ Assault Vest  
Ability: Pickup  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Hasty Nature  
- Draining Kiss  
- Nuzzle  
- Dig  
- U-turn  

";
$svm44398 = "Dedenne @ Starf Berry  
Ability: Cheek Pouch  
Tera Type: &
EVs: 244 HP / 12 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Draining Kiss  
- Toxic  
- Substitute  

";
$svm44409 = "Dedenne @ Electrium Z  
Ability: Plus  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Thunder  
- Draining Kiss  
- Protect  
- Nuzzle  

";
$svm44419 = "Dedenne @ Electrium Z  
Ability: Cheek Pouch  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Modest Nature  
- Thunder  
- Toxic  
- U-turn  
- Protect  

";
$svm44429 = "Vikavolt @ Electrium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 44 Def / 212 SpA  
Modest Nature  
IVs: 0 Atk  
- Zap Cannon  
- Roost  
- Sticky Web  
- Protect  

";
$svm44440 = "Remoraid @ Choice Band  
Ability: Hustle  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Gunk Shot  
- Waterfall  
- Seed Bomb  
- Rock Blast  

";
$svm44450 = "Remoraid @ Scope Lens  
Ability: Sniper  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Mud-Slap  
- Focus Energy  
- Protect  

";
$svm44461 = "Remoraid @ Eviolite  
Ability: Sniper  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Surf  
- Ice Beam  
- Focus Energy  
- Protect  

";
$svm44472 = "Remoraid @ Eviolite  
Ability: Moody  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Ice Beam  
- Substitute  
- Protect  

";
$svm44483 = "Yamper @ Eviolite  
Ability: Ball Fetch  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
- Snarl  
- Nuzzle  
- Roar  
- Protect  

";
$svm44493 = "Corviknight @ Maranga Berry  
Ability: Pressure  
Tera Type: &
EVs: 204 HP / 224 SpD / 80 Spe  
Calm Nature  
IVs: 0 Atk  
- Taunt  
- Roost  
- Agility  
- Spite  

";
$svm44504 = "Deoxys-Speed @ Rocky Helmet  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 216 Def / 44 Spe  
Bold Nature  
IVs: 0 Atk  
- Stealth Rock  
- Iron Defense  
- Thunder Wave  
- Taunt  

";
$svm44515 = "Incineroar @ Rocky Helmet  
Ability: Intimidate  
Tera Type: &
EVs: 248 HP / 32 Atk / 160 SpD / 68 Spe  
Careful Nature  
- Flare Blitz  
- Knock Off  
- Will-O-Wisp  
- Fake Out  

";
$svm44525 = "Iron Bundle @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 212 SpA / 44 SpD / 252 Spe  
Modest Nature  
- Freeze-Dry  
- Icy Wind  
- Ice Spinner  
- Protect  

";
$svm44535 = "Gholdengo @ Electrium Z  
Ability: Good as Gold  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Make It Rain  
- Hex  
- Thunder  
- Nasty Plot  

";
$svm44546 = "Iron Crown @ Choice Scarf  
Ability: Quark Drive  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 20 Atk  
- Tachyon Cutter  
- Psyshock  
- Focus Blast  
- Volt Switch  

";
$svm44557 = "Bisharp (M) @ Darkinium Z  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Knock Off  
- Iron Head  
- Sucker Punch  
- Swords Dance  

";
$svm44567 = "Entei @ Heavy-Duty Boots  
Ability: Inner Focus  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Extreme Speed  
- Sacred Fire  
- Stone Edge  
- Double-Edge  

";
$svm44577 = "Chesnaught @ Sticky Barb  
Ability: Bulletproof  
Tera Type: &
EVs: 252 HP / 204 Def / 52 Spe  
Impish Nature  
- Body Press  
- Knock Off  
- Spikes  
- Synthesis  

";
$svm44587 = "Volcanion @ Heavy-Duty Boots  
Ability: Water Absorb  
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Flamethrower  
- Steam Eruption  
- Roar  
- Earth Power  

";
$svm44598 = "Muk-Alola @ Leftovers  
Ability: Poison Touch  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Poison Jab  
- Knock Off  
- Rest  
- Sleep Talk  

";
$svm44608 = "Bronzong @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Body Press  
- Psychic Noise  
- Iron Defense  
- Stealth Rock  

";
$svm44619 = "Oricorio-Pom-Pom @ Heavy-Duty Boots  
Ability: Dancer  
Tera Type: &
EVs: 248 HP / 228 Def / 32 Spe  
Bold Nature  
IVs: 0 Atk  
- Quiver Dance  
- Taunt  
- Roost  
- Air Slash  

";
$svm44630 = "Basculegion (M) @ Heavy-Duty Boots  
Ability: Adaptability  
Tera Type: &
EVs: 216 Atk / 100 SpA / 192 Spe  
Lonely Nature  
- Wave Crash  
- Flip Turn  
- Shadow Ball  
- Aqua Jet  

";
$svm44640 = "Jirachi @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 160 SpD / 96 Spe  
Timid Nature  
- Stealth Rock  
- Psychic Noise  
- Encore  
- U-turn  

";
$svm44650 = "Cyclizar @ Assault Vest  
Ability: Regenerator  
Tera Type: &
EVs: 140 HP / 192 SpD / 176 Spe  
Jolly Nature  
- Dragon Tail  
- Knock Off  
- U-turn  
- Rapid Spin  

";
$svm44660 = "Registeel @ Rocky Helmet  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Stealth Rock  
- Thunder Wave  
- Body Press  
- Heavy Slam  

";
$svm44670 = "Slowbro @ Eject Button  
Ability: Regenerator  
Tera Type: &
EVs: 232 HP / 252 Def / 24 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Slack Off  
- Scald  
- Psyshock  

";
$svm44681 = "Alakazam @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Hyper Beam  
- Zap Cannon  
- Nasty Plot  

";
$svm44692 = "Alakazam @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 64 HP / 252 Def / 192 Spe  
Bold Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Barrier  
- Recover  
- Calm Mind  

";
$svm44703 = "Alakazam @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 64 HP / 252 Def / 192 Spe  
Bold Nature  
IVs: 0 Atk  
- Hyper Beam  
- Barrier  
- Recover  
- Calm Mind  

";
$svm44714 = "Alakazam @ Alakazite  
Ability: Magic Guard  
Tera Type: &
EVs: 64 HP / 252 Def / 192 Spe  
Bold Nature  
IVs: 0 Atk  
- Charge Beam  
- Barrier  
- Recover  
- Encore  

";
$svm44725 = "Heracross @ Heracronite  
Ability: Moxie  
Tera Type: &
EVs: 156 HP / 252 Atk / 100 Spe  
Adamant Nature  
- Focus Punch  
- Toxic  
- Substitute  
- Bulk Up  

";
$svm44735 = "Alakazam @ Iron Ball  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Focus Blast  
- Thunder Wave  
- Trick  

";


$ggitsover = "Jirachi @ Expert Belt  
Ability: Serene Grace  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Stealth Rock  
- Flash Cannon  
- Psychic  
- Thunder

";
$mt43 = "Alomomola @ Choice Band  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Liquidation  
- Flip Turn  
- Knock Off  
- Aqua Jet  

";
$mt413 = "Iron Crown @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Swords Dance  
- Sacred Sword  
- Iron Head  
- Psycho Cut  

";
$mt423 = "Avalugg-Hisui @ Weakness Policy  
Ability: Sturdy  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Rock Polish  
- Mountain Gale  
- Earthquake  
- Stone Edge  

";
$mt433 = "Zeraora @ Expert Belt  
Ability: Volt Absorb  
Tera Type: &
EVs: 252 Atk / 40 SpA / 216 Spe  
Naughty Nature  
- Plasma Fists  
- Grass Knot  
- Close Combat  
- Volt Switch  

";
$mt443 = "Iron Boulder @ Booster Energy  
Ability: Quark Drive  
Tera Type: &
EVs: 112 HP / 252 Atk / 144 Spe  
Jolly Nature  
- Iron Defense  
- Swords Dance  
- Mighty Cleave  
- Earthquake  

";
$mt453 = "Terapagos @ Heavy-Duty Boots  
Ability: Tera Shift  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Toxic  
- Roar  
- Rapid Spin  
- Tera Starstorm  

";
$mt463 = "Walking Wake @ Rocky Helmet  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Relaxed Nature  
- Scald  
- Flip Turn  
- Draco Meteor  
- Knock Off  

";
$mt473 = "Zeraora @ Shuca Berry  
Ability: Volt Absorb  
Tera Type: &
EVs: 36 HP / 252 Atk / 4 SpD / 216 Spe  
Adamant Nature  
- Knock Off  
- Toxic  
- Plasma Fists  
- Close Combat  

";
$mt482 = "Darmanitan-Galar (M) @ Salac Berry  
Ability: Zen Mode  
Shiny: Yes  
Tera Type: &
EVs: 4 HP / 252 Atk / 24 SpD / 228 Spe  
Jolly Nature  
- Stone Edge  
- Fire Punch  
- Belly Drum  
- Substitute  

";
$mt492 = "Voltorb @ Focus Sash  
Ability: Aftermath  
Shiny: Yes  
Tera Type: &
EVs: 228 HP / 252 SpA / 28 Spe  
Modest Nature  
IVs: 0 Atk / 30 Def  
- Mirror Coat  
- Hidden Power [Ice]  
- Volt Switch  
- Taunt

";
$mt4103 = "Skarmory @ Black Belt  
Ability: Sturdy  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 1 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Defog  
- Roost  
- Spikes  
- Hidden Power [Fighting]

";
$mt4114 = "Jirachi @ Metronome  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 128 Atk / 128 SpD  
Adamant Nature  
- Thunder Wave  
- Stealth Rock  
- Iron Head  
- Heart Stamp  

";
$mt4123 = "Mew @ Leftovers  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Seismic Toss  
- Roost  
- Thunder Wave  
- Super Fang  

";
$mt4133 = "Victini @ Life Orb  
Ability: Victory Star  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- V-create  
- Bolt Strike  
- Thunder Wave  
- U-turn  

";
$mt4142 = "Latios (M) @ Life Orb  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 1 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Draco Meteor  
- Psyshock  
- Thunder Wave  
- Hidden Power [Fighting]  

";
$mt4152 = "Meloetta @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Substitute  
- Calm Mind  
- Protect  
- Hyper Voice  

";
$mt4162 = "Carbink @ Light Clay  
Ability: Sturdy  
Tera Type: &
EVs: 248 HP / 8 Atk / 128 Def / 124 SpD  
Careful Nature  
- Stealth Rock  
- Light Screen  
- Reflect  
- Explosion  

";
$mt4171 = "Tyranitar @ Tyranitarite  
Ability: Sand Stream  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Stone Edge  
- Earthquake  
- Crunch  

";
$mt4180 = "Barbaracle @ White Herb  
Ability: Tough Claws  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Shell Smash  
- Razor Shell  
- Stone Edge  
- Superpower  

";
$mt4189 = "Crustle @ Red Card  
Ability: Sturdy  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Shell Smash  
- Endure  
- Stone Edge  
- Earthquake  

";
$mt4198 = "Terrakion @ Salac Berry  
Ability: Justified  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Swords Dance  
- Substitute  
- Stone Edge  
- Close Combat  

";
$mt4207 = "Hawlucha @ Eject Button  
Ability: Mold Breaker  
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Jolly Nature  
- Encore  
- Endeavor  
- Tailwind  
- U-turn  

";
$mt4216 = "Medicham @ Choice Band  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- High Jump Kick  
- Zen Headbutt  
- Poison Jab  
- Ice Punch  

";
$mt4225 = "Gallade (M) @ Galladite  
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Close Combat  
- Knock Off  
- Wish  

";
$mt4234 = "Infernape @ Focus Sash  
Ability: Blaze  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Stealth Rock  
- Endeavor  
- Encore  
- U-turn  

";
$mt4243 = "Mienshao @ Choice Band  
Ability: Reckless  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- High Jump Kick  
- Knock Off  
- U-turn  
- Stone Edge  

";
$mt4252 = "Clefable @ Choice Specs  
Ability: Unaware  
Tera Type: &
EVs: 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Moonblast  
- Fire Blast  
- Ice Beam  
- Thunder  

";
$mt4262 = "Diancie @ Diancite  
Ability: Clear Body
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Protect  
- Substitute  
- Endeavor  
- Stealth Rock  

";
$mt4272 = "Togekiss @ Choice Specs  
Ability: Serene Grace  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Air Slash  
- Dazzling Gleam  
- Fire Blast  
- Aura Sphere  

";
$mt4282 = "Sylveon @ Choice Specs  
Ability: Pixilate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk / 30 SpA / 30 Spe  
- Hyper Beam  
- Hyper Voice  
- Psyshock  
- Hidden Power [Fire]  

";
$mt4292 = "Whimsicott @ Eject Button  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 144 Def / 112 SpD  
Bold Nature  
IVs: 0 Atk  
- Tailwind  
- Encore  
- Endeavor  
- Memento  

";
$mt4302 = "Kadabra @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk / 30 SpA / 30 Spe  
- Psychic  
- Dazzling Gleam  
- Hidden Power [Fire]  
- Encore  

";
$mt4312 = "Abra @ Focus Sash  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunder Wave  
- Psychic  
- Shadow Ball  
- Encore  

";
$mt4322 = "Solosis @ Focus Sash  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA  
Rash Nature  
IVs: 0 HP / 0 Atk / 0 Def / 0 SpD / 0 Spe  
- Trick Room  
- Endeavor  
- Future Sight  
- Magic Coat  

";
$mt4332 = "Blissey (F) @ Leftovers  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Heal Bell  
- Light Screen  
- Soft-Boiled  
- Seismic Toss  

";
$mt4342 = "Snorlax @ Choice Band  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Return  
- Self-Destruct  
- Earthquake  
- Fire Punch  

";
$mt4351 = "Linoone @ Sitrus Berry  
Ability: Pickup  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Belly Drum  
- Extreme Speed  
- Seed Bomb  
- Shadow Claw  

";
$mt4360 = "Staraptor @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 240 HP / 252 Def / 16 Spe  
Impish Nature  
- Brave Bird  
- Roost  
- Defog  
- U-turn  

";
$mt4369 = "Forretress @ Custap Berry  
Ability: Sturdy  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Stealth Rock  
- Spikes  
- Explosion  
- Rapid Spin  

";
$mt4378 = "Yanmega @ Life Orb  
Ability: Speed Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 1 Atk / 30 SpA / 30 SpD  
- Defog  
- Bug Buzz  
- Hidden Power [Ground]  
- Protect  

";
$mt4388 = "Scolipede @ Life Orb  
Ability: Speed Boost  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Megahorn  
- Aqua Tail  
- Earthquake  
- Rock Slide  

";
$mt4397 = "Leavanny @ Light Clay  
Ability: Swarm  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Reflect  
- Light Screen  
- Sticky Web  
- Toxic  

";

$yerky43 = "Rotom-Wash @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 212 HP / 48 Def / 248 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Hydro Pump  
- Stored Power  
- Substitute  

";
$yerky414 = "Lickilicky @ Leftovers  
Ability: Oblivious  
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Block  
- Toxic  
- Wish  
- Fire Blast  

";
$yerky425 = "Pichu @ Rocky Helmet  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Play Rough  
- Wish  
- Protect  
- Nuzzle  

";
$yerky435 = "Archaludon @ Choice Scarf  
Ability: Stamina  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Thunder  
- Dark Pulse  
- Aura Sphere  

";
$yerky446 = "Revavroom @ Weakness Policy  
Ability: Filter  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Temper Flare  
- Shift Gear  
- Gunk Shot  
- High Horsepower  

";
$yerky456 = "Hydreigon @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 Def / 4 SpA / 252 Spe  
Timid Nature  
- Stealth Rock  
- Draco Meteor  
- U-turn  
- Taunt  

";
$yerky466 = "Raging Bolt @ Assault Vest  
Ability: Protosynthesis  
Tera Type: &
EVs: 64 HP / 252 SpA / 68 SpD / 124 Spe  
Modest Nature  
IVs: 20 Atk  
- Thunderbolt  
- Dragon Pulse  
- Snarl  
- Electroweb  

";
$yerky477 = "Landorus-Therian @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 92 Atk / 164 Spe  
Jolly Nature  
- Stomping Tantrum  
- Crunch  
- Protect  
- Bulk Up  

";
$yerky487 = "Ninetales-Alola @ Light Clay  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 88 Def / 168 Spe  
Timid Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Encore  
- Aurora Veil  
- Protect  

";
$yerky498 = "Tinkatuff @ Eviolite  
Ability: Own Tempo  
Tera Type: &
EVs: 252 HP / 244 Def / 12 SpD  
Careful Nature  
- Encore  
- Thunder Wave  
- Stealth Rock  
- Fake Out  

";
$yerky4108 = "Moltres @ Heavy-Duty Boots  
Ability: Flame Body  
Tera Type: &
EVs: 84 HP / 252 SpA / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Heat Wave  
- Will-O-Wisp  
- Tailwind  
- Protect  

";
$yerky4119 = "Terapagos @ Life Orb  
Ability: Tera Shift  
Tera Type: &
EVs: 48 HP / 252 SpA / 208 Spe  
Timid Nature  
IVs: 15 Atk  
- Tera Starstorm  
- Earth Power  
- Ice Beam  
- Rock Polish  

";
$yerky4130 = "Mew @ Colbur Berry  
Ability: Synchronize  
Tera Type: &
EVs: 112 SpA / 144 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Earth Power  
- Thunder Wave  
- Stealth Rock  

";
$yerky4141 = "Mew @ Lum Berry  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Overheat  
- Trick  
- Stealth Rock  

";
$yerky4152 = "Darkrai @ Focus Sash  
Ability: Bad Dreams  
Tera Type: &
EVs: 48 Def / 252 SpA / 208 Spe  
Timid Nature  
- Knock Off  
- Ice Beam  
- Thunder  
- Sludge Bomb  

";
$yerky4162 = "Infernape @ Focus Sash  
Ability: Blaze  
Tera Type: &
EVs: 56 Atk / 252 SpA / 200 Spe  
Hasty Nature  
- Overheat  
- Close Combat  
- Counter  
- Stealth Rock  

";
$yerky4172 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD  
Careful Nature  
- Stealth Rock  
- Earthquake  
- Rock Tomb  
- Roar  

";
$yerky4182 = "Bewear @ Heavy-Duty Boots  
Ability: Fluffy  
Tera Type: &
EVs: 140 HP / 84 Atk / 20 Def / 12 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Substitute  
- Drain Punch  
- Thunder Punch  

";
$yerky4192 = "Froslass (F) @ Wide Lens  
Ability: Cursed Body  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Triple Axel  
- Spikes  
- Will-O-Wisp  
- Taunt  

";
$yerky4202 = "Dhelmise @ Assault Vest  
Ability: Steelworker  
Tera Type: &
EVs: 252 HP / 44 Atk / 212 SpD  
Adamant Nature  
- Poltergeist  
- Anchor Shot  
- Earthquake  
- Rapid Spin  

";
$yerky4212 = "Latios (M) @ Soul Dew  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Psyshock  
- Luster Purge  
- Recover  

";
$yerky4223 = "Latios (M) @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic Noise  
- Thunder Wave  
- Protect  
- Calm Mind  

";
$yerky4234 = "Great Tusk @ Choice Band  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Megahorn  
- Tera Blast  
- Giga Impact  
- Fire Fang  

";
$yerky4244 = "Hitmontop (M) @ Choice Band  
Ability: Technician  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Adamant Nature  
- Close Combat  
- Sucker Punch  
- Triple Axel  
- Bullet Punch  

";
$yerky4254 = "Tentacruel @ Black Sludge  
Ability: Liquid Ooze  
Tera Type: &
EVs: 252 HP / 240 SpD / 16 Spe  
Calm Nature  
IVs: 0 Atk  
- Rapid Spin  
- Rest  
- Sleep Talk  
- Scald  

";
$yerky4265 = "Drapion @ Choice Scarf  
Ability: Battle Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Brick Break  
- Knock Off  
- Pursuit  
- Poison Jab  

";
$yerky4275 = "Nidoking (M) @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flamethrower  
- Stealth Rock  
- Earth Power  
- Ice Beam  

";
$yerky4286 = "Amoonguss @ Focus Sash  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk / 30 SpA / 30 Spe  
- Spore  
- Giga Drain  
- Hidden Power [Fire]  
- Synthesis  

";
$yerky4297 = "Crobat @ Rocky Helmet  
Ability: Infiltrator  
Tera Type: &
EVs: 252 HP / 36 Def / 220 Spe  
Impish Nature  
- Toxic  
- Brave Bird  
- Roost  
- Haze  

";
$yerky4307 = "Omastar @ Air Balloon  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk / 30 SpA  
- Hydro Pump  
- Ice Beam  
- Hidden Power [Grass]  
- Shell Smash  

";
$yerky4318 = "Mamoswine @ Never-Melt Ice  
Ability: Thick Fat  
Tera Type: &
EVs: 240 Atk / 252 SpA / 16 Spe  
Naughty Nature  
- Earthquake  
- Icicle Crash  
- Knock Off  
- Freeze-Dry  

";
$yerky4328 = "Toxtricity-Low-Key @ Safety Goggles  
Ability: Minus  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Toxic Spikes  
- Magnetic Flux  
- Snarl  
- Thunderbolt  

";
$yerky4339 = "Goodra-Hisui @ Ability Shield  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Acid Armor  
- Body Press  
- Dragon Tail  
- Life Dew  

Mamoswine  
Ability: Snow Cloak  
Tera Type: &
EVs: 248 SpA / 248 SpD / 12 Spe  
- Earthquake  
- Blizzard  
- Stone Edge  
- Amnesia  

";
$yerky4358 = "Raging Bolt @ Leftovers  
Ability: Protosynthesis  
Tera Type: &
EVs: 180 HP / 112 SpD / 216 Spe  
Timid Nature  
IVs: 20 Atk  
- Thunderclap  
- Dragon Pulse  
- Protect  
- Calm Mind  

";
$yerky4369 = "Blastoise @ Safety Goggles  
Ability: Rain Dish  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Spe  
- Muddy Water  
- Flip Turn  
- Roar  
- Protect  

";
$yerky4380 = "Greninja @ Focus Sash  
Ability: Protean  
Tera Type: &
EVs: 136 HP / 252 SpA / 120 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Grass Knot  
- Spikes  
- Protect  

";
$yerky4391 = "Ninetales-Alola @ Light Clay  
Ability: Snow Warning  
Tera Type: &
EVs: 252 HP / 144 SpD / 112 Spe  
Timid Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Icy Wind  
- Aurora Veil  
- Protect  

";
$yerky4402 = "Landorus-Therian @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 52 SpA / 204 SpD  
Sassy Nature  
- Earth Power  
- Weather Ball  
- Stealth Rock  
- U-turn  

";
$yerky4412 = "Hitmontop @ Assault Vest  
Ability: Technician  
Tera Type: &
EVs: 124 HP / 252 Atk / 132 Spe  
Adamant Nature  
- Close Combat  
- Sucker Punch  
- Triple Axel  
- Fake Out  

";
$yerky4422 = "Landorus-Therian (M) @ Choice Band  
Ability: Intimidate  
Tera Type: &
EVs: 232 HP / 132 Atk / 36 Def / 32 SpA / 64 SpD / 12 Spe  
Adamant Nature  
- Knock Off  
- Iron Tail  
- Bulldoze  
- Sludge Wave  

";
$yerky4432 = "Brambleghast @ Colbur Berry  
Ability: Wind Rider  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Spikes  
- Power Whip  
- Rapid Spin  
- Strength Sap  

";
$yerky4442 = "Bronzong @ Mental Herb  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
- Trick Room  
- Ice Spinner  
- Hypnosis  
- Zen Headbutt  

";
$yerky4452 = "Kangaskhan @ Heavy-Duty Boots  
Ability: Early Bird  
Tera Type: &
EVs: 252 HP / 200 SpD / 56 Spe  
Careful Nature  
- Whirlpool  
- Seismic Toss  
- Rest  
- Toxic  

";
$yerky4462 = "Kangaskhan @ Heavy-Duty Boots  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 200 SpD / 56 Spe  
Careful Nature  
IVs: 0 Atk  
- Whirlpool  
- Seismic Toss  
- Rest  
- Toxic  

";
$yerky4473 = "Kangaskhan @ Kangaskhanite  
Ability: Early Bird  
Tera Type: &
EVs: 252 HP / 200 SpD / 56 Spe  
Careful Nature  
- Whirlpool  
- Seismic Toss  
- Rest  
- Toxic  

";
$yerky4483 = "Kangaskhan @ Sitrus Berry  
Ability: Early Bird  
Tera Type: &
EVs: 252 HP / 200 SpD / 56 Spe  
Careful Nature  
- Whirlpool  
- Seismic Toss  
- Rest  
- Toxic  

";
$yerky4493 = "Kangaskhan @ Berry Juice  
Ability: Early Bird  
Tera Type: &
EVs: 252 HP / 200 SpD / 56 Spe  
Careful Nature  
- Whirlpool  
- Seismic Toss  
- Rest  
- Toxic  

";
$yerky4503 = "Seismitoad @ Leftovers  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 28 SpD / 228 Spe  
Timid Nature  
IVs: 0 Atk  
- Scald  
- Infestation  
- Substitute  
- Protect  

";
$yerky4514 = "Landorus-Therian @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 164 HP / 100 SpA / 244 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Weather Ball  
- Protect  
- Calm Mind  

";
$yerky4525 = "Moltres @ Covert Cloak  
Ability: Flame Body  
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe  
Timid Nature  
IVs: 0 Atk  
- Heat Wave  
- Scorching Sands  
- Will-O-Wisp  
- Protect  

";
$yerky4536 = "Tinkatuff @ Eviolite  
Ability: Pickpocket  
Tera Type: &
EVs: 252 HP / 52 Def / 172 SpD / 32 Spe  
Careful Nature  
- Endeavor  
- Skitter Smack  
- Stealth Rock  
- Fake Out  

";
$yerky4546 = "Jirachi @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 176 SpD / 80 Spe  
Careful Nature  
- Stealth Rock  
- Iron Head  
- Body Slam  
- Wish  

";
$yerky4556 = "Alakazam @ Focus Sash  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 30 Atk  
- Encore  
- Tera Blast  
- Psychic  
- Hidden Power [Ice]  

";
$yerky4567 = "Xatu @ Eject Button  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk / 30 Spe  
- Night Shade  
- U-turn  
- Roost  
- Thunder Wave  

";
$yerky4578 = "Landorus (M) @ Choice Scarf  
Ability: Sheer Force  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Focus Blast  
- U-turn  
- Sludge Wave  

";
$yerky4589 = "Mamoswine @ Assault Vest  
Ability: Thick Fat  
Tera Type: &
EVs: 80 HP / 252 Atk / 176 Spe  
Adamant Nature  
- Earthquake  
- Icicle Crash  
- Ice Shard  
- Smack Down  

";
$yerky4599 = "Clodsire @ Red Card  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Earthquake  
- Toxic  
- Toxic Spikes  
- Recover  

";
$yerky4609 = "Iron Valiant @ Choice Scarf  
Ability: Quark Drive  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Knock Off  
- Ice Punch  
- Trick  

";
$yerky4619 = "Tinkaton (F) @ Air Balloon  
Ability: Pickpocket  
Tera Type: &
EVs: 252 HP / 76 SpD / 184 Spe  
Jolly Nature  
- Stealth Rock  
- Gigaton Hammer  
- Foul Play  
- Encore  

";
$yerky4629 = "Muk-Alola @ Black Sludge  
Ability: Poison Touch  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Careful Nature  
- Pain Split  
- Poison Jab  
- Curse  
- Knock Off  

";
$yerky4639 = "Rotom-Wash @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 212 Def / 48 Spe  
Bold Nature  
IVs: 0 Atk  
- Volt Switch  
- Hydro Pump  
- Will-O-Wisp  
- Defog  

";
$yerky4650 = "Rotom-Wash @ Starf Berry  
Ability: Levitate  
Tera Type: &
EVs: 100 HP / 100 Def / 100 SpA / 100 SpD / 108 Spe  
Bold Nature  
IVs: 0 Atk  
- Stored Power  
- Rest  
- Substitute  
- Nasty Plot  

";
$yerky4661 = "Manectric @ Manectite  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Toxic  
- Volt Switch  
- Hidden Power [Ice]  
- Overheat  

";
$yerky4672 = "Thundurus @ Choice Band  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- U-turn  
- Superpower  
- Knock Off  
- Iron Tail  

";
$yerky4682 = "Raichu-Alola @ Aloraichium Z  
Ability: Surge Surfer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Nasty Plot  
- Thunderbolt  
- Psychic  
- Encore  

";
$yerky4692 = "Raichu-Alola @ Aloraichium Z  
Ability: Surge Surfer  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Thunderbolt  
- Knock Off  
- Volt Switch  
- Fake Out  

";
$yerky4702 = "Raichu-Alola @ Choice Band  
Ability: Surge Surfer  
Tera Type: &
EVs: 156 HP / 252 Atk / 4 SpD / 96 Spe  
Adamant Nature  
- Extreme Speed  
- Wild Charge  
- Focus Punch  
- Volt Switch  

";
$yerky4712 = "Ogerpon-Hearthflame (F) @ Hearthflame Mask  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Spiky Shield  
- Ivy Cudgel  
- Horn Leech  

";
$yerky4722 = "Gyarados @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Def  
Impish Nature  
- Thunder Wave  
- Taunt  
- Waterfall  
- Earthquake  

";
$yerky4732 = "Quaquaval @ Heavy-Duty Boots  
Ability: Moxie  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Impish Nature  
- Rapid Spin  
- Low Kick  
- Knock Off  
- Roost  

";
$yerky4742 = "Iron Treads @ Leftovers  
Ability: Quark Drive  
Tera Type: &
EVs: 252 HP / 116 SpD / 140 Spe  
Careful Nature  
- Heavy Slam  
- Body Press  
- Iron Defense  
- Rapid Spin  

";
$yerky4752 = "Suicune @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 252 HP / 32 Def / 224 Spe  
Timid Nature  
IVs: 0 Atk  
- Protect  
- Surf  
- Calm Mind  
- Substitute  

";
$yerky4763 = "Tentacruel @ Black Sludge  
Ability: Liquid Ooze  
Tera Type: &
EVs: 252 HP / 240 Def / 16 Spe  
Bold Nature  
- Toxic Spikes  
- Flip Turn  
- Muddy Water  
- Rapid Spin  

";
$yerky4773 = "Empoleon @ Leftovers  
Ability: Competitive  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Sassy Nature  
- Roar  
- Knock Off  
- Flash Cannon  
- Roost  

";
$yerky4783 = "Quagsire @ Covert Cloak  
Ability: Unaware  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Earthquake  
- Recover  
- Stealth Rock  
- Toxic  

";
$yerky4793 = "Ogerpon-Wellspring (F) @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Play Rough  
- Swords Dance  
- Horn Leech  
- Ivy Cudgel  

";
$yerky4803 = "Greninja @ Choice Scarf  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Dark Pulse  
- Switcheroo  
- Sludge Wave  

";
$yerky4814 = "Greninja @ Choice Specs  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Hydro Pump  
- Ice Beam  
- Water Shuriken  
- Dark Pulse  

";
$yerky4825 = "Lokix @ Life Orb  
Ability: Tinted Lens  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Swords Dance  
- First Impression  
- Leech Life  
- Sucker Punch  

";
$yerky4835 = "Crawdaunt @ Leftovers  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Knock Off  
- Substitute  
- Aqua Jet  
- Swords Dance  

";
$yerky4845 = "Cloyster @ Focus Sash  
Ability: Skill Link  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Ice Shard  
- Rock Blast  
- Icicle Spear  
- Shell Smash  

";
$yerky4855 = "Slowbro @ Red Card  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Scald  
- Toxic  
- Flamethrower  
- Slack Off  

";
$yerky4866 = "Gallade (M) @ Assault Vest  
Ability: Justified  
Tera Type: &
EVs: 252 HP / 64 Atk / 192 SpD  
Adamant Nature  
- Drain Punch  
- Knock Off  
- Rock Slide  
- Leaf Blade  

";
$yerky4876 = "Enamorus (F) @ Choice Scarf  
Ability: Contrary  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Moonblast  
- Sludge Bomb  
- Earth Power  
- Healing Wish  

";
$yerky4886 = "Tornadus-Therian (M) @ Heavy-Duty Boots  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 44 SpA / 216 Spe  
Timid Nature  
- Bleakwind Storm  
- Heat Wave  
- Knock Off  
- Nasty Plot  

";
$yerky4896 = "Articuno @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 208 SpD / 52 Spe  
Calm Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Roost  
- U-turn  
- Haze  

";
$yerky4907 = "Volcanion @ Assault Vest  
Ability: Water Absorb  
Tera Type: &
EVs: 248 HP / 88 SpA / 72 SpD / 100 Spe  
Modest Nature  
- Steam Eruption  
- Flamethrower  
- Hidden Power [Grass]  
- Rock Slide  

";
$yerky4917 = "Cloyster @ Choice Scarf  
Ability: Skill Link  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Icicle Spear  
- Rock Blast  
- Toxic Spikes  
- Explosion  

";
$yerky4927 = "Greninja @ Icium Z  
Ability: Protean  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Ice Beam  
- Grass Knot  
- Extrasensory  
- Spikes  

";
$yerky4938 = "Jirachi @ Leftovers  
Ability: Serene Grace  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Hasty Nature  
IVs: 0 Atk / 30 Def  
- Psychic  
- Ice Punch  
- Thunder  
- Substitute  

";
$yerky4949 = "Scizor @ Choice Scarf  
Ability: Technician  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Bug Bite  
- U-turn  
- Pursuit  
- Aerial Ace  

";
$yerky4959 = "Heatran @ Air Balloon  
Ability: Flash Fire  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 2 Atk / 30 Def  
- Hidden Power [Ice]  
- Magma Storm  
- Earth Power  
- Stone Edge  

";
$yerky4970 = "Flutter Mane @ Leftovers  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 76 Def / 180 Spe  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Pain Split  
- Shadow Ball  
- Substitute  

";
$yerky4981 = "Archaludon @ Choice Scarf  
Ability: Stamina  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Flash Cannon  
- Thunderbolt  
- Foul Play  

";
$yerky4992 = "Gholdengo @ Air Balloon  
Ability: Good as Gold  
Tera Type: &
EVs: 196 SpA / 60 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Focus Blast  
- Substitute  
- Nasty Plot  

";
$yerky41003 = "Ninetales-Alola @ Light Clay  
Ability: Snow Cloak  
Tera Type: &
EVs: 252 HP / 80 Def / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Freeze-Dry  
- Encore  
- Aurora Veil  
- Protect  

";
$yerky41014 = "Darkrai @ Life Orb  
Ability: Bad Dreams  
Tera Type: &
EVs: 252 Atk / 64 SpA / 192 Spe  
Lonely Nature  
- Knock Off  
- Ice Beam  
- Rock Tomb  
- Sucker Punch  

";
$yerky41024 = "Zapdos @ Clear Amulet  
Ability: Pressure  
Tera Type: &
EVs: 208 HP / 32 Def / 92 SpD / 176 Spe  
Timid Nature  
- Hurricane  
- Thunderbolt  
- Eerie Impulse  
- Roost  

";
$yerky41034 = "Scizor @ Liechi Berry  
Ability: Technician  
Tera Type: &
EVs: 252 HP / 44 Atk / 76 Def / 136 Spe  
Adamant Nature  
- Bullet Punch  
- Bug Bite  
- Reversal  
- Substitute  

";
$yerky41044 = "Volcarona @ Leftovers  
Ability: Flame Body  
Tera Type: &
EVs: 252 HP / 236 Def / 12 SpA / 8 Spe  
Timid Nature  
IVs: 0 Atk  
- Hyper Beam  
- Protect  
- Roost  
- Quiver Dance  

";
$yerky41055 = "Zamazenta @ Clear Amulet  
Ability: Dauntless Shield  
Tera Type: &
EVs: 112 HP / 32 Atk / 16 Def / 96 SpD / 252 Spe  
Jolly Nature  
- Close Combat  
- Facade  
- Focus Energy  
- Howl  

";
$yerky41065 = "Drakloak @ Rocky Helmet  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe  
Timid Nature  
- Draco Meteor  
- Night Shade  
- U-turn  
- Thunder Wave  

";
$yerky41075 = "Mareanie @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 76 Def / 180 SpD  
Bold Nature  
IVs: 0 Atk  
- Recover  
- Haze  
- Infestation  
- Toxic Spikes  

";
$yerky41086 = "Misdreavus @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 120 Def / 136 Spe  
Timid Nature  
IVs: 0 Atk  
- Night Shade  
- Pain Split  
- Taunt  
- Will-O-Wisp  

";
$yerky41097 = "Pikachu @ Light Ball  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Thunderbolt  
- Surf  
- Volt Switch  
- Knock Off  

";
$yerky41107 = "Raboot @ Heavy-Duty Boots  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Flare Blitz  
- High Jump Kick  
- U-turn  
- Taunt  

";
$yerky41117 = "Tinkatuff (F) @ Eviolite  
Ability: Pickpocket  
Tera Type: &
EVs: 248 HP / 92 SpD / 168 Spe  
Careful Nature  
- Knock Off  
- Stealth Rock  
- Thunder Wave  
- Encore  

";
$yerky41127 = "Vigoroth @ Eviolite  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Bulk Up  
- Facade  
- Knock Off  
- Slack Off  

";
$yerky41137 = "Vigoroth @ Eviolite  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Bulk Up  
- Stomping Tantrum  
- Knock Off  
- Slack Off  

";
$yerky41147 = "Vigoroth @ Eviolite  
Ability: Vital Spirit  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Jolly Nature  
- Body Slam  
- Knock Off  
- Slack Off  
- Taunt  

";
$yerky41157 = "Sliggoo-Hisui @ Eviolite  
Ability: Gooey  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Flash Cannon  
- Acid Spray  
- Thunderbolt  

";
$yerky41168 = "Frogadier @ Choice Specs  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Hydro Pump  
- Ice Beam  
- U-turn  
- Spikes  

";
$yerky41178 = "Misdreavus @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Psychic Noise  
- Trick  
- Nasty Plot  

";
$yerky41189 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Earthquake  
- Icicle Crash  
- Stealth Rock  
- Ice Shard  

";
$yerky41199 = "Thwackey @ Life Orb  
Ability: Grassy Surge  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Wood Hammer  
- Grassy Glide  
- Knock Off  
- U-turn  

";
$yerky41209 = "Koffing @ Eviolite  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 248 HP / 136 Def / 108 SpD / 16 Spe  
Bold Nature  
- Sludge Bomb  
- Flamethrower  
- Toxic Spikes  
- Thief  

";
$yerky41219 = "Piloswine @ Choice Band  
Ability: Thick Fat  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- High Horsepower  
- Icicle Crash  
- Ice Shard  
- Facade  

";
$yerky41229 = "Prinplup @ Eviolite  
Ability: Competitive  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
- Flip Turn  
- Roost  
- Surf  
- Ice Beam  

";
$yerky41239 = "Servine @ Eviolite  
Ability: Contrary  
Tera Type: &
EVs: 248 HP / 140 SpA / 92 SpD / 28 Spe  
Modest Nature  
- Leaf Storm  
- Knock Off  
- Synthesis  
- Taunt  

";
$yerky41249 = "Mew @ Salac Berry  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- String Shot  
- Agility  
- Scary Face  
- Quash  

";
$yerky41260 = "Basculegion @ Colbur Berry  
Ability: Swift Swim  
Tera Type: &
EVs: 8 HP / 252 Atk / 28 Def / 28 SpD / 192 Spe  
Jolly Nature  
- Phantom Force  
- Flip Turn  
- Liquidation  
- Ice Fang  

";
$yerky41270 = "Urshifu-Rapid-Strike @ Wacan Berry  
Ability: Unseen Fist  
Tera Type: &
EVs: 252 Atk / 48 SpD / 208 Spe  
Adamant Nature  
- Thunder Punch  
- Surging Strikes  
- Close Combat  
- Swords Dance  

";
$yerky41280 = "Garchomp @ Haban Berry  
Ability: Rough Skin  
Tera Type: &
EVs: 32 HP / 252 Atk / 224 Spe  
Adamant Nature  
- Earthquake  
- Swords Dance  
- Dragon Claw  
- Stealth Rock  

";
$yerky41290 = "Jolteon @ Flame Orb  
Ability: Quick Feet  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Weather Ball  
- Alluring Voice  
- Protect  

";
$yerky41301 = "Gigalith @ Wide Lens  
Ability: Sand Force  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Toxic  
- Sandstorm  
- Curse  
- Stone Edge  

";
$yerky41311 = "Cacturne @ Choice Scarf  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 40 SpD / 216 Spe  
Jolly Nature  
IVs: 0 Atk  
- Spikes  
- Foul Play  
- Leech Seed  
- Switcheroo  

";
$yerky41322 = "Magmortar @ Sitrus Berry  
Ability: Flame Body  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Belly Drum  
- Flame Charge  
- Thunder Punch  
- Earthquake  

";
$yerky41332 = "Roaring Moon @ Life Orb  
Ability: Protosynthesis  
Tera Type: &
EVs: 108 Atk / 208 SpA / 192 Spe  
Hasty Nature  
- Crunch  
- Hurricane  
- Flamethrower  
- Iron Head  

";
$yerky41342 = "Tornadus @ Leftovers  
Ability: Prankster  
Tera Type: &
EVs: 160 HP / 16 SpA / 164 SpD / 168 Spe  
Timid Nature  
IVs: 0 Atk  
- Heat Wave  
- Toxic  
- Substitute  
- Protect  

";
$yerky41353 = "Enamorus-Therian (F) @ Weakness Policy  
Ability: Overcoat  
Tera Type: &
EVs: 248 HP / 60 Def / 200 SpD  
Modest Nature  
- Earth Power  
- Grass Knot  
- Calm Mind  
- Draining Kiss  

";
$yerky41363 = "Hydreigon @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 Def / 4 SpA / 252 Spe  
Timid Nature  
- Stealth Rock  
- Draco Meteor  
- U-turn  
- Taunt  

";
$yerky41373 = "Salamence @ Covert Cloak  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 232 SpD / 24 Spe  
Careful Nature  
- Dual Wingbeat  
- Fire Spin  
- Rest  
- Dragon Dance  

";
$yerky41383 = "Gouging Fire @ Binding Band  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 184 SpD / 72 Spe  
Careful Nature  
- Flare Blitz  
- Fire Spin  
- Rest  
- Dragon Dance  

";
$yerky41393 = "Buizel @ Big Nugget  
Ability: Water Veil  
Tera Type: &
EVs: 236 Atk / 36 SpD / 236 Spe  
Adamant Nature  
- Aqua Jet  
- Wave Crash  
- Fling  
- Icy Wind  

";
$yerky41403 = "Deoxys-Speed @ Rocky Helmet  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 216 Def / 44 Spe  
Bold Nature  
IVs: 0 Atk  
- Stealth Rock  
- Spikes  
- Thunder Wave  
- Taunt  

";
$yerky41414 = "Cresselia (F) @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Light Screen  
- Mist  
- Rest  
- Captivate  

";
$yerky41425 = "Hatenna (F) @ Starf Berry  
Ability: Magic Bounce  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Life Dew  
- Stored Power  
- Baton Pass  

";
$yerky41436 = "Ekans @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Glare  
- Gunk Shot  
- Dig  
- Knock Off  

";
$yerky41446 = "Chingling @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Trick  
- Signal Beam  
- Hidden Power [Fire]  

";
$yerky41457 = "Woobat @ Kee Berry  
Ability: Simple  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Roost  
- Stored Power  
- Reflect  

";
$yerky41468 = "Exeggcute @ Petaya Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Psychic  
- Synthesis  
- Protect  

";
$yerky41479 = "Rockruff-Dusk @ Life Orb  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Stone Edge  
- Trailblaze  
- Tera Blast  

";
$yerky41489 = "Clobbopus @ Eviolite  
Ability: Technician  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Bulk Up  
- Circle Throw  
- Pain Split  
- Protect  

";
$yerky41499 = "Seaking @ Leftovers  
Ability: Lightning Rod  
Tera Type: &
EVs: 248 HP / 224 SpD / 36 Spe  
Careful Nature  
- Protect  
- Toxic  
- Haze  
- Drill Run  

";
$yerky41509 = "Bisharp @ Leftovers  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 212 SpD / 48 Spe  
Careful Nature  
- Swords Dance  
- Knock Off  
- Substitute  
- Protect  

";
$yerky41519 = "Slowking @ Light Clay  
Ability: Regenerator  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Fire Blast  
- Scald  
- Light Screen  
- Reflect  

";
$yerky41530 = "Nidorina (F) @ Eviolite  
Ability: Poison Point  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD  
Bold Nature  
IVs: 0 Atk  
- Toxic Spikes  
- Super Fang  
- Counter  
- Protect  

";
$yerky41541 = "Mismagius @ Ghostium Z  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Shadow Ball  
- Thunderbolt  
- Nasty Plot  
- Substitute  

";
$yerky41552 = "Pyukumuku @ Custap Berry  
Ability: Innards Out  
Level: 96  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Hasty Nature  
IVs: 0 Def / 0 SpD  
- Pain Split  
- Rest  
- Block  
- Spite  

";
$yerky41564 = "Haunter @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe  
Jolly Nature  
IVs: 0 Atk  
- Mean Look  
- Perish Song  
- Protect  
- Destiny Bond  

";
$yerky41575 = "Zapdos @ Flyinium Z  
Ability: Static  
Tera Type: &
EVs: 240 HP / 132 Atk / 8 Def / 104 SpD / 24 Spe  
Adamant Nature  
- Curse  
- Roost  
- Sky Attack  
- Wild Charge  

";
$yerky41585 = "Porygon-Z @ Choice Band  
Ability: Adaptability  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Giga Impact  
- Double-Edge  
- Thief  
- Facade  

";
$yerky41595 = "Frogadier @ Groundium Z  
Ability: Protean  
Tera Type: &
EVs: 248 HP / 252 Atk / 4 SpD / 4 Spe  
Adamant Nature  
- Dig  
- Toxic Spikes  
- Rest  
- Toxic  

";
$yerky41605 = "Golduck @ Psychium Z  
Ability: Swift Swim  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Hydro Pump  
- Ice Beam  
- Synchronoise  

";
$yerky41616 = "Psyduck @ Choice Specs  
Ability: Swift Swim  
Shiny: Yes  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Hydro Pump  
- Ice Beam  
- Toxic  
- Worry Seed  

";
$yerky41628 = "Magnezone @ Custap Berry  
Ability: Magnet Pull  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Hidden Power [Fire]  
- Sunny Day  
- Rain Dance  
- Endure  

";
$yerky41639 = "Thundurus-Therian (M) @ Normalium Z  
Ability: Volt Absorb  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Nasty Plot  
- Thunderbolt  
- Hidden Power [Ice]  
- Hyper Beam  

";
$yerky41650 = "Exploud @ Sitrus Berry  
Ability: Soundproof  
Tera Type: &
EVs: 208 HP / 48 SpA / 252 Spe  
Hasty Nature  
- Whirlpool  
- Taunt  
- Hammer Arm  
- Boomburst  

";
$yerky41660 = "Swablu @ Eviolite  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 96 Def / 160 SpD  
Bold Nature  
IVs: 0 Atk  
- Roost  
- Haze  
- Toxic  
- Heal Bell  

";
$yerky41671 = "Blissey (F) @ Leftovers  
Ability: Natural Cure  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Block  
- Skill Swap  
- Soft-Boiled  
- Toxic  

";
$yerky41682 = "Umbreon @ Leftovers  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 8 Def / 60 SpD / 188 Spe  
Calm Nature  
IVs: 0 Atk  
- Taunt  
- Toxic  
- Foul Play  
- Wish  

";
$yerky41693 = "Abra @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Signal Beam  
- Shadow Ball  
- Protect  

";
$yerky41704 = "Grubbin @ Liechi Berry  
Ability: Swarm  
Tera Type: &
EVs: 244 HP / 252 Atk / 12 Spe  
Adamant Nature  
- Substitute  
- Lunge  
- Protect  
- Baton Pass  

";
$yerky41714 = "Jangmo-o @ Dragonium Z  
Ability: Bulletproof  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Draco Meteor  
- Protect  
- Focus Blast  
- Tera Blast  

";
$yerky41724 = "Meowth-Galar @ Life Orb  
Ability: Tough Claws  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Fake Out  
- Iron Head  
- U-turn  
- Knock Off  

";
$yerky41734 = "Fletchling @ Liechi Berry  
Ability: Gale Wings  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Natural Gift  
- Brave Bird  
- Acrobatics  

";
$yerky41744 = "Pupitar @ Life Orb  
Ability: Shed Skin  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Dragon Dance  
- Stone Edge  
- High Horsepower  
- Tera Blast  

";
$yerky41754 = "Electrike @ Choice Specs  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flamethrower  
- Volt Switch  
- Thunder  
- Hidden Power [Ice]  

";
$yerky41765 = "Wiglett @ Water Gem  
Ability: Sand Veil  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Protect  
- Aqua Jet  
- Memento  

";
$yerky41775 = "Flittle @ Kee Berry  
Ability: Speed Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Stored Power  
- Reflect  
- Protect  

";
$yerky41786 = "Capsakid @ Petaya Berry  
Ability: Insomnia  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Substitute  
- Leaf Storm  
- Endeavor  
- Tera Blast  

";
$yerky41796 = "Rellor @ Eviolite  
Ability: Shed Skin  
Tera Type: &
EVs: 252 HP / 144 Def / 112 SpD  
Sassy Nature  
- Rest  
- Cosmic Power  
- Sludge Bomb  
- Leech Life  

";
$yerky41806 = "Jigglypuff @ Choice Specs  
Ability: Competitive  
Tera Type: &
EVs: 252 Def / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Alluring Voice  
- Fire Blast  
- Ice Beam  
- Grass Knot  

";
$yerky41817 = "Budew @ Bright Powder  
Ability: Poison Point  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spikes  
- Protect  
- Double Team  
- Swagger  

";
$yerky41828 = "Pawmo @ Leftovers  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Focus Punch  
- Nuzzle  
- Encore  

";
$yerky41838 = "Greavard @ Ghost Gem  
Ability: Pickup  
Tera Type: &
EVs: 252 HP / 252 Atk  
Adamant Nature  
- Poltergeist  
- Protect  
- Stomping Tantrum  
- Yawn  

";
$yerky41848 = "Greavard @ Eviolite  
Ability: Fluffy  
Tera Type: &
EVs: 248 HP / 132 Def / 128 SpD  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Night Shade  
- Yawn  
- Confuse Ray  

";
$yerky41859 = "Drifloon @ Choice Scarf  
Ability: Aftermath  
Tera Type: &
EVs: 128 Def / 128 SpD / 252 Spe  
Timid Nature  
- Trick  
- Defog  
- Phantom Force  
- Knock Off  

";
$yerky41869 = "Drizzile @ Water Gem  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Hydro Pump  
- Protect  
- U-turn  
- Tera Blast  

";
$yerky41879 = "Frogadier @ Eviolite  
Ability: Protean  
Tera Type: &
EVs: 216 SpA / 164 Spe  
Hasty Nature  
- Grass Knot  
- Gunk Shot  
- U-turn  
- Hidden Power [Fire]  

";
$yerky41889 = "Gallade (M) @ Galladite  
Ability: Steadfast  
Tera Type: &
EVs: 96 HP / 252 Atk / 160 Spe  
Adamant Nature  
- Swords Dance  
- Close Combat  
- Shadow Sneak  
- Poison Jab  

";
$yerky41899 = "Crocalor @ Liechi Berry  
Ability: Blaze  
Tera Type: &
EVs: 224 HP / 252 Atk / 32 Spe  
Adamant Nature  
- Substitute  
- Temper Flare  
- Seed Bomb  
- Slack Off  

";
$yerky41909 = "Omanyte @ Life Orb  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Shell Smash  
- Surf  
- Ice Beam  
- Tera Blast  

";
$yerky41919 = "Omanyte @ Eviolite  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Calm Nature  
- Spikes  
- Stealth Rock  
- Knock Off  
- Protect  

";
$yerky41929 = "Whismur @ Choice Specs  
Ability: Soundproof  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Tera Blast  
- Fire Blast  
- Ice Beam  
- Extrasensory  

";
$yerky41939 = "Ogerpon-Wellspring @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Ivy Cudgel  
- U-turn  
- Knock Off  
- Spikes  

";
$yerky41949 = "Ogerpon-Wellspring (F) @ Wellspring Mask  
Ability: Water Absorb  
Tera Type: &
EVs: 172 HP / 76 Atk / 76 SpD / 184 Spe  
Jolly Nature  
- Ivy Cudgel  
- Wood Hammer  
- Follow Me  
- Spiky Shield  

";
$yerky41959 = "Dragonite @ Heavy-Duty Boots  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Extreme Speed  
- Ice Spinner  
- Thunder Punch  
- Dragon Dance  

";
$yerky41969 = "Dragonite @ Heavy-Duty Boots  
Ability: Multiscale  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Dragon Claw  
- Encore  
- Roost  
- Dragon Dance  

";
$yerky41979 = "Magearna @ Shuca Berry  
Ability: Soul-Heart  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Relaxed Nature  
- Fleur Cannon  
- Trick Room  
- Spikes  
- Volt Switch  

";
$yerky41989 = "Magearna @ Leftovers  
Ability: Soul-Heart  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Fleur Cannon  
- Spikes  
- Thunder Wave  
- Volt Switch  

";
$yerky42000 = "Magearna @ Assault Vest  
Ability: Soul-Heart  
Tera Type: &
EVs: 248 HP / 72 Def / 188 SpD  
Calm Nature  
- Fleur Cannon  
- Ice Beam  
- Tera Blast  
- Volt Switch  

";
$yerky42010 = "Magearna @ Choice Specs  
Ability: Soul-Heart  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Fleur Cannon  
- Flash Cannon  
- Grass Knot  
- Volt Switch  

";
$yerky42021 = "Zygarde @ Leftovers  
Ability: Aura Break  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Thousand Arrows  
- Coil  
- Dragon Dance  
- Protect  

";
$yerky42031 = "Ting-Lu @ Rocky Helmet  
Ability: Vessel of Ruin  
Tera Type: &
EVs: 204 HP / 96 SpD / 208 Spe  
Careful Nature  
- Earthquake  
- Ruination  
- Taunt  
- Stealth Rock  

";
$yerky42041 = "Garganacl @ Leftovers  
Ability: Purifying Salt  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Iron Defense  
- Body Press  
- Salt Cure  
- Recover  

";
$yerky42051 = "Kingdra @ Life Orb  
Ability: Swift Swim  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Muddy Water  
- Draco Meteor  
- Weather Ball  
- Protect  

";
$yerky42062 = "Enamorus @ Life Orb  
Ability: Cute Charm  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Earth Power  
- Springtide Storm  
- Protect  

";
$yerky42073 = "Mew @ Covert Cloak  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Pollen Puff  
- Taunt  
- Tailwind  
- Will-O-Wisp  

";
$yerky42084 = "Primarina @ Leftovers  
Ability: Liquid Voice  
Tera Type: &
EVs: 204 HP / 252 SpA / 52 Spe  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Moonblast  
- Protect  
- Calm Mind  

";
$yerky42095 = "Kommo-o @ Kommonium Z  
Ability: Bulletproof  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
- Clanging Scales  
- Drain Punch  
- Flamethrower  
- Taunt  

";
$yerky42105 = "Latias (F) @ Choice Scarf  
Ability: Levitate  
Tera Type: &
EVs: 248 SpA / 8 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Draco Meteor  
- Psychic  
- Trick  
- Healing Wish  

";
$yerky42116 = "Diancie @ Diancite  
Ability: Magic Bounce  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Naive Nature  
- Moonblast  
- Mystical Fire  
- Diamond Storm  
- Spikes  

";
$yerky42126 = "Diancie @ Weakness Policy  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 232 Atk / 24 Def  
Sassy Nature  
IVs: 0 Spe  
- Diamond Storm  
- Body Press  
- Trick Room  
- Protect  

";
$yerky42137 = "Diancie @ Diancite  
Ability: Magic Bounce  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Hasty Nature  
- Protect  
- Moonblast  
- Diamond Storm  
- Earth Power  

";
$yerky42147 = "Latias @ Weakness Policy  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 232 Def / 24 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Agility  
- Stored Power  
- Draining Kiss  

";
$yerky42158 = "Latias @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 232 Def / 24 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Agility  
- Stored Power  
- Aura Sphere  

";
$yerky42169 = "Landorus-Therian @ Flyinium Z  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 112 Def / 144 Spe  
Impish Nature  
- Stealth Rock  
- Earthquake  
- Fly  
- U-turn  

";
$yerky42179 = "Landorus-Therian @ Leftovers  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 112 Def / 144 Spe  
Impish Nature  
- Defog  
- Earthquake  
- Toxic  
- U-turn  

";


$bina41 = "Pancham @ Choice Band  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 252 Def  
Adamant Nature  
- Superpower  
- Knock Off  
- Gunk Shot  
- Parting Shot  

";
$bina411 = "Houndour @ Life Orb  
Ability: Flash Fire  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Nasty Plot  
- Fire Blast  
- Dark Pulse  
- Tera Blast  

";
$bina421 = "Ducklett @ Life Orb  
Ability: Hydration  
Tera Type: &
EVs: 252 Atk / 252 SpA / 4 Spe  
Mild Nature  
- Rain Dance  
- Dive  
- Hurricane  
- Protect  

";
$bina431 = "Klang @ Eviolite  
Ability: Clear Body  
Tera Type: &
EVs: 252 HP / 92 Def / 164 SpD  
Calm Nature  
- Volt Switch  
- Gear Grind  
- Rest  
- Sleep Talk  

";
$bina441 = "Swoobat @ Light Clay  
Ability: Unaware  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Reflect  
- Light Screen  
- Calm Mind  
- Air Slash  

";
$bina452 = "Poochyena @ Eviolite  
Ability: Quick Feet  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Yawn  
- Protect  
- Heal Bell  
- Super Fang  

";
$bina463 = "Cyclizar @ Chople Berry  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 8 Def / 248 Spe  
Jolly Nature  
- Rapid Spin  
- Mud Shot  
- Knock Off  
- U-turn  

";
$bina473 = "Rhyperior @ Custap Berry  
Ability: Solid Rock  
Shiny: Yes  
Tera Type: &
EVs: 236 HP / 252 Atk / 20 Spe  
Adamant Nature  
- Avalanche  
- Earthquake  
- Dragon Tail  
- Stealth Rock  

";
$bina484 = "Slowbro @ Slowbronite  
Ability: Oblivious  
Tera Type: &
EVs: 248 HP / 96 SpA / 164 SpD  
Modest Nature  
IVs: 0 Atk  
- Thunder Wave  
- Rain Dance  
- Slack Off  
- Surf  

";
$bina495 = "Meloetta @ Liechi Berry  
Ability: Serene Grace  
Tera Type: &
EVs: 48 HP / 84 Atk / 168 Def / 208 Spe  
Jolly Nature  
- Relic Song  
- Giga Impact  
- Close Combat  
- Substitute  

";
$bina4105 = "Finneon @ Eviolite  
Ability: Storm Drain  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
- Defog  
- Scald  
- U-turn  
- Toxic  

";
$bina4115 = "Eevee @ Eevium Z  
Ability: Adaptability  
Tera Type: &
EVs: 136 HP / 252 Atk / 120 Spe  
Adamant Nature  
- Last Resort  
- Protect  

";
$bina4123 = "Eevee @ Eevium Z  
Ability: Adaptability  
Tera Type: &
EVs: 240 HP / 152 Atk / 116 Spe  
Adamant Nature  
- Last Resort  
- Protect  
- Return  

";
$bina4132 = "HOES... FREAKS... (Helioptile) @ Eviolite  
Ability: Dry Skin  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
- Glare  
- Dragon Tail  
- Protect  
- Volt Switch  

";
$bina4142 = "HOES... FREAKS... (Helioptile) @ Eviolite  
Ability: Dry Skin  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Glare  
- Electrify  
- Protect  
- Light Screen  

";
$bina4153 = "Gossifleur @ Choice Specs  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Sleep Powder  
- Leaf Storm  
- Giga Drain  
- Tera Blast  

";
$bina4163 = "Chewtle @ Eviolite  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
- Counter  
- Dragon Tail  
- Body Slam  
- Chilling Water  

";
$bina4173 = "Chewtle @ Life Orb  
Ability: Strong Jaw  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Shell Smash  
- Liquidation  
- Poison Jab  
- Ice Fang  

";
$bina4183 = "Chewtle @ Water Gem  
Ability: Shell Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Shell Smash  
- Liquidation  
- Protect  
- Tera Blast  

";
$bina4193 = "Chewtle @ Water Gem  
Ability: Shell Armor  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Shell Smash  
- Liquidation  
- Stomping Tantrum  
- Poison Jab  

";
$bina4203 = "Chewtle @ Water Gem  
Ability: Shell Armor  
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe  
Modest Nature  
- Shell Smash  
- Protect  
- Hydro Pump  
- Tera Blast  

";
$bina4213 = "Vivillon-Modern @ Heavy-Duty Boots  
Ability: Compound Eyes  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Sleep Powder  
- U-turn  
- Hurricane  
- Endeavor  

";
$bina4223 = "Houndour @ Eviolite  
Ability: Early Bird  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Nasty Plot  
- Overheat  
- Dark Pulse  
- Protect  

";
$bina4234 = "Venusaur @ Leftovers  
Ability: Chlorophyll  
Tera Type: &
EVs: 184 HP / 216 SpD / 108 Spe  
Calm Nature  
IVs: 0 Atk  
- Amnesia  
- Synthesis  
- Sunny Day  
- Weather Ball  

";
$bina4245 = "Pecharunt @ Weakness Policy  
Ability: Poison Puppeteer  
Tera Type: &
EVs: 208 Atk / 132 SpD / 168 Spe  
Adamant Nature  
- Gunk Shot  
- Hex  
- Recover  
- Memento  

";
$bina4255 = "Deino @ Choice Band  
Ability: Hustle  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Outrage  
- Crunch  
- Tera Blast  
- Superpower  

";
$bina4265 = "Axew @ Dragon Gem  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Dragon Dance  
- Outrage  
- Poison Jab  
- Protect  

";
$bina4275 = "Bellsprout @ Life Orb  
Ability: Chlorophyll  
Tera Type: &
EVs: 40 Atk / 252 SpA / 216 Spe  
Rash Nature  
- Sunny Day  
- Weather Ball  
- Solar Beam  
- Knock Off  

";
$bina4285 = "Flabébé-Blue (F) @ Eviolite  
Ability: Symbiosis  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Draining Kiss  
- Synthesis  
- Stored Power  
";
$bina4295 = "Gothita @ Choice Scarf  
Ability: Shadow Tag  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Trick  
- Psychic Noise  
- Thunder Wave  
- Tera Blast  

";
$bina4305 = "Tapu Fini @ Wide Lens  
Ability: Misty Surge  
Tera Type: &
EVs: 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Rain Dance  
- Muddy Water  
- Moonblast  
- Protect  

";
$bina4316 = "Sylveon @ Room Service  
Ability: Pixilate  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def  
Relaxed Nature  
- Hyper Voice  
- Hyper Beam  
- Protect  
- Quick Attack  

";
$bina4326 = "Tapu Lele @ Kebia Berry  
Ability: Psychic Surge  
Tera Type: &
EVs: 180 HP / 180 Def / 140 SpA / 4 SpD / 4 Spe  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Dazzling Gleam  
- Psyshock  
- Protect  
- Nature's Madness  

";
$bina4337 = "Tapu Lele @ Light Clay  
Ability: Psychic Surge  
Tera Type: &
EVs: 244 HP / 196 Def / 68 SpD  
Relaxed Nature  
IVs: 0 Atk / 25 Spe  
- Light Screen  
- Moonblast  
- Aromatic Mist  
- Reflect  

";
$bina4348 = "Torkoal @ Charcoal  
Ability: Drought  
Level: 50  
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD  
Quiet Nature  
IVs: 0 Atk / 0 Spe  
- Eruption  
- Heat Wave  
- Earth Power  
- Protect  

";
$bina4360 = "Hatterene @ Chilan Berry  
Ability: Magic Bounce  
Level: 50  
Tera Type: &
EVs: 252 HP / 188 Def / 68 SpD  
Relaxed Nature  
IVs: 0 Atk / 0 Spe  
- Expanding Force  
- Dazzling Gleam  
- Trick Room  
- Heal Pulse  

";
$bina4372 = "Sobble @ Eviolite  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 56 Def / 200 SpA  
Modest Nature  
- Substitute  
- Baton Pass  
- Hydro Pump  
- Fell Stinger  

";
$bina4382 = "Gible @ Bright Powder  
Ability: Sand Veil  
Tera Type: &
EVs: 248 HP / 116 Def / 144 SpD  
Careful Nature  
- Sandstorm  
- Substitute  
- Toxic  
- Bulldoze  

";
$bina4392 = "Frigibax @ Loaded Dice  
Ability: Thermal Exchange  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Icicle Spear  
- Outrage  
- Protect  

";
$bina4402 = "Kirlia @ Eviolite  
Ability: Trace  
Tera Type: &
EVs: 248 HP / 160 Def / 100 SpD  
Calm Nature  
IVs: 0 Atk  
- Wish  
- Protect  
- Teleport  
- Swagger  

";
$bina4413 = "Tarountula @ Bug Gem  
Ability: Stakeout  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Leech Life  
- Protect  
- Sticky Web  
- Thief  

";
$bina4423 = "Meditite @ Fighting Gem  
Ability: Pure Power  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- High Jump Kick  
- Protect  
- Bulk Up  
- Bullet Punch  

";
$bina4433 = "Loudred @ Throat Spray  
Ability: Scrappy  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Protect  
- Fire Blast  
- Blizzard  

";
$bina4444 = "Capsakid @ Petaya Berry  
Ability: Chlorophyll  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Sunny Day  
- Solar Beam  
- Substitute  
- Endeavor  

";
$bina4455 = "Skiddo @ Eviolite  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 56 Def / 200 SpD  
Impish Nature  
- Bulk Up  
- Milk Drink  
- Horn Leech  
- Body Slam  

";
$bina4465 = "Skiddo @ Eviolite  
Ability: Sap Sipper  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Impish Nature  
- Bulk Up  
- Milk Drink  
- Horn Leech  
- Tera Blast  

";
$bina4475 = "Tranquill @ Mirror Herb  
Ability: Super Luck  
Tera Type: &
EVs: 232 HP / 136 Atk / 140 Spe  
Adamant Nature  
- Swagger  
- Morning Sun  
- Return  
- Protect  

";
$bina4485 = "Spewpa @ Leftovers  
Ability: Shed Skin  
Tera Type: &
EVs: 252 HP / 152 Def / 104 SpD  
Bold Nature  
IVs: 0 Atk  
- Stun Spore  
- Iron Defense  
- Protect  
- Struggle Bug  

";
$bina4496 = "Electrike @ Choice Scarf  
Ability: Lightning Rod  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Volt Switch  
- Thunder  
- Hidden Power [Ice]  
- Switcheroo  

";
$bina4507 = "Electrike @ Eviolite  
Ability: Static  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD  
Careful Nature  
- Rest  
- Sleep Talk  
- Curse  
- Spark  

";
$bina4517 = "Rowlet @ Eviolite  
Ability: Long Reach  
Tera Type: &
EVs: 252 HP / 104 Def / 152 SpD  
Impish Nature  
- Curse  
- Dual Wingbeat  
- Synthesis  
- Baton Pass  

";
$bina4527 = "Voltorb-Hisui @ Choice Specs  
Ability: Soundproof  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Leaf Storm  
- Thunder  
- Volt Switch  
- Tera Blast  

";
$bina4537 = "Shuppet @ Ghost Gem  
Ability: Frisk  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Poltergeist  
- Protect  
- Shadow Sneak  
- Thief  

";
$bina4547 = "Snom @ Eviolite  
Ability: Ice Scales  
Tera Type: &
EVs: 252 HP / 224 Def / 32 SpD  
Bold Nature  
IVs: 0 Atk  
- Icy Wind  
- Mirror Coat  
- Protect  
- Bug Buzz  

";
$bina4558 = "Abra @ Life Orb  
Ability: Magic Guard  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Psychic  
- Signal Beam  
- Shadow Ball  
- Protect  

";
$bina4569 = "Grubbin @ Liechi Berry  
Ability: Swarm  
Tera Type: &
EVs: 244 HP / 252 Atk / 12 Spe  
Adamant Nature  
- Substitute  
- Lunge  
- Protect  
- Baton Pass  

";
$bina4579 = "Jangmo-o @ Dragonium Z  
Ability: Bulletproof  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Draco Meteor  
- Protect  
- Focus Blast  
- Tera Blast  

";
$bina4589 = "Meowth-Galar @ Life Orb  
Ability: Tough Claws  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Fake Out  
- Iron Head  
- U-turn  
- Knock Off  

";
$bina4599 = "Fletchling @ Liechi Berry  
Ability: Gale Wings  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Swords Dance  
- Natural Gift  
- Brave Bird  
- Acrobatics  

";
$bina4609 = "Pupitar @ Life Orb  
Ability: Shed Skin  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Hasty Nature  
- Dragon Dance  
- Stone Edge  
- High Horsepower  
- Tera Blast  

";
$bina4619 = "Electrike @ Choice Specs  
Ability: Static  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Flamethrower  
- Volt Switch  
- Thunder  
- Hidden Power [Ice]  

";
$bina4630 = "Wiglett @ Water Gem  
Ability: Sand Veil  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Liquidation  
- Protect  
- Aqua Jet  
- Memento  

";
$bina4640 = "Flittle @ Kee Berry  
Ability: Speed Boost  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Stored Power  
- Reflect  
- Protect  

";
$bina4651 = "Capsakid @ Petaya Berry  
Ability: Insomnia  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
- Substitute  
- Leaf Storm  
- Endeavor  
- Tera Blast  

";
$bina4661 = "Rellor @ Eviolite  
Ability: Shed Skin  
Tera Type: &
EVs: 252 HP / 144 Def / 112 SpD  
Sassy Nature  
- Rest  
- Cosmic Power  
- Sludge Bomb  
- Leech Life  

";
$bina4671 = "Jigglypuff @ Choice Specs  
Ability: Competitive  
Tera Type: &
EVs: 252 Def / 252 SpA / 4 SpD  
Modest Nature  
IVs: 0 Atk  
- Alluring Voice  
- Fire Blast  
- Ice Beam  
- Grass Knot  

";
$bina4682 = "Budew @ Bright Powder  
Ability: Poison Point  
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Spikes  
- Protect  
- Double Team  
- Swagger  

";
$bina4693 = "Pawmo @ Leftovers  
Ability: Iron Fist  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Substitute  
- Focus Punch  
- Nuzzle  
- Encore  

";
$bina4703 = "Greavard @ Ghost Gem  
Ability: Pickup  
Tera Type: &
EVs: 252 HP / 252 Atk  
Adamant Nature  
- Poltergeist  
- Protect  
- Stomping Tantrum  
- Yawn  

";
$bina4713 = "Greavard @ Eviolite  
Ability: Fluffy  
Tera Type: &
EVs: 248 HP / 132 Def / 128 SpD  
Bold Nature  
IVs: 0 Atk  
- Rest  
- Night Shade  
- Yawn  
- Confuse Ray  

";
$bina4724 = "Drifloon @ Choice Scarf  
Ability: Aftermath  
Tera Type: &
EVs: 128 Def / 128 SpD / 252 Spe  
Timid Nature  
- Trick  
- Defog  
- Phantom Force  
- Knock Off  

";
$bina4734 = "Drizzile @ Water Gem  
Ability: Torrent  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Hydro Pump  
- Protect  
- U-turn  
- Tera Blast  

";
$bina4744 = "Frogadier @ Eviolite  
Ability: Protean  
Tera Type: &
EVs: 216 SpA / 164 Spe  
Hasty Nature  
- Grass Knot  
- Gunk Shot  
- U-turn  
- Hidden Power [Fire]  

";
$bina4754 = "Gallade (M) @ Galladite  
Ability: Steadfast  
Tera Type: &
EVs: 96 HP / 252 Atk / 160 Spe  
Adamant Nature  
- Swords Dance  
- Close Combat  
- Shadow Sneak  
- Poison Jab  

";
$bina4764 = "Crocalor @ Liechi Berry  
Ability: Blaze  
Tera Type: &
EVs: 224 HP / 252 Atk / 32 Spe  
Adamant Nature  
- Substitute  
- Temper Flare  
- Seed Bomb  
- Slack Off  

";
$bina4774 = "Omanyte @ Life Orb  
Ability: Weak Armor  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Shell Smash  
- Surf  
- Ice Beam  
- Tera Blast  

";
$bina4784 = "Omanyte @ Eviolite  
Ability: Shell Armor  
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe  
Calm Nature  
- Spikes  
- Stealth Rock  
- Knock Off  
- Protect  

";
$bina4794 = "Whismur @ Choice Specs  
Ability: Soundproof  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Tera Blast  
- Fire Blast  
- Ice Beam  
- Extrasensory  

";
$bina4804 = "Mew @ Salac Berry  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- String Shot  
- Agility  
- Scary Face  
- Quash  

";
$bina4815 = "Basculegion @ Colbur Berry  
Ability: Swift Swim  
Tera Type: &
EVs: 8 HP / 252 Atk / 28 Def / 28 SpD / 192 Spe  
Jolly Nature  
- Phantom Force  
- Flip Turn  
- Liquidation  
- Ice Fang  

";
$bina4825 = "Urshifu-Rapid-Strike @ Wacan Berry  
Ability: Unseen Fist  
Tera Type: &
EVs: 252 Atk / 48 SpD / 208 Spe  
Adamant Nature  
- Thunder Punch  
- Surging Strikes  
- Close Combat  
- Swords Dance  

";
$bina4835 = "Garchomp @ Haban Berry  
Ability: Rough Skin  
Tera Type: &
EVs: 32 HP / 252 Atk / 224 Spe  
Adamant Nature  
- Earthquake  
- Swords Dance  
- Dragon Claw  
- Stealth Rock  

";
$bina4845 = "Jolteon @ Flame Orb  
Ability: Quick Feet  
Tera Type: &
EVs: 80 HP / 252 SpA / 176 Spe  
Timid Nature  
IVs: 0 Atk  
- Volt Switch  
- Weather Ball  
- Alluring Voice  
- Protect  

";
$bina4856 = "Gigalith @ Wide Lens  
Ability: Sand Force  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Toxic  
- Sandstorm  
- Curse  
- Stone Edge  

";
$bina4866 = "Cacturne @ Choice Scarf  
Ability: Water Absorb  
Tera Type: &
EVs: 252 HP / 40 SpD / 216 Spe  
Jolly Nature  
IVs: 0 Atk  
- Spikes  
- Foul Play  
- Leech Seed  
- Switcheroo  

";
$bina4877 = "Magmortar @ Sitrus Berry  
Ability: Flame Body  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Jolly Nature  
- Belly Drum  
- Flame Charge  
- Thunder Punch  
- Earthquake  

";
$bina4887 = "Roaring Moon @ Life Orb  
Ability: Protosynthesis  
Tera Type: &
EVs: 108 Atk / 208 SpA / 192 Spe  
Hasty Nature  
- Crunch  
- Hurricane  
- Flamethrower  
- Iron Head  

";
$bina4897 = "Tornadus @ Leftovers  
Ability: Prankster  
Tera Type: &
EVs: 160 HP / 16 SpA / 164 SpD / 168 Spe  
Timid Nature  
IVs: 0 Atk  
- Heat Wave  
- Toxic  
- Substitute  
- Protect  

";
$bina4908 = "Enamorus-Therian (F) @ Weakness Policy  
Ability: Overcoat  
Tera Type: &
EVs: 248 HP / 60 Def / 200 SpD  
Modest Nature  
- Earth Power  
- Grass Knot  
- Calm Mind  
- Draining Kiss  

";
$bina4918 = "Hydreigon @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 Def / 4 SpA / 252 Spe  
Timid Nature  
- Stealth Rock  
- Draco Meteor  
- U-turn  
- Taunt  

";
$bina4928 = "Salamence @ Covert Cloak  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 232 SpD / 24 Spe  
Careful Nature  
- Dual Wingbeat  
- Fire Spin  
- Rest  
- Dragon Dance  

";
$bina4938 = "Gouging Fire @ Binding Band  
Ability: Protosynthesis  
Tera Type: &
EVs: 252 HP / 184 SpD / 72 Spe  
Careful Nature  
- Flare Blitz  
- Fire Spin  
- Rest  
- Dragon Dance  

";
$bina4948 = "Buizel @ Big Nugget  
Ability: Water Veil  
Tera Type: &
EVs: 236 Atk / 36 SpD / 236 Spe  
Adamant Nature  
- Aqua Jet  
- Wave Crash  
- Fling  
- Icy Wind  

";
$bina4958 = "Deoxys-Speed @ Rocky Helmet  
Ability: Pressure  
Tera Type: &
EVs: 248 HP / 216 Def / 44 Spe  
Bold Nature  
IVs: 0 Atk  
- Stealth Rock  
- Spikes  
- Thunder Wave  
- Taunt  

";
$bina4969 = "Cresselia (F) @ Rocky Helmet  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Calm Nature  
IVs: 0 Atk  
- Light Screen  
- Mist  
- Rest  
- Captivate  

";
$bina4980 = "Hatenna (F) @ Starf Berry  
Ability: Magic Bounce  
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA  
Bold Nature  
IVs: 0 Atk  
- Calm Mind  
- Life Dew  
- Stored Power  
- Baton Pass  

";
$bina4991 = "Ekans @ Eviolite  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Glare  
- Gunk Shot  
- Dig  
- Knock Off  

";
$bina41001 = "Chingling @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Psychic  
- Trick  
- Signal Beam  
- Hidden Power [Fire]  

";
$bina41012 = "Woobat @ Kee Berry  
Ability: Simple  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Calm Mind  
- Roost  
- Stored Power  
- Reflect  

";
$bina41023 = "Exeggcute @ Petaya Berry  
Ability: Harvest  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe  
Modest Nature  
IVs: 0 Atk  
- Substitute  
- Psychic  
- Synthesis  
- Protect  

";
$bina41034 = "Rockruff-Dusk @ Life Orb  
Ability: Own Tempo  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Swords Dance  
- Stone Edge  
- Trailblaze  
- Tera Blast  

";
$bina41044 = "Clobbopus @ Eviolite  
Ability: Technician  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Adamant Nature  
- Bulk Up  
- Circle Throw  
- Pain Split  
- Protect  

";
$bina41054 = "Mawile @ Mawilite  
Ability: Intimidate
Level: 92  
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD  
Brave Nature  
IVs: 1 Spe  
- Play Rough  
- Stone Edge  
- Sucker Punch  
- Protect 
 
";
$bina41066 = "Tapu Fini @ Leftovers  
Ability: Misty Surge 
Level: 94 
Tera Type: &
EVs: 252 HP / 120 Def / 132 SpA / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Heal Pulse  
- Psych Up  
- Muddy Water  
- Hidden Power [Grass]  

";
$bina41078 = "Mew @ Normalium Z  
Ability: Synchronize  
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe  
Calm Nature  
IVs: 0 Atk  
- Transform  
- Snarl  
- Life Dew  
- Will-O-Wisp  

";
$bina41089 = "Grimmsnarl @ Light Clay  
Ability: Prankster  
Tera Type: &
EVs: 248 HP / 172 Def / 88 SpD  
Careful Nature  
- Reflect  
- Light Screen  
- Spirit Break  
- Parting Shot  

";
$bina41099 = "Sinistcha @ Sitrus Berry  
Ability: Hospitality  
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD  
Sassy Nature  
IVs: 0 Atk / 0 Spe  
- Trick Room  
- Rage Powder  
- Matcha Gotcha  
- Shadow Ball  

";
$bina41110 = "Diancie @ Weakness Policy  
Ability: Clear Body  
Level: 96
Tera Type: &
EVs: 252 HP / 160 Def / 96 SpD  
Relaxed Nature  
IVs: 0 Spe  
- Trick Room  
- Diamond Storm  
- Body Press  
- Protect  

";
$bina41122 = "Thundurus @ Assault Vest  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Wild Charge  
- Sky Drop  
- Superpower  
- Volt Switch  

";
$bina41132 = "Weezing @ Leftovers  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 84 Atk / 72 Def / 32 SpA / 60 SpD / 8 Spe  
Brave Nature  
- Fire Blast  
- Sludge Bomb  
- Haze  
- Protect  

";
$bina41142 = "Zapdos @ Grassy Seed  
Ability: Pressure  
Tera Type: &
EVs: 232 HP / 252 SpA / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Thunderbolt  
- Hurricane  
- Tailwind  
- Roost  

";
$bina41153 = "Ampharos @ Leftovers  
Ability: Plus  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Magnetic Flux  
- Thunderbolt  
- Protect  
- Dragon Tail  

";
$bina41163 = "Mareanie @ Eviolite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 76 Def / 180 SpD  
Bold Nature  
IVs: 0 Atk  
- Recover  
- Haze  
- Infestation  
- Toxic Spikes  

";
$bina41174 = "Raboot @ Heavy-Duty Boots  
Ability: Libero  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Flare Blitz  
- High Jump Kick  
- U-turn  
- Taunt  

";
$bina41184 = "Clefairy @ Eviolite  
Ability: Magic Guard  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 0 Atk  
- Night Shade  
- Encore  
- Stealth Rock  
- Moonlight  

";
$bina41195 = "Frogadier @ Choice Specs  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
- Surf  
- Ice Beam  
- U-turn  
- Hydro Pump  

";
$bina41205 = "Drakloak @ Eviolite  
Ability: Cursed Body  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Night Shade  
- Dragon Tail  
- Rest  
- Sleep Talk  

";
$bina41215 = "Piloswine @ Eviolite  
Ability: Thick Fat  
Tera Type: &
EVs: 252 HP / 208 Atk / 48 Def  
Adamant Nature  
- High Horsepower  
- Icicle Crash  
- Reversal  
- Ice Shard  

";
$bina41225 = "Whimsicott @ Rocky Helmet  
Ability: Prankster  
Tera Type: &
EVs: 160 HP / 140 SpA / 208 Spe  
Timid Nature  
IVs: 0 Atk  
- Moonblast  
- Encore  
- Tailwind  
- Protect  

";
$bina41236 = "Koffing @ Eviolite  
Ability: Neutralizing Gas  
Tera Type: &
EVs: 252 HP / 4 Def / 204 SpD / 48 Spe  
Bold Nature  
IVs: 0 Atk  
- Sludge Bomb  
- Flamethrower  
- Toxic Spikes  
- Pain Split  

";
$bina41247 = "Sneasler @ Booster Energy  
Ability: Unburden  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Gunk Shot  
- Close Combat  
- Substitute  
- Fake Out  

";
$bina41257 = "Tornadus (M) @ Normal Gem  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Acrobatics  
- U-turn  
- Tailwind  
- Protect  

";
$bina41267 = "Archaludon @ Life Orb  
Ability: Stalwart  
Tera Type: &
EVs: 252 SpA / 232 SpD / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Flash Cannon  
- Electro Shot  
- Protect  

";
$bina41278 = "Kommo-o @ Sitrus Berry  
Ability: Overcoat  
Tera Type: &
EVs: 252 HP / 84 Def / 172 Spe  
Timid Nature  
IVs: 0 Atk  
- Clanging Scales  
- Vacuum Wave  
- Boomburst  
- Clangorous Soul  

";
$bina41289 = "Ogerpon-Hearthflame (F) @ Hearthflame Mask  
Ability: Mold Breaker  
Tera Type: &
EVs: 252 HP / 72 Def / 184 Spe  
Jolly Nature  
- Power Whip  
- Ivy Cudgel  
- Follow Me  
- Spiky Shield  

";
$bina41299 = "Sylveon @ Life Orb  
Ability: Pixilate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
- Hyper Voice  
- Shadow Ball  
- Double-Edge  
- Protect  

";
$bina41309 = "Audino @ Audinite  
Ability: Regenerator  
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD  
Calm Nature  
IVs: 0 Atk  
- Dazzling Gleam  
- Grass Knot  
- Wish  
- Protect  

";
$bina41320 = "Tyranitar @ Focus Sash  
Ability: Sand Stream  
Tera Type: &
EVs: 144 Atk / 112 SpA / 252 Spe  
Hasty Nature  
- Earthquake  
- Ice Beam  
- Thunder Wave  
- Stealth Rock  

";
$bina41330 = "Landorus (M) @ Choice Scarf  
Ability: Sand Force  
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe  
Naive Nature  
- Earthquake  
- Stone Edge  
- Hidden Power [Ice]  
- U-turn  

";
$bina41340 = "Poliwrath @ Expert Belt  
Ability: Water Absorb  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Rash Nature  
- Scald  
- Focus Blast  
- Earthquake  
- Vacuum Wave  

";
$bina41350 = "Misdreavus @ Eviolite  
Ability: Levitate  
Tera Type: &
EVs: 116 HP / 252 SpA / 140 Spe  
Timid Nature  
IVs: 3 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Shadow Ball  
- Hidden Power [Fighting]  
- Will-O-Wisp  
- Nasty Plot  

";
$bina41361 = "Rotom-Mow @ Choice Specs  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD  
Modest Nature  
IVs: 2 Atk / 30 SpA / 30 Spe  
- Leaf Storm  
- Volt Switch  
- Signal Beam  
- Hidden Power [Fire]  

";
$bina41372 = "Raging Bolt @ Booster Energy  
Ability: Protosynthesis  
Tera Type: &
EVs: 8 HP / 248 Def / 252 Spe  
Jolly Nature  
IVs: 20 Atk / 20 SpA  
- Thunderbolt  
- Weather Ball  
- Protect  
- Calm Mind  

";
$bina41383 = "Greninja @ Focus Sash  
Ability: Protean  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Modest Nature  
IVs: 0 Atk  
- Blizzard  
- Hydro Pump  
- Haze  
- Protect  

";
$bina41394 = "Moltres @ Heavy-Duty Boots  
Ability: Pressure  
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe  
Timid Nature  
IVs: 0 Atk  
- Heat Wave  
- Weather Ball  
- Tailwind  
- Protect  

";
$bina41405 = "Politoed @ Eject Button  
Ability: Drizzle  
Tera Type: &
EVs: 252 HP / 160 SpD / 96 Spe  
Calm Nature  
IVs: 0 Atk  
- Weather Ball  
- Icy Wind  
- Encore  
- Protect  

";
$bina41416 = "Overqwil @ Life Orb  
Ability: Swift Swim  
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe  
Jolly Nature  
- Gunk Shot  
- Liquidation  
- Toxic Spikes  
- Protect  

";
$bina41426 = "Corviknight @ Sitrus Berry  
Ability: Mirror Armor  
Tera Type: &
EVs: 252 HP / 52 Def / 188 SpD / 16 Spe  
Careful Nature  
- Brave Bird  
- Tailwind  
- Roost  
- U-turn  

";
$bina41436 = "Tornadus (M) @ Chilan Berry  
Ability: Prankster  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Bold Nature  
IVs: 0 Atk  
- Bleakwind Storm  
- Taunt  
- Tailwind  
- Protect  

";
$bina41447 = "Mew @ Eject Button  
Ability: Synchronize  
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe  
Timid Nature  
- Psychic  
- Snarl  
- Stealth Rock  
- Fake Out  

";
$bina41457 = "Landorus-Therian (M) @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 188 Def / 44 SpA / 24 Spe  
Modest Nature  
IVs: 0 Atk  
- Imprison  
- Protect  
- Earth Power  
- Sludge Bomb  

";
$bina41468 = "Arcanine @ Choice Scarf  
Ability: Intimidate  
Shiny: Yes  
Tera Type: &
EVs: 200 HP / 252 SpA / 56 Spe  
Rash Nature  
IVs: 0 Atk / 30 SpA  
- Overheat  
- Safeguard  
- Heat Wave  
- Hidden Power [Grass]  

";
$bina41480 = "Tyranitar @ Safety Goggles  
Ability: Sand Stream  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 16 Atk / 240 Def  
Adamant Nature  
- Foul Play  
- Rock Slide  
- Toxic  
- Protect  

";
$bina41491 = "Kangaskhan-Mega (F) @ Kangaskhanite  
Ability: Early Bird  
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe  
Jolly Nature  
- Fake Out  
- Seismic Toss  
- Low Kick  
- Rock Tomb  

";
$bina41501 = "Scizor @ Leftovers  
Ability: Technician  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Bullet Punch  
- Bug Bite  
- Swords Dance  
- Protect  

";
$bina41511 = "Landorus (M) @ Life Orb  
Ability: Sheer Force  
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe  
Naive Nature  
IVs: 1 Atk / 30 SpA  
- Earth Power  
- Sludge Wave  
- Hidden Power [Electric]  
- Protect  

";
$bina41522 = "Conkeldurr @ Assault Vest  
Ability: Iron Fist  
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe  
Adamant Nature  
- Drain Punch  
- Mach Punch  
- Rock Slide  
- Ice Punch  

";
$bina41532 = "Latias (F) @ Kee Berry  
Ability: Levitate  
Tera Type: &
EVs: 240 HP / 252 SpA / 16 Spe  
Modest Nature  
IVs: 0 Atk  
- Calm Mind  
- Draco Meteor  
- Thunderbolt  
- Recover  

";
$bina41543 = "Tyranitar @ Focus Sash  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe  
Adamant Nature  
- Rock Slide  
- Crunch  
- Rock Tomb  
- Protect  

";
$bina41553 = "Latias (F) @ Haban Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 72 SpA / 184 Spe  
Timid Nature  
IVs: 0 Atk  
- Thunderbolt  
- Ice Beam  
- Draco Meteor  
- Tailwind  

";
$bina41564 = "Porygon2 @ Eviolite  
Ability: Download  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD  
Bold Nature  
IVs: 1 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Trick Room  
- Thunderbolt  
- Hidden Power [Fighting]  
- Recover  

";
$bina41575 = "Tyranitar @ Babiri Berry  
Ability: Sand Stream  
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD  
Brave Nature  
IVs: 0 Spe  
- Rock Slide  
- Low Kick  
- Iron Head  
- Protect  

";
$bina41586 = "Scizor @ Occa Berry  
Ability: Swarm  
Tera Type: &
EVs: 252 HP / 216 Atk / 40 SpD  
Adamant Nature  
- Bullet Punch  
- Acrobatics  
- Brick Break  
- Protect  

";
$bina41596 = "Blastoise @ Eject Button  
Ability: Torrent  
Tera Type: &
EVs: 252 HP / 96 Def / 160 SpD  
Bold Nature  
IVs: 1 Atk / 30 Def / 30 SpA / 30 SpD / 30 Spe  
- Follow Me  
- Hidden Power [Fighting]  
- Scald  
- Roar  

";
$bina41607 = "Gardevoir @ Gardevoirite  
Ability: Trace  
Shiny: Yes  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Modest Nature  
IVs: 0 Atk  
- Hyper Voice  
- Psychic  
- Energy Ball  
- Protect  

";
$bina41619 = "Latias (F) @ Haban Berry  
Ability: Levitate  
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA  
Modest Nature  
IVs: 0 Atk  
- Draco Meteor  
- Psychic  
- Recover  
- Icy Wind  

";
$bina41630 = "Rhyperior @ Custap Berry  
Ability: Solid Rock  
Tera Type: &
EVs: 236 HP / 20 Atk / 252 SpD  
Careful Nature  
- Earthquake  
- Rock Wrecker  
- Endure  
- Swords Dance  

";
$bina41639 = "Gastrodon-East @ Rocky Helmet  
Ability: Storm Drain  
Tera Type: &
EVs: 252 HP / 196 Def / 60 SpA  
Modest Nature  
IVs: 0 Atk  
- Earth Power  
- Ice Beam  
- Recover  
- Protect  

";
$bina41649 = "Gothitelle @ Sitrus Berry  
Ability: Shadow Tag  
Tera Type: &
EVs: 252 HP / 224 Def / 16 SpD / 16 Spe  
Calm Nature  
IVs: 0 Atk  
- Psychic  
- Protect  
- Helping Hand  
- Taunt  

";
$bina41659 = "Landorus-Therian @ Sitrus Berry  
Ability: Intimidate  
Tera Type: &
EVs: 252 HP / 40 SpA / 216 SpD  
Sassy Nature  
- Earth Power  
- Superpower  
- Stealth Rock  
- U-turn  

";
$bina41668 = "Salamence @ Salamencite  
Ability: Intimidate  
Level: 95
Tera Type: &
EVs: 252 HP / 160 SpD / 96 Spe  
Timid Nature  
- Hyper Voice  
- Dragon Tail  
- Roost  
- Protect  

";
$bina41678 = "Bisharp @ Life Orb  
Ability: Defiant  
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Knock Off  
- Sucker Punch  
- Protect  
- Swords Dance  

";
$bina41687 = "Conkeldurr @ Assault Vest  
Ability: Iron Fist  
Tera Type: &
EVs: 252 HP / 56 Atk / 192 SpD / 8 Spe  
Adamant Nature  
- Drain Punch  
- Knock Off  
- Ice Punch  
- Mach Punch  

";

?>