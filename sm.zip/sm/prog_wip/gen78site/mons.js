createMons();

//search filter
let filterInput = document.getElementById('filter');
//when key is lifted
filterInput.addEventListener("keyup", filterNames);
//function for filtering
function filterNames() {
    let filterValue = document.getElementById('filter').value.toUpperCase();
    let div = document.getElementById('monElements');
    let mondivs = div.querySelectorAll('div.pokemon');
    //loop through mons
    for (let i = 0; i < mondivs.length; i++) {
        let a = mondivs[i].getElementsByTagName('a')[0];
        //if matches are found
        if (a.innerHTML.toUpperCase().indexOf(filterValue) > -1) {
            mondivs[i].style.display = 'block';
        } else {
            mondivs[i].style.display = 'none';
        }
    }
}