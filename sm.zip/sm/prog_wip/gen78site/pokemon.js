//pokemon constructor
function pokemon(objn, name, item, nature, ability, evs, move1, move2, move3, move4){
    this.objn = objn
    this.name = name
    this.item = item
    this.nature = nature
    this.evs = evs
    this.ability = ability
    this.move1 = move1
    this.move2 = move2
    this.move3 = move3
    this.move4 = move4
}

//pokemon
//dragapult
let dragapult_1 = new pokemon("dragapult_1", "Dragapult", "Choice Specs", "Timid", "Infiltrator", "252 SpA / 4 SpD / 252 Spe", "Draco Meteor", "Shadow Ball", "Fire Blast", "Surf");
let dragapult_2 = new pokemon("dragapult_2", "Dragapult", "Choice Scarf", "Modest", "Infiltrator", "216 HP / 252 SpA / 4 SpD / 36 Spe", "Draco Meteor", "Shadow Ball", "Fire Blast", "Surf");
let dragapult_3 = new pokemon("dragapult_3", "Dragapult", "Haban Berry", "Timid", "Infiltrator", "88 Def / 188 SpA / 232 Spe", "Substitute", "Disable", "Shadow Ball", "Draco Meteor");
let dragapult_4 = new pokemon("dragapult_4", "Dragapult", "Choice Band", "Jolly", "Infiltrator", "216 Atk / 60 Def / 232 Spe", "Outrage", "Phantom Force", "Dragon Darts", "Breaking Swipe");
let dragapult_5 = new pokemon("dragapult_5", "Dragapult", "Sitrus Berry", "Timid", "Infiltrator", "208 HP / 216 Def / 4 SpD / 80 Spe", "Substitute", "Disable", "Will-O-Wisp", "Hex");
let dragapult_6 = new pokemon("dragapult_6", "Dragapult", "Sitrus Berry", "Timid", "Clear Body", "24 HP / 252 Def / 232 Spe", "Curse", "Substitute", "Disable", "Shadow Ball");
let dragapult_7 = new pokemon("dragapult_7", "Dragapult", "Sitrus Berry", "Jolly", "Clear Body", "248 HP / 124 Def / 56 SpD / 80 Spe", "Phantom Force", "Curse", "Substitute", "Disable");
//darm galar"
let darmanitan_galar_1 = new pokemon("darmanitan_galar_1", "Darmanitan-Galar", "Choice Scarf", "Adamant", "Gorilla Tactics", "252 Atk / 4 SpD / 252 Spe", "Icicle Crash", "Flare Blitz", "Superpower", "Earthquake");
let darmanitan_galar_2 = new pokemon("darmanitan_galar_2", "Darmanitan-Galar", "Choice Band", "Adamant", "Gorilla Tactics", "252 Atk / 4 SpD / 252 Spe", "Icicle Crash", "Flare Blitz", "Superpower", "Earthquake");
let darmanitan_galar_3 = new pokemon("darmanitan_galar_3", "Darmanitan-Galar", "Choice Scarf", "Adamant", "Gorilla Tactics", "196 Atk / 112 SpD / 200 Spe", "Icicle Crash", "Flare Blitz", "Superpower", "Earthquake");
let darmanitan_galar_4 = new pokemon("darmanitan_galar_4", "Darmanitan-Galar", "Choice Band", "Jolly", "Gorilla Tactics", "252 Atk / 4 SpD / 252 Spe", "Icicle Crash", "Flare Blitz", "Superpower", "Giga Impact");
let darmanitan_galar_5 = new pokemon("darmanitan_galar_5", "Darmanitan-Galar", "Choice Band", "Adamant", "Gorilla Tactics", "252 Atk / 4 SpD / 252 Spe", "Icicle Crash", "Flare Blitz", "Giga Impact", "Earthquake");
//weezing
let weezing_galar_1 = new pokemon("weezing_galar_1", "Weezing-Galar", "Choice Specs", "Bold", "Neutralizing Gas", "248 HP / 60 Def / 100 SpA / 96 SpD / 4 Spe", "Strange Steam", "Sludge Bomb", "Thunderbolt", "Overheat");
//corviknight
let corviknight_1 = new pokemon("corviknight_1", "Corviknight", "Sitrus Berry", "Impish", "Pressure", "248 HP / 24 Atk / 72 Def / 48 SpD / 116 Spe", "Iron Head", "Iron Defense", "Taunt", "Roost");
let corviknight_2 = new pokemon("corviknight_2", "Corviknight", "Sitrus Berry", "Careful", "Pressure", "252 HP / 4 Def / 252 SpD", "Roost", "Iron Defense", "Taunt", "Iron Head");
//excadrill
let excadrill_1 = new pokemon("excadrill_1", "Excadrill", "Life Orb", "Adamant", "Mold Breaker", "224 Atk / 36 SpD / 248 Spe", "Earthquake", "Iron Head", "Bulldoze", "Substitute");
let excadrill_2 = new pokemon("excadrill_2", "Excadrill", "Choice Band", "Jolly", "Mold Breaker", "220 Atk / 36 SpD / 252 Spe", "Earthquake", "Iron Head", "Poison Jab", "X-Scissor");
let excadrill_3 = new pokemon("excadrill_3", "Excadrill", "Choice Scarf", "Adamant", "Mold Breaker", "224 Atk / 36 SpD / 248 Spe", "Earthquake", "Iron Head", "Poison Jab", "X-Scissor");
//mimikyu
let mimikyu_1 = new pokemon("mimikyu_1", "Mimikyu", "Life Orb", "Adamant", "Disguise", "252 Atk / 4 SpD / 252 Spe", "Swords Dance", "Play Rough", "Shadow Claw", "Shadow Sneak");
let mimikyu_2 = new pokemon("mimikyu_2", "Mimikyu", "Salac Berry", "Jolly", "Disguise", "4 HP / 252 Atk / 252 Spe", "Curse", "Protect", "Substitute", "Phantom Force");
let mimikyu_3 = new pokemon("mimikyu_3", "Mimikyu", "Life Orb", "Adamant", "Disguise", "252 Atk / 4 SpD / 252 Spe", "Play Rough", "Phantom Force", "Swords Dance", "Shadow Sneak");
let mimikyu_4 = new pokemon("mimikyu_4", "Mimikyu", "Choice Band", "Adamant", "Disguise", "248 HP / 252 Atk / 8 Def", "Play Rough", "Shadow Claw", "Shadow Sneak", "Wood Hammer");
//milotic
let milotic_1 = new pokemon("milotic_1", "Milotic", "Flame Orb", "Bold", "Marvel Scale", "248 HP / 252 Def / 8 SpD", "Scald", "Recover", "Light Screen", "Mirror Coat");
//sylveon
let sylveon_1 = new pokemon("sylveon_1", "Sylveon", "Pixie Plate", "Quiet", "Pixilate", "248 HP / 200 Def / 60 SpA", "Hyper Beam", "Hyper Voice", "Mystical Fire", "Quick Attack");
let sylveon_2 = new pokemon("sylveon_2", "Sylveon", "Choice Specs", "Modest", "Pixilate", "252 SpA / 4 SpD / 252 Spe", "Hyper Beam", "Hyper Voice", "Mystical Fire", "Shadow Ball");
let sylveon_3 = new pokemon("sylveon_3", "Sylveon", "Pixie Plate", "Modest", "Pixilate", "248 HP / 200 Def / 60 SpA", "Yawn", "Protect", "Hyper Voice", "Fake Tears");
let sylveon_4 = new pokemon("sylveon_4", "Sylveon", "Babiri Berry", "Bold", "Pixilate", "136 HP / 236 Def / 136 SpA", "Hyper Voice", "Yawn", "Protect", "Fake Tears");
let sylveon_5 = new pokemon("sylveon_5", "Sylveon", "Babiri Berry", "Modest", "Pixilate", "16 HP / 200 Def / 52 SpA / 240 Spe", "Hyper Voice", "Hyper Beam", "Mystical Fire", "Fake Tears");
//grimmsnarl
let grimmsnarl_1 = new pokemon("grimmsnarl_1", "Grimmsnarl", "Choice Band", "Adamant", "Prankster", "120 HP / 132 Atk / 252 Def / 4 Spe", "Darkest Lariat", "Play Rough", "Superpower", "Trick");
let grimmsnarl_2 = new pokemon("grimmsnarl_2", "Grimmsnarl", "Sitrus Berry", "Impish", "Prankster", "244 HP / 12 Atk / 252 Def", "Taunt", "Bulk Up", "Play Rough", "Sucker Punch");
//arcanine
let arcanine_1 = new pokemon("arcanine_1", "Arcanine", "Choice Band", "Jolly", "Intimidate", "52 HP / 4 Atk / 252 SpD / 200 Spe", "Flare Blitz", "Outrage", "Close Combat", "Crunch");
let arcanine_2 = new pokemon("arcanine_2", "Arcanine", "Air Balloon", "Bold", "Intimidate", "252 HP / 236 Def / 20 SpA", "Burn Up", "Will-O-Wisp", "Morning Sun", "Flamethrower");
let arcanine_3 = new pokemon("arcanine_3", "Arcanine", "Air Balloon", "Bold", "Intimidate", "248 HP / 136 Def / 76 SpA / 40 SpD / 8 Spe", "Fire Blast", "Snarl", "Morning Sun", "Will-O-Wisp");
//duraludon
let duraludon_1 = new pokemon("duraludon_1", "Duraludon", "Choice Specs", "Modest", "Heavy Metal", "248 HP / 160 Def / 12 SpA / 88 SpD", "Draco Meteor", "Steel Beam", "Flash Cannon", "Thunderbolt");
//dracovish
let dracovish_1 = new pokemon("dracovish_1", "Dracovish", "Choice Band", "Jolly", "Strong Jaw", "252 Atk / 4 SpD / 252 Spe", "Fishious Rend", "Outrage", "Earthquake", "Crunch");
let dracovish_2 = new pokemon("dracovish_2", "Dracovish", "Choice Scarf", "Jolly", "Strong Jaw", "252 Atk / 4 SpD / 252 Spe", "Fishious Rend", "Outrage", "Earthquake", "Crunch");
//rillaboom
let rillaboom_1 = new pokemon("rillaboom_1", "Rillaboom", "Liechi Berry", "Jolly", "Overgrow", "32 HP / 252 Atk / 224 Spe", "Drum Beating", "Substitute", "Wood Hammer", "Earthquake");
let rillaboom_2 = new pokemon("rillaboom_2", "Rillaboom", "Leftovers", "Impish", "Overgrow", "240 HP / 56 Def / 100 SpD / 112 Spe", "Drum Beating", "Leech Seed", "Taunt", "Substitute");
let rillaboom_3 = new pokemon("rillaboom_3", "Rillaboom", "Choice Band", "Adamant", "Grassy Surge", "56 HP / 252 Atk / 200 Spe", "Wood Hammer", "Drum Beating", "Superpower", "U-turn");
//gastrodon
let gastrodon_1 = new pokemon("gastrodon_1", "Gastrodon", "Sitrus Berry", "Calm", "Storm Drain", "248 HP / 112 Def / 148 SpD", "Scald", "Recover", "Acid Armor", "Amnesia");
let gastrodon_2 = new pokemon("gastrodon_2", "Gastrodon", "Sitrus Berry", "Bold", "Sticky Hold", "236 HP / 176 Def / 96 SpD", "Acid Armor", "Amnesia", "Scald", "Recover");
//haxorus
let haxorus_1 = new pokemon("haxorus_1", "Haxorus", "Choice Scarf", "Jolly", "Mold Breaker", "252 Atk / 4 SpD / 252 Spe", "Outrage", "Close Combat", "Iron Tail", "Poison Jab");
let haxorus_2 = new pokemon("haxorus_2", "Haxorus", "Choice Band", "Jolly", "Mold Breaker", "252 Atk / 4 SpD / 252 Spe", "Outrage", "Close Combat", "Earthquake", "Iron Tail");
let haxorus_3 = new pokemon("haxorus_3", "Haxorus", "Life Orb", "Jolly", "Mold Breaker", "252 Atk / 4 SpD / 252 Spe", "Taunt", "Swords Dance", "Outrage", "Close Combat");
let haxorus_4 = new pokemon("haxorus_4", "Haxorus", "Life Orb", "Jolly", "Unnerve", "252 Atk / 4 SpD / 252 Spe", "Taunt", "Swords Dance", "Outrage", "Close Combat");
//indeedee
let indeedee_1 = new pokemon("indeedee_1", "Indeedee-F", "Choice Specs", "Modest", "Psychic Surge", "192 HP / 156 Def / 148 SpA / 4 SpD / 8 Spe", "Psychic", "Mystical Fire", "Trick", "Hyper Voice");
//cinderace
let cinderace_1 = new pokemon("cinderace_1", "Cinderace", "Liechi Berry", "Adamant", "Blaze", "252 Atk / 4 SpD / 252 Spe", "Pyro Ball", "Substitute", "Taunt", "Reversal");
let cinderace_2 = new pokemon("cinderace_2", "Cinderace", "Choice Band", "Jolly", "Libero", "200 HP / 124 Atk / 96 Def / 88 Spe", "Pyro Ball", "Giga Impact", "High Jump Kick", "Gunk Shot");
let cinderace_3 = new pokemon("cinderace_3", "Cinderace", "Choice Scarf", "Adamant", "Libero", "88 Atk / 244 Def / 176 Spe", "Flare Blitz", "High Jump Kick", "Gunk Shot", "Counter");
let cinderace_4 = new pokemon("cinderace_4", "Cinderace", "Life Orb", "Adamant", "Libero", "4 HP / 168 Atk / 132 Def / 204 Spe", "High Jump Kick", "Gunk Shot", "Bulk Up", "Substitute");
let cinderace_5 = new pokemon("cinderace_5", "Cinderace", "Life Orb", "Adamant", "Libero", "4 HP / 168 Atk / 132 Def / 204 Spe", "High Jump Kick", "Gunk Shot", "Taunt", "Substitute");
//rotom heat
let rotom_heat_1 = new pokemon("rotom_heat_1", "Rotom-Heat", "Kee Berry", "Bold", "Levitate", "248 HP / 48 Def / 208 SpD / 4 Spe", "Will-O-Wisp", "Eerie Impulse", "Thunderbolt", "Rest");
let rotom_heat_2 = new pokemon("rotom_heat_2", "Rotom-Heat", "Choice Specs", "Modest", "Levitate", "240 HP / 252 SpA / 16 Spe", "Thunderbolt", "Overheat", "Rest", "Trick");
let rotom_heat_3 = new pokemon("rotom_heat_3", "Rotom-Heat", "Choice Scarf", "Bold", "Levitate", "144 HP / 40 Def / 160 SpA / 164 Spe", "Thunderbolt", "Overheat", "Trick", "Rest");
//hydreigon
let hydreigon_1 = new pokemon("hydreigon_1", "Hydreigon", "Haban Berry", "Modest", "Levitate", "100 HP / 248 SpA / 160 Spe", "Draco Meteor", "Dark Pulse", "Nasty Plot", "Fire Blast");
let hydreigon_2 = new pokemon("hydreigon_2", "Hydreigon", "Choice Scarf", "Timid", "Levitate", "4 HP / 252 SpA / 252 Spe", "Draco Meteor", "Dark Pulse", "Focus Blast", "Fire Blast");
let hydreigon_3 = new pokemon("hydreigon_3", "Hydreigon", "Choice Specs", "Modest", "Levitate", "4 HP / 252 SpA / 28 SpD / 224 Spe", "Draco Meteor", "Dark Pulse", "Fire Blast", "Focus Blast");
//tyranitar
let tyranitar_1 = new pokemon("tyranitar_1", "Tyranitar", "Choice Band", "Adamant", "Sand Stream", "232 HP / 252 Atk / 24 Spe", "Crunch", "Stone Edge", "Heavy Slam", "Superpower");
//aromatisse
let aromatisse_1 = new pokemon("aromatisse_1", "Aromatisse", "Wiki Berry", "Relaxed", "Aroma Veil", "120 HP / 252 Def / 132 SpA / 4 SpD", "Encore", "Trick Room", "Disable", "Moonblast");
let aromatisse_2 = new pokemon("aromatisse_2", "Aromatisse", "Wiki Berry", "Bold", "Aroma Veil", "252 HP / 252 Def / 4 SpD", "Encore", "Trick Room", "Disable", "Moonblast");
let aromatisse_3 = new pokemon("aromatisse_3", "Aromatisse", "Wiki Berry", "Calm", "Aroma Veil", "232 HP / 132 Def / 144 SpD", "Moonblast", "Encore", "Disable", "Trick room");
let aromatisse_4 = new pokemon("aromatisse_4", "Aromatisse", "Wiki Berry", "Calm", "Aroma Veil", "244 HP / 40 Def / 224 SpD", "Moonblast", "Encore", "Disable", "Trick Room");
//rotom wash
let rotom_wash_1 = new pokemon("rotom_wash_1", "Rotom-Wash", "Kee Berry", "Bold", "Levitate", "248 HP / 184 Def / 28 SpD / 48 Spe", "Will-O-Wisp", "Eerie Impulse", "Thunderbolt", "Rest");
let rotom_wash_2 = new pokemon("rotom_wash_2", "Rotom-Wash", "Choice Specs", "Modest", "Levitate", "240 HP / 252 SpA / 16 Spe", "Thunderbolt", "Hydro Pump", "Trick", "Rest");
//golisopod
let golisopod_1 = new pokemon("golisopod_1", "Golisopod", "Choice Band", "Adamant", "Emergency Exit", "248 HP / 156 Atk / 60 Def / 44 Spe", "Leech Life", "Liquidation", "Close Combat", "Payback");
let golisopod_2 = new pokemon("golisopod_2", "Golisopod", "Life Orb", "Adamant", "Emergency Exit", "252 HP / 252 Atk / 4 SpD", "Leech Life", "Liquidation", "Aqua Jet", "Taunt");
//togekiss
let togekiss_1 = new pokemon("togekiss_1", "Togekiss", "Choice Scarf", "Timid", "Serene Grace", "252 SpA / 4 SpD / 252 Spe", "Air Slash", "Dazzling Gleam", "Fire Blast", "Trick");
let togekiss_2 = new pokemon("togekiss_2", "Togekiss", "Maranga Berry", "Calm", "Serene Grace", "252 HP / 64 Def / 104 SpD / 88 Spe", "Air Slash", "Thunder Wave", "Roost", "Nasty Plot");
//aegislash
let aegislash_1 = new pokemon("aegislash_1", "Aegislash", "Choice Band", "Brave", "Stance Change", "244 HP / 252 Atk / 12 Spe", "Close Combat", "Iron Head", "Gyro Ball", "Shadow Claw");
let aegislash_2 = new pokemon("aegislash_2", "Aegislash", "Weakness Policy", "Quiet", "Stance Change", "248 HP / 8 Atk / 252 SpA", "Shadow Ball", "Flash Cannon", "King's Shield", "Shadow Sneak");
//gengar
let gengar_1 = new pokemon("gengar_1", "Gengar", "Life Orb", "Timid", "Cursed Body", "252 SpA / 4 SpD / 252 Spe", "Shadow Ball", "Sludge Wave", "Dazzling Gleam", "Encore");
let gengar_2 = new pokemon("gengar_2", "Gengar", "Choice Specs", "Timid", "Cursed Body", "252 SpA / 4 SpD / 252 Spe", "Shadow Ball", "Sludge Wave", "Energy Ball", "Dazzling gleam");
//eldegoss
let eldegoss_1 = new pokemon("eldegoss_1", "Eldegoss", "Sitrus Berry", "Bold", "Cotton Down", "248 HP / 252 Def / 8 Spe", "Cotton guard", "Leech Seed", "Rest", "Rapid Spin");
//alcremie 
let alcremie_1 = new pokemon("alcremie_1", "Alcremie", "Sitrus Berry", "Bold", "Aroma Veil", "228 HP / 252 Def / 28 Spe", "Baby-Doll Eyes", "Calm Mind", "Recover", "Dazzling Gleam");
//centiskorch
let centiskorch_1 = new pokemon("centiskorch_1", "Centiskorch", "Choice Band", "Adamant", "Flash Fire", "248 HP / 252 Atk / 8 SpD", "Flare Blitz", "Leech Life", "Power Whip", "Knock Off");
//toxapex
let toxapex_1 = new pokemon("toxapex_1", "Toxapex", "Sitrus Berry", "Bold", "Limber", "248 HP / 172 Def / 88 SpD", "Toxic", "Iron Defense", "Recover", "Scald");
//toxtricity
let toxtricity_1 = new pokemon("toxtricity_1", "Toxtricity", "Life Orb", "Modest", "Punk Rock", "68 HP / 252 Def / 188 SpA", "Overdrive", "Nuzzle", "Charge", "Hex");
let toxtricity_2 = new pokemon("toxtricity_2", "Toxtricity", "Choice Specs", "Modest", "Punk Rock", "252 HP / 36 Def / 220 SpA", "Overdrive", "Boomburst", "Sludge Wave", "Uproar");
//rhyperior
let rhyperior_1 = new pokemon("rhyperior_1", "Rhyperior", "Assault Vest", "Impish", "Solid Rock", "248 HP / 116 Def / 144 SpD", "Metal Burst", "Earthquake", "Rock Wrecker", "Rock Blast");
let rhyperior_2 = new pokemon("rhyperior_2", "Rhyperior", "Choice Band", "Adamant", "Solid Rock", "104 HP / 68 Atk / 164 SpD / 172 Spe", "Rock Wrecker", "Earthquake", "Heat Crash", "Poison Jab");
//corsola 
let corsola_1 = new pokemon("corsola_1", "Corsola-Galar", "Eviolite", "Bold", "Cursed Body", "248 HP / 212 Def / 48 SpD", "Strength Sap", "Spite", "Amnesia", "Rest");
let corsola_2 = new pokemon("corsola_2", "Corsola-Galar", "Eviolite", "Bold", "Cursed Body", "248 HP / 252 Def / 8 SpD", "Spite", "Strength Sap", "Icy Wind", "Rest");
let corsola_3 = new pokemon("corsola_3", "Corsola-Galar", "Eviolite", "Bold", "Cursed Body", "248 HP / 252 Def / 8 SpD", "Night Shade", "Will-O-Wisp", "Strength Sap", "Rest");
//crustle
let crustle_1 = new pokemon("crustle_1", "Crustle", "Mental Herb", "Adamant", "Sturdy", "252 Atk / 4 SpD / 252 Spe", "Rock Wrecker", "Shell Smash", "Counter", "Rock Blast");
let crustle_2 = new pokemon("crustle_2", "Crustle", "Choice Band", "Brave", "Sturdy", "160 HP / 252 Atk / 96 Def", "Rock Wrecker", "Rock Blast", "Heavy Slam", "Earthquake");
//sawk
let sawk_1 = new pokemon("sawk_1", "Sawk", "Choice Scarf", "Jolly", "Sturdy", "252 Atk / 4 SpD / 252 Spe", "Close Combat", "Earthquake", "Throat Chop", "Poison Jab");
let sawk_2 = new pokemon("sawk_2", "Sawk", "Choice Band", "Adamant", "Sturdy", "8 HP / 252 Atk / 156 Def / 92 Spe", "Close Combat", "Payback", "Poison Jab", "Counter");
let sawk_3 = new pokemon("sawk_3", "Sawk", "Choice Band", "Jolly", "Sturdy", "252 Atk / 4 Def / 252 Spe", "Close Combat", "Knock Off", "Poison Jab", "Counter");
//whimsicott
let whimsicott_1 = new pokemon("whimsicott_1", "Whimsicott", "Leftovers", "Bold", "Prankster", "240 HP / 120 Def / 148 SpD", "Leech Seed", "Protect", "Substitute", "Taunt");
let whimsicott_2 = new pokemon("whimsicott_2", "Whimsicott", "Babiri Berry", "Bold", "Prankster", "240 HP / 120 Def / 148 SpD", "Leech Seed", "Protect", "Substitute", "Taunt");
//goodra 
let goodra_1 = new pokemon("goodra_1", "Goodra", "Haban Berry", "Modest", "Sap Sipper", "252 HP / 28 Def / 176 SpA / 52 Spe", "Acid Spray", "Draco Meteor", "Thunderbolt", "Counter");
//conkeldurr
let conkeldurr_1 = new pokemon("conkeldurr_1", "Conkeldurr", "Life Orb", "Adamant", "Iron Fist", "248 HP / 208 Atk / 52 SpD", "Close Combat", "Mach Punch", "Payback", "Ice Punch");
let conkeldurr_2 = new pokemon("conkeldurr_2", "Conkeldurr", "Life Orb", "Adamant", "Iron Fist", "248 HP / 208 Atk / 52 SpD", "Close Combat", "Mach Punch", "Payback", "Earthquake");
//dracozolt
let dracozolt_1 = new pokemon("dracozolt_1", "Dracozolt", "Choice Scarf", "Adamant", "Hustle", "252 Atk / 4 Def / 252 Spe", "Bolt Beak", "Outrage", "Fire Fang", "Low Kick");
let dracozolt_2 = new pokemon("dracozolt_2", "Dracozolt", "Choice Band", "Adamant", "Hustle", "252 Atk / 4 SpD / 252 Spe", "Bolt Beak", "Outrage", "Fire Fang", "Rock Blast");
//steelix
let steelix_1 = new pokemon("steelix_1", "Steelix", "Choice Band", "Brave", "Sturdy", "240 HP / 252 Atk / 16 Def", "Earthquake", "Heavy Slam", "Gyro Ball", "Body Press");
let steelix_2 = new pokemon("steelix_2", "Steelix", "Figy Berry", "Adamant", "Sturdy", "240 HP / 252 Atk / 16 Def", "Earthquake", "Heavy Slam", "Protect", "Torment");
//snorlax
let snorlax_1 = new pokemon("snorlax_1", "Snorlax", "Choice Band", "Adamant", "Thick Fat", "12 HP / 236 Atk / 252 Def / 8 SpD", "Giga Impact", "Heat Crash", "Heavy Slam", "Counter");
let snorlax_2 = new pokemon("snorlax_2", "Snorlax", "Chople Berry", "Careful", "Thick Fat", "252 HP / 4 Atk / 184 Def / 68 SpD", "Counter", "Tackle", "Amnesia", "Rest");
//koommoo
let kommoo_1 = new pokemon("kommoo_1", "Kommo-o", "Haban Berry", "Impish", "Bulletproof", "244 HP / 156 Atk / 56 Def / 52 Spe", "Iron Defense", "Taunt", "Outrage", "Body Press");
let kommoo_2 = new pokemon("kommoo_2", "Kommo-o", "Haban Berry", "Bold", "Bulletproof", "160 HP / 96 Def / 140 SpA / 112 Spe", "Iron Defense", "Body Press", "Taunt", "Clanging Scales");
let kommoo_3 = new pokemon("kommoo_3", "Kommo-o", "Haban Berry", "Bold", "Soundproof", "160 HP / 96 Def / 140 SpA / 112 Spe", "Iron Defense", "Body Press", "Substitute", "Clanging Scales");
//silvally
let silvally_water_1 = new pokemon("silvally_water_1", "Silvally-Water", "Water Memory", "Impish", "RKS System", "232 HP / 96 Atk / 180 Def", "Parting Shot", "Iron Defense", "Multi Attack", "Rest");
//terrakion
let terrakion_1 = new pokemon("terrakion_1", "Terrakion", "Choice Band", "Jolly", "Justified", "140 Atk / 144 SpD / 224 Spe", "Close Combat", "Stone Edge", "Rock Tomb", "Poison Jab");
//keldeo 
let keldeo_1 = new pokemon("keldeo_1", "Keldeo", "Choice Specs", "Timid", "Justified", "72 HP / 200 Def / 60 SpA / 176 Spe", "Focus Blast", "Hydro Pump", "Secret Sword", "Icy Wind");
//incineroar 
let incineroar_1 = new pokemon("incineroar_1", "Incineroar", "Weakness Policy", "Impish", "Intimidate", "248 HP / 28 Atk / 208 Def / 24 Spe", "Bulk Up", "Flare Blitz", "Flame Charge", "Darkest Lariat");
//primarina
let primarina_1 = new pokemon("primarina_1", "Primarina", "Choice Specs", "Modest", "Torrent", "252 HP / 56 Def / 184 SpA / 16 Spe", "Hydro Cannon", "Sparkling Aria", "Moonblast", "Energy Ball");
let primarina_2 = new pokemon("primarina_2", "Primarina", "Petaya Berry", "Calm", "Torrent", "236 HP / 16 Def / 128 SpA / 128 SpD", "Hydro Cannon", "Sparkling Aria", "Moonblast", "Substitute");
let primarina_3 = new pokemon("primarina_3", "Primarina", "Mystic Water", "Modest", "Torrent", "252 HP / 124 Def / 128 SpA / 4 SpD", "Sparkling Aria", "Moonblast", "Aqua Jet", "Encore");
let primarina_4 = new pokemon("primarina_4", "Primarina", "Assault Vest", "Modest", "Torrent", "252 HP / 124 Def / 128 SpA / 4 Spe", "Hydro Cannon", "Moonblast", "Sparkling Aria", "Aqua Jet");
//zeraora
let zeraora_1 = new pokemon("zeraora_1", "Zeraora", "Choice Band", "Jolly", "Volt Absorb", "252 Atk / 4 Def / 252 Spe", "Plasma Fists", "Outrage", "Close Combat", "Knock Off");
let zeraora_2 = new pokemon("zeraora_2", "Zeraora", "Life Orb", "Jolly", "Volt Absorb", "252 Atk / 4 SpD / 252 Spe", "Taunt", "Plasma Fists", "Outrage", "Close Combat");
let zeraora_3 = new pokemon("zeraora_3", "Zeraora", "Life Orb", "Adamant", "Volt Absorb", "252 Atk / 4 SpD / 252 Spe", "Fake Out", "Plasma Fists", "Close Combat", "Taunt");
let zeraora_4 = new pokemon("zeraora_4", "Zeraora", "Life Orb", "Jolly", "Volt absorb", "252 Atk / 4 SpD / 252 Spe", "Fake Out", "Plasma Fists", "Outrage", "Taunt");
//blastoise 
let blastoise_1 = new pokemon("blastoise_1", "Blastoise", "Petaya Berry", "Timid", "Torrent", "216 HP / 72 Def / 104 SpA / 116 Spe", "Hydro Cannon", "Shell Smash", "Dragon Pulse", "Substitute");
//mandibuzz
let mandibuzz_1 = new pokemon("mandibuzz_1", "Mandibuzz", "Sitrus Berry", "Bold", "Overcoat", "248 HP / 16 Def / 92 SpD / 152 Spe", "Iron Defense", "Roost", "Snarl", "Taunt");
//venusaur 
let venusaur_1 = new pokemon("venusaur_1", "Venusaur", "Petaya Berry", "Modest", "Overgrow", "236 HP / 168 SpA / 104 Spe", "Frenzy Plant", "Sludge Bomb", "Sleep Powder", "Substitute");
//avalugg
let avalugg_1 = new pokemon("avalugg_1", "Avalugg", "Choice Band", "Naughty", "Sturdy", "252 HP / 252 Atk / 4 Def", "Icicle Spear", "Heavy Slam", "Earthquake", "Mirror Coat");
let avalugg_2 = new pokemon("avalugg_2", "Avalugg", "Choice Band", "Impish", "Sturdy", "4 HP / 252 Atk / 252 Def", "Icicle Spear", "Body Press", "Heavy Slam", "Earthquake");
//hippowdon 
let hippowdon_1 = new pokemon("hippowdon_1", "Hippowdon", "Choice Band", "Adamant", "Sand Stream", "44 HP / 248 Atk / 208 SpD / 8 Spe", "Earthquake", "Heavy Slam", "Rock Tomb", "Crunch");
//pyukumuku
let pyukumuku_1 = new pokemon("pyukumuku_1", "Pyukumuku", "Lum Berry", "Bold", "Unaware", "252 HP / 200 Def / 56 SpD", "Taunt", "Counter", "Mirror Coat", "Recover");
let pyukumuku_2 = new pokemon("pyukumuku_2", "Pyukumuku", "Rocky Helmet", "Bold", "Unaware", "252 HP / 252 Def / 4 SpD", "Counter", "Mirror Coat", "Spite", "Recover");
//diggersby
let diggersby_1 = new pokemon("diggersby_1", "Diggersby", "Choice Band", "Adamant", "Huge Power", "252 Atk / 4 SpD / 252 Spe", "Earthquake", "Giga Impact", "Bulldoze", "Fire Punch");
//gyarados
let gyarados_1 = new pokemon("gyarados_1", "Gyarados", "Life Orb", "Adamant", "Intimidate", "40 HP / 252 Atk / 168 SpD / 48 Spe", "Waterfall", "Power Whip", "Outrage", "Taunt");
//chandelure
let chandelure_1 = new pokemon("chandelure_1", "Chandelure", "Choice Scarf ", "Timid", "Infiltrator", "252 SpA / 4 SpD / 252 Spe", "Shadow Ball", "Overheat", "Energy Ball", "Trick");
//durant 
let durant_1 = new pokemon("durant_1", "Durant", "Choice Band", "Jolly", "Hustle", "252 Atk / 4 SpD / 252 Spe", "Iron Head", "First Impression", "Superpower", "Stone Edge");
//meowstic
let meowstic_1 = new pokemon("meowstic_1", "Meowstic", "Maranga Berry", "Bold", "Prankster", "224 HP / 180 Def / 104 SpD", "Psychic", "Calm Mind", "Charm", "Rest");
let meowstic_2 = new pokemon("meowstic_2", "Meowstic", "Maranga Berry", "Bold", "Prankster", "224 HP / 180 Def / 104 SpD", "Charm", "Calm Mind", "Psyshock", "Rest");
//celebi
let celebi_1 = new pokemon("celebi_1", "Celebi", "Choice Specs", "Timid", "Natural Cure", "252 SpA / 4 SpD / 252 Spe", "Trick", "Leaf Storm", "Psychic", "Recover");
//gardevoir
let gardevoir_1 = new pokemon("gardevoir_1", "Gardevoir", "Choice Scarf", "Timid", "Trace", "4 Def / 252 SpA / 252 Spe", "Moonblast", "Psychic", "Trick", "Disable");
//clefable
let clefable_1 = new pokemon("clefable_1", "Clefable", "Leftovers", "Bold", "Magic Guard", "252 HP / 252 Def / 4 SpA", "Moonblast", "Toxic", "Soft Boiled", "Cosmic Power");
//darmanitan 
let darmanitan_1 = new pokemon("darmanitan_1", "Darmanitan", "Choice Scarf", "Jolly", "Sheer Force", "252 Atk / 4 SpD / 252 Spe", "Flare Blitz", "Superpower", "Earthquake", "Trick");
//kyurem 
let kyurem_1 = new pokemon("kyurem_1", "Kyurem", "Choice Specs", "Timid", "Pressure", "252 SpA / 4 SpD / 252 Spe", "Draco Meteor", "Ice Beam", "Freeze Dry", "Earth Power");
let kyurem_2 = new pokemon("kyurem_2", "Kyurem", "Haban Berry", "Bold", "Pressure", "232 HP / 108 Def / 168 SpD", "Noble Roar", "Roost", "Draco Meteor", "Freeze Dry");
//type null
let type_null_1 = new pokemon("type_null_1", "Type: Null", "Eviolite", "Impish", "Battle Armor", "228 HP / 216 Def / 64 SpD", "Iron Defense", "Confide", "Flame Charge", "Rest");
//hatterene 
let hatterene_1 = new pokemon("hatterene_1", "Hatterene", "Sitrus Berry", "Modest", "Magic Bounce", "248 HP / 80 Def / 36 SpA / 144 SpD", "Draining Kiss", "Psychic", "Mystical Fire", "Calm Mind");
//butterfree
let butterfree_1 = new pokemon("butterfree_1", "Butterfree", "Leftovers", "Timid", "Compound Eyes", "252 SpA / 4 SpD / 252 Spe", "Sleep Powder", "Quiver Dance", "Substitute", "Bug Buzz");
//ninetales
let ninetales_1 = new pokemon("ninetales_1", "Ninetales", "Salac Berry", "Timid", "Drought", "4 Def / 252 SpA / 252 Spe", "Endure", "Disable", "Pain Split", "Overheat");
//roserade
let roserade_1 = new pokemon("roserade_1", "Roserade", "Life Orb", "Timid", "Natural Cure", "8 HP / 52 Def / 208 SpA / 240 Spe", "Sleep Powder", "Sludge Bomb", "Leaf Storm", "Dazzling Gleam");
//rotom mow
let rotom_mow_1 = new pokemon("rotom_mow_1", "Rotom-Mow", "Choice Specs", "Modest", "Levitate", "248 HP / 88 Def / 168 SpA / 4 Spe", "Leaf Storm", "Thunderbolt", "Trick", "Rest");
//salazzle
let salazzle_1 = new pokemon("salazzle_1", "Salazzle", "Life Orb", "Modest", "Oblivious", "252 SpA / 4 SpD / 252 Spe", "Fake Out", "Overheat", "Sludge Wave", "Encore");
//Wobbuffet
let wobbuffet_1 = new pokemon("wobbuffet_1", "Wobbuffet", "Assault Vest", "Bold", "Shadow Tag", "4 HP / 252 Def / 252 SpD", "Counter", "Mirror Coat", "", "");
//magnezone
let magnezone_1 = new pokemon("magnezone_1", "Magnezone", "Choice Specs", "Modest", "Sturdy", "216 HP / 248 SpA / 20 SpD / 24 Spe", "Thunderbolt", "Flash cannon", "Hyper Beam", "Mirror Coat");
//volcarona
let volcarona_1 = new pokemon("volcarona_1", "Volcarona", "Choice Specs", "Timid", "Flame Body", "252 SpA / 4 SpD / 252 Spe", "Overheat", "Bug Buzz", "Giga Drain", "Hurricane");
let volcarona_2 = new pokemon("volcarona_2", "Volcarona", "Passho Berry", "Calm", "Flame Body", "252 HP / 4 SpA / 252 SpD", "Flamethrower", "Quiver Dance", "Roost", "Giga Drain");
let volcarona_3 = new pokemon("volcarona_3", "Volcarona", "Petaya Berry", "Timid", "Swarm", "4 HP / 212 Def / 40 SpA / 252 Spe", "Overheat", "Bug Buzz", "Quiver Dance", "Substitute");
//porygonz
let porygonz_1 = new pokemon("porygonz_1", "Porygon-Z", "Choice Scarf", "Timid", "Adaptability", "64 HP / 252 SpA / 192 Spe", "Hyper Beam", "Trick", "Rest", "Uproar");
let porygonz_2 = new pokemon("porygonz_2", "Porygon-Z", "Choice Specs", "Timid", "Adaptability", "252 SpA / 4 SpD / 252 Spe", "Hyper Beam", "Trick", "Rest", "Uproar");
//chansey
let chansey_1 = new pokemon("chansey_1", "Chansey", "Eviolite", "Bold", "Serene Grace", "248 HP / 252 Def / 8 SpD", "Counter", "Toxic", "Soft Boiled", "Seismic Toss");
//urshifu
let urshifu_1 = new pokemon("urshifu_1", "Urshifu-Rapid-Strike", "Choice Band", "Adamant", "Unseen Fist", "136 HP / 84 Atk / 244 Def / 44 Spe", "Surging Strikes", "Close Combat", "Poison Jab", "Counter");
//azumarill
let azumarill_1 = new pokemon("azumarill_1", "Azumarill", "Choice Band", "Adamant", "Huge Power", "252 HP / 252 Atk / 4 SpD", "Play Rough", "Liquidation", "Superpower", "Giga Impact");
//porygon2
let porygon2_1 = new pokemon("porygon2_1", "Porygon2", "Eviolite", "Bold", "Analytic", "252 HP / 252 Def / 4 SpD", "Curse", "Eerie Impulse", "Conversion", "Recover");
//magearna 
let magearna_1 = new pokemon("magearna_1", "Magearna", "Sitrus Berry", "Modest", "Soul Heart", "248 HP / 36 Def / 224 SpA", "Calm Mind", "Iron Defense", "Pain Split", "Fleur Cannon");
let magearna_2 = new pokemon("magearna_2", "Magearna", "Choice Specs", "Timid", "Soul Heart", "248 HP / 36 Def / 28 SpA / 196 Spe", "Fleur Cannon", "Flash Cannon", "Trick", "Rest");
//scyther
let scyther_1 = new pokemon("scyther_1", "Scyther", "Eviolite", "Jolly", "Technician", "248 HP / 20 Def / 24 SpD / 216 Spe", "Dual Wingbeat", "Knock Off", "Struggle Bug", "Roost");

//matchups
dragapult_1.lmatchups = [dragapult_2, darmanitan_galar_1, weezing_galar_1, darmanitan_galar_3, milotic_1, sylveon_1, sylveon_2, grimmsnarl_1, arcanine_1, gastrodon_1, haxorus_1, indeedee_1, hydreigon_1, tyranitar_1, aromatisse_1, togekiss_1, aegislash_1, aegislash_2, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, sawk_1, sylveon_3, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, steelix_1, snorlax_1, kommoo_1, sawk_2, snorlax_2, terrakion_1, keldeo_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, gyarados_1, chandelure_1, crustle_2, hydreigon_2, primarina_3, gardevoir_1, steelix_2, clefable_1, sawk_3, type_null_1, gastrodon_2, ninetales_1, kommoo_2, kyurem_2, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, pyukumuku_2, zeraora_4, sylveon_5, togekiss_2, wobbuffet_1, magnezone_1, volcarona_2, chansey_1, azumarill_1, porygon2_1];
dragapult_2.lmatchups = [weezing_galar_1, darmanitan_galar_3, milotic_1, sylveon_1, sylveon_2, grimmsnarl_1, duraludon_1, gastrodon_1, indeedee_1, rotom_heat_1, hydreigon_1, tyranitar_1, aromatisse_1, rotom_wash_1, golisopod_1, togekiss_1, aegislash_1, aegislash_2, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, corviknight_2, sylveon_3, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, steelix_1, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, crustle_2, primarina_3, gardevoir_1, steelix_2, clefable_1, sawk_3, type_null_1, hatterene_1, gastrodon_2, ninetales_1, kommoo_2, kyurem_2, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, pyukumuku_2, zeraora_4, sylveon_5, togekiss_2, wobbuffet_1, magnezone_1, volcarona_2, chansey_1, azumarill_1, porygon2_1, scyther_1];
dragapult_3.lmatchups = [dragapult_1, darmanitan_galar_1, darmanitan_galar_3, corviknight_1, milotic_1, sylveon_1, sylveon_2, gastrodon_1, hydreigon_1, aromatisse_1, togekiss_1, alcremie_1, rhyperior_1, corviknight_2, sylveon_3, conkeldurr_1, grimmsnarl_2, snorlax_2, incineroar_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, pyukumuku_1, avalugg_2, gyarados_1, whimsicott_2, chandelure_1, hydreigon_2, primarina_3, gardevoir_1, steelix_2, clefable_1, type_null_1, hatterene_1, gastrodon_2, kommoo_2, kyurem_2, arcanine_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, pyukumuku_2, zeraora_4, sylveon_5, togekiss_2, volcarona_2, porygon2_1, volcarona_3, scyther_1];
dragapult_4.lmatchups = [dragapult_1, dragapult_2, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, corviknight_1, milotic_1, sylveon_1, grimmsnarl_1, arcanine_1, duraludon_1, haxorus_1, tyranitar_1, aromatisse_1, golisopod_1, togekiss_1, eldegoss_1, alcremie_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, corviknight_2, sylveon_3, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, steelix_1, kommoo_1, silvally_water_1, sawk_2, keldeo_1, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, hippowdon_1, avalugg_2, gyarados_1, arcanine_2, chandelure_1, durant_1, crustle_2, meowstic_1, hydreigon_2, primarina_3, gardevoir_1, steelix_2, clefable_1, type_null_1, gastrodon_2, ninetales_1, kommoo_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, primarina_4, sylveon_4, pyukumuku_2, zeraora_4, sylveon_5, togekiss_2, wobbuffet_1, chansey_1, azumarill_1, porygon2_1, scyther_1];
dragapult_5.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_3, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, arcanine_2, gastrodon_1, haxorus_1, hydreigon_1, hydreigon_2, aromatisse_1, togekiss_1, aegislash_2, alcremie_1, whimsicott_1, snorlax_2, incineroar_1, primarina_2, primarina_3, zeraora_1, mandibuzz_1, pyukumuku_1, gardevoir_1, clefable_1, type_null_1, dracovish_2, hatterene_1, gastrodon_2, dragapult_6, kommoo_2, kyurem_2, arcanine_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, zeraora_4, sylveon_5, togekiss_2, volcarona_2, volcarona_3, scyther_1];
dragapult_6.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, excadrill_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, haxorus_1, hydreigon_1, hydreigon_2, aromatisse_1, togekiss_1, aegislash_2, alcremie_1, rhyperior_1, whimsicott_1, whimsicott_2, conkeldurr_1, primarina_2, primarina_3, zeraora_1, mandibuzz_1, chandelure_1, gardevoir_1, clefable_1, hatterene_1, kommoo_2, kyurem_2, arcanine_3, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, zeraora_4, sylveon_5, togekiss_2, volcarona_2, scyther_1];
dragapult_7.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_6, darmanitan_galar_1, darmanitan_galar_3, corviknight_1, corviknight_2, sylveon_1, sylveon_2, sylveon_3, sylveon_4, sylveon_5, grimmsnarl_1, grimmsnarl_2, haxorus_1, hydreigon_1, hydreigon_2, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, alcremie_1, rhyperior_1, crustle_1, whimsicott_1, whimsicott_2, conkeldurr_1, conkeldurr_2, kommoo_1, kommoo_2, kommoo_3, primarina_2, primarina_3, primarina_4, zeraora_1, blastoise_1, mandibuzz_1, avalugg_1, avalugg_2, gyarados_1, clefable_1, kyurem_2, scyther_1];
darmanitan_galar_1.lmatchups = [dragapult_2, weezing_galar_1, milotic_1, sylveon_1, arcanine_1, dracovish_1, gastrodon_1, haxorus_1, indeedee_1, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, aegislash_2, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, crustle_1, sawk_1, sylveon_3, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, steelix_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, rotom_wash_2, avalugg_1, pyukumuku_1, avalugg_2, arcanine_2, durant_1, crustle_2, meowstic_1, hydreigon_2, steelix_2, darmanitan_1, sawk_3, type_null_1, gastrodon_2, ninetales_1, arcanine_3, aromatisse_2, aromatisse_3, meowstic_2, primarina_4, pyukumuku_2, sylveon_5, wobbuffet_1, magnezone_1, volcarona_2, porygonz_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, volcarona_3];
darmanitan_galar_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, weezing_galar_1, darmanitan_galar_3, excadrill_2, excadrill_3, milotic_1, arcanine_1, dracovish_2, gastrodon_1, haxorus_1, golisopod_1, togekiss_1, gengar_2, dragapult_4, haxorus_2, darmanitan_galar_4, rhyperior_1, corsola_1, golisopod_2, crustle_1, sawk_1, conkeldurr_1, conkeldurr_2, corsola_2, corsola_3, dracozolt_1, steelix_1, sawk_2, snorlax_2, rotom_heat_3, terrakion_1, keldeo_1, zeraora_1, avalugg_1, pyukumuku_1, avalugg_2, arcanine_2, chandelure_1, durant_1, crustle_2, hydreigon_2, celebi_1, steelix_2, darmanitan_1, sawk_3, kyurem_1, dragapult_5, ninetales_1, dragapult_6, haxorus_3, haxorus_4, arcanine_3, roserade_1, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, zeraora_4, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, porygonz_2, urshifu_1, azumarill_1, dragapult_7, volcarona_3];
darmanitan_galar_3.lmatchups = [darmanitan_galar_1, weezing_galar_1, corviknight_1, milotic_1, sylveon_1, arcanine_1, dracovish_1, gastrodon_1, haxorus_1, indeedee_1, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, aegislash_1, aegislash_2, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, crustle_1, sawk_1, sylveon_3, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, steelix_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, rotom_wash_2, avalugg_1, pyukumuku_1, avalugg_2, arcanine_2, chandelure_1, durant_1, crustle_2, meowstic_1, steelix_2, darmanitan_1, sawk_3, type_null_1, gastrodon_2, ninetales_1, arcanine_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, pyukumuku_2, sylveon_5, wobbuffet_1, magnezone_1, volcarona_2, porygonz_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, volcarona_3];
darmanitan_galar_4.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, excadrill_3, milotic_1, dracovish_2, haxorus_1, haxorus_2, togekiss_1, gengar_2, rhyperior_1, corsola_1, crustle_1, sawk_1, conkeldurr_1, conkeldurr_2, corsola_2, corsola_3, dracozolt_1, steelix_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_3, terrakion_1, keldeo_1, incineroar_1, zeraora_1, avalugg_1, pyukumuku_1, avalugg_2, arcanine_2, chandelure_1, durant_1, crustle_2, meowstic_1, hydreigon_2, celebi_1, steelix_2, darmanitan_1, sawk_3, dragapult_5, ninetales_1, dragapult_6, haxorus_3, haxorus_4, arcanine_3, meowstic_2, zeraora_2, zeraora_3, pyukumuku_2, zeraora_4, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, urshifu_1, dragapult_7, volcarona_3];
darmanitan_galar_5.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, excadrill_2, excadrill_3, arcanine_1, arcanine_2, dracovish_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, rotom_heat_3, hydreigon_2, hydreigon_3, golisopod_1, gengar_2, rhyperior_1, corsola_1, corsola_2, corsola_3, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, steelix_2, terrakion_1, keldeo_1, incineroar_1, zeraora_1, avalugg_1, avalugg_2, pyukumuku_1, chandelure_1, durant_1, celebi_1, darmanitan_1, kyurem_1, hatterene_1, ninetales_1, arcanine_3, roserade_1, zeraora_2, zeraora_3, pyukumuku_2, zeraora_4, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7, volcarona_3];
weezing_galar_1.lmatchups = [dragapult_3, corviknight_1, excadrill_1, excadrill_2, milotic_1, arcanine_1, duraludon_1, gastrodon_1, indeedee_1, rotom_heat_1, tyranitar_1, aromatisse_1, rotom_wash_1, aegislash_1, aegislash_2, gengar_1, gengar_2, centiskorch_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, corviknight_2, corsola_2, corsola_3, silvally_water_1, snorlax_2, rotom_heat_2, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, pyukumuku_1, diggersby_1, chandelure_1, meowstic_1, celebi_1, gardevoir_1, steelix_2, darmanitan_1, kyurem_1, type_null_1, dragapult_5, hatterene_1, gastrodon_2, butterfree_1, ninetales_1, dragapult_6, kyurem_2, arcanine_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, pyukumuku_2, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_2, chansey_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
corviknight_1.lmatchups = [dragapult_1, darmanitan_galar_2, sylveon_2, arcanine_1, duraludon_1, dracovish_1, indeedee_1, rotom_heat_1, hydreigon_1, rotom_wash_1, alcremie_1, darmanitan_galar_4, toxtricity_1, toxtricity_2, goodra_1, corsola_2, dracozolt_1, kommoo_1, silvally_water_1, rotom_heat_2, rotom_heat_3, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, gyarados_1, arcanine_2, chandelure_1, rillaboom_2, hydreigon_3, celebi_1, darmanitan_1, kyurem_1, type_null_1, dragapult_5, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, arcanine_3, zeraora_2, zeraora_3, rotom_mow_1, zeraora_4, sylveon_5, salazzle_1, magnezone_1, volcarona_1, volcarona_2, volcarona_3];
corviknight_2.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, arcanine_1, dracovish_1, hydreigon_1, eldegoss_1, centiskorch_1, toxtricity_1, toxtricity_2, corsola_2, dracozolt_1, kommoo_1, silvally_water_1, rotom_heat_2, rotom_heat_3, incineroar_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, gyarados_1, arcanine_2, chandelure_1, rillaboom_2, hydreigon_3, celebi_1, darmanitan_1, type_null_1, dragapult_5, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, arcanine_3, zeraora_2, zeraora_3, rotom_mow_1, zeraora_4, sylveon_5, salazzle_1, magnezone_1, volcarona_1, volcarona_2, urshifu_1, volcarona_3];
excadrill_1.lmatchups = [rillaboom_1, dragapult_1, dragapult_2, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, corviknight_1, excadrill_2, excadrill_3, milotic_1, arcanine_1, dracovish_1, dracovish_2, gastrodon_1, haxorus_1, indeedee_1, hydreigon_1, golisopod_1, eldegoss_1, haxorus_2, darmanitan_galar_4, rhyperior_1, corsola_1, golisopod_2, corviknight_2, sawk_1, conkeldurr_1, conkeldurr_2, steelix_1, snorlax_1, kommoo_1, silvally_water_1, rotom_heat_3, terrakion_1, keldeo_1, incineroar_1, primarina_1, zeraora_1, primarina_2, mandibuzz_1, avalugg_1, hippowdon_1, avalugg_2, gyarados_1, arcanine_2, whimsicott_2, chandelure_1, durant_1, rillaboom_2, meowstic_1, hydreigon_2, hydreigon_3, primarina_3, celebi_1, steelix_2, darmanitan_1, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, ninetales_1, kommoo_2, haxorus_3, haxorus_4, darmanitan_galar_5, arcanine_3, kommoo_3, roserade_1, meowstic_2, zeraora_2, zeraora_3, primarina_4, rotom_mow_1, salazzle_1, rillaboom_3, volcarona_1, urshifu_1, azumarill_1, porygon2_1, volcarona_3, scyther_1];
excadrill_2.lmatchups = [rillaboom_1, dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, corviknight_1, excadrill_3, milotic_1, arcanine_1, dracovish_1, dracovish_2, gastrodon_1, haxorus_1, golisopod_1, eldegoss_1, haxorus_2, darmanitan_galar_4, rhyperior_1, corsola_1, golisopod_2, corviknight_2, sawk_1, goodra_1, conkeldurr_1, conkeldurr_2, corsola_2, corsola_3, steelix_1, snorlax_1, kommoo_1, silvally_water_1, snorlax_2, rotom_heat_3, terrakion_1, keldeo_1, incineroar_1, zeraora_1, blastoise_1, mandibuzz_1, venusaur_1, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, gyarados_1, arcanine_2, chandelure_1, durant_1, meowstic_1, primarina_3, celebi_1, steelix_2, darmanitan_1, kyurem_1, type_null_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, arcanine_3, kommoo_3, roserade_1, meowstic_2, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, rotom_mow_1, salazzle_1, rillaboom_3, wobbuffet_1, volcarona_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
excadrill_3.lmatchups = [rillaboom_1, dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, corviknight_1, milotic_1, grimmsnarl_1, arcanine_1, dracovish_1, dracovish_2, gastrodon_1, haxorus_1, indeedee_1, tyranitar_1, aromatisse_1, golisopod_1, aegislash_1, aegislash_2, eldegoss_1, dragapult_4, centiskorch_1, haxorus_2, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, crustle_1, corviknight_2, sawk_1, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, steelix_1, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, keldeo_1, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, venusaur_1, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, chandelure_1, durant_1, crustle_2, meowstic_1, hydreigon_2, hydreigon_3, primarina_3, steelix_2, darmanitan_1, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, arcanine_3, kommoo_3, aromatisse_2, meowstic_2, primarina_4, pyukumuku_2, rotom_mow_1, rillaboom_3, wobbuffet_1, volcarona_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
milotic_1.lmatchups = [rillaboom_1, corviknight_1, rotom_heat_1, hydreigon_1, aromatisse_1, rotom_wash_1, eldegoss_1, alcremie_1, haxorus_2, toxapex_1, toxtricity_1, corsola_1, corviknight_2, whimsicott_1, sylveon_3, goodra_1, corsola_2, corsola_3, dracozolt_1, kommoo_1, silvally_water_1, snorlax_2, zeraora_1, mandibuzz_1, rotom_wash_2, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, whimsicott_2, rillaboom_2, meowstic_1, celebi_1, gardevoir_1, clefable_1, type_null_1, dragapult_5, hatterene_1, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, togekiss_2, rillaboom_3, magnezone_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7];
sylveon_1.lmatchups = [darmanitan_galar_2, weezing_galar_1, corviknight_1, excadrill_1, excadrill_2, excadrill_3, milotic_1, sylveon_2, arcanine_1, duraludon_1, dracovish_1, dracovish_2, gastrodon_1, indeedee_1, rotom_heat_1, tyranitar_1, rotom_wash_1, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, centiskorch_1, haxorus_2, toxapex_1, darmanitan_galar_4, toxtricity_1, toxtricity_2, rhyperior_2, corsola_1, corviknight_2, dracozolt_1, steelix_1, snorlax_1, silvally_water_1, snorlax_2, rotom_heat_2, rotom_heat_3, primarina_1, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, durant_1, crustle_2, meowstic_1, clefable_1, type_null_1, ninetales_1, dracozolt_2, darmanitan_galar_5, arcanine_3, roserade_1, meowstic_2, primarina_4, salazzle_1, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_2, chansey_1, porygon2_1, volcarona_3, scyther_1];
sylveon_2.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, weezing_galar_1, excadrill_1, excadrill_2, excadrill_3, milotic_1, arcanine_1, dracovish_1, dracovish_2, rotom_heat_1, rotom_wash_1, aegislash_1, aegislash_2, gengar_1, gengar_2, centiskorch_1, haxorus_2, toxapex_1, darmanitan_galar_4, rhyperior_1, corsola_1, crustle_1, corviknight_2, sawk_1, dracozolt_1, steelix_1, snorlax_1, sawk_2, snorlax_2, rotom_heat_2, terrakion_1, venusaur_1, avalugg_1, avalugg_2, diggersby_1, durant_1, crustle_2, steelix_2, darmanitan_1, sawk_3, ninetales_1, dracozolt_2, darmanitan_galar_5, arcanine_3, kommoo_3, roserade_1, aromatisse_4, zeraora_3, primarina_4, zeraora_4, salazzle_1, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_2, chansey_1, urshifu_1, porygon2_1, scyther_1];
sylveon_3.lmatchups = [primarina_1, darmanitan_galar_2, darmanitan_galar_4, weezing_galar_1, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_2, arcanine_1, duraludon_1, dracovish_1, haxorus_2, tyranitar_1, aegislash_1, aegislash_2, gengar_2, centiskorch_1, toxtricity_1, toxtricity_2, rhyperior_2, dracozolt_1, steelix_1, snorlax_1, rotom_heat_3, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, diggersby_1, durant_1, crustle_2, gardevoir_1, hatterene_1, ninetales_1, dracozolt_2, darmanitan_galar_5, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, sylveon_5, salazzle_1, rillaboom_3, magnezone_1, volcarona_1, volcarona_2, porygonz_2];
sylveon_4.lmatchups = [darmanitan_galar_4, darmanitan_galar_5, weezing_galar_1, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_2, arcanine_1, dracovish_1, rillaboom_1, indeedee_1, rotom_heat_2, rotom_heat_3, aromatisse_1, aegislash_2, gengar_1, gengar_2, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_2, dracozolt_1, dracozolt_2, kommoo_3, primarina_1, venusaur_1, diggersby_1, chandelure_1, gardevoir_1, darmanitan_1, hatterene_1, roserade_1, sylveon_5, salazzle_1, rillaboom_3, magnezone_1, volcarona_1, volcarona_2, porygonz_2];
sylveon_5.lmatchups = [darmanitan_galar_2, darmanitan_galar_4, darmanitan_galar_5, excadrill_1, excadrill_2, excadrill_3, sylveon_1, sylveon_2, arcanine_1, arcanine_3, dracovish_1, dracovish_2, rillaboom_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, gengar_1, gengar_2, centiskorch_1, toxtricity_1, toxtricity_2, rhyperior_2, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, goodra_1, dracozolt_1, dracozolt_2, snorlax_1, snorlax_2, kommoo_3, primarina_2, primarina_4, venusaur_1, diggersby_1, chandelure_1, darmanitan_1, hatterene_1, ninetales_1, roserade_1, salazzle_1, rillaboom_3, volcarona_1, volcarona_2, porygonz_2];
grimmsnarl_1.lmatchups = [rillaboom_1, dragapult_3, darmanitan_galar_1, darmanitan_galar_2, weezing_galar_1, corviknight_1, excadrill_1, excadrill_2, milotic_1, sylveon_1, sylveon_2, arcanine_1, duraludon_1, dracovish_1, dracovish_2, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, togekiss_1, aegislash_1, gengar_1, gengar_2, alcremie_1, centiskorch_1, haxorus_2, darmanitan_galar_4, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, golisopod_2, corviknight_2, sawk_1, sylveon_3, dracozolt_1, steelix_1, snorlax_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, incineroar_1, primarina_1, zeraora_1, primarina_2, rotom_wash_2, venusaur_1, avalugg_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, durant_1, crustle_2, primarina_3, gardevoir_1, steelix_2, clefable_1, sawk_3, type_null_1, hatterene_1, ninetales_1, dracozolt_2, darmanitan_galar_5, arcanine_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, sylveon_5, salazzle_1, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, porygonz_2, chansey_1, azumarill_1, volcarona_3, scyther_1];
grimmsnarl_2.lmatchups = [weezing_galar_1, excadrill_1, excadrill_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, duraludon_1, gastrodon_1, indeedee_1, rotom_heat_1, tyranitar_1, aromatisse_1, rotom_wash_1, togekiss_1, aegislash_2, alcremie_1, toxapex_1, toxtricity_1, toxtricity_2, steelix_1, snorlax_1, rotom_heat_2, rotom_heat_3, incineroar_1, primarina_1, primarina_2, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, arcanine_2, primarina_3, gardevoir_1, steelix_2, clefable_1, kyurem_1, hatterene_1, gastrodon_2, ninetales_1, arcanine_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, sylveon_4, rotom_mow_1, sylveon_5, salazzle_1, togekiss_2, rillaboom_3, magnezone_1, volcarona_1, porygonz_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, volcarona_3];
arcanine_1.lmatchups = [dragapult_3, milotic_1, dracovish_1, dracovish_2, gastrodon_1, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, aegislash_2, gengar_1, alcremie_1, toxapex_1, darmanitan_galar_4, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, crustle_1, sawk_1, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, steelix_1, snorlax_1, kommoo_1, silvally_water_1, snorlax_2, rotom_heat_2, rotom_heat_3, terrakion_1, keldeo_1, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, avalugg_1, hippowdon_1, pyukumuku_1, gyarados_1, arcanine_2, durant_1, crustle_2, meowstic_1, primarina_3, steelix_2, clefable_1, darmanitan_1, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, pyukumuku_2, salazzle_1, wobbuffet_1, magnezone_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7];
arcanine_2.lmatchups = [dragapult_1, dragapult_3, milotic_1, sylveon_3, dracovish_1, dracovish_2, gastrodon_1, indeedee_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, rotom_wash_1, rotom_wash_2, gengar_1, gengar_2, alcremie_1, toxapex_1, toxtricity_1, corsola_1, corsola_2, corsola_3, goodra_1, snorlax_2, kommoo_1, silvally_water_1, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, pyukumuku_1, meowstic_1, hydreigon_2, hydreigon_3, primarina_3, celebi_1, gardevoir_1, clefable_1, kyurem_1, type_null_1, hatterene_1, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_4, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, salazzle_1, togekiss_2, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, urshifu_1, porygon2_1, magearna_1, dragapult_7, volcarona_3];
arcanine_3.lmatchups = [dragapult_1, milotic_1, sylveon_3, dracovish_1, dracovish_2, gastrodon_1, gastrodon_2, haxorus_3, haxorus_4, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, hydreigon_3, tyranitar_1, rotom_wash_1, rotom_wash_2, togekiss_1, gengar_1, gengar_2, alcremie_1, toxapex_1, corsola_1, corsola_2, corsola_3, whimsicott_1, goodra_1, snorlax_2, kommoo_1, kommoo_2, silvally_water_1, keldeo_1, incineroar_1, primarina_1, primarina_2, primarina_3, blastoise_1, mandibuzz_1, pyukumuku_1, meowstic_1, clefable_1, darmanitan_1, kyurem_2, type_null_1, hatterene_1, butterfree_1, kommoo_3, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, salazzle_1, togekiss_2, volcarona_2, porygonz_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7];
duraludon_1.lmatchups = [dragapult_1, dragapult_3, darmanitan_galar_1, darmanitan_galar_2, excadrill_1, excadrill_2, excadrill_3, milotic_1, sylveon_2, arcanine_1, gastrodon_1, indeedee_1, rotom_heat_1, hydreigon_1, rotom_wash_1, aegislash_1, aegislash_2, darmanitan_galar_4, corsola_1, sawk_1, goodra_1, steelix_1, kommoo_1, sawk_2, snorlax_2, rotom_heat_2, terrakion_1, keldeo_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, hippowdon_1, pyukumuku_1, diggersby_1, arcanine_2, whimsicott_2, chandelure_1, durant_1, meowstic_1, hydreigon_2, hydreigon_3, steelix_2, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, butterfree_1, ninetales_1, dragapult_6, kommoo_2, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, kommoo_3, meowstic_2, primarina_4, pyukumuku_2, sylveon_5, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_2, chansey_1, urshifu_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
dracovish_1.lmatchups = [rillaboom_1, dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_2, weezing_galar_1, milotic_1, duraludon_1, dracovish_2, gastrodon_1, haxorus_1, hydreigon_1, rotom_wash_1, golisopod_1, eldegoss_1, dragapult_4, haxorus_2, toxapex_1, darmanitan_galar_4, corsola_1, golisopod_2, crustle_1, sawk_1, whimsicott_1, goodra_1, grimmsnarl_2, corsola_2, corsola_3, dracozolt_1, kommoo_1, silvally_water_1, sawk_2, keldeo_1, primarina_1, zeraora_1, primarina_2, blastoise_1, venusaur_1, pyukumuku_1, gyarados_1, whimsicott_2, crustle_2, hydreigon_2, hydreigon_3, primarina_3, celebi_1, gardevoir_1, steelix_2, sawk_3, kyurem_1, dragapult_5, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, darmanitan_galar_5, kyurem_2, kommoo_3, roserade_1, primarina_4, pyukumuku_2, rotom_mow_1, zeraora_4, rillaboom_3, magnezone_1, porygonz_1, porygonz_2, azumarill_1, dragapult_7, volcarona_3, scyther_1];
dracovish_2.lmatchups = [rillaboom_1, dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, corviknight_1, milotic_1, duraludon_1, gastrodon_1, haxorus_1, hydreigon_1, aromatisse_1, rotom_wash_1, golisopod_1, togekiss_1, eldegoss_1, dragapult_4, toxapex_1, corsola_1, golisopod_2, crustle_1, sawk_1, whimsicott_1, goodra_1, grimmsnarl_2, corsola_2, corsola_3, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, keldeo_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, venusaur_1, pyukumuku_1, gyarados_1, whimsicott_2, crustle_2, rillaboom_2, meowstic_1, hydreigon_2, primarina_3, celebi_1, gardevoir_1, steelix_2, sawk_3, kyurem_1, type_null_1, ninetales_1, dragapult_6, kommoo_2, kyurem_2, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, porygonz_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, scyther_1];
rillaboom_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, weezing_galar_1, corviknight_1, arcanine_1, duraludon_1, haxorus_1, indeedee_1, rotom_heat_1, hydreigon_1, aromatisse_1, golisopod_1, togekiss_1, gengar_1, gengar_2, eldegoss_1, alcremie_1, dragapult_4, centiskorch_1, haxorus_2, toxapex_1, darmanitan_galar_4, golisopod_2, crustle_1, corviknight_2, sawk_1, goodra_1, conkeldurr_1, grimmsnarl_2, corsola_2, corsola_3, kommoo_1, sawk_2, rotom_heat_2, rotom_heat_3, keldeo_1, incineroar_1, mandibuzz_1, venusaur_1, avalugg_1, avalugg_2, arcanine_2, chandelure_1, durant_1, meowstic_1, hydreigon_2, hydreigon_3, celebi_1, clefable_1, darmanitan_1, kyurem_1, type_null_1, dragapult_5, butterfree_1, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, kommoo_3, roserade_1, aromatisse_2, meowstic_2, salazzle_1, togekiss_2, rillaboom_3, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, magearna_1, dragapult_7, volcarona_3, scyther_1];
rillaboom_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, excadrill_2, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_2, arcanine_1, arcanine_2, duraludon_1, rillaboom_1, haxorus_2, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, aromatisse_1, golisopod_1, golisopod_2, togekiss_1, gengar_1, gengar_2, eldegoss_1, alcremie_1, centiskorch_1, toxtricity_2, crustle_1, sawk_1, goodra_1, snorlax_1, incineroar_1, venusaur_1, avalugg_1, avalugg_2, diggersby_1, chandelure_1, durant_1, meowstic_1, hydreigon_2, hydreigon_3, celebi_1, clefable_1, darmanitan_1, kyurem_1, dragapult_5, hatterene_1, butterfree_1, ninetales_1, dragapult_6, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, kommoo_3, roserade_1, meowstic_2, rotom_mow_1, salazzle_1, togekiss_2, rillaboom_3, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, dragapult_7, volcarona_3, scyther_1];
rillaboom_3.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, darmanitan_galar_5, weezing_galar_1, corviknight_1, corviknight_2, arcanine_1, arcanine_2, arcanine_3, haxorus_1, haxorus_2, haxorus_3, haxorus_4, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_3, golisopod_1, golisopod_2, togekiss_1, togekiss_2, aegislash_1, aegislash_2, gengar_1, gengar_2, eldegoss_1, centiskorch_1, toxapex_1, toxtricity_2, corsola_1, corsola_2, corsola_3, crustle_2, sawk_1, sawk_2, sawk_3, goodra_1, dracozolt_2, steelix_2, snorlax_2, kommoo_1, kommoo_2, kommoo_3, incineroar_1, mandibuzz_1, venusaur_1, avalugg_1, avalugg_2, chandelure_1, durant_1, darmanitan_1, kyurem_1, kyurem_2, type_null_1, butterfree_1, ninetales_1, roserade_1, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
gastrodon_1.lmatchups = [corviknight_1, milotic_1, grimmsnarl_1, rillaboom_1, indeedee_1, rotom_heat_1, rotom_wash_1, gengar_2, eldegoss_1, centiskorch_1, haxorus_2, toxapex_1, darmanitan_galar_4, corsola_1, golisopod_2, corviknight_2, whimsicott_1, sylveon_3, goodra_1, corsola_2, corsola_3, kommoo_1, sawk_2, snorlax_2, primarina_1, mandibuzz_1, rotom_wash_2, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, whimsicott_2, chandelure_1, rillaboom_2, meowstic_1, primarina_3, celebi_1, gardevoir_1, clefable_1, sawk_3, kyurem_1, type_null_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, roserade_1, meowstic_2, sylveon_4, pyukumuku_2, rotom_mow_1, rillaboom_3, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7];
gastrodon_2.lmatchups = [darmanitan_galar_2, corviknight_1, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, dracovish_1, dracovish_2, rillaboom_1, rillaboom_2, gastrodon_1, hydreigon_1, gengar_2, eldegoss_1, centiskorch_1, toxapex_1, corsola_1, corsola_2, corsola_3, whimsicott_1, whimsicott_2, goodra_1, snorlax_2, kommoo_1, silvally_water_1, primarina_1, primarina_3, mandibuzz_1, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, chandelure_1, meowstic_1, celebi_1, clefable_1, kyurem_1, type_null_1, hatterene_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, roserade_1, meowstic_2, sylveon_4, pyukumuku_2, rotom_mow_1, sylveon_5, rillaboom_3, volcarona_1, volcarona_2, porygonz_2, chansey_1, urshifu_1, porygon2_1, magearna_1, dragapult_7];
haxorus_1.lmatchups = [dragapult_2, dragapult_3, weezing_galar_1, corviknight_1, milotic_1, sylveon_1, sylveon_2, grimmsnarl_1, arcanine_1, duraludon_1, gastrodon_1, indeedee_1, rotom_heat_1, hydreigon_1, aromatisse_1, rotom_wash_1, golisopod_1, togekiss_1, aegislash_1, aegislash_2, eldegoss_1, alcremie_1, toxapex_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, crustle_1, corviknight_2, sylveon_3, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, steelix_1, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, keldeo_1, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, venusaur_1, avalugg_1, pyukumuku_1, avalugg_2, gyarados_1, arcanine_2, durant_1, crustle_2, meowstic_1, hydreigon_2, primarina_3, steelix_2, clefable_1, sawk_3, type_null_1, hatterene_1, gastrodon_2, ninetales_1, kommoo_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, wobbuffet_1, magnezone_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, volcarona_3];
haxorus_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, corviknight_1, arcanine_1, dracovish_2, haxorus_1, aromatisse_1, togekiss_1, aegislash_2, gengar_1, gengar_2, eldegoss_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, corviknight_2, conkeldurr_1, conkeldurr_2, corsola_2, corsola_3, dracozolt_1, steelix_1, kommoo_1, snorlax_2, terrakion_1, keldeo_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, pyukumuku_1, avalugg_2, gyarados_1, arcanine_2, whimsicott_2, durant_1, crustle_2, meowstic_1, hydreigon_2, primarina_3, gardevoir_1, steelix_2, sawk_3, type_null_1, dragapult_5, ninetales_1, dragapult_6, kommoo_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, meowstic_2, zeraora_2, primarina_4, sylveon_4, pyukumuku_2, zeraora_4, sylveon_5, salazzle_1, wobbuffet_1, volcarona_1, porygonz_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
haxorus_3.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, arcanine_1, duraludon_1, dracovish_2, haxorus_1, hydreigon_2, aromatisse_1, togekiss_1, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, toxtricity_2, rhyperior_1, rhyperior_2, crustle_2, whimsicott_1, whimsicott_2, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, snorlax_1, kommoo_1, kommoo_2, terrakion_1, keldeo_1, primarina_1, primarina_2, primarina_3, zeraora_1, avalugg_1, avalugg_2, hippowdon_1, gyarados_1, durant_1, celebi_1, gardevoir_1, clefable_1, hatterene_1, kyurem_2, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, zeraora_4, sylveon_5, salazzle_1, togekiss_2, volcarona_1, porygonz_1, urshifu_1, azumarill_1, volcarona_3, scyther_1];
haxorus_4.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, arcanine_1, duraludon_1, dracovish_2, haxorus_1, hydreigon_2, aromatisse_1, togekiss_1, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, toxtricity_2, rhyperior_2, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, steelix_2, snorlax_1, terrakion_1, keldeo_1, primarina_1, primarina_2, primarina_3, zeraora_1, avalugg_1, avalugg_2, hippowdon_1, gyarados_1, durant_1, celebi_1, gardevoir_1, clefable_1, hatterene_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, zeraora_4, sylveon_5, salazzle_1, togekiss_2, magnezone_1, volcarona_1, porygonz_1, urshifu_1, azumarill_1, volcarona_3, scyther_1];
indeedee_1.lmatchups = [dragapult_3, darmanitan_galar_2, milotic_1, sylveon_2, grimmsnarl_1, arcanine_1, dracovish_1, dracovish_2, rotom_heat_1, hydreigon_1, tyranitar_1, aromatisse_1, rotom_wash_1, golisopod_1, togekiss_1, aegislash_1, centiskorch_1, haxorus_2, darmanitan_galar_4, rhyperior_2, corsola_1, golisopod_2, crustle_1, corviknight_2, sawk_1, goodra_1, dracozolt_1, snorlax_1, sawk_2, rotom_heat_2, terrakion_1, primarina_1, zeraora_1, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, avalugg_1, pyukumuku_1, diggersby_1, gyarados_1, durant_1, crustle_2, meowstic_1, hydreigon_2, hydreigon_3, celebi_1, steelix_2, sawk_3, kyurem_1, dragapult_5, hatterene_1, gastrodon_2, ninetales_1, dragapult_6, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, pyukumuku_2, rotom_mow_1, sylveon_5, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, dragapult_7, volcarona_3, scyther_1];
rotom_heat_1.lmatchups = [darmanitan_galar_2, dragapult_1, dragapult_3, excadrill_1, excadrill_2, excadrill_3, dracovish_1, dracovish_2, hydreigon_1, tyranitar_1, gengar_1, eldegoss_1, alcremie_1, centiskorch_1, haxorus_2, darmanitan_galar_4, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, crustle_1, whimsicott_1, goodra_1, corsola_2, corsola_3, kommoo_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, terrakion_1, keldeo_1, primarina_1, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, diggersby_1, gyarados_1, whimsicott_2, crustle_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, gardevoir_1, sawk_3, type_null_1, dragapult_5, hatterene_1, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, zeraora_4, salazzle_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3];
rotom_heat_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_2, darmanitan_galar_4, excadrill_1, excadrill_2, excadrill_3, dracovish_1, dracovish_2, gastrodon_1, haxorus_1, haxorus_2, hydreigon_1, tyranitar_1, rhyperior_1, rhyperior_2, crustle_1, sawk_1, sawk_2, whimsicott_1, goodra_1, dracozolt_1, snorlax_1, kommoo_1, terrakion_1, keldeo_1, primarina_2, blastoise_1, rotom_wash_2, hippowdon_1, diggersby_1, crustle_2, meowstic_1, hydreigon_2, hydreigon_3, sawk_3, kyurem_1, dragapult_5, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kommoo_3, aromatisse_4, meowstic_2, primarina_4, wobbuffet_1, volcarona_2, porygonz_1, porygonz_2, urshifu_1, dragapult_7];
rotom_heat_3.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, excadrill_3, sylveon_2, dracovish_1, dracovish_2, gastrodon_1, haxorus_1, haxorus_2, indeedee_1, rotom_heat_2, hydreigon_1, tyranitar_1, aromatisse_1, golisopod_1, golisopod_2, toxtricity_2, rhyperior_1, rhyperior_2, corsola_3, crustle_1, sawk_1, whimsicott_1, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, snorlax_1, kommoo_1, terrakion_1, keldeo_1, primarina_1, zeraora_1, primarina_2, blastoise_1, rotom_wash_2, diggersby_1, chandelure_1, crustle_2, meowstic_1, hydreigon_2, hydreigon_3, primarina_3, gardevoir_1, kyurem_1, dragapult_5, hatterene_1, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_3, primarina_4, zeraora_4, wobbuffet_1, volcarona_2, porygonz_1, porygonz_2, azumarill_1, dragapult_7];
hydreigon_1.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, weezing_galar_1, sylveon_1, sylveon_2, grimmsnarl_1, arcanine_1, tyranitar_1, aromatisse_1, golisopod_1, togekiss_1, aegislash_1, gengar_1, gengar_2, alcremie_1, dragapult_4, centiskorch_1, haxorus_2, darmanitan_galar_4, rhyperior_2, golisopod_2, crustle_1, sawk_1, sylveon_3, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, steelix_1, snorlax_1, sawk_2, terrakion_1, keldeo_1, primarina_1, zeraora_1, primarina_2, avalugg_1, pyukumuku_1, avalugg_2, durant_1, crustle_2, hydreigon_3, primarina_3, gardevoir_1, clefable_1, sawk_3, kyurem_1, hatterene_1, haxorus_3, haxorus_4, darmanitan_galar_5, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_3, primarina_4, sylveon_4, sylveon_5, togekiss_2, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, azumarill_1, volcarona_3, scyther_1];
hydreigon_2.lmatchups = [dragapult_2, weezing_galar_1, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, arcanine_1, gastrodon_1, rotom_heat_1, hydreigon_1, tyranitar_1, aromatisse_1, rotom_wash_1, golisopod_1, golisopod_2, togekiss_1, aegislash_1, aegislash_2, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, crustle_2, sawk_1, sawk_2, whimsicott_1, goodra_1, conkeldurr_1, conkeldurr_2, steelix_1, snorlax_1, snorlax_2, kommoo_1, silvally_water_1, terrakion_1, keldeo_1, primarina_1, primarina_2, zeraora_1, mandibuzz_1, avalugg_2, hippowdon_1, gyarados_1, durant_1, primarina_3, gardevoir_1, steelix_2, clefable_1, sawk_3, type_null_1, hatterene_1, gastrodon_2, ninetales_1, kommoo_2, kyurem_2, arcanine_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, primarina_4, sylveon_4, zeraora_4, sylveon_5, togekiss_2, volcarona_1, volcarona_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, volcarona_3, scyther_1];
hydreigon_3.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, dracovish_2, gastrodon_1, haxorus_1, haxorus_2, hydreigon_2, aromatisse_1, togekiss_1, gengar_1, gengar_2, alcremie_1, rhyperior_1, crustle_1, crustle_2, sawk_1, sawk_2, whimsicott_1, goodra_1, dracozolt_1, steelix_1, snorlax_1, snorlax_2, terrakion_1, keldeo_1, primarina_1, primarina_2, zeraora_1, mandibuzz_1, avalugg_2, gyarados_1, durant_1, primarina_3, gardevoir_1, steelix_2, clefable_1, sawk_3, dragapult_5, hatterene_1, gastrodon_2, ninetales_1, dragapult_6, haxorus_3, haxorus_4, kyurem_2, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, primarina_4, sylveon_4, zeraora_4, sylveon_5, togekiss_2, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, azumarill_1, magearna_1, dragapult_7, volcarona_3];
tyranitar_1.lmatchups = [dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, corviknight_1, excadrill_1, excadrill_2, milotic_1, sylveon_2, grimmsnarl_1, arcanine_1, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, haxorus_1, rotom_wash_1, aegislash_2, eldegoss_1, haxorus_2, toxapex_1, darmanitan_galar_4, rhyperior_1, rhyperior_2, crustle_1, corviknight_2, sawk_1, conkeldurr_1, conkeldurr_2, corsola_3, dracozolt_1, steelix_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, terrakion_1, keldeo_1, zeraora_1, blastoise_1, mandibuzz_1, venusaur_1, hippowdon_1, pyukumuku_1, avalugg_2, diggersby_1, arcanine_2, durant_1, rillaboom_2, hydreigon_3, steelix_2, darmanitan_1, sawk_3, type_null_1, dragapult_5, gastrodon_2, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kommoo_3, roserade_1, zeraora_2, zeraora_3, pyukumuku_2, rotom_mow_1, rillaboom_3, wobbuffet_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3];
aromatisse_1.lmatchups = [corviknight_1, excadrill_1, excadrill_2, sylveon_1, sylveon_2, duraludon_1, dracovish_1, rotom_heat_1, tyranitar_1, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, toxapex_1, darmanitan_galar_4, toxtricity_2, corsola_1, crustle_1, corviknight_2, sylveon_3, steelix_1, snorlax_2, primarina_1, venusaur_1, hippowdon_1, diggersby_1, chandelure_1, durant_1, crustle_2, primarina_3, gardevoir_1, steelix_2, darmanitan_1, hatterene_1, dracozolt_2, darmanitan_galar_5, arcanine_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, salazzle_1, togekiss_2, magnezone_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, volcarona_3];
aromatisse_2.lmatchups = [snorlax_2, zeraora_1, darmanitan_galar_5, corviknight_1, corviknight_2, excadrill_1, excadrill_2, sylveon_2, arcanine_3, duraludon_1, dracovish_1, rillaboom_2, gastrodon_1, tyranitar_1, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, toxapex_1, toxtricity_1, toxtricity_2, corsola_1, crustle_1, whimsicott_1, dracozolt_2, steelix_1, steelix_2, primarina_1, venusaur_1, hippowdon_1, pyukumuku_1, diggersby_1, durant_1, meowstic_1, gardevoir_1, hatterene_1, roserade_1, meowstic_2, primarina_4, salazzle_1, togekiss_2, magnezone_1, volcarona_2, porygonz_2, chansey_1, volcarona_3];
aromatisse_3.lmatchups = [snorlax_2, darmanitan_galar_2, darmanitan_galar_4, darmanitan_galar_5, corviknight_1, corviknight_2, excadrill_1, excadrill_2, arcanine_3, duraludon_1, dracovish_1, rillaboom_1, rillaboom_2, gastrodon_1, haxorus_2, tyranitar_1, golisopod_2, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_2, corsola_1, crustle_1, crustle_2, whimsicott_1, dracozolt_1, dracozolt_2, steelix_1, steelix_2, snorlax_1, zeraora_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_1, diggersby_1, gyarados_1, durant_1, meowstic_1, gardevoir_1, hatterene_1, roserade_1, meowstic_2, primarina_4, salazzle_1, togekiss_2, rillaboom_3, volcarona_2, porygonz_2, chansey_1, volcarona_3];
aromatisse_4.lmatchups = [darmanitan_galar_2, darmanitan_galar_4, darmanitan_galar_5, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, arcanine_3, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, rillaboom_2, gastrodon_1, haxorus_2, tyranitar_1, golisopod_2, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, crustle_1, crustle_2, whimsicott_1, dracozolt_1, dracozolt_2, steelix_1, steelix_2, snorlax_1, snorlax_2, zeraora_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_1, diggersby_1, gyarados_1, durant_1, meowstic_1, hatterene_1, roserade_1, meowstic_2, primarina_4, salazzle_1, togekiss_2, rillaboom_3, volcarona_2, porygonz_2, chansey_1, azumarill_1, volcarona_3];
rotom_wash_1.lmatchups = [aromatisse_1, dragapult_1, dragapult_3, darmanitan_galar_2, excadrill_1, excadrill_2, excadrill_3, rillaboom_1, hydreigon_1, gengar_1, gengar_2, eldegoss_1, alcremie_1, dragapult_4, centiskorch_1, haxorus_2, darmanitan_galar_4, corsola_1, whimsicott_1, sylveon_3, goodra_1, corsola_2, corsola_3, dracozolt_1, kommoo_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, mandibuzz_1, venusaur_1, diggersby_1, whimsicott_2, chandelure_1, rillaboom_2, meowstic_1, hydreigon_3, celebi_1, gardevoir_1, kyurem_1, type_null_1, dragapult_5, hatterene_1, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, sylveon_4, rotom_mow_1, zeraora_4, sylveon_5, salazzle_1, rillaboom_3, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7, volcarona_3];
rotom_wash_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_2, darmanitan_galar_4, excadrill_1, excadrill_2, excadrill_3, sylveon_2, dracovish_1, rillaboom_1, haxorus_1, haxorus_2, hydreigon_1, aromatisse_1, sawk_1, sawk_2, whimsicott_1, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, snorlax_1, kommoo_1, venusaur_1, diggersby_1, whimsicott_2, rillaboom_2, meowstic_1, hydreigon_2, hydreigon_3, celebi_1, sawk_3, kyurem_1, dragapult_5, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, kommoo_3, roserade_1, meowstic_2, rotom_mow_1, sylveon_5, rillaboom_3, wobbuffet_1, volcarona_2, porygonz_1, porygonz_2, dragapult_7];
golisopod_1.lmatchups = [dragapult_3, weezing_galar_1, corviknight_1, milotic_1, sylveon_1, sylveon_2, gastrodon_1, tyranitar_1, aromatisse_1, rotom_wash_1, togekiss_1, aegislash_2, eldegoss_1, alcremie_1, toxapex_1, darmanitan_galar_4, toxtricity_1, toxtricity_2, rhyperior_2, corsola_1, crustle_1, corviknight_2, whimsicott_1, sylveon_3, goodra_1, grimmsnarl_2, corsola_2, corsola_3, dracozolt_1, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, incineroar_1, primarina_1, zeraora_1, primarina_2, mandibuzz_1, rotom_wash_2, venusaur_1, pyukumuku_1, arcanine_2, whimsicott_2, durant_1, hydreigon_3, primarina_3, steelix_2, clefable_1, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, butterfree_1, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_3, primarina_4, pyukumuku_2, rotom_mow_1, sylveon_5, togekiss_2, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, scyther_1];
golisopod_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, weezing_galar_1, corviknight_1, milotic_1, sylveon_1, sylveon_2, duraludon_1, haxorus_2, tyranitar_1, rotom_wash_1, golisopod_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_2, crustle_1, corviknight_2, sylveon_3, goodra_1, grimmsnarl_2, corsola_2, dracozolt_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, incineroar_1, primarina_1, primarina_2, mandibuzz_1, rotom_wash_2, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, arcanine_2, durant_1, crustle_2, hydreigon_3, primarina_3, clefable_1, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, zeraora_3, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, togekiss_2, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, porygonz_2, chansey_1, azumarill_1, dragapult_7, scyther_1];
togekiss_1.lmatchups = [darmanitan_galar_1, darmanitan_galar_3, excadrill_1, excadrill_2, excadrill_3, sylveon_2, duraludon_1, rotom_heat_1, tyranitar_1, rotom_wash_1, aegislash_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, sawk_1, whimsicott_1, steelix_1, snorlax_1, rotom_heat_2, rotom_heat_3, zeraora_1, rotom_wash_2, arcanine_2, whimsicott_2, meowstic_1, steelix_2, darmanitan_1, gastrodon_2, ninetales_1, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, zeraora_4, togekiss_2, magnezone_1, porygonz_1];
togekiss_2.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, darmanitan_galar_5, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, dracovish_1, haxorus_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, tyranitar_1, rotom_wash_1, rotom_wash_2, aegislash_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, dracozolt_1, dracozolt_2, steelix_1, steelix_2, snorlax_1, snorlax_2, terrakion_1, zeraora_1, zeraora_2, zeraora_3, zeraora_4, mandibuzz_1, hippowdon_1, diggersby_1, durant_1, darmanitan_1, magnezone_1, porygonz_2, chansey_1];
aegislash_1.lmatchups = [dragapult_3, darmanitan_galar_1, darmanitan_galar_2, corviknight_1, excadrill_1, excadrill_2, milotic_1, arcanine_1, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, rotom_heat_1, rotom_wash_1, golisopod_1, aegislash_2, eldegoss_1, dragapult_4, centiskorch_1, haxorus_2, toxapex_1, darmanitan_galar_4, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, golisopod_2, crustle_1, corviknight_2, sawk_1, whimsicott_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, dracozolt_1, steelix_1, snorlax_1, kommoo_1, silvally_water_1, sawk_2, rotom_heat_2, rotom_heat_3, keldeo_1, incineroar_1, primarina_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, whimsicott_2, chandelure_1, crustle_2, rillaboom_2, primarina_3, steelix_2, darmanitan_1, sawk_3, type_null_1, dragapult_5, gastrodon_2, butterfree_1, ninetales_1, dragapult_6, dracozolt_2, darmanitan_galar_5, arcanine_3, kommoo_3, primarina_4, pyukumuku_2, rotom_mow_1, sylveon_5, salazzle_1, magnezone_1, volcarona_1, volcarona_2, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
aegislash_2.lmatchups = [darmanitan_galar_2, excadrill_1, excadrill_2, milotic_1, dracovish_1, gastrodon_1, rotom_heat_1, hydreigon_1, rotom_wash_1, togekiss_1, alcremie_1, toxapex_1, darmanitan_galar_4, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, golisopod_2, corviknight_2, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, snorlax_1, silvally_water_1, snorlax_2, rotom_heat_2, rotom_heat_3, incineroar_1, primarina_1, mandibuzz_1, rotom_wash_2, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, whimsicott_2, chandelure_1, crustle_2, rillaboom_2, steelix_2, darmanitan_1, type_null_1, gastrodon_2, butterfree_1, ninetales_1, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, zeraora_4, salazzle_1, magnezone_1, volcarona_1, volcarona_2, urshifu_1, porygon2_1, magearna_1, volcarona_3, scyther_1];
gengar_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, excadrill_1, excadrill_2, excadrill_3, milotic_1, duraludon_1, dracovish_1, dracovish_2, gastrodon_1, haxorus_1, indeedee_1, tyranitar_1, golisopod_1, aegislash_1, aegislash_2, dragapult_4, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, golisopod_2, crustle_1, corviknight_2, sawk_1, goodra_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, dracozolt_1, steelix_1, snorlax_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, terrakion_1, keldeo_1, incineroar_1, zeraora_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, chandelure_1, crustle_2, hydreigon_2, gardevoir_1, steelix_2, darmanitan_1, sawk_3, kyurem_1, gastrodon_2, ninetales_1, dragapult_6, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, zeraora_4, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, chansey_1, dragapult_7, volcarona_3, scyther_1];
gengar_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, excadrill_1, excadrill_2, excadrill_3, milotic_1, arcanine_1, duraludon_1, dracovish_2, haxorus_1, indeedee_1, tyranitar_1, golisopod_1, aegislash_1, aegislash_2, dragapult_4, centiskorch_1, toxtricity_1, toxtricity_2, golisopod_2, crustle_1, corviknight_2, sawk_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, dracozolt_1, steelix_1, snorlax_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, terrakion_1, incineroar_1, zeraora_1, blastoise_1, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, gyarados_1, chandelure_1, crustle_2, hydreigon_2, gardevoir_1, steelix_2, darmanitan_1, sawk_3, kyurem_1, type_null_1, dragapult_5, ninetales_1, dragapult_6, kyurem_2, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, zeraora_4, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, chansey_1, porygon2_1, magearna_1, dragapult_7, volcarona_3, scyther_1];
eldegoss_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, weezing_galar_1, corviknight_1, sylveon_1, sylveon_2, grimmsnarl_1, arcanine_1, duraludon_1, indeedee_1, hydreigon_1, aromatisse_1, togekiss_1, aegislash_2, gengar_1, gengar_2, alcremie_1, centiskorch_1, darmanitan_galar_4, toxtricity_1, toxtricity_2, corsola_1, golisopod_2, sylveon_3, goodra_1, grimmsnarl_2, corsola_2, steelix_1, kommoo_1, snorlax_2, rotom_heat_2, rotom_heat_3, terrakion_1, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, rotom_wash_2, venusaur_1, diggersby_1, arcanine_2, chandelure_1, durant_1, meowstic_1, hydreigon_2, hydreigon_3, primarina_3, celebi_1, gardevoir_1, clefable_1, darmanitan_1, kyurem_1, dragapult_5, hatterene_1, butterfree_1, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, sylveon_4, rotom_mow_1, sylveon_5, salazzle_1, togekiss_2, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, porygon2_1, dragapult_7, volcarona_3];
alcremie_1.lmatchups = [gardevoir_1, togekiss_1, darmanitan_galar_2, excadrill_1, excadrill_2, excadrill_3, sylveon_2, duraludon_1, dracovish_1, dracovish_2, tyranitar_1, aegislash_1, gengar_1, gengar_2, toxapex_1, darmanitan_galar_4, toxtricity_2, corsola_1, corviknight_2, whimsicott_1, sylveon_3, goodra_1, steelix_1, snorlax_1, silvally_water_1, rotom_heat_2, rotom_heat_3, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, diggersby_1, chandelure_1, durant_1, crustle_2, meowstic_1, celebi_1, clefable_1, darmanitan_1, type_null_1, butterfree_1, dracozolt_2, darmanitan_galar_5, kyurem_2, roserade_1, meowstic_2, sylveon_4, pyukumuku_2, sylveon_5, salazzle_1, togekiss_2, rillaboom_3, magnezone_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, urshifu_1, porygon2_1];
centiskorch_1.lmatchups = [dragapult_3, darmanitan_galar_2, corviknight_1, excadrill_1, milotic_1, arcanine_1, dracovish_1, dracovish_2, haxorus_1, aromatisse_1, golisopod_1, alcremie_1, haxorus_2, toxapex_1, darmanitan_galar_4, corsola_1, golisopod_2, crustle_1, goodra_1, grimmsnarl_2, corsola_2, corsola_3, dracozolt_1, steelix_1, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, terrakion_1, keldeo_1, incineroar_1, blastoise_1, mandibuzz_1, rotom_wash_2, pyukumuku_1, diggersby_1, gyarados_1, arcanine_2, crustle_2, steelix_2, sawk_3, type_null_1, dragapult_5, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, arcanine_3, kommoo_3, aromatisse_2, pyukumuku_2, wobbuffet_1, volcarona_1, porygonz_2, chansey_1, urshifu_1, porygon2_1, dragapult_7, scyther_1];
toxapex_1.lmatchups = [dragapult_3, darmanitan_galar_2, corviknight_1, excadrill_1, excadrill_2, grimmsnarl_1, duraludon_1, indeedee_1, rotom_heat_1, hydreigon_1, rotom_wash_1, togekiss_1, gengar_2, eldegoss_1, darmanitan_galar_4, toxtricity_1, toxtricity_2, rhyperior_2, corsola_1, corviknight_2, whimsicott_1, goodra_1, corsola_2, corsola_3, dracozolt_1, kommoo_1, silvally_water_1, snorlax_2, rotom_heat_2, rotom_heat_3, zeraora_1, mandibuzz_1, rotom_wash_2, hippowdon_1, diggersby_1, gyarados_1, whimsicott_2, rillaboom_2, meowstic_1, hydreigon_3, celebi_1, gardevoir_1, clefable_1, kyurem_1, type_null_1, dragapult_5, hatterene_1, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, meowstic_2, zeraora_2, zeraora_3, rotom_mow_1, zeraora_4, sylveon_5, togekiss_2, magnezone_1, porygonz_1, porygonz_2, dragapult_7];
toxtricity_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, excadrill_1, excadrill_2, excadrill_3, sylveon_2, arcanine_1, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, haxorus_1, haxorus_2, indeedee_1, rotom_heat_1, hydreigon_1, tyranitar_1, rotom_wash_1, alcremie_1, centiskorch_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, crustle_1, sawk_1, whimsicott_1, goodra_1, conkeldurr_2, dracozolt_1, steelix_1, snorlax_1, kommoo_1, snorlax_2, rotom_heat_2, rotom_heat_3, terrakion_1, keldeo_1, zeraora_1, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, diggersby_1, chandelure_1, crustle_2, meowstic_1, hydreigon_2, hydreigon_3, celebi_1, gardevoir_1, steelix_2, darmanitan_1, kyurem_1, type_null_1, hatterene_1, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, meowstic_2, zeraora_2, zeraora_3, primarina_4, zeraora_4, salazzle_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7, volcarona_3];
toxtricity_2.lmatchups = [mandibuzz_1, dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, excadrill_1, excadrill_2, excadrill_3, arcanine_1, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, haxorus_2, indeedee_1, rotom_heat_1, hydreigon_1, tyranitar_1, rotom_wash_1, centiskorch_1, rhyperior_1, rhyperior_2, corsola_1, crustle_1, sawk_1, goodra_1, conkeldurr_2, steelix_1, snorlax_1, kommoo_1, sawk_2, snorlax_2, rotom_heat_2, terrakion_1, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, diggersby_1, crustle_2, hydreigon_3, celebi_1, gardevoir_1, steelix_2, darmanitan_1, sawk_3, kyurem_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, meowstic_2, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, urshifu_1, porygon2_1, magearna_1, dragapult_7, volcarona_3];
rhyperior_1.lmatchups = [corviknight_1, sylveon_1, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, rotom_wash_1, eldegoss_1, alcremie_1, toxapex_1, rhyperior_2, corsola_1, corviknight_2, whimsicott_1, grimmsnarl_2, corsola_2, corsola_3, kommoo_1, silvally_water_1, sawk_2, snorlax_2, keldeo_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, pyukumuku_1, arcanine_2, whimsicott_2, rillaboom_2, meowstic_1, primarina_3, celebi_1, clefable_1, sawk_3, type_null_1, dragapult_5, gastrodon_2, kommoo_2, haxorus_4, kyurem_2, arcanine_3, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, meowstic_2, primarina_4, pyukumuku_2, rotom_mow_1, rillaboom_3, wobbuffet_1, magnezone_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, magearna_1];
rhyperior_2.lmatchups = [dragapult_1, dragapult_3, darmanitan_galar_2, darmanitan_galar_4, corviknight_1, excadrill_2, milotic_1, sylveon_2, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, rotom_wash_1, gengar_2, centiskorch_1, corsola_1, crustle_1, corviknight_2, sawk_1, whimsicott_1, grimmsnarl_2, corsola_2, corsola_3, snorlax_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, keldeo_1, primarina_1, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, avalugg_1, pyukumuku_1, avalugg_2, gyarados_1, arcanine_2, chandelure_1, rillaboom_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, steelix_2, sawk_3, kyurem_1, type_null_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, darmanitan_galar_5, arcanine_3, kommoo_3, roserade_1, meowstic_2, pyukumuku_2, rotom_mow_1, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, chansey_1, urshifu_1, porygon2_1, magearna_1, dragapult_7];
corsola_1.lmatchups = [corviknight_1, grimmsnarl_1, hydreigon_1, togekiss_1, gengar_1, gengar_2, golisopod_2, crustle_1, corviknight_2, whimsicott_1, sylveon_3, grimmsnarl_2, kommoo_1, rotom_heat_2, rotom_heat_3, mandibuzz_1, rotom_wash_2, gyarados_1, whimsicott_2, chandelure_1, rillaboom_2, hydreigon_3, primarina_3, celebi_1, gardevoir_1, darmanitan_1, hatterene_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, meowstic_2, zeraora_2, zeraora_3, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, salazzle_1, porygonz_1, porygonz_2, porygon2_1, dragapult_7];
corsola_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, indeedee_1, hydreigon_1, togekiss_1, aegislash_2, gengar_1, gengar_2, alcremie_1, toxtricity_1, toxtricity_2, corsola_1, crustle_1, whimsicott_1, goodra_1, rotom_heat_2, rotom_heat_3, primarina_2, blastoise_1, rotom_wash_2, whimsicott_2, chandelure_1, rillaboom_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, gardevoir_1, darmanitan_1, dragapult_5, hatterene_1, butterfree_1, dragapult_6, haxorus_3, haxorus_4, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, salazzle_1, togekiss_2, volcarona_2, porygonz_1, porygonz_2, porygon2_1, dragapult_7, volcarona_3];
corsola_3.lmatchups = [dragapult_1, dragapult_2, dragapult_3, corviknight_1, corviknight_2, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, indeedee_1, hydreigon_1, togekiss_1, aegislash_2, gengar_1, gengar_2, eldegoss_1, alcremie_1, toxtricity_1, toxtricity_2, corsola_1, corsola_2, whimsicott_1, goodra_1, snorlax_2, rotom_heat_2, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, whimsicott_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, gardevoir_1, darmanitan_1, type_null_1, dragapult_5, hatterene_1, butterfree_1, dragapult_6, haxorus_3, haxorus_4, kyurem_2, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, sylveon_5, togekiss_2, volcarona_2, porygonz_1, porygonz_2, porygon2_1, dragapult_7, volcarona_3];
crustle_1.lmatchups = [dragapult_2, dragapult_3, dragapult_4, excadrill_1, excadrill_2, milotic_1, duraludon_1, gastrodon_1, haxorus_2, rotom_wash_1, aegislash_2, toxapex_1, rhyperior_1, corviknight_2, sawk_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_3, kommoo_1, sawk_2, keldeo_1, rotom_wash_2, pyukumuku_1, arcanine_2, crustle_2, meowstic_1, hydreigon_2, primarina_3, gardevoir_1, steelix_2, sawk_3, type_null_1, dragapult_5, gastrodon_2, dragapult_6, kommoo_2, dracozolt_2, kommoo_3, meowstic_2, primarina_4, pyukumuku_2, rotom_mow_1, salazzle_1, rillaboom_3, magnezone_1, urshifu_1, porygon2_1];
crustle_2.lmatchups = [weezing_galar_1, corviknight_1, corviknight_2, milotic_1, grimmsnarl_2, arcanine_2, duraludon_1, gastrodon_1, tyranitar_1, rotom_wash_1, rotom_wash_2, eldegoss_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, sawk_1, sawk_2, conkeldurr_1, conkeldurr_2, snorlax_2, kommoo_1, silvally_water_1, keldeo_1, incineroar_1, mandibuzz_1, venusaur_1, hippowdon_1, pyukumuku_1, diggersby_1, rillaboom_2, meowstic_1, steelix_2, sawk_3, type_null_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, arcanine_3, kommoo_3, aromatisse_2, meowstic_2, pyukumuku_2, rotom_mow_1, salazzle_1, magnezone_1, chansey_1, urshifu_1, porygon2_1, dragapult_7];
sawk_1.lmatchups = [dragapult_2, dragapult_3, dragapult_4, corviknight_1, corviknight_2, milotic_1, sylveon_1, gastrodon_1, haxorus_1, haxorus_2, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, golisopod_2, aegislash_2, eldegoss_1, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, corsola_1, conkeldurr_1, conkeldurr_2, grimmsnarl_2, corsola_2, corsola_3, kommoo_1, silvally_water_1, keldeo_1, mandibuzz_1, venusaur_1, hippowdon_1, pyukumuku_1, gyarados_1, arcanine_2, meowstic_1, primarina_3, steelix_2, clefable_1, type_null_1, dragapult_5, hatterene_1, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, haxorus_3, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, pyukumuku_2, wobbuffet_1, volcarona_1, volcarona_2, urshifu_1, porygon2_1, magearna_1, dragapult_7, volcarona_3, scyther_1];
sawk_2.lmatchups = [dragapult_3, weezing_galar_1, corviknight_1, excadrill_1, milotic_1, sylveon_1, haxorus_2, aromatisse_1, aegislash_2, eldegoss_1, toxapex_1, toxtricity_1, corsola_1, corsola_2, corsola_3, sawk_1, conkeldurr_1, conkeldurr_2, keldeo_1, blastoise_1, mandibuzz_1, venusaur_1, gyarados_1, arcanine_2, primarina_3, gardevoir_1, steelix_2, sawk_3, dragapult_5, butterfree_1, ninetales_1, dragapult_6, kommoo_2, haxorus_3, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_3, primarina_4, pyukumuku_2, salazzle_1, wobbuffet_1, volcarona_1, volcarona_2, urshifu_1, dragapult_7, volcarona_3, scyther_1];
sawk_3.lmatchups = [dragapult_3, dragapult_4, weezing_galar_1, corviknight_1, corviknight_2, excadrill_2, milotic_1, sylveon_1, grimmsnarl_2, arcanine_2, rillaboom_2, rotom_heat_3, aromatisse_1, togekiss_1, aegislash_2, eldegoss_1, alcremie_1, toxapex_1, toxtricity_1, corsola_1, corsola_2, corsola_3, sawk_1, steelix_2, silvally_water_1, keldeo_1, primarina_3, mandibuzz_1, venusaur_1, hippowdon_1, gyarados_1, meowstic_1, gardevoir_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, haxorus_3, arcanine_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_3, primarina_4, pyukumuku_2, zeraora_4, salazzle_1, volcarona_1, urshifu_1, porygon2_1, magearna_1, dragapult_7, volcarona_3, scyther_1];
whimsicott_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, excadrill_1, excadrill_2, excadrill_3, sylveon_1, sylveon_2, grimmsnarl_1, arcanine_1, duraludon_1, rillaboom_1, haxorus_1, indeedee_1, hydreigon_1, tyranitar_1, gengar_1, gengar_2, eldegoss_1, centiskorch_1, toxtricity_2, crustle_1, sawk_1, sylveon_3, goodra_1, grimmsnarl_2, steelix_1, snorlax_1, sawk_2, terrakion_1, incineroar_1, mandibuzz_1, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, chandelure_1, crustle_2, rillaboom_2, celebi_1, gardevoir_1, clefable_1, darmanitan_1, sawk_3, kyurem_1, hatterene_1, butterfree_1, darmanitan_galar_5, roserade_1, sylveon_4, rotom_mow_1, sylveon_5, salazzle_1, rillaboom_3, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, urshifu_1, volcarona_3, scyther_1];
whimsicott_2.lmatchups = [dragapult_1, dragapult_2, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, excadrill_2, excadrill_3, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, arcanine_1, rillaboom_1, haxorus_1, indeedee_1, hydreigon_1, tyranitar_1, aromatisse_1, gengar_1, gengar_2, eldegoss_1, centiskorch_1, toxtricity_1, toxtricity_2, rhyperior_2, crustle_1, sawk_1, sawk_2, goodra_1, snorlax_1, terrakion_1, incineroar_1, mandibuzz_1, venusaur_1, avalugg_1, avalugg_2, chandelure_1, crustle_2, rillaboom_2, hydreigon_2, hydreigon_3, celebi_1, gardevoir_1, clefable_1, darmanitan_1, sawk_3, kyurem_1, hatterene_1, butterfree_1, darmanitan_galar_5, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, sylveon_4, rotom_mow_1, sylveon_5, salazzle_1, rillaboom_3, volcarona_1, volcarona_2, porygonz_1, porygonz_2, urshifu_1, volcarona_3, scyther_1];
goodra_1.lmatchups = [dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, corviknight_2, excadrill_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, haxorus_2, aromatisse_1, aegislash_1, aegislash_2, rhyperior_1, rhyperior_2, corsola_1, crustle_1, sawk_1, grimmsnarl_2, snorlax_1, kommoo_1, sawk_2, terrakion_1, keldeo_1, primarina_1, zeraora_1, primarina_2, venusaur_1, avalugg_1, avalugg_2, diggersby_1, durant_1, crustle_2, gardevoir_1, sawk_3, dragapult_5, dragapult_6, haxorus_4, dracozolt_2, darmanitan_galar_5, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, primarina_4, sylveon_4, zeraora_4, magnezone_1, porygonz_2, chansey_1, azumarill_1, dragapult_7, scyther_1];
conkeldurr_1.lmatchups = [weezing_galar_1, corviknight_1, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, dracovish_1, indeedee_1, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, golisopod_2, eldegoss_1, alcremie_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_1, corsola_1, whimsicott_1, grimmsnarl_2, corsola_2, corsola_3, kommoo_1, silvally_water_1, primarina_1, primarina_2, mandibuzz_1, venusaur_1, pyukumuku_1, gyarados_1, arcanine_2, whimsicott_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, gardevoir_1, clefable_1, kyurem_1, dragapult_5, hatterene_1, gastrodon_2, butterfree_1, kommoo_2, dracozolt_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, togekiss_2, rillaboom_3, wobbuffet_1, volcarona_1, volcarona_2, urshifu_1, azumarill_1, porygon2_1, scyther_1];
conkeldurr_2.lmatchups = [weezing_galar_1, corviknight_1, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, dracovish_1, indeedee_1, rotom_heat_1, aromatisse_1, rotom_wash_1, golisopod_1, golisopod_2, togekiss_1, eldegoss_1, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, corsola_1, whimsicott_1, grimmsnarl_2, corsola_2, corsola_3, kommoo_1, silvally_water_1, primarina_1, primarina_2, mandibuzz_1, venusaur_1, pyukumuku_1, gyarados_1, arcanine_2, whimsicott_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, gardevoir_1, clefable_1, kyurem_1, dragapult_5, hatterene_1, gastrodon_2, butterfree_1, kommoo_2, dracozolt_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, togekiss_2, rillaboom_3, wobbuffet_1, volcarona_1, volcarona_2, urshifu_1, azumarill_1, porygon2_1, scyther_1];
dracozolt_1.lmatchups = [kyurem_2, dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, excadrill_1, excadrill_2, excadrill_3, grimmsnarl_2, duraludon_1, dracovish_2, haxorus_1, hydreigon_1, togekiss_1, eldegoss_1, alcremie_1, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, crustle_1, sawk_1, whimsicott_1, steelix_1, snorlax_1, kommoo_1, sawk_2, snorlax_2, zeraora_1, avalugg_1, hippowdon_1, avalugg_2, arcanine_2, whimsicott_2, durant_1, crustle_2, meowstic_1, hydreigon_2, gardevoir_1, steelix_2, sawk_3, type_null_1, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, kommoo_3, aromatisse_2, meowstic_2, zeraora_2, zeraora_4, wobbuffet_1, magnezone_1, porygonz_1, chansey_1, porygon2_1, dragapult_7];
dracozolt_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, excadrill_1, excadrill_2, excadrill_3, grimmsnarl_2, arcanine_1, dracovish_1, dracovish_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, hydreigon_1, hydreigon_2, hydreigon_3, togekiss_1, gengar_1, gengar_2, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, dracozolt_1, steelix_1, steelix_2, kommoo_1, kommoo_2, terrakion_1, keldeo_1, zeraora_1, avalugg_1, avalugg_2, hippowdon_1, diggersby_1, durant_1, meowstic_1, gardevoir_1, kyurem_1, butterfree_1, ninetales_1, darmanitan_galar_5, kyurem_2, kommoo_3, roserade_1, meowstic_2, zeraora_2, zeraora_4, magnezone_1, porygonz_1, porygonz_2, dragapult_7];
steelix_1.lmatchups = [dragapult_3, weezing_galar_1, corviknight_1, corviknight_2, milotic_1, dracovish_1, dracovish_2, gastrodon_1, indeedee_1, rotom_heat_1, rotom_wash_1, golisopod_1, golisopod_2, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, sawk_1, goodra_1, conkeldurr_1, conkeldurr_2, kommoo_1, silvally_water_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, gyarados_1, arcanine_2, whimsicott_2, rillaboom_2, meowstic_1, primarina_3, celebi_1, steelix_2, sawk_3, type_null_1, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, haxorus_3, kyurem_2, arcanine_3, kommoo_3, primarina_4, pyukumuku_2, rotom_mow_1, sylveon_5, salazzle_1, rillaboom_3, volcarona_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, volcarona_3, scyther_1];
steelix_2.lmatchups = [urshifu_1, corviknight_1, corviknight_2, milotic_1, arcanine_2, rillaboom_1, rillaboom_2, gastrodon_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, rotom_wash_1, rotom_wash_2, golisopod_2, eldegoss_1, toxapex_1, corsola_1, corsola_2, corsola_3, whimsicott_2, conkeldurr_1, conkeldurr_2, snorlax_2, kommoo_1, silvally_water_1, incineroar_1, primarina_2, primarina_3, blastoise_1, mandibuzz_1, pyukumuku_1, gyarados_1, meowstic_1, celebi_1, type_null_1, dragapult_5, gastrodon_2, butterfree_1, dragapult_6, kommoo_2, haxorus_3, kyurem_2, arcanine_3, kommoo_3, meowstic_2, primarina_4, pyukumuku_2, rotom_mow_1, sylveon_5, salazzle_1, volcarona_2, chansey_1, porygon2_1, magearna_1, volcarona_3, scyther_1];
snorlax_1.lmatchups = [dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_4, corviknight_1, corviknight_2, milotic_1, duraludon_1, dracovish_1, gastrodon_1, rotom_heat_1, tyranitar_1, rotom_wash_1, eldegoss_1, toxapex_1, rhyperior_1, corsola_1, corsola_2, corsola_3, crustle_1, sawk_1, conkeldurr_1, conkeldurr_2, steelix_1, kommoo_1, silvally_water_1, sawk_2, snorlax_2, terrakion_1, keldeo_1, incineroar_1, primarina_2, blastoise_1, mandibuzz_1, venusaur_1, pyukumuku_1, avalugg_2, diggersby_1, arcanine_2, durant_1, meowstic_1, steelix_2, sawk_3, type_null_1, dragapult_5, gastrodon_2, butterfree_1, ninetales_1, dragapult_6, kommoo_2, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, meowstic_2, pyukumuku_2, wobbuffet_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, magearna_1, dragapult_7];
snorlax_2.lmatchups = [dragapult_4, corviknight_1, corviknight_2, excadrill_1, sylveon_3, grimmsnarl_2, dracovish_1, rillaboom_1, indeedee_1, hydreigon_1, togekiss_1, aegislash_1, corsola_1, corsola_2, crustle_1, sawk_1, sawk_2, whimsicott_1, goodra_1, conkeldurr_1, conkeldurr_2, kommoo_1, rotom_heat_2, rotom_heat_3, keldeo_1, incineroar_1, mandibuzz_1, rotom_wash_2, diggersby_1, whimsicott_2, chandelure_1, rillaboom_2, primarina_3, celebi_1, gardevoir_1, sawk_3, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kommoo_3, meowstic_2, sylveon_4, pyukumuku_2, rotom_mow_1, porygonz_1, porygonz_2, urshifu_1, porygon2_1, dragapult_7];
kommoo_1.lmatchups = [dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, indeedee_1, hydreigon_1, aromatisse_1, togekiss_1, aegislash_2, gengar_1, gengar_2, alcremie_1, corsola_2, corsola_3, whimsicott_1, sawk_2, keldeo_1, primarina_1, primarina_2, mandibuzz_1, whimsicott_2, meowstic_1, primarina_3, celebi_1, gardevoir_1, clefable_1, sawk_3, kyurem_1, type_null_1, dragapult_5, hatterene_1, dragapult_6, kommoo_2, haxorus_4, darmanitan_galar_5, kyurem_2, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, sylveon_4, sylveon_5, togekiss_2, volcarona_1, porygonz_2, azumarill_1, scyther_1];
kommoo_2.lmatchups = [darmanitan_galar_2, darmanitan_galar_4, weezing_galar_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, indeedee_1, hydreigon_1, hydreigon_3, aromatisse_1, togekiss_1, aegislash_1, aegislash_2, gengar_1, gengar_2, alcremie_1, corsola_2, corsola_3, sawk_3, whimsicott_1, whimsicott_2, goodra_1, keldeo_1, primarina_1, primarina_2, primarina_3, mandibuzz_1, diggersby_1, meowstic_1, celebi_1, gardevoir_1, clefable_1, kyurem_1, hatterene_1, butterfree_1, haxorus_4, darmanitan_galar_5, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, sylveon_4, sylveon_5, salazzle_1, togekiss_2, volcarona_1, porygonz_1, porygonz_2, azumarill_1, scyther_1];
kommoo_3.lmatchups = [dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_4, darmanitan_galar_5, weezing_galar_1, corviknight_1, corviknight_2, grimmsnarl_1, grimmsnarl_2, gastrodon_1, gastrodon_2, haxorus_4, indeedee_1, hydreigon_1, aromatisse_1, togekiss_1, aegislash_2, gengar_1, gengar_2, alcremie_1, toxapex_1, toxtricity_1, toxtricity_2, corsola_1, corsola_2, corsola_3, sawk_3, whimsicott_1, whimsicott_2, keldeo_1, primarina_1, primarina_2, primarina_3, pyukumuku_1, diggersby_1, meowstic_1, celebi_1, gardevoir_1, clefable_1, kyurem_1, hatterene_1, butterfree_1, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, primarina_4, pyukumuku_2, salazzle_1, togekiss_2, volcarona_1, porygonz_1, porygonz_2, azumarill_1, porygon2_1, scyther_1];
silvally_water_1.lmatchups = [dragapult_3, sylveon_2, sylveon_3, grimmsnarl_2, duraludon_1, rillaboom_1, gastrodon_1, haxorus_2, hydreigon_1, gengar_2, eldegoss_1, toxtricity_1, toxtricity_2, corsola_1, corsola_2, corsola_3, whimsicott_1, goodra_1, dracozolt_1, kommoo_1, sawk_2, snorlax_2, rotom_heat_2, rotom_heat_3, keldeo_1, primarina_1, zeraora_1, blastoise_1, mandibuzz_1, rotom_wash_2, venusaur_1, pyukumuku_1, gyarados_1, whimsicott_2, chandelure_1, rillaboom_2, meowstic_1, hydreigon_3, celebi_1, kyurem_1, type_null_1, dragapult_5, hatterene_1, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, togekiss_2, rillaboom_3, magnezone_1, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7];
terrakion_1.lmatchups = [zeraora_2, dragapult_3, darmanitan_galar_1, darmanitan_galar_3, corviknight_1, corviknight_2, excadrill_3, milotic_1, sylveon_1, sylveon_3, grimmsnarl_1, grimmsnarl_2, dracovish_1, dracovish_2, rillaboom_1, aromatisse_1, rotom_wash_1, aegislash_1, aegislash_2, alcremie_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, crustle_1, sawk_1, sawk_2, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, snorlax_2, kommoo_1, silvally_water_1, keldeo_1, primarina_1, zeraora_1, primarina_2, blastoise_1, rotom_wash_2, venusaur_1, avalugg_1, hippowdon_1, pyukumuku_1, avalugg_2, durant_1, crustle_2, rillaboom_2, meowstic_1, primarina_3, celebi_1, steelix_2, clefable_1, sawk_3, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_3, primarina_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, rillaboom_3, wobbuffet_1, magnezone_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7];
keldeo_1.lmatchups = [dragapult_3, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, gastrodon_1, indeedee_1, aromatisse_1, togekiss_1, alcremie_1, toxapex_1, corsola_1, corsola_2, corsola_3, whimsicott_1, conkeldurr_1, conkeldurr_2, dracozolt_1, primarina_1, zeraora_1, primarina_2, rotom_wash_2, venusaur_1, avalugg_1, pyukumuku_1, gyarados_1, whimsicott_2, rillaboom_2, meowstic_1, primarina_3, celebi_1, gardevoir_1, steelix_2, type_null_1, dragapult_5, hatterene_1, gastrodon_2, ninetales_1, dragapult_6, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, azumarill_1, dragapult_7, scyther_1];
incineroar_1.lmatchups = [dragapult_1, weezing_galar_1, milotic_1, sylveon_1, sylveon_2, sylveon_3, duraludon_1, dracovish_1, dracovish_2, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, tyranitar_1, aromatisse_1, rotom_wash_1, togekiss_1, alcremie_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_2, crustle_1, sawk_1, sawk_2, goodra_1, dracozolt_1, kommoo_1, silvally_water_1, terrakion_1, keldeo_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, rotom_wash_2, pyukumuku_1, gyarados_1, hydreigon_2, hydreigon_3, primarina_3, gardevoir_1, clefable_1, sawk_3, kyurem_1, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, kommoo_3, aromatisse_2, aromatisse_3, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, salazzle_1, togekiss_2, volcarona_1, porygonz_1, porygonz_2, urshifu_1, azumarill_1, magearna_1, volcarona_3];
primarina_1.lmatchups = [dragapult_3, darmanitan_galar_2, darmanitan_galar_4, corviknight_2, milotic_1, sylveon_2, rillaboom_1, rotom_heat_2, gengar_2, alcremie_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, corsola_1, corsola_3, crustle_1, sawk_1, sawk_2, whimsicott_1, dracozolt_1, snorlax_1, snorlax_2, zeraora_1, rotom_wash_2, venusaur_1, avalugg_1, diggersby_1, gyarados_1, whimsicott_2, crustle_2, rillaboom_2, celebi_1, steelix_2, sawk_3, type_null_1, dragapult_5, butterfree_1, ninetales_1, dragapult_6, dracozolt_2, darmanitan_galar_5, roserade_1, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, pyukumuku_2, rotom_mow_1, zeraora_4, salazzle_1, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_2, porygonz_2, chansey_1, porygon2_1, magearna_1, dragapult_7, scyther_1];
primarina_2.lmatchups = [darmanitan_galar_2, darmanitan_galar_4, sylveon_2, rillaboom_1, gastrodon_1, rotom_wash_1, alcremie_1, centiskorch_1, toxapex_1, toxtricity_2, rhyperior_2, corsola_1, crustle_1, sawk_1, sawk_2, whimsicott_1, dracozolt_1, snorlax_2, silvally_water_1, primarina_1, zeraora_1, rotom_wash_2, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, whimsicott_2, rillaboom_2, meowstic_1, celebi_1, gardevoir_1, clefable_1, sawk_3, type_null_1, hatterene_1, gastrodon_2, butterfree_1, dracozolt_2, darmanitan_galar_5, kyurem_2, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, rotom_mow_1, zeraora_4, togekiss_2, rillaboom_3, magnezone_1, volcarona_2, porygonz_2, chansey_1, porygon2_1, magearna_1, scyther_1];
primarina_3.lmatchups = [darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, duraludon_1, rillaboom_1, rillaboom_2, indeedee_1, rotom_heat_2, tyranitar_1, rotom_wash_1, rotom_wash_2, gengar_2, alcremie_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, crustle_2, goodra_1, dracozolt_1, snorlax_1, silvally_water_1, primarina_1, zeraora_1, venusaur_1, diggersby_1, gyarados_1, meowstic_1, celebi_1, type_null_1, hatterene_1, butterfree_1, dracozolt_2, darmanitan_galar_5, kyurem_2, roserade_1, aromatisse_3, aromatisse_4, meowstic_2, zeraora_2, zeraora_3, primarina_4, pyukumuku_2, rotom_mow_1, zeraora_4, salazzle_1, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, porygon2_1, scyther_1];
primarina_4.lmatchups = [darmanitan_galar_4, darmanitan_galar_5, corviknight_2, milotic_1, rillaboom_1, rillaboom_2, gastrodon_1, gastrodon_2, rotom_heat_1, tyranitar_1, rotom_wash_1, rotom_wash_2, alcremie_1, centiskorch_1, toxapex_1, rhyperior_2, corsola_1, crustle_2, whimsicott_1, whimsicott_2, dracozolt_1, dracozolt_2, snorlax_1, snorlax_2, silvally_water_1, primarina_1, zeraora_1, zeraora_2, zeraora_3, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, meowstic_1, meowstic_2, celebi_1, clefable_1, kyurem_2, type_null_1, roserade_1, pyukumuku_2, rotom_mow_1, zeraora_4, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_2, chansey_1, porygon2_1, magearna_1, scyther_1];
zeraora_1.lmatchups = [darmanitan_galar_1, darmanitan_galar_3, sylveon_1, grimmsnarl_2, duraludon_1, rillaboom_1, gastrodon_1, rotom_heat_1, rotom_heat_2, rotom_wash_1, aegislash_2, eldegoss_1, alcremie_1, centiskorch_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, sawk_1, sawk_2, whimsicott_1, conkeldurr_1, conkeldurr_2, steelix_1, snorlax_1, snorlax_2, incineroar_1, venusaur_1, avalugg_1, hippowdon_1, avalugg_2, arcanine_2, whimsicott_2, durant_1, crustle_2, rillaboom_2, meowstic_1, steelix_2, clefable_1, darmanitan_1, sawk_3, type_null_1, gastrodon_2, kommoo_2, arcanine_3, kommoo_3, meowstic_2, pyukumuku_2, rotom_mow_1, rillaboom_3, wobbuffet_1, porygonz_1, chansey_1, porygon2_1, volcarona_3];
zeraora_2.lmatchups = [hatterene_1, darmanitan_galar_1, darmanitan_galar_3, weezing_galar_1, excadrill_3, sylveon_1, sylveon_2, grimmsnarl_2, arcanine_1, arcanine_2, arcanine_3, duraludon_1, rillaboom_1, rillaboom_2, gastrodon_1, gastrodon_2, haxorus_1, rotom_heat_2, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_2, eldegoss_1, alcremie_1, centiskorch_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_3, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, conkeldurr_1, conkeldurr_2, steelix_1, steelix_2, snorlax_2, incineroar_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, chandelure_1, durant_1, meowstic_1, meowstic_2, celebi_1, gardevoir_1, darmanitan_1, kyurem_1, ninetales_1, roserade_1, rotom_mow_1, sylveon_5, rillaboom_3, wobbuffet_1, porygonz_1, chansey_1, urshifu_1];
zeraora_3.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_3, excadrill_3, sylveon_1, grimmsnarl_2, arcanine_1, arcanine_2, arcanine_3, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, rillaboom_2, gastrodon_1, gastrodon_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, rotom_heat_2, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_2, eldegoss_1, alcremie_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_3, crustle_1, crustle_2, whimsicott_1, whimsicott_2, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, dracozolt_2, steelix_1, steelix_2, snorlax_2, kommoo_1, kommoo_2, kommoo_3, incineroar_1, zeraora_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, durant_1, meowstic_1, meowstic_2, celebi_1, gardevoir_1, darmanitan_1, hatterene_1, roserade_1, rotom_mow_1, zeraora_4, sylveon_5, rillaboom_3, porygonz_1, chansey_1, dragapult_7];
zeraora_4.lmatchups = [darmanitan_galar_1, darmanitan_galar_3, excadrill_1, excadrill_2, excadrill_3, sylveon_1, grimmsnarl_2, arcanine_1, arcanine_2, arcanine_3, duraludon_1, rillaboom_1, rillaboom_2, gastrodon_1, gastrodon_2, haxorus_1, rotom_heat_2, tyranitar_1, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_2, golisopod_2, eldegoss_1, alcremie_1, centiskorch_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_3, crustle_1, crustle_2, sawk_2, whimsicott_1, whimsicott_2, conkeldurr_1, conkeldurr_2, steelix_1, steelix_2, snorlax_2, incineroar_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_2, diggersby_1, chandelure_1, durant_1, meowstic_1, meowstic_2, celebi_1, gardevoir_1, darmanitan_1, hatterene_1, rotom_mow_1, sylveon_5, rillaboom_3, magnezone_1, porygonz_1, chansey_1];
blastoise_1.lmatchups = [darmanitan_galar_4, excadrill_1, milotic_1, sylveon_2, grimmsnarl_2, rillaboom_1, gastrodon_1, aromatisse_1, rotom_wash_1, alcremie_1, toxapex_1, toxtricity_1, toxtricity_2, corsola_1, crustle_1, sawk_1, whimsicott_1, goodra_1, dracozolt_1, snorlax_2, primarina_1, primarina_2, zeraora_1, rotom_wash_2, venusaur_1, pyukumuku_1, diggersby_1, gyarados_1, whimsicott_2, rillaboom_2, primarina_3, celebi_1, gardevoir_1, clefable_1, sawk_3, kyurem_1, hatterene_1, gastrodon_2, butterfree_1, dragapult_6, kommoo_2, dracozolt_2, darmanitan_galar_5, kyurem_2, kommoo_3, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, primarina_4, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, rillaboom_3, magnezone_1, volcarona_2, porygonz_2, chansey_1, azumarill_1, volcarona_3];
mandibuzz_1.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_2, dracovish_1, rotom_heat_2, rotom_heat_3, hydreigon_1, aromatisse_1, togekiss_1, gengar_2, eldegoss_1, alcremie_1, toxtricity_1, corsola_2, crustle_1, dracozolt_1, terrakion_1, primarina_1, primarina_2, zeraora_1, blastoise_1, rotom_wash_2, rillaboom_2, celebi_1, gardevoir_1, darmanitan_1, kyurem_1, type_null_1, hatterene_1, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, primarina_4, sylveon_4, rotom_mow_1, zeraora_4, sylveon_5, porygonz_1, porygonz_2, chansey_1, urshifu_1];
venusaur_1.lmatchups = [dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, arcanine_1, duraludon_1, haxorus_2, aegislash_2, gengar_1, centiskorch_1, corsola_1, corsola_2, corsola_3, steelix_1, snorlax_2, kommoo_1, incineroar_1, mandibuzz_1, diggersby_1, arcanine_2, chandelure_1, durant_1, meowstic_1, hydreigon_3, celebi_1, darmanitan_1, kyurem_1, type_null_1, dragapult_5, butterfree_1, ninetales_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kyurem_2, arcanine_3, roserade_1, meowstic_2, salazzle_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, dragapult_7, volcarona_3, scyther_1];
avalugg_1.lmatchups = [corviknight_1, corviknight_2, milotic_1, dracovish_1, dracovish_2, gastrodon_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, rotom_wash_1, rotom_wash_2, golisopod_1, centiskorch_1, toxapex_1, rhyperior_1, corsola_1, corsola_2, corsola_3, crustle_1, conkeldurr_1, conkeldurr_2, snorlax_1, snorlax_2, silvally_water_1, incineroar_1, blastoise_1, venusaur_1, pyukumuku_1, avalugg_2, arcanine_2, durant_1, crustle_2, meowstic_1, primarina_3, steelix_2, type_null_1, dragapult_5, gastrodon_2, butterfree_1, ninetales_1, kommoo_2, kyurem_2, arcanine_3, aromatisse_2, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, salazzle_1, magnezone_1, volcarona_2, chansey_1, urshifu_1, porygon2_1];
avalugg_2.lmatchups = [weezing_galar_1, corviknight_1, corviknight_2, milotic_1, duraludon_1, dracovish_1, gastrodon_1, indeedee_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, aromatisse_1, rotom_wash_1, rotom_wash_2, golisopod_1, golisopod_2, eldegoss_1, centiskorch_1, toxapex_1, rhyperior_1, corsola_1, corsola_2, corsola_3, conkeldurr_1, conkeldurr_2, snorlax_2, silvally_water_1, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, pyukumuku_1, arcanine_2, durant_1, crustle_2, meowstic_1, primarina_3, steelix_2, type_null_1, dragapult_5, gastrodon_2, butterfree_1, ninetales_1, kommoo_2, arcanine_3, kommoo_3, aromatisse_2, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, sylveon_5, salazzle_1, magnezone_1, volcarona_2, chansey_1, urshifu_1, azumarill_1, porygon2_1];
hippowdon_1.lmatchups = [dragapult_3, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, milotic_1, sylveon_2, dracovish_1, dracovish_2, rillaboom_1, gastrodon_1, rotom_heat_1, rotom_heat_3, hydreigon_1, rotom_wash_1, rotom_wash_2, golisopod_1, golisopod_2, eldegoss_1, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, sawk_2, goodra_1, snorlax_1, snorlax_2, kommoo_1, silvally_water_1, keldeo_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, venusaur_1, avalugg_1, pyukumuku_1, avalugg_2, diggersby_1, gyarados_1, arcanine_2, whimsicott_2, durant_1, rillaboom_2, meowstic_1, hydreigon_3, primarina_3, celebi_1, steelix_2, kyurem_1, type_null_1, dragapult_5, gastrodon_2, butterfree_1, dragapult_6, kommoo_2, darmanitan_galar_5, kyurem_2, arcanine_3, kommoo_3, roserade_1, meowstic_2, primarina_4, pyukumuku_2, rotom_mow_1, sylveon_5, rillaboom_3, wobbuffet_1, magnezone_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, magearna_1, dragapult_7];
pyukumuku_1.lmatchups = [dragapult_4, corviknight_1, corviknight_2, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_2, rillaboom_1, rotom_heat_2, rotom_heat_3, aromatisse_1, rotom_wash_2, eldegoss_1, toxapex_1, toxtricity_1, toxtricity_2, corsola_1, corsola_2, corsola_3, sawk_2, whimsicott_1, goodra_1, dracozolt_1, snorlax_2, mandibuzz_1, venusaur_1, gyarados_1, whimsicott_2, rillaboom_2, hydreigon_3, celebi_1, gardevoir_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, roserade_1, zeraora_2, zeraora_3, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, togekiss_2, rillaboom_3, magnezone_1, porygonz_1, porygonz_2, chansey_1, azumarill_1, dragapult_7];
pyukumuku_2.lmatchups = [dragapult_5, dragapult_6, corviknight_1, corviknight_2, sylveon_1, sylveon_2, sylveon_3, sylveon_4, rillaboom_1, rillaboom_2, haxorus_3, rotom_heat_2, rotom_heat_3, hydreigon_1, hydreigon_3, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_2, togekiss_1, eldegoss_1, toxapex_1, toxtricity_1, toxtricity_2, whimsicott_1, whimsicott_2, goodra_1, dracozolt_1, dracozolt_2, zeraora_2, zeraora_3, mandibuzz_1, venusaur_1, gyarados_1, celebi_1, gardevoir_1, clefable_1, butterfree_1, roserade_1, rotom_mow_1, sylveon_5, togekiss_2, rillaboom_3, magnezone_1, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7];
diggersby_1.lmatchups = [dragapult_1, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, excadrill_2, grimmsnarl_2, arcanine_1, dracovish_1, dracovish_2, rillaboom_1, haxorus_1, haxorus_2, gengar_2, rhyperior_1, corsola_1, corsola_2, corsola_3, crustle_1, sawk_1, sawk_2, dracozolt_1, steelix_1, terrakion_1, keldeo_1, incineroar_1, zeraora_1, avalugg_1, avalugg_2, arcanine_2, durant_1, hydreigon_2, hydreigon_3, celebi_1, darmanitan_1, sawk_3, kyurem_1, type_null_1, dragapult_5, butterfree_1, ninetales_1, dragapult_6, haxorus_3, haxorus_4, darmanitan_galar_5, arcanine_3, roserade_1, zeraora_2, zeraora_3, salazzle_1, rillaboom_3, magnezone_1, volcarona_1, porygonz_1, porygonz_2, porygon2_1, dragapult_7, volcarona_3];
gyarados_1.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, weezing_galar_1, sylveon_2, grimmsnarl_2, duraludon_1, rillaboom_1, rotom_heat_2, rotom_heat_3, hydreigon_1, tyranitar_1, rotom_wash_1, rotom_wash_2, golisopod_1, alcremie_1, toxtricity_1, toxtricity_2, rhyperior_1, corsola_2, corsola_3, crustle_1, whimsicott_1, goodra_1, dracozolt_1, snorlax_1, snorlax_2, kommoo_1, terrakion_1, zeraora_1, mandibuzz_1, venusaur_1, avalugg_1, avalugg_2, diggersby_1, arcanine_2, whimsicott_2, durant_1, crustle_2, rillaboom_2, meowstic_1, celebi_1, kyurem_1, type_null_1, dragapult_5, dragapult_6, kommoo_2, dracozolt_2, darmanitan_galar_5, kyurem_2, kommoo_3, aromatisse_2, meowstic_2, zeraora_2, zeraora_3, rotom_mow_1, zeraora_4, sylveon_5, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, porygonz_1, porygonz_2, chansey_1, urshifu_1, scyther_1];
chandelure_1.lmatchups = [dragapult_2, darmanitan_galar_1, sylveon_1, sylveon_2, grimmsnarl_1, arcanine_1, dracovish_1, dracovish_2, haxorus_1, haxorus_2, hydreigon_1, tyranitar_1, rotom_wash_2, golisopod_1, golisopod_2, centiskorch_1, toxapex_1, rhyperior_1, crustle_1, sawk_1, sawk_2, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, snorlax_1, kommoo_1, terrakion_1, keldeo_1, incineroar_1, primarina_1, primarina_2, blastoise_1, mandibuzz_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_1, gyarados_1, crustle_2, hydreigon_2, hydreigon_3, primarina_3, steelix_2, darmanitan_1, sawk_3, kyurem_1, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kyurem_2, arcanine_3, kommoo_3, aromatisse_3, aromatisse_4, primarina_4, pyukumuku_2, togekiss_2, wobbuffet_1, magnezone_1, volcarona_2, chansey_1, urshifu_1, azumarill_1];
durant_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, weezing_galar_1, corviknight_1, corviknight_2, milotic_1, arcanine_2, gastrodon_1, rotom_heat_3, rotom_wash_1, togekiss_1, aegislash_2, gengar_1, gengar_2, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, crustle_1, sawk_1, sawk_2, whimsicott_1, whimsicott_2, conkeldurr_1, conkeldurr_2, steelix_1, snorlax_2, silvally_water_1, keldeo_1, incineroar_1, primarina_1, blastoise_1, pyukumuku_1, chandelure_1, crustle_2, primarina_3, steelix_2, darmanitan_1, sawk_3, dragapult_5, gastrodon_2, ninetales_1, dragapult_6, kommoo_2, arcanine_3, kommoo_3, primarina_4, pyukumuku_2, sylveon_5, magnezone_1, urshifu_1, porygon2_1, magearna_1, dragapult_7];
meowstic_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, darmanitan_galar_2, corviknight_1, corviknight_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, dracovish_1, hydreigon_1, tyranitar_1, golisopod_1, golisopod_2, aegislash_1, aegislash_2, gengar_1, gengar_2, centiskorch_1, corsola_1, whimsicott_1, whimsicott_2, goodra_1, snorlax_2, incineroar_1, mandibuzz_1, pyukumuku_1, chandelure_1, durant_1, hydreigon_2, hydreigon_3, celebi_1, gardevoir_1, hatterene_1, butterfree_1, dragapult_6, haxorus_3, haxorus_4, darmanitan_galar_5, meowstic_2, sylveon_4, pyukumuku_2, sylveon_5, rillaboom_3, volcarona_1, volcarona_2, porygonz_2, chansey_1, urshifu_1, porygon2_1, dragapult_7, volcarona_3];
meowstic_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_6, darmanitan_galar_2, darmanitan_galar_5, corviknight_1, corviknight_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, dracovish_1, haxorus_3, haxorus_4, hydreigon_1, hydreigon_2, hydreigon_3, tyranitar_1, golisopod_1, golisopod_2, aegislash_1, aegislash_2, gengar_1, gengar_2, eldegoss_1, centiskorch_1, whimsicott_1, whimsicott_2, goodra_1, kommoo_1, kommoo_2, kommoo_3, silvally_water_1, incineroar_1, mandibuzz_1, pyukumuku_1, chandelure_1, durant_1, celebi_1, gardevoir_1, butterfree_1, sylveon_4, pyukumuku_2, sylveon_5, rillaboom_3, volcarona_1, porygonz_2, urshifu_1, porygon2_1, dragapult_7, volcarona_3];
celebi_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_3, excadrill_3, sylveon_1, sylveon_2, sylveon_3, arcanine_1, duraludon_1, haxorus_1, rotom_heat_2, rotom_heat_3, hydreigon_1, hydreigon_2, hydreigon_3, golisopod_1, golisopod_2, togekiss_1, aegislash_1, aegislash_2, gengar_1, gengar_2, centiskorch_1, crustle_2, sawk_1, sawk_2, goodra_1, snorlax_1, incineroar_1, zeraora_1, avalugg_1, avalugg_2, chandelure_1, durant_1, darmanitan_1, kyurem_1, dragapult_5, hatterene_1, butterfree_1, ninetales_1, dragapult_6, dracozolt_2, kyurem_2, aromatisse_3, aromatisse_4, sylveon_4, salazzle_1, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, chansey_1, dragapult_7, volcarona_3, scyther_1];
gardevoir_1.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_1, sylveon_2, duraludon_1, rillaboom_1, rillaboom_2, haxorus_1, indeedee_1, rotom_heat_2, tyranitar_1, golisopod_1, golisopod_2, aegislash_1, aegislash_2, centiskorch_1, rhyperior_1, rhyperior_2, sawk_1, steelix_1, snorlax_1, silvally_water_1, primarina_1, zeraora_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, diggersby_1, gyarados_1, durant_1, steelix_2, darmanitan_1, hatterene_1, gastrodon_2, ninetales_1, darmanitan_galar_5, primarina_4, sylveon_5, togekiss_2, rillaboom_3, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, azumarill_1, volcarona_3, scyther_1];
clefable_1.lmatchups = [darmanitan_galar_2, darmanitan_galar_4, weezing_galar_1, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_2, sylveon_3, duraludon_1, dracovish_1, dracovish_2, indeedee_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, tyranitar_1, aromatisse_1, rotom_wash_1, togekiss_1, aegislash_1, gengar_1, gengar_2, centiskorch_1, toxtricity_2, corsola_1, corsola_2, corsola_3, crustle_1, sawk_2, goodra_1, steelix_1, steelix_2, snorlax_2, silvally_water_1, primarina_1, mandibuzz_1, venusaur_1, avalugg_1, pyukumuku_1, diggersby_1, chandelure_1, durant_1, meowstic_1, gardevoir_1, darmanitan_1, kyurem_1, type_null_1, hatterene_1, butterfree_1, dracozolt_2, darmanitan_galar_5, roserade_1, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, sylveon_4, sylveon_5, rillaboom_3, magnezone_1, porygonz_1, porygonz_2, chansey_1, urshifu_1];
darmanitan_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, milotic_1, grimmsnarl_1, duraludon_1, dracovish_1, dracovish_2, haxorus_1, haxorus_2, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, rotom_wash_1, rotom_wash_2, golisopod_1, golisopod_2, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, crustle_1, crustle_2, sawk_2, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, steelix_2, snorlax_1, snorlax_2, kommoo_1, silvally_water_1, keldeo_1, incineroar_1, primarina_1, primarina_2, primarina_3, blastoise_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_1, gyarados_1, meowstic_1, gastrodon_1, sawk_3, kyurem_1, dragapult_5, gastrodon_2, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, kommoo_3, meowstic_2, primarina_4, pyukumuku_2, wobbuffet_1, magnezone_1, chansey_1, urshifu_1, azumarill_1, dragapult_7];
kyurem_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, darmanitan_galar_1, darmanitan_galar_3, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, haxorus_1, haxorus_2, rotom_heat_1, hydreigon_2, hydreigon_3, tyranitar_1, aromatisse_1, aegislash_1, aegislash_2, alcremie_1, centiskorch_1, rhyperior_1, corsola_1, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, goodra_1, dracozolt_1, steelix_1, steelix_2, snorlax_1, snorlax_2, terrakion_1, keldeo_1, primarina_1, zeraora_1, avalugg_1, avalugg_2, pyukumuku_1, durant_1, gardevoir_1, type_null_1, dragapult_5, hatterene_1, ninetales_1, dragapult_6, haxorus_3, haxorus_4, kyurem_2, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_3, pyukumuku_2, zeraora_4, sylveon_5, wobbuffet_1, magnezone_1, volcarona_2, porygonz_2, chansey_1, porygon2_1, dragapult_7, volcarona_3];
kyurem_2.lmatchups = [darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, darmanitan_galar_5, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_1, sylveon_2, sylveon_3, grimmsnarl_1, grimmsnarl_2, arcanine_1, haxorus_4, rotom_heat_3, hydreigon_1, tyranitar_1, aromatisse_1, aegislash_1, gengar_1, centiskorch_1, corsola_1, corsola_2, crustle_1, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, goodra_1, conkeldurr_1, conkeldurr_2, snorlax_2, kommoo_2, terrakion_1, keldeo_1, primarina_1, zeraora_1, mandibuzz_1, avalugg_2, diggersby_1, durant_1, meowstic_1, gardevoir_1, clefable_1, type_null_1, hatterene_1, butterfree_1, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, sylveon_4, sylveon_5, togekiss_2, magnezone_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1];
type_null_1.lmatchups = [darmanitan_galar_2, darmanitan_galar_4, sylveon_2, sylveon_3, grimmsnarl_2, dracovish_1, rillaboom_2, indeedee_1, rotom_heat_2, rotom_heat_3, hydreigon_1, aromatisse_1, rotom_wash_2, togekiss_1, gengar_1, toxtricity_2, corsola_1, corsola_2, sawk_2, sawk_3, whimsicott_1, whimsicott_2, goodra_1, conkeldurr_1, conkeldurr_2, snorlax_2, terrakion_1, incineroar_1, blastoise_1, pyukumuku_1, chandelure_1, celebi_1, gardevoir_1, darmanitan_1, hatterene_1, butterfree_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, dracozolt_2, darmanitan_galar_5, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, zeraora_2, zeraora_3, sylveon_4, pyukumuku_2, rotom_mow_1, zeraora_4, sylveon_5, salazzle_1, togekiss_2, porygonz_1, porygonz_2, chansey_1, urshifu_1, porygon2_1, dragapult_7];
hatterene_1.lmatchups = [dragapult_1, dragapult_4, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_2, arcanine_1, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, haxorus_2, rotom_heat_2, tyranitar_1, golisopod_1, golisopod_2, aegislash_1, aegislash_2, gengar_1, gengar_2, centiskorch_1, toxtricity_2, rhyperior_1, rhyperior_2, crustle_1, crustle_2, sawk_2, goodra_1, dracozolt_1, steelix_1, steelix_2, snorlax_1, snorlax_2, incineroar_1, primarina_1, zeraora_1, avalugg_1, avalugg_2, hippowdon_1, diggersby_1, gyarados_1, chandelure_1, durant_1, darmanitan_1, dracozolt_2, roserade_1, venusaur_1, meowstic_2, pyukumuku_2, salazzle_1, rillaboom_3, magnezone_1, volcarona_1, volcarona_2, porygonz_2, azumarill_1, volcarona_3, scyther_1];
butterfree_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_2, grimmsnarl_1, grimmsnarl_2, arcanine_1, arcanine_2, dracovish_1, dracovish_2, haxorus_1, haxorus_2, indeedee_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, hydreigon_2, hydreigon_3, rotom_wash_1, rotom_wash_2, golisopod_2, togekiss_1, gengar_1, gengar_2, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, crustle_1, crustle_2, sawk_1, sawk_3, goodra_1, dracozolt_1, steelix_1, snorlax_2, kommoo_1, terrakion_1, keldeo_1, zeraora_1, mandibuzz_1, pyukumuku_1, gyarados_1, chandelure_1, durant_1, gardevoir_1, darmanitan_1, kyurem_1, hatterene_1, ninetales_1, dragapult_6, haxorus_3, haxorus_4, darmanitan_galar_5, zeraora_2, zeraora_3, rotom_mow_1, zeraora_4, salazzle_1, togekiss_2, volcarona_1, volcarona_2, porygonz_1, porygonz_2, urshifu_1, dragapult_7, volcarona_3, scyther_1];
ninetales_1.lmatchups = [dragapult_3, dragapult_5, milotic_1, arcanine_2, gastrodon_1, gastrodon_2, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, tyranitar_1, aromatisse_1, rotom_wash_1, rotom_wash_2, golisopod_2, alcremie_1, centiskorch_1, toxapex_1, rhyperior_1, corsola_1, corsola_2, corsola_3, crustle_1, goodra_1, conkeldurr_1, conkeldurr_2, snorlax_2, kommoo_1, silvally_water_1, incineroar_1, primarina_2, primarina_3, blastoise_1, mandibuzz_1, hippowdon_1, pyukumuku_1, gyarados_1, chandelure_1, meowstic_1, clefable_1, darmanitan_1, type_null_1, hatterene_1, dragapult_6, kommoo_2, haxorus_3, haxorus_4, kyurem_2, arcanine_3, kommoo_3, aromatisse_2, aromatisse_3, aromatisse_4, meowstic_2, primarina_4, sylveon_4, pyukumuku_2, salazzle_1, togekiss_2, volcarona_2, chansey_1, porygon2_1, dragapult_7];
roserade_1.lmatchups = [dragapult_1, dragapult_4, darmanitan_galar_1, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, rotom_heat_2, rotom_heat_3, golisopod_1, golisopod_2, togekiss_1, aegislash_1, aegislash_2, gengar_1, gengar_2, corsola_1, goodra_1, dracozolt_1, snorlax_1, snorlax_2, terrakion_1, zeraora_1, mandibuzz_1, chandelure_1, durant_1, meowstic_1, celebi_1, gardevoir_1, darmanitan_1, kyurem_1, type_null_1, ninetales_1, meowstic_2, zeraora_4, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, chansey_1, volcarona_3, scyther_1];
rotom_mow_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, darmanitan_galar_5, sylveon_1, sylveon_2, sylveon_3, sylveon_4, arcanine_1, arcanine_2, arcanine_3, duraludon_1, rillaboom_1, haxorus_1, haxorus_2, haxorus_3, haxorus_4, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, hydreigon_2, hydreigon_3, gengar_1, gengar_2, centiskorch_1, toxtricity_1, toxtricity_2, sawk_1, sawk_2, sawk_3, goodra_1, dracozolt_1, dracozolt_2, snorlax_1, kommoo_1, kommoo_2, kommoo_3, incineroar_1, venusaur_1, avalugg_1, avalugg_2, diggersby_1, chandelure_1, durant_1, meowstic_1, meowstic_2, celebi_1, darmanitan_1, kyurem_1, kyurem_2, ninetales_1, roserade_1, salazzle_1, rillaboom_3, wobbuffet_1, volcarona_1, volcarona_2, porygonz_1, porygonz_2, dragapult_7, volcarona_3];
salazzle_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_3, excadrill_3, milotic_1, dracovish_1, dracovish_2, gastrodon_1, gastrodon_2, haxorus_1, indeedee_1, rotom_heat_2, rotom_heat_3, hydreigon_2, hydreigon_3, tyranitar_1, rotom_wash_2, golisopod_2, gengar_2, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, sawk_1, goodra_1, dracozolt_1, snorlax_1, snorlax_2, silvally_water_1, terrakion_1, keldeo_1, primarina_2, primarina_4, zeraora_1, zeraora_2, zeraora_3, zeraora_4, blastoise_1, hippowdon_1, pyukumuku_1, pyukumuku_2, gyarados_1, chandelure_1, meowstic_1, meowstic_2, gardevoir_1, clefable_1, darmanitan_1, kyurem_1, kyurem_2, wobbuffet_1, volcarona_2, porygonz_1, chansey_1, urshifu_1, dragapult_7];
wobbuffet_1.lmatchups = [dragapult_3, dragapult_5, dragapult_6, corviknight_1, corviknight_2, excadrill_1, milotic_1, sylveon_3, sylveon_4, sylveon_5, grimmsnarl_2, arcanine_2, arcanine_3, rillaboom_1, rillaboom_2, gastrodon_1, gastrodon_2, haxorus_3, haxorus_4, rotom_heat_1, hydreigon_1, hydreigon_2, hydreigon_3, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_1, togekiss_2, aegislash_1, aegislash_2, alcremie_1, toxapex_1, corsola_1, corsola_2, corsola_3, crustle_1, crustle_2, sawk_3, whimsicott_1, whimsicott_2, goodra_1, dracozolt_2, steelix_2, snorlax_2, silvally_water_1, incineroar_1, primarina_2, blastoise_1, mandibuzz_1, venusaur_1, pyukumuku_1, pyukumuku_2, durant_1, meowstic_1, meowstic_2, clefable_1, kyurem_2, type_null_1, ninetales_1, volcarona_2, chansey_1, urshifu_1, porygon2_1, magearna_1, dragapult_7, volcarona_3, scyther_1];
magnezone_1.lmatchups = [dragapult_3, dragapult_4, dragapult_5, dragapult_6, excadrill_1, excadrill_2, excadrill_3, arcanine_2, arcanine_3, gastrodon_1, gastrodon_2, haxorus_2, haxorus_3, rotom_heat_1, rotom_heat_2, hydreigon_1, tyranitar_1, aromatisse_4, corsola_1, sawk_1, sawk_2, sawk_3, whimsicott_2, steelix_1, steelix_2, snorlax_2, kommoo_1, kommoo_2, kommoo_3, incineroar_1, zeraora_2, zeraora_3, type_null_1, ninetales_1, salazzle_1, wobbuffet_1, volcarona_2, chansey_1, porygon2_1, magearna_1, dragapult_7, volcarona_3, scyther_1];
volcarona_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_3, milotic_1, dracovish_1, dracovish_2, haxorus_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, tyranitar_1, aromatisse_3, aromatisse_4, rotom_wash_2, togekiss_2, alcremie_1, toxapex_1, rhyperior_1, corsola_1, corsola_2, corsola_3, crustle_1, crustle_2, goodra_1, dracozolt_1, steelix_2, snorlax_1, snorlax_2, silvally_water_1, terrakion_1, primarina_1, primarina_2, primarina_3, primarina_4, zeraora_1, zeraora_3, zeraora_4, blastoise_1, mandibuzz_1, avalugg_1, avalugg_2, pyukumuku_1, pyukumuku_2, gyarados_1, chandelure_1, darmanitan_1, kyurem_2, type_null_1, ninetales_1, wobbuffet_1, magnezone_1, volcarona_2, porygonz_1, chansey_1, azumarill_1, porygon2_1, dragapult_7, scyther_1];
volcarona_2.lmatchups = [dragapult_4, darmanitan_galar_2, darmanitan_galar_4, darmanitan_galar_5, arcanine_1, dracovish_1, dracovish_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, rotom_heat_1, tyranitar_1, golisopod_1, golisopod_2, centiskorch_1, toxapex_1, rhyperior_1, rhyperior_2, corsola_1, crustle_1, crustle_2, sawk_3, goodra_1, dracozolt_1, dracozolt_2, snorlax_1, snorlax_2, kommoo_1, kommoo_2, kommoo_3, terrakion_1, incineroar_1, zeraora_1, zeraora_2, zeraora_3, zeraora_4, mandibuzz_1, hippowdon_1, pyukumuku_1, pyukumuku_2, diggersby_1, gyarados_1, meowstic_2, clefable_1, darmanitan_1, kyurem_2, type_null_1, chansey_1, urshifu_1, azumarill_1, porygon2_1, dragapult_7, scyther_1];
volcarona_3.lmatchups = [dragapult_1, dragapult_2, dragapult_4, dragapult_6, dragapult_7, sylveon_2, arcanine_1, arcanine_3, dracovish_2, gastrodon_1, gastrodon_2, rotom_heat_2, rotom_heat_3, golisopod_2, centiskorch_1, toxapex_1, rhyperior_1, corsola_1, crustle_1, crustle_2, dracozolt_1, dracozolt_2, snorlax_1, snorlax_2, kommoo_1, kommoo_2, kommoo_3, terrakion_1, keldeo_1, primarina_1, primarina_2, primarina_3, primarina_4, mandibuzz_1, hippowdon_1, pyukumuku_1, pyukumuku_2, gyarados_1, chandelure_1, darmanitan_1, kyurem_2, type_null_1, volcarona_2, porygonz_1, chansey_1, urshifu_1, azumarill_1, scyther_1];
porygonz_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, weezing_galar_1, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, sylveon_1, sylveon_2, sylveon_3, sylveon_5, duraludon_1, gastrodon_2, haxorus_1, tyranitar_1, togekiss_2, aegislash_1, aegislash_2, gengar_1, gengar_2, rhyperior_1, rhyperior_2, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, goodra_1, steelix_1, steelix_2, snorlax_1, terrakion_1, primarina_1, primarina_2, primarina_4, avalugg_2, chandelure_1, durant_1, meowstic_1, meowstic_2, darmanitan_1, kyurem_2, wobbuffet_1, magnezone_1, volcarona_2, dragapult_7];
porygonz_2.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, darmanitan_galar_1, darmanitan_galar_3, darmanitan_galar_4, corviknight_1, corviknight_2, dracovish_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, hydreigon_2, tyranitar_1, aegislash_1, aegislash_2, gengar_1, gengar_2, rhyperior_1, rhyperior_2, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, conkeldurr_1, conkeldurr_2, dracozolt_1, steelix_1, steelix_2, terrakion_1, keldeo_1, zeraora_1, zeraora_2, zeraora_3, zeraora_4, avalugg_2, chandelure_1, durant_1, celebi_1, darmanitan_1, ninetales_1, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, porygonz_1, dragapult_7];
chansey_1.lmatchups = [dragapult_3, dragapult_5, dragapult_6, darmanitan_galar_2, darmanitan_galar_4, corviknight_1, corviknight_2, sylveon_3, sylveon_4, sylveon_5, rillaboom_2, haxorus_3, haxorus_4, rotom_heat_2, rotom_heat_3, rotom_wash_2, aegislash_1, aegislash_2, eldegoss_1, toxapex_1, corsola_1, corsola_2, corsola_3, crustle_1, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, conkeldurr_1, conkeldurr_2, dracozolt_2, snorlax_2, kommoo_1, kommoo_2, kommoo_3, terrakion_1, keldeo_1, durant_1, meowstic_2, gardevoir_1, butterfree_1, rotom_mow_1, porygonz_1, porygonz_2, urshifu_1, dragapult_7];
urshifu_1.lmatchups = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, weezing_galar_1, corviknight_1, milotic_1, sylveon_1, sylveon_3, sylveon_4, sylveon_5, rillaboom_1, rillaboom_2, rillaboom_3, hydreigon_3, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_1, golisopod_2, togekiss_1, gengar_2, eldegoss_1, toxapex_1, toxtricity_1, corsola_1, corsola_2, corsola_3, dracozolt_1, dracozolt_2, kommoo_1, silvally_water_1, keldeo_1, primarina_1, primarina_3, primarina_4, zeraora_3, blastoise_1, venusaur_1, pyukumuku_2, diggersby_1, celebi_1, gardevoir_1, kyurem_1, hatterene_1, ninetales_1, roserade_1, rotom_mow_1, magnezone_1, volcarona_1, porygonz_1, porygonz_2, azumarill_1, porygon2_1, dragapult_7, scyther_1];
azumarill_1.lmatchups = [dragapult_3, dragapult_5, dragapult_6, darmanitan_galar_4, darmanitan_galar_5, weezing_galar_1, corviknight_1, corviknight_2, milotic_1, sylveon_1, sylveon_2, sylveon_3, sylveon_5, arcanine_2, rillaboom_1, rillaboom_2, rillaboom_3, gastrodon_2, rotom_heat_2, aromatisse_1, aromatisse_2, rotom_wash_1, rotom_wash_2, aegislash_2, gengar_1, gengar_2, eldegoss_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_2, corsola_1, corsola_2, corsola_3, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, dracozolt_1, dracozolt_2, steelix_2, snorlax_2, zeraora_1, zeraora_2, zeraora_3, zeraora_4, venusaur_1, pyukumuku_2, diggersby_1, gyarados_1, celebi_1, clefable_1, kyurem_1, type_null_1, butterfree_1, ninetales_1, roserade_1, rotom_mow_1, salazzle_1, wobbuffet_1, magnezone_1, porygonz_1, porygonz_2, chansey_1, porygon2_1, dragapult_7];
porygon2_1.lmatchups = [blastoise_1, dragapult_5, dragapult_6, corviknight_1, corviknight_2, sylveon_3, sylveon_4, sylveon_5, grimmsnarl_1, grimmsnarl_2, dracovish_1, rillaboom_2, haxorus_3, haxorus_4, indeedee_1, rotom_heat_2, rotom_heat_3, hydreigon_1, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_2, golisopod_2, togekiss_1, togekiss_2, gengar_1, toxapex_1, whimsicott_1, whimsicott_2, dracozolt_2, kommoo_1, kommoo_2, incineroar_1, zeraora_2, zeraora_3, zeraora_4, mandibuzz_1, venusaur_1, pyukumuku_1, gyarados_1, chandelure_1, celebi_1, gardevoir_1, clefable_1, darmanitan_1, hatterene_1, butterfree_1, rotom_mow_1, salazzle_1, porygonz_1, porygonz_2, chansey_1, dragapult_7, volcarona_3];
scyther_1.lmatchups = [dragapult_1, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, darmanitan_galar_5, corviknight_1, corviknight_2, sylveon_3, sylveon_4, sylveon_5, grimmsnarl_2, arcanine_1, arcanine_2, arcanine_3, gastrodon_1, gastrodon_2, rotom_heat_1, rotom_heat_2, rotom_heat_3, tyranitar_1, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_1, rotom_wash_2, togekiss_1, togekiss_2, eldegoss_1, alcremie_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, crustle_1, crustle_2, dracozolt_1, dracozolt_2, snorlax_1, snorlax_2, silvally_water_1, terrakion_1, incineroar_1, zeraora_1, zeraora_2, zeraora_3, zeraora_4, mandibuzz_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_1, pyukumuku_2, chandelure_1, durant_1, meowstic_1, meowstic_2, clefable_1, darmanitan_1, kyurem_2, type_null_1, ninetales_1, salazzle_1, chansey_1, porygon2_1];

//pokemon list
let pokemon_list = [dragapult_1, dragapult_2, dragapult_3, dragapult_4, dragapult_5, dragapult_6, dragapult_7, darmanitan_galar_1, darmanitan_galar_2, darmanitan_galar_3, darmanitan_galar_4, darmanitan_galar_5, weezing_galar_1, corviknight_1, corviknight_2, excadrill_1, excadrill_2, excadrill_3, milotic_1, sylveon_1, sylveon_2, sylveon_3, sylveon_4, sylveon_5, grimmsnarl_1, grimmsnarl_2, arcanine_1, arcanine_2, arcanine_3, duraludon_1, dracovish_1, dracovish_2, rillaboom_1, rillaboom_2, rillaboom_3, gastrodon_1, gastrodon_2, haxorus_1, haxorus_2, haxorus_3, haxorus_4, indeedee_1, rotom_heat_1, rotom_heat_2, rotom_heat_3, hydreigon_1, hydreigon_2, hydreigon_3, tyranitar_1, aromatisse_1, aromatisse_2, aromatisse_3, aromatisse_4, rotom_wash_1, rotom_wash_2, golisopod_1, golisopod_2, aegislash_1, aegislash_2, gengar_1, gengar_2, eldegoss_1, alcremie_1, centiskorch_1, toxapex_1, toxtricity_1, toxtricity_2, rhyperior_1, rhyperior_2, corsola_1, corsola_2, corsola_3, crustle_1, crustle_2, sawk_1, sawk_2, sawk_3, whimsicott_1, whimsicott_2, goodra_1, conkeldurr_1, conkeldurr_2, dracozolt_1, dracozolt_2, steelix_1, steelix_2, snorlax_1, snorlax_2, kommoo_1, kommoo_2, kommoo_3, silvally_water_1, terrakion_1, keldeo_1, incineroar_1, primarina_1, primarina_2, primarina_3, primarina_4, zeraora_1, zeraora_2, zeraora_3, zeraora_4, blastoise_1, mandibuzz_1, venusaur_1, avalugg_1, avalugg_2, hippowdon_1, pyukumuku_1, pyukumuku_2, diggersby_1, gyarados_1, chandelure_1, durant_1, meowstic_1, meowstic_2, celebi_1, gardevoir_1, clefable_1, darmanitan_1, kyurem_1, kyurem_2, type_null_1, hatterene_1, butterfree_1, ninetales_1, roserade_1, rotom_mow_1, salazzle_1, wobbuffet_1, magnezone_1, volcarona_1, volcarona_2, volcarona_3, porygonz_1, porygonz_2, chansey_1, urshifu_1, azumarill_1, porygon2_1, scyther_1];

//gen7 stuff
//all gyarados stuff
var gyarados_mega_g7 = new pokemon("gyarados_mega_g7", "Gyarados", "Gyaradosite", "Adamant", "248 HP / 44 Atk / 40 Def / 32 SpD / 144 Spe", "Intimidate", "Waterfall", "Dragon Dance", "Outrage", "Earthquake", "s");
var gyarados_mega_2_g7 = new pokemon("gyarados_mega_2_g7", "Gyarados", "Gyaradosite", "Adamant", "4 HP / 252 Atk / 252 Spe", "Intimidate", "Waterfall", "Dragon Dance", "Outrage", "Earthquake", "s");
var gyarados_mega_3_g7 = new pokemon("gyarados_mega_3_g7", "Gyarados", "Gyaradosite", "Jolly", "88 HP / 248 Atk / 172 Spe", "Intimidate", "Ice Fang", "Dragon Dance", "Taunt", "Earthquake", "s");
var gyarados_mega_4_g7 = new pokemon("gyarados_mega_4_g7", "Gyarados", "Gyaradosite", "Adamant", "248 HP / 12 Def / 32 SpD / 216 Spe", "Intimidate", "Taunt", "Waterfall", "Dragon Dance", "Outrage", "s");
var gyarados_mega_5_g7 = new pokemon("gyarados_mega_5_g7", "Gyarados", "Gyaradosite", "Adamant", "40 HP / 252 Atk / 216 Spe", "Intimidate", "Dragon Dance", "Crunch", "Outrage", "Waterfall", "s");
//all charizardx stuff
var charizard_mega_x_g7 = new pokemon("charizard_mega_x_g7", "Charizard-X", "Charizardite X", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Tough Claws", "Outrage", "Flare Blitz", "Dragon Dance", "Flame Charge", "s");
var charizard_mega_x_2_g7 = new pokemon("charizard_mega_x_2_g7", "Charizard-X", "Charizardite X", "Jolly", "232 HP / 232 SpD / 44 Spe", "Tough Claws", "Flame Charge", "Flare Blitz", "Outrage", "Will-O-Wisp", "s");
var charizard_mega_x_3_g7 = new pokemon("charizard_mega_x_3_g7", "Charizard-X", "Charizardite X", "Jolly", "64 HP / 228 Atk / 56 Def / 160 Spe", "Blaze", "Belly Drum", "Flare Blitz", "Outrage", "Flame Charge", "s");
var charizard_mega_x_4_g7 = new pokemon("charizard_mega_x_4_g7", "Charizard-X", "Charizardite X", "Jolly", "212 HP / 12 Atk / 176 SpD / 108 Spe", "Tough Claws", "Belly Drum", "Outrage", "Flare Blitz", "Flame Charge", "s");
//all charizardy stuff
var charizard_mega_y_g7 = new pokemon("charizard_mega_y_g7", "Charizard-Y", "Charizardite Y", "Timid", "252 SpA / 4 SpD / 252 Spe", "Drought", "Blast Burn", "Air Slash", "Solar Beam", "Flame Charge", "a+");
//all dnite stuff
var dragonite_1_g7 = new pokemon("dragonite_1_g7", "Dragonite", "Flyinium Z", "Adamant", "252 HP / 252 Atk / 4 SpD", "Multiscale", "Fly", "Earthquake", "Extreme Speed", "Dragon Dance", "s");
var dragonite_2_g7 = new pokemon("dragonite_2_g7", "Dragonite", "Flyinium Z", "Quiet", "240 HP / 252 SpA / 16 SpD", "Multiscale", "Hurricane", "Draco Meteor", "Fire Blast", "Extreme Speed", "s");
var dragonite_3_g7 = new pokemon("dragonite_3_g7", "Dragonite", "Dragonium Z", "Adamant", "192 HP / 120 Atk / 28 Def / 168 Spe", "Multiscale", "Outrage", "Dragon Dance", "Substitute", "Bulldoze", "s");
var dragonite_4_g7 = new pokemon("dragonite_4_g7", "Dragonite", "Dragonium Z", "Quiet", "240 HP / 252 SpA / 16 SpD", "Multiscale", "Draco Meteor", "Extreme Speed", "Earthquake", "Flamethrower", "s");
var dragonite_5_g7 = new pokemon("dragonite_5_g7", "Dragonite", "Choice Band", "Adamant", "180 HP / 150 Atk / 80 SpD / 100 Spe", "Multiscale", "Outrage", "Earthquake", "Superpower", "Fire Punch", "s");
var dragonite_6_g7 = new pokemon("dragonite_6_g7", "Dragonite", "Choice Scarf", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Multiscale", "Outrage", "Iron Head", "Fire Punch", "Earthquake", "s");
//all magearna stuff
var magearna_1_g7 = new pokemon("magearna_1_g7", "Magearna", "Fairium Z", "Bold", "248 HP / 20 SpA / 24 SpD / 216 Spe", "Soul Heart", "Fleur Cannon", "Calm Mind", "Iron Defense", "Pain Split", "s-");
var magearna_2_g7 = new pokemon("magearna_2_g7", "Magearna", "Choice Specs", "Modest", "248 HP / 28 Def / 200 SpA / 32 SpD", "Soul Heart", "Fleur Cannon", "Flash Cannon", "Thunderbolt", "Hidden Power Fire", "s-");
//all megagross stuff
var metagross_mega_1_g7 = new pokemon("metagross_mega_1_g7", "Metagross", "Metagrossite", "Impish", "252 HP / 152 Atk / 32 Def / 72 Spe", "Clear Body", "Thunder Punch", "Meteor Mash", "Earthquake", "Bullet Punch", "a+");
var metagross_mega_2_g7 = new pokemon("metagross_mega_2_g7", "Metagross", "Metagrossite", "Adamant", "252 HP / 84 Atk / 172 SpD", "Clear Body", "Meteor Mash", "Earthquake", "Zen Headbutt", "Bullet Punch", "a+");
var metagross_mega_3_g7 = new pokemon("metagross_mega_3_g7", "Metagross", "Metagrossite", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Clear Body", "Substitute", "Earthquake", "Ice Punch", "Meteor Mash", "a+");
var metagross_mega_4_g7 = new pokemon("metagross_mega_4_g7", "Metagross_Mega", "Metagrossite", "Impish", "252 HP / 80 Atk / 28 Def / 20 SpD / 128 Spe", "Clear Body", "Meteor Mash", "Thunder Punch", "Magnet Rise", "Earthquake", "a+");
//all pz stuff
var porygonz_1_g7 = new pokemon("porygonz_1_g7", "Porygon-Z", "Normalium Z", "Timid", "4 Def / 252 SpA / 252 Spe", "Adaptability", "Shadow Ball", "Hyper Beam", "Conversion", "Recover", "a+");
var porygonz_2_g7 = new pokemon("porygonz_2_g7", "Porygon-Z", "Choice Scarf", "Modest", "32 HP / 4 Def / 252 SpA / 220 Spe", "Adaptability", "Uproar", "Hyper Beam", "Ice Beam", "Shadow Ball", "a+");
var porygonz_3_g7 = new pokemon("porygonz_3_g7", "Porygon-Z", "Normalium Z", "Timid", "36 HP / 184 Def / 72 SpA / 216 Spe", "Adaptability", "Shadow Ball", "Conversion", "Hyper Beam", "Recover", "a+");
var porygonz_4_g7 = new pokemon("porygonz_4_g7", "Porygon-Z", "Normalium Z", "Timid", "156 HP / 108 Def / 24 SpA / 4 SpD / 216 Spe", "Adaptability", "Shadow Ball", "Conversion", "Hyper Beam", "Nasty Plot", "a+");
var porygonz_5_g7 = new pokemon("porygonz_5_g7", "Porygon-Z", "Choice Scarf", "Modest", "32 HP / 4 Def / 252 SpA / 220 Spe", "Adaptability", "Hyper Beam", "Uproar", "Hidden Power Fire", "Trick", "a+");
//all tapu lele stuff1
var tapu_lele_1_g7 = new pokemon("tapu_lele_1_g7", "Tapu Lele", "Psychium Z", "Modest", "248 HP / 88 Def / 28 SpD / 144 Spe", "Psychic Surge", "Moonblast", "Psyshock", "Reflect", "Calm Mind", "a+");
var tapu_lele_2_g7 = new pokemon("tapu_lele_2_g7", "Tapu Lele", "Psychium Z", "Timid", "4 HP / 252 SpA / 252 Spe", "Psychic Surge", "Reflect", "Moonblast", "Psychic", "Calm Mind", "a+");
var tapu_lele_3_g7 = new pokemon("tapu_lele_3_g7", "Tapu Lele", "Psychium Z", "Timid", "108 HP / 168 SpA / 232 Spe", "Psychic Surge", "Reflect", "Moonblast", "Psychic", "Calm Mind", "a+");
//all mega slowbro stuff
var slowbro_mega_1_g7 = new pokemon("slowbro_mega_1_g7", "Slowbro", "Slowbronite", "Calm", "252 HP / 4 Def / 252 SpD", "Oblivious", "Scald", "Calm Mind", "Iron Defense", "Slack Off", "a");
var slowbro_mega_2_g7 = new pokemon("slowbro_mega_2_g7", "Slowbro", "Slowbronite", "Calm", "252 HP/ 4 Def / 252 SpD", "Oblivious", "Scald", "Amnesia", "Iron Defense", "Slack Off", "a");
//all greninja stuff
var greninja_1_g7 = new pokemon("greninja_1_g7", "Greninja", "Choice Specs", "Timid", "4 Def / 252 SpA / 252 Spe", "Protean", "Hydro Cannon", "Dark Pulse", "Grass Knot", "Ice Beam", "a+");
var greninja_2_g7 = new pokemon("greninja_2_g7", "Greninja", "Petaya Berry", "Timid", "12 HP / 156 Def / 180 SpA / 160 Spe", "Torrent", "Substitute", "Hydro Cannon", "Work Up", "Taunt", "a+");
var greninja_4_g7 = new pokemon("greninja_4_g7", "Greninja", "Choice Specs", "Timid", "4 Def / 252 SpA / 252 Spe", "Protean", "Hydro Cannon", "Dark Pulse", "Hidden Power Fire", "Ice Beam", "a+");
var greninja_5_g7 = new pokemon("greninja_5_g7", "Greninja", "Choice Specs", "Modest", "252 SpA / 4 SpD / 252 Spe", "Protean", "Hydro Cannon", "Ice Beam", "Dark Pulse", "Hidden Power [Fire]", "a+");
var greninja_6_g7 = new pokemon("greninja_6_g7", "Greninja", "Choice Specs", "Timid", "4 Def / 252 SpA / 252 Spe", "Protean", "Hydro Cannon", "Dark Pulse", "Hidden Power [Ground]", "Ice Beam", "a+");
var greninja_7_g7 = new pokemon("greninja_7_g7", "Greninja", "Waterium Z", "Timid", "156 Def / 192 SpA / 160 Spe", "Torrent", "Hydro Cannon", "Substitute", "Work Up", "Taunt", "a+");
//all jumpluff stuff
var jumpluff_1_g7 = new pokemon("jumpluff_1_g7", "Jumpluff", "Grassium Z", "Timid", "252 Def / 4 SpD / 252 Spe", "Infiltrator", "Sleep Powder", "Substitute", "Infestation", "Leech Seed", "b+");
var jumpluff_2_g7 = new pokemon("jumpluff_2_g7", "Jumpluff", "Wide Lens", "Timid", "224 Def / 32 SpD / 252 Spe", "Infiltrator", "Sleep Powder", "Leech Seed", "Substitute", "Protect", "b+");
//all lando t stuff
var landorus_therian_1_g7 = new pokemon("landorus_therian_1_g7", "Landorus-Therian", "Groundium Z", "Adamant", "248 HP / 80 Def / 112 SpD / 68 Spe", "Intimidate", "Earthquake", "Rock Tomb", "Bulk Up", "Smack Down", "a-");
var landorus_therian_2_g7 = new pokemon("landorus_therian_2_g7", "Landorus-Therian", "Choice Scarf", "Jolly", "252 Atk / 8 Def / 248 Spe", "Intimidate", "Earthquake", "Superpower", "Rock Slide", "Fly", "a-");
var landorus_therian_3_g7 = new pokemon("landorus_therian_3_g7", "Landorus-Therian", "Flyinium Z", "Adamant", "52 HP / 244 Atk / 76 Def / 136 Spe", "Intimidate", "Fly", "Earthquake", "Swords Dance", "Substitute", "a-");
//all mega lop stuff
var lopunny_mega_1_g7 = new pokemon("lopunny_mega_1_g7", "Lopunny", "Lopunnite", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Scrappy", "Fake Out", "Giga Impact", "High Jump Kick", "Ice Punch", "b");
//all mew stuff
var mew_1_g7 = new pokemon("mew_1_g7", "Mew", "Mewnium Z", "Calm", "240 HP / 252 SpA / 16 SpD", "Synchronize", "Fake Out", "Nasty Plot", "Psychic", "Overheat", "a");
var mew_2_g7 = new pokemon("mew_2_g7", "Mew", "Kee Berry", "Timid", "184 HP / 72 SpD / 252 Spe", "Synchronize", "Taunt", "Amnesia", "Will-O-Wisp", "Soft-Boiled", "a");
//all meloetta stuff
var meloetta_1_g7 = new pokemon("meloetta_1_g7", "Meloetta", "Normalium Z", "Modest", "204 HP / 252 Def / 52 SpD", "Serene Grace", "Hyper Beam", "Calm Mind", "Psyshock", "Laser Focus", "a");
var meloetta_2_g7 = new pokemon("meloetta_2_g7", "Meloetta", "Normalium Z", "Modest", "248 HP / 208 Def / 20 SpA / 16 SpD / 16 Spe", "Serene Grace", "Celebrate", "Hyper Beam", "Uproar", "Laser Focus", "a");
//all magnezone stuff
var magnezone_1_g7 = new pokemon("magnezone_1_g7", "Magnezone", "Electrium Z", "Timid", "4 HP / 252 SpA / 252 Spe", "Sturdy", "Electroweb", "Zap Cannon", "Metal Sound", "Flash Cannon", "a-");
var magnezone_2_g7 = new pokemon("magnezone_2_g7", "Magnezone", "Electrium Z", "Modest", "80 HP / 252 SpA / 176 Spe", "Sturdy", "Metal Sound", "Zap Cannon", "Electroweb", "Protect", "a-");
var magnezone_3_g7 = new pokemon("magnezone_3_g7", "Magnezone", "Electrium Z", "Modest", "80 HP / 252 SpA / 176 Spe", "Sturdy", "Electroweb", "Zap Cannon", "Flash Cannon", "Metal Sound", "a-");
//all togekiss sets
var togekiss_1_g7 = new pokemon("togekiss_1_g7", "Togekiss", "Electrium Z", "Calm", "156 HP / 148 SpD / 204 Spe", "Serene Grace", "Thunder Wave", "Air Slash", "Roost", "Charm", "b+");
var togekiss_2_g7 = new pokemon("togekiss_2_g7", "Togekiss", "Fairium Z", "Bold", "248 HP / 176 Def / 24 SpA / 60 SpD", "Serene Grace", "Charm", "Roost", "Dazzling Gleam", "Nasty Plot", "b+");
//all aegislash stuff
var aegislash_1_g7 = new pokemon("aegislash_1_g7", "Aegislash", "Ghostium Z", "Quiet", "252 HP / 4 Def / 252 SpA", "Stance Change", "Shadow Ball", "King's Shield", "Shadow Sneak", "Metal Sound", "a-");
//all altaria mega stuff
var altaria_mega_1_g7 = new pokemon("altaria_mega_1_g7", "Altaria", "Altarianite", "Bold", "248 HP / 252 Def / 8 Spe", "Cloud Nine", "Cotton Guard", "Roost", "Hyper Voice", "Fire Blast", "b+");
var altaria_mega_2_g7 = new pokemon("altaria_mega_2_g7", "Altaria", "Altarianite", "Calm", "232 HP / 120 Def / 156 SpD", "Cloud Nine", "Cotton Guard", "Hyper Voice", "Roost", "Fire Blast", "b+");
//all donphan stuff
var donphan_1_g7 = new pokemon("donphan_1_g7", "Donphan", "Groundium Z", "Adamant", "248 HP / 252 Atk / 8 SpD", "Sturdy", "Earthquake", "Head Smash", "Ice Shard", "Counter", "b+");
var donphan_2_g7 = new pokemon("donphan_2_g7", "Donphan", "Choice Band", "Adamant", "252 Atk / 144 Def / 112 Spe", "Sturdy", "Earthquake", "Ice Shard", "Gunk Shot", "Fire Fang", "b+");
var donphan_3_g7 = new pokemon("donphan_3_g7", "Donphan", "Groundium Z", "Adamant", "252 Atk / 80 Def / 176 Spe", "Sturdy", "Earthquake", "Bulldoze", "Rock Tomb", "Ice Shard", "b+");
//all mega gardevoir stuff
var gardevoir_mega_1_g7 = new pokemon("gardevoir_mega_1_g7", "Gardevoir", "Gardevoirite", "Timid", "224 HP / 96 Def / 12 SpA / 176 Spe", "Trace", "Hyper Beam", "Calm Mind", "Will-O-Wisp", "Psyshock", "a");
var gardevoir_mega_2_g7 = new pokemon("gardevoir_mega_2_g7", "Gardevoir", "Gardevoirite", "Timid", "4 Def / 252 SpA / 252 Spe", "Trace", "Hyper Beam", "Will-O-Wisp", "Psyshock", "Calm Mind", "a");
//all genesect stuff
var genesect_1_g7 = new pokemon("genesect_1_g7", "Genesect", "Choice Specs", "Bold", "236 HP / 240 Def / 32 SpA", "Download", "Bug Buzz", "Flash Cannon", "Ice Beam", "Thunderbolt", "b+");
var genesect_2_g7 = new pokemon("genesect_2_g7", "Genesect", "Choice Scarf", "Modest", "20 HP / 224 SpA / 36 SpD / 228 Spe", "Download", "Thunderbolt", "Flamethrower", "Ice Beam", "Bug Buzz", "b+");
var genesect_3_g7 = new pokemon("genesect_3_g7", "Genesect", "Choice Specs", "Timid", "84 HP / 200 SpA / 224 Spe", "Download", "Ice Beam", "Bug Buzz", "Flamethrower", "Flash Cannon", "b+");
//all kommo-o stuff
var kommoo_1_g7 = new pokemon("kommoo_1_g7", "Kommo-o", "Kommonium Z", "Sassy", "240 HP / 28 SpA / 84 SpD / 156 Spe", "Soundproof", "Clanging Scales", "Close Combat", "Flamethrower", "Taunt", "a-");
//all naganadel stuff
var naganadel_1_g7 = new pokemon("naganadel_1_g7", "Naganadel", "Choice Specs", "Timid", "252 SpA / 4 SpD / 252 Spe", "Beast Boost", "Draco Meteor", "Sludge Wave", "Fire Blast", "Air Slash", "b");
//all primarina stuff
var primarina_1_g7 = new pokemon("primarina_1_g7", "Primarina", "Primarium Z", "Relaxed", "200 HP / 252 Def / 56 SpA", "Torrent", "Moonblast", "Sparkling Aria", "Aqua Jet", "Encore", "a-");
//all tapu fini stuff
var tapu_fini_1_g7 = new pokemon("tapu_fini_1_g7", "Tapu Fini", "Tapunium Z", "Bold", "228 HP / 96 Def / 68 SpA / 116 Spe", "Misty Surge", "Nature's Madness", "Taunt", "Brine", "Moonblast", "a-");
var tapu_fini_2_g7 = new pokemon("tapu_fini_2_g7", "Tapu Fini", "Waterium Z", "Bold", "248 HP / 128 Def / 52 SpA / 24 SpD / 56 Spe ", "Misty Surge", "Hydro Pump", "Rain Dance", "Calm Mind", "Moonblast", "a-");
//all mega ttar stuff
var tyranitar_mega_1_g7 = new pokemon("tyranitar_mega_1_g7", "Tyranitar", "Tyranitarite", "Adamant", "248 HP / 104 Atk / 72 Def / 64 SpD / 20 Spe", "Sand Stream", "Earthquake", "Rock Tomb", "Stone Edge", "Taunt", "b+");
//all mega venusaur stuff
var venusaur_mega_1_g7 = new pokemon("venusaur_mega_1_g7", "Venusaur", "Venusaurite", "Modest", "216 HP / 92 SpA / 44 SpD / 156 Spe", "Thick Fat", "Sleep Powder", "Sludge Bomb", "Synthesis", "Giga Drain", "b+");
var venusaur_mega_2_g7 = new pokemon("venusaur_mega_2_g7", "Venusaur", "Venusaurite", "Bold", "248 HP / 108 Def / 80 SpA / 72 SpD", "Thick Fat", "Leech Seed", "Sludge Bomb", "Charm", "Synthesis", "b+");
//all aggron/mega stuff
var aggron_mega_1_g7 = new pokemon("aggron_mega_1_g7", "Aggron", "Aggronite", "Brave", "252 HP / 252 Atk / 4 Def", "Sturdy", "Heavy Slam", "Head Smash", "Metal Burst", "Earthquake", "b");
//all celesteela stuff
var celesteela_1_g7 = new pokemon("celesteela_1_g7", "Celesteela", "Leftovers", "Relaxed", "248 HP / 252 Def / 8 SpD", "Beast Boost", "Heavy Slam", "Flamethrower", "Protect", "Leech Seed", "b+");
var celesteela_2_g7 = new pokemon("celesteela_2_g7", "Celesteela", "Steelium Z", "Bold", "216 HP / 248 Def / 44 SpA", "Beast Boost", "Metal Sound", "Flamethrower", "Giga Drain", "Flash Cannon", "b+");
//all chansey stuff
var chansey_1_g7 = new pokemon("chansey_1_g7", "Chansey", "Eviolite", "Bold", "248 HP / 252 Def / 8 SpD", "Serene Grace", "Charm", "Soft Boiled", "Charge Beam", "Toxic", "c+");
//all ferrothorn stuff
var ferrothorn_1_g7 = new pokemon("ferrothorn_1_g7", "Ferrothorn", "Leftovers", "Relaxed", "248 HP / 252 Def / 8 SpD", "Iron Barbs", "Leech Seed", "Protect", "Gyro Ball", "Power Whip", "b");
//all garchomp stuff
var garchomp_1_g7 = new pokemon("garchomp_1_g7", "Garchomp", "Groundium Z", "Jolly", "4 HP / 252 Atk / 252 Spe", "Rough Skin", "Earthquake", "Substitute", "Swords Dance", "Rock Tomb", "b+");
var garchomp_2_g7 = new pokemon("garchomp_2_g7", "Garchomp", "Choice Scarf", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Rough Skin", "Earthquake", "Outrage", "Stone Edge", "Poison Jab", "b+");
var garchomp_3_g7 = new pokemon("garchomp_3_g7", "Garchomp", "Choice Band", "Jolly", "4 HP / 252 Atk / 252 Spe", "Rough Skin", "Outrage", "Earthquake", "Fire Fang", "Poison Jab", "b+");
//all heatran stuff
var heatran_1_g7 = new pokemon("heatran_1_g7", "Heatran", "Air Balloon", "Modest", "96 HP / 248 SpA / 36 SpD / 128 Spe", "Flash Fire", "Overheat", "Flash Cannon", "Rock Tomb", "Earth Power", "b+");
var heatran_2_g7 = new pokemon("heatran_2_g7", "Heatran", "Grassium Z", "Modest", "72 HP / 252 SpA / 184 Spe", "Flash Fire", "Overheat", "Solar Beam", "Rock Tomb", "Earth Power", "b+");
var heatran_3_g7 = new pokemon("heatran_3_g7", "Heatran", "Air Balloon", "Modest", "104 HP / 252 SpA / 32 SpD / 120 Spe", "Flash Fire", "Overheat", "Ancient Power", "Flash Cannon", "Taunt", "b+");
//all kartana stuff
var kartana_1_g7 = new pokemon("kartana_1_g7", "Kartana", "Grassium Z", "Jolly", "252 Atk / 4 Def / 252 Spe", "Beast Boost", "Leaf Blade", "Swords Dance", "Sacred Sword", "Smart Strike", "b");
var kartana_2_g7 = new pokemon("kartana_2_g7", "Kartana", "Choice Band", "Jolly", "4 HP / 252 Atk / 252 Spe", "Beast Boost", "Giga Impact", "Leaf Blade", "Sacred Sword", "Smart Strike", "b");
var kartana_3_g7 = new pokemon("kartana_3_g7", "Kartana", "Grassium Z", "Jolly", "176 HP / 56 Atk / 24 Def / 252 Spe", "Beast Boost", "Iron Defense", "Synthesis", "Leaf Blade", "Swords Dance", "b");
//all mawile stuff
var mawile_mega_1_g7 = new pokemon("mawile_mega_1_g7", "Mawile", "Mawilite", "Adamant", "248 HP / 252 Atk / 8 SpD", "Intimidate", "Play Rough", "Swords Dance", "Sucker Punch", "Iron Head", "b+");
//all necrozma stuff
var necrozma_1_g7 = new pokemon("necrozma_1_g7", "Necrozma", "Choice Specs", "Modest", "252 HP / 16 Def / 228 SpA / 12 SpD", "Prism Armor", "Photon Geyser", "Prismatic Laser", "Heat Wave", "Signal Beam", "b");
var necrozma_2_g7 = new pokemon("necrozma_2_g7", "Necrozma", "Iapapa Berry", "Calm", "248 HP / 20 Def / 240 SpD", "Prism Armor", "Iron Defense", "Calm Mind", "Moonlight", "Stored Power", "b");
//all pinsir mega stuff
var pinser_mega_1_g7 = new pokemon("pinser_mega_1_g7", "Pinsir", "Pinsirite", "Jolly", "56 HP / 212 Atk / 240 Spe", "Hyper Cutter", "Swords Dance", "Giga Impact", "Earthquake", "Substitute", "b-");
//all sableye mega stuff
var sableye_mega_1_g7 = new pokemon("sableye_mega_1_g7", "Sableye", "Sablenite", "Bold", "248 HP / 48 Def / 212 SpD", "Prankster", "Snarl", "Will-O-Wisp", "Foul Play", "Recover", "b+");
var sableye_mega_2_g7 = new pokemon("sableye_mega_2_g7", "Sableye", "Sablenite", "Calm", "252 HP / 4 Def / 252 SpD", "Prankster", "Recover", "Foul Play", "Calm Mind", "Will-O-Wisp", "b+");
//all victini stuff
var victini_1_g7 = new pokemon("victini_1_g7", "Victini", "Choice Band", "Adamant", "108 HP / 212 Atk / 88 SpD / 100 Spe", "Victory Star", "V-create", "Zen Headbutt", "Flame Charge", "Bolt Strike", "b+");
var victini_2_g7 = new pokemon("victini_2_g7", "Victini", "Psychium Z", "Bold", "96 HP / 212 Def / 200 SpA", "Victory Star", "Psychic", "Glaciate", "Blue Flare", "Will-O-Wisp", "b+");
//all volcarona stuff
var volcarona_1_g7 = new pokemon("volcarona_1_g7", "Volcarona", "Buginium Z", "Timid", "52 Def / 224 SpA / 232 Spe", "Swarm", "Bug Buzz", "Overheat", "Substitute", "Quiver Dance", "b");
var volcarona_2_g7 = new pokemon("volcarona_2_g7", "Volcarona", "Buginium Z", "Calm", "240 HP / 32 Def / 216 SpD / 20 Spe", "Swarm", "Quiver Dance", "Roost", "Bug Buzz", "Flamethrower", "b");
//all zeraora stuff
var zeraora_1_g7 = new pokemon("zeraora_1_g7", "Zeraora", "Electrium Z", "Jolly", "184 Atk / 132 Def / 192 Spe", "Volt Absorb", "Plasma Fists", "Bulk Up", "Charge", "Taunt", "a");
var zeraora_2_g7 = new pokemon("zeraora_2_g7", "Zeraora", "Electrium Z", "Jolly", "48 HP / 252 Atk / 120 Def / 88 Spe", "Volt Absorb", "Plasma Fists", "Outrage", "Fake Out", "Charge", "a");
var zeraora_3_g7 = new pokemon("zeraora_3_g7", "Zeraora", "Electrium Z", "Hasty", "60 Atk / 168 SpA / 128 SpD / 152 Spe", "Volt Absorb", "Plasma Fists", "Fake Out", "Thunder", "Charge", "a");
var zeraora_4_g7 = new pokemon("zeraora_4_g7", "Zeraora", "Choice Band", "Adamant", "252 Atk / 32 Def / 224 Spe", "Volt Absorb", "Plasma Fists", "Iron Tail", "Fire Punch", "Outrage", "a");
//all archeops stuff
var archeops_1_g7 = new pokemon("archeops_1_g7", "Archeops", "Choice Band", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Defeatist", "Head Smash", "Outrage", "Earthquake", "Fly", "b-");
//all blastoise mega stuff
var blastoise_mega_1_g7 = new pokemon("blastoise_mega_1_g7", "Blastoise", "Blastoisinite", "Modest", "128 HP / 248 SpA / 20 SpD / 112 Spe", "Mega Launcher", "Fake Out", "Hydro Cannon", "Dark Pulse", "Ice Beam", "c");
//all blaziken/mega stuff
var blaziken_mega_1_g7 = new pokemon("blaziken_mega_1_g7", "Blaziken", "Blazikenite", "Adamant", "4 HP / 252 Atk / 252 Spe", "Speed Boost", "Protect", "Flare Blitz", "High Jump Kick", "Stone Edge", "b");
//all crustle stuff
var crustle_1_g7 = new pokemon("crustle_1_g7", "Crustle", "Rockium Z", "Adamant", "160 HP / 144 Atk / 204 Spe", "Sturdy", "Rock Wrecker", "Rock Blast", "Counter", "Shell Smash", "b");
//all deoxys S stuff
var deoxys_s_1_g7 = new pokemon("deoxys_s_1_g7", "Deoxys-Speed", "Choice Specs", "Modest", "252 SpA / 4 SpD / 252 Spe", "Pressure", "Psycho Boost", "Ice Beam", "Thunderbolt", "Focus Blast", "b-");
var deoxys_s_2_g7 = new pokemon("deoxys_s_2_g7", "Deoxys-Speed", "Psychium Z", "Timid", "100 HP / 164 SpA / 4 SpD / 240 Spe", "Pressure", "Recover", "Reflect", "Light Screen", "Psycho Boost", "b-");
//all mega diancie stuff
var diancie_mega_1_g7 = new pokemon("diancie_mega_1_g7", "Diancie", "Diancite", "Hasty", "4 Atk / 252 SpA / 252 Spe", "Clear body", "Diamond Storm", "Moonblast", "Earth Power", "Magnet Rise", "b-");
//all durant stuff
var durant_1_g7 = new pokemon("durant_1_g7", "Durant", "Choice Band", "Jolly", "24 HP / 232 Atk / 252 Spe", "Hustle", "Iron Head", "X-Scissor", "Stone Edge", "Superpower", "c+");
//all golem stuff
var golem_1_g7 = new pokemon("golem_1_g7", "Golem", "Rockium Z", "Adamant", "252 Atk / 4 Def / 252 Spe", "Sturdy", "Stone Edge", "Earthquake", "Counter", "Sucker Punch", "b-");
//all haxorus stuff
var haxorus_1_g7 = new pokemon("haxorus_1_g7", "Haxorus", "Choice Scarf", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Mold Breaker", "Iron Tail", "Outrage", "Earthquake", "Rock slide", "b");
var haxorus_2_g7 = new pokemon("haxorus_2_g7", "Haxorus", "Choice Band", "Jolly", "8 HP / 252 Atk / 8 Def / 240 Spe", "Mold Breaker", "Earthquake", "Iron Tail", "Superpower", "Outrage", "b");
//all heracross mega stuff
var heracross_mega_1_g7 = new pokemon("heracross_mega_1_g7", "Heracross", "Heracronite", "Adamant", "252 HP / 252 Atk / 4 SpD", "Guts", "Pin Missile", "Rock Blast", "Bullet Seed", "Close Combat", "c+");
//all hoopau stuff
var hoopau_1_g7 = new pokemon("hoopau_1_g7", "Hoopa-Unbound", "Darkinium Z", "Quiet", "252 HP / 236 Def / 20 SpA", "Magician", "Dark Pulse", "Hyperspace Fury", "Hyperspace Hole", "Thunderbolt", "b");
var hoopau_2_g7 = new pokemon("hoopau_2_g7", "Hoopa-Unbound", "Choice Band", "Adamant", "88 HP / 148 Atk / 92 Def / 180 Spe", "Magician", "Gunk Shot", "Hyperspace Fury", "Zen Headbutt", "Fire Punch", "b");
var hoopau_3_g7 = new pokemon("hoopau_3_g7", "Hoopa-Unbound", "Choice Specs", "Modest", "88 HP / 92 Def / 148 SpA / 180 Spe", "Magician", "Psyshock", "Dark Pulse", "Focus Blast", "Thunderbolt", "b");
//all incineroar stuff
var incineroar_1_g7 = new pokemon("incineroar_1_g7", "Incineroar", "Incinium Z", "Adamant", "168 HP / 112 Atk / 228 SpD", "Intimidate", "Darkest Lariat", "Flare Blitz", "Fake Out", "Bulk Up", "b");
//ll krookodile stuff
var krookodile_1_g7 = new pokemon("krookodile_1_g7", "Krookodile", "Groundium Z", "Adamant", "152 HP / 56 Atk / 244 Def / 56 Spe", "Intimidate", "Earthquake", "Rock Tomb", "Taunt", "Bulk Up", "b");
//all kyurem stuff
var kyurem_1_g7 = new pokemon("kyurem_1_g7", "Kyurem", "Groundium Z", "Bold", "224 HP / 136 Def / 148 SpD", "Pressure", "Noble Roar", "Roost", "Ice Beam", "Earth Power", "b-");
//all clefable stuff
var clefable_1_g7 = new pokemon("clefable_1_g7", "Clefable", "Psychium Z", "Bold", "248 HP / 236 Def / 24 SpD", "Unaware", "Magic Coat", "Moonblast", "Reflect", "Moonlight", "b+");
//all manaphy stuff
var manaphy_1_g7 = new pokemon("manaphy_1_g7", "Manaphy", "Waterium Z", "Modest", "68 HP / 252 SpA / 4 SpD / 184 Spe", "Hydration", "Surf", "Tail Glow", "Calm Mind", "Rain Dance", "b-");
//all medicham mega stuff
var medicham_mega_1_g7 = new pokemon("medicham_mega_1_g7", "Medicham", "Medichamite", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Pure Power", "Fake Out", "High Jump Kick", "Zen Headbutt", "Ice Punch", "b-");
//all sawk sets
var sawk_1_g7 = new pokemon("sawk_1_g7", "Sawk", "Choice Scarf", "Adamant", "252 Atk / 4 SpD / 252 Spe", "Sturdy", "Close Combat", "Poison Jab", "Ice Punch", "Stone Edge", "b");
//all blacephalon sets
var blacephalon_1_g7 = new pokemon("blacephalon_1_g7", "Blacephalon", "Ghostium Z", "Timid","16 HP / 252 SpA / 240 Spe", "Beast Boost", "Shadow Ball", "Calm Mind", "Mind Blown", "Taunt", "c+");
//illumise <3
var illumise_1_g7 = new pokemon("illumise_1_g7", "Illumise", "Fairium Z", "Bold", "252 HP / 252 Def / 4 SpD", "Prankster", "Charm", "Infestation", "Encore", "Roost", "c");
//vivillon
var vivillon_1_g7 = new pokemon("vivillon_1_g7", "Vivillon", "Leftovers", "Timid", "4 Def / 252 SpA / 252 Spe", "Compound Eyes", "Substitute", "Sleep Powder", "Quiver Dance", "Hurricane", "b-");
//all smeargle sets
var smeargle_1_g7 = new pokemon("smeargle_1_g7", "Smeargle", "Normalium Z", "Timid", "252 HP / 4 Def / 252 Spe", "Own Tempo", "Substitute", "Spore", "Imprison", "Transform", "c+");
//all aron sets
var aron_1_g7 = new pokemon("aron_1_g7", "Aron", "Shell Bell", "Brave", "4 HP", "Sturdy", "Endeavor", "Toxic", "Sandstorm", "Metal Burst", "d");
//all shedinja sets
var shedinja_1_g7 = new pokemon("shedinja_1_g7", "Shedinja", "Ghostium Z", "Adamant", "4 HP / 252 Atk / 252 Spe", "Wonder Guard", "Phantom Force", "Will-O-Wisp", "X-Scissor", "Swords Dance", "d");
//all raikou sets
var raikou_1_g7 = new pokemon("raikou_1_g7", "Raikou", "Electrium Z", "Timid", "4 HP / 252 SpA / 252 Spe", "Inner Focus", "Zap Cannon", "Hidden Power Fire", "Laser Focus", "Calm Mind", "c+");
//all maudino sets
var audino_mega_1_g7 = new pokemon("audino_mega_1_g7", "Audino", "Audinite", "Calm", "252 HP / 88 Def / 168 SpD", "Klutz", "Amnesia", "Baby Doll Eyes", "Lucky Chant", "Rest", "c+");
//all salazzle sets
var salazzle_1_g7 = new pokemon("salazzle_1_g7", "Salazzle", "Poisonium Z", "Timid", "252 SpA / 4 SpD / 252 Spe", "Oblivious", "Sludge Wave", "Overheat", "Fake Out", "Taunt", "c-");
//all darmanitan sets
var darmanitan_1_g7 = new pokemon("darmanitan_1_g7", "Darmanitan", "Choice Scarf", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Sheer Force", "Flare Blitz", "Earthquake", "Rock Slide", "Superpower", "c");
//all whimsicott sets
var whimsicott_1_g7 = new pokemon("whimsicott_1_g7", "Whimsicott", "Babiri Berry", "Calm", "88 HP / 228 Def / 192 SpD", "Prankster", "Taunt", "Protect", "Leech Seed", "Substitute", "b");
//all terrakion sets
var terrakion_1_g7 = new pokemon("terrakion_1_g7", "Terrakion", "Rockium Z", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Justified", "Stone Edge", "Close Combat", "Taunt", "Swords Dance", "c+");
//all umbreon sets
var umbreon_1_g7 = new pokemon("umbreon_1_g7", "Umbreon", "Fairium Z", "Calm", "248 HP / 100 Def / 160 SpD", "Synchronize", "Charm", "Moonlight", "Foul Play", "Snarl", "c+");
//all pheromosa sets
var pheromosa_2_g7 = new pokemon("pheromosa_2_g7", "Pheromosa", "Choice Band", "Naive", "252 Atk / 4 SpA / 252 Spe", "Beast Boost", "High Jump Kick", "Double Kick", "Giga Impact", "Ice Beam", "b");
var pheromosa_3_g7 = new pokemon("pheromosa_3_g7", "Pheromosa", "Choice Specs", "Timid", "252 SpA / 4 SpD / 252 Spe", "Beast Boost", "Hidden Power Rock", "Focus Blast", "Bug Buzz", "Ice Beam", "b");
//all zapdos sets
var zapdos_1_g7 = new pokemon("zapdos_1_g7", "Zapdos", "Electrium Z", "Calm", "248 HP / 132 Def / 120 SpD / 8 Spe", "Pressure", "Roost", "Substitute", "Thunder", "Toxic", "b-");
//all porygon2 sets
var porygon2_1_g7 = new pokemon("porygon2_1_g7", "Porygon2", "Eviolite", "Calm", "248 HP / 176 Def / 84 SpD", "Analytic", "Recover", "Ice Beam", "Foul Play", "Thunderbolt", "b");
//all pyukumuku sets
var pyukumuku_1_g7 = new pokemon("pyukumuku_1_g7", "Pyukumuku", "Psychium Z", "Calm", "248 HP / 124 Def / 136 SpD", "Unaware", "Light Screen", "Recover", "Toxic", "Soak", "c");
//all araquanid sets
var araquanid_1_g7 = new pokemon("araquanid_1_g7", "Araquanid", "Waterium Z", "Adamant", "192 HP / 248 Atk / 68 SpD", "Water Bubble", "Liquidation", "Mirror Coat", "Laser Focus", "Toxic", "c+");
//all salamence sets
var salamence_1_g7 = new pokemon("salamence_1_g7", "Salamence", "Dragonium Z", "Impish", "36 HP / 28 Atk / 236 Def / 208 Spe", "Intimidate", "Iron Defense", "Roost", "Dragon Dance", "Outrage", "c+");
//all swampert sets
var swampert_mega_1_g7 = new pokemon("swampert_mega_1_g7", "Swampert", "Swampertite", "Brave", "168 HP / 252 Atk / 36 SpA / 52 SpD", "Torrent", "Yawn", "Protect", "Earthquake", "Ice Beam", "b-");
//all carracosta sets
var carracosta_1_g7 = new pokemon("carracosta_1_g7", "Carracosta", "Waterium Z", "Naive", "16 Atk / 252 SpA / 240 Spe", "Sturdy", "Stone Edge", "Shell Smash", "Hydro Pump", "Aqua Jet", "b-");
//all gallade sets
var gallade_mega_1_g7 = new pokemon("gallade_mega_1_g7", "Gallade", "Galladite", "Jolly", "16 HP / 192 Atk / 108 Def / 192 Spe", "Justified", "Bulk Up", "Close Combat", "Rock Tomb", "Will-O-Wisp", "c+");
//all weavile sets
var weavile_1_g7 = new pokemon("weavile_1_g7", "Weavile", "Darkinium Z", "Adamant", "16 HP / 196 Atk / 60 Def / 236 Spe", "Pressure", "Foul Play", "Fake Out", "Icicle Crash", "Taunt", "c-");
//all infernape sets
var infernape_1_g7 = new pokemon("infernape_1_g7", "Infernape", "Petaya Berry", "Hasty", "4 Atk / 252 SpA / 252 Spe", "Blaze", "Fake Out", "Substitute", "Blast Burn", "Focus Blast", "c");
//all type null sets
var type_null_1_g7 = new pokemon("type_null_1_g7", "Type: Null", "Eviolite", "Impish", "248 HP / 196 Def / 64 SpD", "Battle Armor", "Iron Defense", "Confide", "Rest", "Flame Charge", "b");
//all vaporeon sets
var vaporeon_1_g7 = new pokemon("vaporeon_1_g7", "Vaporeon", "Waterium Z", "Modest", "168 HP / 200 Def / 116 SpA / 24 SpD", "Water Absorb", "Fake Tears", "Yawn", "Protect", "Hydro Pump", "c");
//all entei sets
var entei_1_g7 = new pokemon("entei_1_g7", "Entei", "Rockium Z", "Adamant", "248 HP / 8 Atk / 44 Def / 208 SpD", "Pressure", "Extreme Speed", "Stone Edge", "Sacred Fire", "Laser Focus", "c+");
//all slaking sets
var slaking_1_g7 = new pokemon("slaking_1_g7", "Slaking", "Choice Band", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Truant", "Giga Impact", "Fire Punch", "Play Rough", "Earthquake", "c+");
//all tapu bulu sets
var tapu_bulu_1_g7 = new pokemon("tapu_bulu_1_g7", "Tapu Bulu", "Grassium Z", "Adamant", "240 HP / 8 Atk / 124 SpD / 136 Spe", "Grassy Surge", "Wood Hammer", "Taunt", "Swords Dance", "Rock Tomb", "b-");
//all talonflame sets
var talonflame_1_g7 = new pokemon("talonflame_1_g7", "Talonflame", "Flyinium Z", "Jolly", "176 HP / 160 Atk / 124 Def / 48 Spe", "Gale Wings", "Brave Bird", "Swords Dance", "Flare Blitz", "Taunt", "c");
//all nihilego sets
var nihilego_1_g7 = new pokemon("nihilego_1_g7", "Nihilego", "Rockium_Z", "Timid", "16 HP / 252 SpA / 240 Spe", "Beast Boost", "Power Gem", "Acid Spray", "Dazzling Gleam", "Sludge Wave", "c+");
//all volcanion sets
var volcanion_1_g7 = new pokemon("volcanion_1_g7", "Volcanion", "Choice Specs", "Modest", "8 HP / 252 SpA / 248 Spe", "Water Absorb", "Overheat", "Steam Eruption", "Sludge Wave", "Focus Blast", "c");
//all rotom-heat sets
var rotom_heat_1_g7 = new pokemon("rotom_heat_1_g7", "Rotom-Heat", "Electrium Z", "Timid", "36 HP / 252 SpA / 4 SpD / 216 Spe", "Levitate", "Thunder", "Overheat", "Charge", "Electroweb", "c+");
//all registeel sets
var registeel_1_g7 = new pokemon("registeel_1_g7", "Registeel", "Leftovers", "Calm", "252 HP / 60 Def / 196 SpD", "Clear Body", "Iron Defense", "Amnesia", "Seismic Toss", "Rest", "b");
var registeel_2_g7 = new pokemon("registeel_2_g7", "Registeel", "Leftovers", "Calm", "252 HP / 60 Def / 196 SpD", "Clear Body", "Seismic Toss", "Counter", "Amnesia", "Rest", "b");
//all diggersby sets
var diggersby_1_g7 = new pokemon("diggersby_1_g7", "Diggersby", "Choice Band", "Adamant", "252 Atk / 4 SpD / 252 Spe", "Huge Power", "Giga Impact", "Earthquake", "Ice Punch", "Fire Punch", "c");
//all serperior sets
var serperior_1_g7 = new pokemon("serperior_1_g7", "Serperior", "Leftovers", "Timid", "252 HP / 4 SpA / 252 Spe", "Contrary", "Leaf Storm", "Protect", "Leech Seed", "Substitute", "b+");
//all lucario sets
var lucario_mega_1_g7 = new pokemon("lucario_mega_1_g7", "Lucario", "Lucarionite", "Jolly", "8 HP / 252 Atk / 8 Def / 240 Spe", "Adaptability", "Reversal", "Meteor Mash", "Substitute", "Swords Dance", "c");

//matchup lists
gyarados_mega_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, gallade_mega_1_g7, salamence_1_g7, pyukumuku_1_g7, umbreon_1_g7, magearna_2_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, altaria_mega_2_g7, smeargle_1_g7, kartana_2_g7, tapu_fini_2_g7, heracross_mega_1_g7, deoxys_s_1_g7, zeraora_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, kartana_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, kommoo_1_g7, genesect_1_g7, gardevoir_mega_1_g7, charizard_mega_y_g7, magearna_1_g7, jumpluff_1_g7, slowbro_mega_1_g7, metagross_mega_1_g7, greninja_1_g7, tapu_lele_1_g7, magnezone_1_g7, altaria_mega_1_g7, clefable_1_g7, porygonz_2_g7, vivillon_1_g7,porygonz_3_g7, zeraora_2_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, tapu_bulu_1_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, serperior_1_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, tapu_lele_3_g7];
gyarados_mega_2_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, venusaur_mega_2_g7, gallade_mega_1_g7, salamence_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, altaria_mega_2_g7, genesect_2_g7, smeargle_1_g7, kartana_2_g7, tapu_fini_2_g7, heracross_mega_1_g7, zeraora_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, kartana_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, kommoo_1_g7, genesect_1_g7, gardevoir_mega_1_g7, magearna_1_g7, jumpluff_1_g7, slowbro_mega_1_g7, metagross_mega_1_g7, greninja_1_g7, tapu_lele_1_g7, altaria_mega_1_g7, clefable_1_g7, porygonz_2_g7, vivillon_1_g7,porygonz_3_g7, zeraora_2_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, tapu_bulu_1_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, serperior_1_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, tapu_lele_3_g7, porygonz_5_g7];
gyarados_mega_3_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, gallade_mega_1_g7, salamence_1_g7, araquanid_1_g7, porygon2_1_g7, umbreon_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, altaria_mega_2_g7, genesect_2_g7, smeargle_1_g7, kartana_2_g7, tapu_fini_2_g7, hoopau_1_g7, heracross_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, zeraora_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, kartana_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, kommoo_1_g7, genesect_1_g7, gardevoir_mega_1_g7, charizard_mega_y_g7, gyarados_mega_g7, gyarados_mega_2_g7, magearna_1_g7, slowbro_mega_1_g7, metagross_mega_1_g7, porygonz_1_g7, tapu_lele_1_g7, meloetta_1_g7, altaria_mega_1_g7, clefable_1_g7, porygonz_2_g7, gyarados_mega_4_g7, porygonz_3_g7, zeraora_2_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, slaking_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, serperior_1_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, tapu_lele_3_g7, porygonz_5_g7];
gyarados_mega_4_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, venusaur_mega_2_g7, gallade_mega_1_g7, salamence_1_g7, porygon2_1_g7, umbreon_1_g7, magearna_2_g7, raikou_1_g7, mew_2_g7, altaria_mega_2_g7, metagross_mega_1_g7, magearna_1_g7, kommoo_1_g7, genesect_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, gardevoir_mega_1_g7, altaria_mega_1_g7, magnezone_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, zeraora_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, heracross_mega_1_g7, clefable_1_g7, smeargle_1_g7, porygonz_3_g7, zeraora_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, tapu_bulu_1_g7, landorus_therian_3_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, tapu_lele_3_g7];
gyarados_mega_5_g7.lmatchups = [porygonz_2_g7, togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_4_g7, metagross_mega_1_g7, magearna_1_g7, kommoo_1_g7, genesect_1_g7, jumpluff_1_g7,tapu_lele_1_g7, gardevoir_mega_1_g7, altaria_mega_2_g7, altaria_mega_1_g7, magnezone_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, smeargle_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, zeraora_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, clefable_1_g7, vivillon_1_g7, magearna_2_g7, umbreon_1_g7, porygon2_1_g7, salamence_1_g7, gallade_mega_1_g7, venusaur_mega_2_g7, porygonz_3_g7, zeraora_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, tapu_bulu_1_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, tapu_lele_3_g7, porygonz_5_g7];
kyurem_1_g7.lmatchups = [celesteela_2_g7, gyarados_mega_5_g7, dragonite_3_g7, carracosta_1_g7, deoxys_s_2_g7, salamence_1_g7, hoopau_2_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, pheromosa_2_g7, terrakion_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, smeargle_1_g7, kartana_2_g7, tapu_fini_2_g7, illumise_1_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, heracross_mega_1_g7, durant_1_g7, blaziken_mega_1_g7, crustle_1_g7, jumpluff_1_g7, archeops_1_g7, celesteela_1_g7, mawile_mega_1_g7, pinser_mega_1_g7, chansey_1_g7, tyranitar_mega_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, gyarados_mega_g7, kommoo_1_g7, naganadel_1_g7, gyarados_mega_2_g7, lopunny_mega_1_g7, mew_1_g7, meloetta_1_g7, magnezone_1_g7, gardevoir_mega_1_g7, genesect_1_g7, aegislash_1_g7, slowbro_mega_1_g7, magnezone_1_g7, gyarados_mega_3_g7, porygonz_1_g7, tapu_lele_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, vivillon_1_g7, charizard_mega_x_3_g7, type_null_1_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, charizard_mega_x_4_g7, genesect_3_g7, nihilego_1_g7, metagross_mega_3_g7, dragonite_5_g7, porygonz_4_g7, hoopau_3_g7, registeel_1_g7, metagross_mega_4_g7, lucario_mega_1_g7, dragonite_6_g7, tapu_lele_3_g7, registeel_2_g7];
naganadel_1_g7.lmatchups = [landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, garchomp_2_g7, magearna_2_g7, darmanitan_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, aron_1_g7, heatran_2_g7, victini_2_g7, dragonite_2_g7, sawk_1_g7, incineroar_1_g7, hoopau_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, blastoise_mega_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, donphan_1_g7, aegislash_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_2_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_2_g7, slowbro_mega_1_g7, greninja_1_g7, lopunny_mega_1_g7, mew_1_g7, meloetta_1_g7, porygonz_2_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, vaporeon_1_g7, entei_1_g7, charizard_mega_x_4_g7, nihilego_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
metagross_mega_1_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, gallade_mega_1_g7, swampert_mega_1_g7, volcarona_2_g7, salamence_1_g7, hoopau_2_g7, pyukumuku_1_g7, umbreon_1_g7, garchomp_2_g7, darmanitan_1_g7, salazzle_1_g7, slowbro_mega_2_g7, mew_2_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, blacephalon_1_g7, greninja_2_g7, dragonite_2_g7, medicham_mega_1_g7, manaphy_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, blaziken_mega_1_g7, victini_1_g7, sableye_mega_1_g7, heatran_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, kommoo_1_g7, genesect_1_g7, aegislash_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, slowbro_mega_1_g7,jumpluff_1_g7, porygonz_1_g7, landorus_therian_1_g7, donphan_1_g7, volcarona_1_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, garchomp_3_g7, jumpluff_2_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, metagross_mega_4_g7, zapdos_1_g7, donphan_3_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
metagross_mega_2_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, gallade_mega_1_g7, swampert_mega_1_g7, donphan_2_g7, volcarona_2_g7, salamence_1_g7, hoopau_2_g7, pyukumuku_1_g7, umbreon_1_g7, garchomp_2_g7, darmanitan_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, mew_2_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, blacephalon_1_g7, victini_2_g7, greninja_2_g7, manaphy_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, blaziken_mega_1_g7, blastoise_mega_1_g7, victini_1_g7, sableye_mega_1_g7, metagross_mega_1_g7, heatran_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, primarina_1_g7, genesect_1_g7, aegislash_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, slowbro_mega_1_g7,jumpluff_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, porygonz_1_g7, landorus_therian_1_g7, donphan_1_g7, volcarona_1_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, metagross_mega_4_g7, donphan_3_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
metagross_mega_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, metagross_mega_1_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, manaphy_1_g7, genesect_1_g7, genesect_2_g7, genesect_3_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, porygonz_2_g7, porygonz_3_g7, donphan_1_g7, donphan_2_g7, magnezone_2_g7, lopunny_mega_1_g7, heatran_1_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, blastoise_mega_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, necrozma_1_g7, necrozma_2_g7, blacephalon_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, golem_1_g7, durant_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, umbreon_1_g7, porygon2_1_g7, araquanid_1_g7, swampert_mega_1_g7, weavile_1_g7, type_null_1_g7, talonflame_1_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, greninja_7_g7, registeel_2_g7];
metagross_mega_4_g7.lmatchups = [magearna_1_g7, dragonite_2_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_1_g7, genesect_2_g7, genesect_3_g7, landorus_therian_1_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_2_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, porygonz_1_g7, porygonz_3_g7, porygonz_4_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, aron_1_g7, mew_2_g7, heatran_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_2_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, necrozma_2_g7, blacephalon_1_g7, raikou_1_g7, kartana_2_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, hoopau_3_g7, golem_1_g7, blaziken_mega_1_g7, illumise_1_g7, vivillon_1_g7, shedinja_1_g7, darmanitan_1_g7, umbreon_1_g7, porygon2_1_g7, salamence_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, weavile_1_g7, infernape_1_g7, type_null_1_g7, vaporeon_1_g7, volcanion_1_g7, rotom_heat_1_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, zapdos_1_g7, lucario_mega_1_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
magearna_1_g7.lmatchups = [celesteela_2_g7, greninja_4_g7, carracosta_1_g7, volcarona_2_g7, pyukumuku_1_g7, whimsicott_1_g7, darmanitan_1_g7, salazzle_1_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, greninja_2_g7, manaphy_1_g7, kyurem_1_g7, krookodile_1_g7, blaziken_mega_1_g7, victini_1_g7, heatran_1_g7, garchomp_1_g7, aegislash_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, jumpluff_1_g7,landorus_therian_1_g7, magnezone_1_g7, volcarona_1_g7, vivillon_1_g7, charizard_mega_x_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, garchomp_3_g7, jumpluff_2_g7, entei_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, metagross_mega_3_g7, volcanion_1_g7, dragonite_5_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, heatran_3_g7, registeel_2_g7];
magearna_2_g7.lmatchups = [greninja_4_g7, audino_mega_1_g7, venusaur_mega_2_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, araquanid_1_g7, porygon2_1_g7, greninja_2_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, landorus_therian_1_g7, jumpluff_1_g7,donphan_1_g7, magnezone_1_g7, meloetta_1_g7, mew_1_g7, mew_2_g7, heatran_1_g7, heatran_2_g7, chansey_1_g7, aggron_mega_1_g7, smeargle_1_g7, tapu_fini_1_g7, zeraora_1_g7, volcarona_1_g7, victini_1_g7, victini_2_g7, blacephalon_1_g7, raikou_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, golem_1_g7, sawk_1_g7, blaziken_mega_1_g7, vivillon_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, charizard_mega_x_4_g7, greninja_5_g7, metagross_mega_3_g7, volcanion_1_g7, dragonite_5_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, heatran_3_g7, registeel_2_g7];
dragonite_1_g7.lmatchups = [togekiss_1_g7, togekiss_2_g7, celesteela_2_g7, gyarados_mega_5_g7, dragonite_3_g7, swampert_mega_1_g7, salamence_1_g7, haxorus_2_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, aron_1_g7, smeargle_1_g7, victini_2_g7, dragonite_2_g7, illumise_1_g7, medicham_mega_1_g7, kyurem_1_g7, incineroar_1_g7, haxorus_1_g7, blastoise_mega_1_g7, archeops_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, genesect_1_g7, gardevoir_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_2_g7, magearna_1_g7, jumpluff_1_g7, lopunny_mega_1_g7, slowbro_mega_1_g7,landorus_therian_1_g7, metagross_mega_1_g7, tapu_lele_1_g7, altaria_mega_1_g7, donphan_1_g7, clefable_1_g7, weavile_1_g7, necrozma_2_g7, type_null_1_g7, gardevoir_mega_2_g7, jumpluff_2_g7, greninja_5_g7, metagross_mega_3_g7, dragonite_5_g7, sableye_mega_2_g7, serperior_1_g7, metagross_mega_4_g7, zapdos_1_g7, dragonite_6_g7, tapu_lele_3_g7];
dragonite_2_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, swampert_mega_1_g7, deoxys_s_2_g7, haxorus_2_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, aron_1_g7, smeargle_1_g7, tapu_fini_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, kyurem_1_g7, magearna_1_g7, jumpluff_1_g7, greninja_1_g7, medicham_mega_1_g7, slowbro_mega_1_g7, tapu_lele_1_g7, porygonz_1_g7, gardevoir_mega_1_g7, altaria_mega_1_g7, meloetta_1_g7, mew_1_g7, lopunny_mega_1_g7, heatran_1_g7, chansey_1_g7, celesteela_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, sableye_mega_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, clefable_1_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, entei_1_g7, greninja_5_g7, metagross_mega_3_g7, dragonite_5_g7, sableye_mega_2_g7, registeel_1_g7, zapdos_1_g7, dragonite_6_g7, tapu_lele_3_g7, registeel_2_g7];
dragonite_3_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, genesect_1_g7, genesect_2_g7, landorus_therian_1_g7, jumpluff_1_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, gardevoir_mega_1_g7, donphan_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, lopunny_mega_1_g7, ferrothorn_1_g7, aggron_mega_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, vivillon_1_g7, shedinja_1_g7, whimsicott_1_g7, magearna_2_g7, umbreon_1_g7, porygon2_1_g7, haxorus_2_g7, donphan_2_g7, weavile_1_g7, necrozma_2_g7, type_null_1_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, tapu_bulu_1_g7, genesect_3_g7, greninja_5_g7, metagross_mega_3_g7, greninja_6_g7, sableye_mega_2_g7, registeel_1_g7, metagross_mega_4_g7, kartana_3_g7, tapu_lele_3_g7];
dragonite_4_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, gyarados_mega_5_g7, charizard_mega_x_2_g7, gyarados_mega_g7, gyarados_mega_3_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, kyurem_1_g7, metagross_mega_2_g7, metagross_mega_1_g7, magearna_1_g7, jumpluff_1_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, gardevoir_mega_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, chansey_1_g7, celesteela_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, haxorus_1_g7, diancie_mega_1_g7, clefable_1_g7, vivillon_1_g7, whimsicott_1_g7, magearna_2_g7, umbreon_1_g7, porygon2_1_g7, haxorus_2_g7, volcarona_2_g7, pyukumuku_1_g7, deoxys_s_2_g7, swampert_mega_1_g7, dragonite_3_g7, weavile_1_g7, porygonz_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, entei_1_g7, greninja_5_g7, metagross_mega_3_g7, sableye_mega_2_g7, registeel_1_g7, serperior_1_g7, zapdos_1_g7, tapu_lele_3_g7, registeel_2_g7];
dragonite_5_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, metagross_mega_3_g7, dragonite_3_g7, charizard_mega_x_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_5_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, magnezone_2_g7, aron_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, smeargle_1_g7, tapu_fini_1_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, victini_2_g7, necrozma_2_g7, mawile_mega_1_g7, heracross_mega_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, whimsicott_1_g7, salamence_1_g7, swampert_mega_1_g7, togekiss_1_g7, togekiss_2_g7, weavile_1_g7, type_null_1_g7, sableye_mega_2_g7, magnezone_3_g7, tapu_lele_3_g7, registeel_2_g7];
dragonite_6_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, metagross_mega_1_g7, metagross_mega_2_g7, metagross_mega_4_g7, magearna_1_g7, magearna_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, charizard_mega_x_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_2_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, sableye_mega_2_g7, necrozma_2_g7, mawile_mega_1_g7, incineroar_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_2_g7, crustle_1_g7, clefable_1_g7, illumise_1_g7, whimsicott_1_g7, umbreon_1_g7, porygon2_1_g7, pyukumuku_1_g7, salamence_1_g7, togekiss_1_g7, togekiss_2_g7, type_null_1_g7, registeel_1_g7, diggersby_1_g7, heatran_3_g7, registeel_2_g7];
charizard_mega_y_g7.lmatchups = [togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, volcarona_2_g7, salamence_1_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, raikou_1_g7, altaria_mega_2_g7, aron_1_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, sawk_1_g7, incineroar_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, blaziken_mega_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, pinser_mega_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, primarina_1_g7, kommoo_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, dragonite_1_g7, gyarados_mega_2_g7, lopunny_mega_1_g7,magnezone_1_g7, donphan_1_g7, clefable_1_g7, porygonz_2_g7, weavile_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, charizard_mega_x_4_g7, greninja_5_g7, nihilego_1_g7, dragonite_5_g7, rotom_heat_1_g7, zeraora_3_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, porygonz_5_g7];
charizard_mega_x_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, deoxys_s_2_g7, salamence_1_g7, araquanid_1_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, gyarados_mega_4_g7, salazzle_1_g7, altaria_mega_2_g7, aron_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, illumise_1_g7, manaphy_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, blastoise_mega_1_g7, archeops_1_g7, pinser_mega_1_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, naganadel_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, dragonite_1_g7, lopunny_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7,landorus_therian_1_g7, greninja_1_g7, tapu_lele_1_g7, mew_1_g7, meloetta_1_g7, altaria_mega_1_g7, donphan_1_g7, clefable_1_g7, porygonz_2_g7, garchomp_1_g7, weavile_1_g7, porygonz_3_g7, meloetta_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, greninja_7_g7, heatran_3_g7, porygonz_5_g7];
charizard_mega_x_2_g7.lmatchups = [dragonite_3_g7, togekiss_2_g7, togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, gallade_mega_1_g7, carracosta_1_g7, deoxys_s_2_g7, salamence_1_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, garchomp_1_g7, altaria_mega_2_g7, smeargle_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, greninja_2_g7, illumise_1_g7, medicham_mega_1_g7, manaphy_1_g7, krookodile_1_g7,incineroar_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, archeops_1_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, charizard_mega_x_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, landorus_therian_1_g7, porygonz_1_g7, tapu_lele_1_g7, altaria_mega_1_g7, donphan_1_g7, clefable_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, dragonite_6_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7];
charizard_mega_x_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, charizard_mega_x_g7, landorus_therian_1_g7, landorus_therian_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, donphan_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_1_g7, aron_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_2_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, victini_2_g7, necrozma_1_g7, blacephalon_1_g7, krookodile_1_g7, hoopau_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, clefable_1_g7, illumise_1_g7, terrakion_1_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, gallade_mega_1_g7, togekiss_2_g7, meloetta_2_g7, tapu_lele_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
charizard_mega_x_4_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, charizard_mega_x_g7, landorus_therian_1_g7, landorus_therian_3_g7, greninja_2_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, donphan_1_g7, donphan_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_2_g7, aron_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_2_g7, primarina_1_g7, archeops_1_g7, necrozma_1_g7, krookodile_1_g7, incineroar_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, illumise_1_g7, terrakion_1_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, swampert_mega_1_g7, gallade_mega_1_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, charizard_mega_x_3_g7, talonflame_1_g7, nihilego_1_g7, dragonite_5_g7, porygonz_4_g7, diggersby_1_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
manaphy_1_g7.lmatchups = [togekiss_1_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, salamence_1_g7, haxorus_2_g7, pyukumuku_1_g7, garchomp_2_g7, whimsicott_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, aron_1_g7, kartana_2_g7, dragonite_2_g7, sawk_1_g7, medicham_mega_1_g7, kartana_1_g7, clefable_1_g7, crustle_1_g7, haxorus_1_g7, heracross_mega_1_g7, volcarona_1_g7, zeraora_1_g7, archeops_1_g7, garchomp_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, dragonite_1_g7, ferrothorn_1_g7, porygonz_1_g7, porygonz_2_g7, jumpluff_1_g7, meloetta_1_g7, magnezone_1_g7, kommoo_1_g7, naganadel_1_g7, venusaur_mega_1_g7, vivillon_1_g7, porygonz_3_g7, zeraora_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, slaking_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, tapu_lele_3_g7, porygonz_5_g7];
kommoo_1_g7.lmatchups = [porygonz_1_g7, togekiss_2_g7, togekiss_1_g7, landorus_therian_2_g7, volcarona_2_g7, dragonite_4_g7, dragonite_3_g7, deoxys_s_2_g7, salamence_1_g7, hoopau_2_g7, haxorus_2_g7, magearna_2_g7, vivillon_1_g7, slowbro_mega_2_g7, smeargle_1_g7, victini_2_g7, tapu_fini_2_g7, dragonite_2_g7, medicham_mega_1_g7, haxorus_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, archeops_1_g7, pinser_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, naganadel_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_2_g7, tapu_lele_1_g7, slowbro_mega_1_g7, mew_1_g7, gardevoir_mega_1_g7, clefable_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, slaking_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, nihilego_1_g7, dragonite_5_g7, sableye_mega_2_g7, hoopau_3_g7, diggersby_1_g7, dragonite_6_g7, zeraora_4_g7, tapu_lele_3_g7];
genesect_1_g7.lmatchups = [togekiss_1_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, carracosta_1_g7, swampert_mega_1_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, magearna_2_g7, darmanitan_1_g7, salazzle_1_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, dragonite_2_g7, manaphy_1_g7, incineroar_1_g7, crustle_1_g7, blaziken_mega_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, naganadel_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, greninja_1_g7, magnezone_1_g7, aegislash_1_g7, kommoo_1_g7, lopunny_mega_1_g7, volcarona_1_g7, vivillon_1_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, lucario_mega_1_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
genesect_2_g7.lmatchups = [togekiss_1_g7, celesteela_2_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, magearna_2_g7, terrakion_1_g7, darmanitan_1_g7, salazzle_1_g7, audino_mega_1_g7, raikou_1_g7, altaria_mega_2_g7, blacephalon_1_g7, dragonite_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, manaphy_1_g7, kommoo_1_g7, medicham_mega_1_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, donphan_1_g7, altaria_mega_1_g7, aegislash_1_g7, magnezone_1_g7, mew_1_g7, lopunny_mega_1_g7, heatran_2_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, volcarona_1_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, incineroar_1_g7, heracross_mega_1_g7, golem_1_g7, diancie_mega_1_g7, sawk_1_g7, blaziken_mega_1_g7, clefable_1_g7, dragonite_2_g7, crustle_1_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
genesect_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_4_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_2_g7, greninja_1_g7, greninja_4_g7, medicham_mega_1_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_2_g7, magnezone_1_g7, magnezone_2_g7, aron_1_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_3_g7, chansey_1_g7, aggron_mega_1_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, blacephalon_1_g7, raikou_1_g7, incineroar_1_g7, golem_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, pyukumuku_1_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, weavile_1_g7, infernape_1_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, magnezone_3_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
landorus_therian_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, illumise_1_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, diancie_mega_1_g7, kyurem_1_g7, deoxys_s_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, necrozma_1_g7, chansey_1_g7, primarina_1_g7, kommoo_1_g7, gardevoir_mega_1_g7, charizard_mega_y_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, slowbro_mega_1_g7, jumpluff_1_g7,porygonz_1_g7, greninja_1_g7, mew_1_g7, meloetta_1_g7, altaria_mega_1_g7, clefable_1_g7, porygonz_2_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, genesect_3_g7, greninja_5_g7, metagross_mega_3_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, diggersby_1_g7, serperior_1_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, porygonz_5_g7];
landorus_therian_2_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, audino_mega_1_g7, tapu_lele_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, manaphy_1_g7, genesect_1_g7, genesect_2_g7, landorus_therian_1_g7, jumpluff_1_g7,slowbro_mega_2_g7, slowbro_mega_1_g7, gardevoir_mega_1_g7, donphan_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, necrozma_1_g7, hoopau_1_g7, golem_1_g7, deoxys_s_1_g7, clefable_1_g7, illumise_1_g7, whimsicott_1_g7, magearna_2_g7, umbreon_1_g7, porygon2_1_g7, salamence_1_g7, pyukumuku_1_g7, donphan_2_g7, deoxys_s_2_g7, swampert_mega_1_g7, carracosta_1_g7, dragonite_3_g7, dragonite_4_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, genesect_3_g7, metagross_mega_3_g7, dragonite_5_g7, sableye_mega_2_g7, serperior_1_g7, metagross_mega_4_g7, donphan_3_g7, tapu_lele_3_g7, registeel_2_g7];
landorus_therian_3_g7.lmatchups = [gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_5_g7, kyurem_1_g7, naganadel_1_g7, dragonite_2_g7, dragonite_3_g7, charizard_mega_y_g7, manaphy_1_g7, genesect_1_g7, genesect_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_2_g7, altaria_mega_1_g7, meloetta_2_g7, celesteela_1_g7, celesteela_2_g7, smeargle_1_g7, tapu_fini_2_g7, primarina_1_g7, victini_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, blacephalon_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, vivillon_1_g7, whimsicott_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, salamence_1_g7, swampert_mega_1_g7, carracosta_1_g7, weavile_1_g7, type_null_1_g7, slaking_1_g7, genesect_3_g7, greninja_5_g7, metagross_mega_3_g7, porygonz_4_g7, greninja_6_g7, rotom_heat_1_g7, diggersby_1_g7, metagross_mega_4_g7, greninja_7_g7, tapu_lele_3_g7, porygonz_5_g7];
jumpluff_1_g7.lmatchups = [gardevoir_mega_2_g7, greninja_4_g7, venusaur_mega_2_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, pheromosa_3_g7, pheromosa_2_g7, darmanitan_1_g7, salazzle_1_g7, raikou_1_g7, genesect_2_g7, kartana_2_g7, sawk_1_g7, heracross_mega_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, blaziken_mega_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, kartana_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, naganadel_1_g7, kommoo_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, lopunny_mega_1_g7, greninja_1_g7, genesect_1_g7, volcarona_1_g7, porygonz_2_g7, weavile_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, meloetta_2_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, serperior_1_g7, dragonite_6_g7, kartana_3_g7, porygonz_5_g7];
jumpluff_2_g7.lmatchups = [gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, naganadel_1_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, kommoo_1_g7, genesect_1_g7, genesect_2_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7,slowbro_mega_2_g7, porygonz_2_g7, gardevoir_mega_2_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_2_g7, lopunny_mega_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, sableye_mega_1_g7, blacephalon_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, hoopau_2_g7, heracross_mega_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, salamence_1_g7, togekiss_1_g7, togekiss_2_g7, weavile_1_g7, type_null_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_6_g7, sableye_mega_2_g7, registeel_1_g7, dragonite_6_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
greninja_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, donphan_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, magearna_2_g7, darmanitan_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, genesect_2_g7, aron_1_g7, tapu_fini_2_g7, sawk_1_g7, manaphy_1_g7, kyurem_1_g7, hoopau_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, crustle_1_g7, blaziken_mega_1_g7, zeraora_1_g7, sableye_mega_1_g7, ferrothorn_1_g7, chansey_1_g7, aggron_mega_1_g7, tapu_fini_1_g7, kommoo_1_g7, gardevoir_mega_1_g7, charizard_mega_x_2_g7, metagross_mega_1_g7, metagross_mega_2_g7, lopunny_mega_1_g7, magearna_1_g7, tapu_lele_1_g7, magnezone_1_g7, meloetta_1_g7, donphan_1_g7, clefable_1_g7, porygonz_2_g7, zeraora_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, vaporeon_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, volcanion_1_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, zeraora_4_g7, registeel_2_g7, porygonz_5_g7];
greninja_2_g7.lmatchups = [garchomp_2_g7, salamence_1_g7, jumpluff_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, salazzle_1_g7, slowbro_mega_2_g7, raikou_1_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7,tapu_fini_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, kyurem_1_g7, naganadel_1_g7, dragonite_1_g7, manaphy_1_g7, kommoo_1_g7, genesect_1_g7, greninja_1_g7, slowbro_mega_1_g7, porygonz_2_g7, donphan_1_g7, altaria_mega_1_g7, magnezone_1_g7, lopunny_mega_1_g7, ferrothorn_1_g7, chansey_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, hoopau_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, dragonite_2_g7, zeraora_2_g7, meloetta_2_g7, magnezone_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, genesect_3_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, zeraora_3_g7, serperior_1_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, porygonz_5_g7];
greninja_4_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, charizard_mega_x_2_g7, manaphy_1_g7, kommoo_1_g7, genesect_2_g7, tapu_lele_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, donphan_1_g7, audino_mega_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, lopunny_mega_1_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, sableye_mega_1_g7, hoopau_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, darmanitan_1_g7, garchomp_2_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, hoopau_2_g7, pyukumuku_1_g7, donphan_2_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, venusaur_mega_2_g7, zeraora_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, vaporeon_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, volcanion_1_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, zeraora_4_g7, registeel_2_g7, porygonz_5_g7];
greninja_5_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_2_g7, charizard_mega_x_2_g7, manaphy_1_g7, genesect_2_g7, landorus_therian_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, porygonz_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, magnezone_1_g7, magnezone_2_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, lopunny_mega_1_g7, garchomp_2_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, hoopau_1_g7, hoopau_2_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, pyukumuku_1_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, togekiss_1_g7, infernape_1_g7, type_null_1_g7, vaporeon_1_g7, talonflame_1_g7, volcanion_1_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, registeel_2_g7, porygonz_5_g7];
greninja_6_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, magearna_1_g7, magearna_2_g7, charizard_mega_x_2_g7, charizard_mega_x_4_g7, manaphy_1_g7, kommoo_1_g7, genesect_2_g7, landorus_therian_2_g7, tapu_lele_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, lopunny_mega_1_g7, garchomp_2_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_2_g7, aggron_mega_1_g7, venusaur_mega_2_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, zeraora_2_g7, sableye_mega_1_g7, hoopau_1_g7, hoopau_2_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, darmanitan_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, pyukumuku_1_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, togekiss_1_g7, togekiss_2_g7, type_null_1_g7, vaporeon_1_g7, talonflame_1_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, zapdos_1_g7, donphan_3_g7, zeraora_4_g7, registeel_2_g7, porygonz_5_g7];
greninja_7_g7.lmatchups = [hoopau_1_g7, haxorus_1_g7, genesect_1_g7, garchomp_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, dragonite_6_g7, manaphy_1_g7, kommoo_1_g7, genesect_2_g7, landorus_therian_2_g7, jumpluff_1_g7, greninja_1_g7, greninja_4_g7, greninja_6_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, porygonz_2_g7, donphan_1_g7, donphan_2_g7, donphan_3_g7, altaria_mega_1_g7, altaria_mega_2_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, meloetta_2_g7, lopunny_mega_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, zeraora_4_g7, raikou_1_g7, heracross_mega_1_g7, golem_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, araquanid_1_g7, salamence_1_g7, vaporeon_1_g7, tapu_bulu_1_g7, volcanion_1_g7, serperior_1_g7, porygonz_5_g7];
medicham_mega_1_g7.lmatchups = [togekiss_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, gallade_mega_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, pheromosa_3_g7, pheromosa_2_g7, darmanitan_1_g7, salazzle_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, altaria_mega_2_g7, kartana_2_g7, blacephalon_1_g7, victini_2_g7, greninja_2_g7, illumise_1_g7, clefable_1_g7, diancie_mega_1_g7, durant_1_g7, haxorus_1_g7, deoxys_s_1_g7, kartana_1_g7, blaziken_mega_1_g7, mawile_mega_1_g7, zeraora_1_g7, archeops_1_g7, necrozma_1_g7, pinser_mega_1_g7, sableye_mega_1_g7, victini_1_g7, garchomp_1_g7, aegislash_1_g7, naganadel_1_g7, primarina_1_g7, genesect_1_g7, gardevoir_mega_1_g7, altaria_mega_1_g7, gyarados_mega_g7, mew_1_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, metagross_mega_2_g7, porygonz_2_g7, tapu_lele_1_g7, slowbro_mega_1_g7, greninja_1_g7, jumpluff_1_g7, lopunny_mega_1_g7, vivillon_1_g7, weavile_1_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, magnezone_2_g7, tapu_lele_2_g7, garchomp_3_g7, jumpluff_2_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, greninja_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, tapu_lele_3_g7, porygonz_5_g7];
slowbro_mega_1_g7.lmatchups = [magnezone_3_g7, celesteela_2_g7, greninja_4_g7, venusaur_mega_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, magearna_2_g7, audino_mega_1_g7, raikou_1_g7, shedinja_1_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, illumise_1_g7, kyurem_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, durant_1_g7, blastoise_mega_1_g7, zeraora_1_g7, kartana_1_g7, chansey_1_g7, venusaur_mega_1_g7, primarina_1_g7, genesect_1_g7, gardevoir_mega_1_g7, aegislash_1_g7, charizard_mega_y_g7, magearna_1_g7, jumpluff_1_g7, porygonz_1_g7, greninja_1_g7, magnezone_1_g7, volcarona_1_g7, vivillon_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, greninja_5_g7, nihilego_1_g7, porygonz_4_g7, greninja_6_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, registeel_2_g7];
slowbro_mega_2_g7.lmatchups = [magnezone_3_g7, greninja_4_g7,deoxys_s_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, magearna_2_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, kyurem_1_g7, magearna_1_g7, charizard_mega_y_g7, genesect_1_g7, jumpluff_1_g7, greninja_1_g7, porygonz_1_g7, aegislash_1_g7, magnezone_1_g7, ferrothorn_1_g7, chansey_1_g7, venusaur_mega_1_g7, primarina_1_g7, zeraora_1_g7, volcarona_1_g7, kartana_2_g7, kartana_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, durant_1_g7, illumise_1_g7, blacephalon_1_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, vivillon_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, greninja_5_g7, nihilego_1_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, registeel_2_g7];
tapu_lele_1_g7.lmatchups = [porygonz_1_g7, celesteela_2_g7, carracosta_1_g7, hoopau_2_g7, haxorus_2_g7, pyukumuku_1_g7, magearna_2_g7, salazzle_1_g7, slowbro_mega_2_g7, mew_2_g7, shedinja_1_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, blacephalon_1_g7, victini_2_g7, greninja_2_g7, sawk_1_g7, manaphy_1_g7, durant_1_g7, archeops_1_g7, victini_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, heatran_1_g7, ferrothorn_1_g7, celesteela_1_g7, aggron_mega_1_g7, naganadel_1_g7, genesect_1_g7, gardevoir_mega_1_g7, aegislash_1_g7, charizard_mega_y_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, jumpluff_1_g7, magnezone_1_g7, meloetta_1_g7, volcarona_1_g7, vivillon_1_g7, porygonz_3_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, genesect_3_g7, metagross_mega_3_g7, zeraora_3_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
tapu_lele_2_g7.lmatchups = [porygonz_2_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, magearna_2_g7, charizard_mega_y_g7, charizard_mega_x_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, gardevoir_mega_1_g7, donphan_2_g7, audino_mega_1_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, pinser_mega_1_g7, necrozma_2_g7, blacephalon_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, hoopau_2_g7, haxorus_1_g7, haxorus_2_g7, durant_1_g7, sawk_1_g7, crustle_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, carracosta_1_g7, weavile_1_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, genesect_3_g7, greninja_5_g7, metagross_mega_3_g7, greninja_6_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
tapu_lele_3_g7.lmatchups = [naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, metagross_mega_3_g7, metagross_mega_4_g7, magearna_1_g7, magearna_2_g7, dragonite_6_g7, charizard_mega_y_g7, charizard_mega_x_g7, genesect_3_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_2_g7, greninja_5_g7, greninja_7_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_2_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, heatran_3_g7, garchomp_1_g7, garchomp_3_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_4_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, pinser_mega_1_g7, necrozma_2_g7, blacephalon_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, kartana_3_g7, hoopau_2_g7, haxorus_1_g7, haxorus_2_g7, durant_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, pyukumuku_1_g7, carracosta_1_g7, weavile_1_g7, slaking_1_g7, tapu_bulu_1_g7, registeel_1_g7, lucario_mega_1_g7, registeel_2_g7, porygonz_5_g7];
porygonz_1_g7.lmatchups = [gyarados_mega_2_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, magearna_2_g7, terrakion_1_g7, darmanitan_1_g7, salazzle_1_g7, audino_mega_1_g7, raikou_1_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, greninja_2_g7, sawk_1_g7, medicham_mega_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, crustle_1_g7, archeops_1_g7, zeraora_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, garchomp_1_g7, chansey_1_g7, tyranitar_mega_1_g7, naganadel_1_g7, genesect_1_g7, gardevoir_mega_1_g7, charizard_mega_x_g7, charizard_mega_y_g7, dragonite_1_g7, magearna_1_g7, jumpluff_1_g7, lopunny_mega_1_g7, greninja_1_g7, magnezone_1_g7, volcarona_1_g7, porygonz_2_g7, weavile_1_g7, infernape_1_g7, zeraora_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, greninja_5_g7, nihilego_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, registeel_1_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
porygonz_2_g7.lmatchups = [dragonite_2_g7, gyarados_mega_g7, togekiss_1_g7, landorus_therian_2_g7, zeraora_1_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, magearna_2_g7, terrakion_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, aron_1_g7, heatran_2_g7, dragonite_1_g7, sawk_1_g7, kyurem_1_g7, incineroar_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, slowbro_mega_1_g7, mew_1_g7, meloetta_1_g7, magnezone_1_g7, donphan_1_g7, gardevoir_mega_1_g7, genesect_1_g7, kommoo_1_g7, venusaur_mega_1_g7, aggron_mega_1_g7, celesteela_1_g7, ferrothorn_1_g7, heatran_1_g7, mawile_mega_1_g7, necrozma_1_g7, sableye_mega_1_g7, blaziken_mega_1_g7, crustle_1_g7, deoxys_s_1_g7, diancie_mega_1_g7, golem_1_g7, haxorus_1_g7, hoopau_1_g7, clefable_1_g7, chansey_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, vaporeon_1_g7, entei_1_g7, genesect_3_g7, nihilego_1_g7, dragonite_5_g7, sableye_mega_2_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, donphan_3_g7, dragonite_6_g7, heatran_3_g7, registeel_2_g7];
porygonz_3_g7.lmatchups = [naganadel_1_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_3_g7, charizard_mega_y_g7, genesect_1_g7, genesect_2_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, medicham_mega_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, audino_mega_1_g7, magnezone_1_g7, meloetta_1_g7, lopunny_mega_1_g7, garchomp_1_g7, chansey_1_g7, celesteela_2_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, volcarona_1_g7, volcarona_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, hoopau_1_g7, haxorus_2_g7, durant_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, vivillon_1_g7, salazzle_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, pyukumuku_1_g7, carracosta_1_g7, gallade_mega_1_g7, togekiss_1_g7, weavile_1_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, genesect_3_g7, greninja_5_g7, nihilego_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, dragonite_6_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
porygonz_4_g7.lmatchups = [naganadel_1_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, charizard_mega_y_g7, genesect_3_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7, medicham_mega_1_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, magnezone_1_g7, magnezone_2_g7, meloetta_1_g7, lopunny_mega_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_3_g7, celesteela_2_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, volcarona_2_g7, pinser_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, hoopau_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, vivillon_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, carracosta_1_g7, infernape_1_g7, slaking_1_g7, nihilego_1_g7, gallade_mega_1_g7, weavile_1_g7, greninja_6_g7, zeraora_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
porygonz_5_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_4_g7, kyurem_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, metagross_mega_3_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, dragonite_6_g7, kommoo_1_g7, landorus_therian_2_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, gardevoir_mega_1_g7, donphan_1_g7, donphan_2_g7, donphan_3_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, meloetta_1_g7, meloetta_2_g7, mew_1_g7, heatran_1_g7, heatran_2_g7, heatran_3_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, zeraora_1_g7, volcarona_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, blacephalon_1_g7, mawile_mega_1_g7, incineroar_1_g7, hoopau_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, darmanitan_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, pyukumuku_1_g7, araquanid_1_g7, carracosta_1_g7, togekiss_1_g7, vaporeon_1_g7, entei_1_g7, nihilego_1_g7, registeel_1_g7, registeel_2_g7];
gardevoir_mega_1_g7.lmatchups = [celesteela_2_g7, carracosta_1_g7, swampert_mega_1_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_2_g7, magearna_2_g7, terrakion_1_g7, darmanitan_1_g7, salazzle_1_g7, slowbro_mega_2_g7, mew_2_g7, genesect_2_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, greninja_2_g7, sawk_1_g7, manaphy_1_g7, durant_1_g7, crustle_1_g7, archeops_1_g7, victini_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, heatran_1_g7, garchomp_1_g7, ferrothorn_1_g7, celesteela_1_g7, aggron_mega_1_g7, naganadel_1_g7, genesect_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, lopunny_mega_1_g7, meloetta_1_g7, magnezone_1_g7, aegislash_1_g7, volcarona_1_g7, vivillon_1_g7, weavile_1_g7, charizard_mega_x_3_g7, meloetta_2_g7, magnezone_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, entei_1_g7, slaking_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, metagross_mega_3_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
gardevoir_mega_2_g7.lmatchups = [porygonz_2_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, magearna_2_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, genesect_1_g7, greninja_2_g7, donphan_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, meloetta_2_g7, lopunny_mega_1_g7, heatran_1_g7, garchomp_1_g7, garchomp_2_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, archeops_1_g7, volcarona_1_g7, victini_1_g7, pinser_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, incineroar_1_g7, haxorus_1_g7, durant_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, pyukumuku_1_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, weavile_1_g7, garchomp_3_g7, entei_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, metagross_mega_3_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
donphan_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, salamence_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, smeargle_1_g7, tapu_fini_2_g7, dragonite_2_g7, illumise_1_g7, kyurem_1_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, necrozma_1_g7, kartana_1_g7, heatran_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, kommoo_1_g7, genesect_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, porygonz_1_g7, tapu_lele_1_g7, slowbro_mega_1_g7,mew_1_g7, meloetta_1_g7, altaria_mega_1_g7, gardevoir_mega_1_g7, clefable_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, sableye_mega_2_g7, serperior_1_g7, metagross_mega_4_g7, kartana_3_g7, heatran_3_g7, tapu_lele_3_g7];
donphan_2_g7.lmatchups = [tapu_fini_2_g7, togekiss_2_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, crustle_1_g7, magearna_1_g7, gyarados_mega_g7, gyarados_mega_3_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, kyurem_1_g7, metagross_mega_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, manaphy_1_g7, kommoo_1_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, gardevoir_mega_1_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_2_g7, altaria_mega_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, heatran_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, smeargle_1_g7, blastoise_mega_1_g7, victini_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, krookodile_1_g7, hoopau_1_g7, heracross_mega_1_g7, golem_1_g7, sawk_1_g7, illumise_1_g7, vivillon_1_g7, umbreon_1_g7, porygon2_1_g7, salamence_1_g7, araquanid_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, vaporeon_1_g7, porygonz_4_g7, sableye_mega_2_g7, magnezone_3_g7, metagross_mega_4_g7, donphan_3_g7, kartana_3_g7, heatran_3_g7];
donphan_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, metagross_mega_4_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, manaphy_1_g7, kommoo_1_g7, genesect_1_g7, landorus_therian_1_g7, landorus_therian_3_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_3_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aron_1_g7, mew_1_g7, mew_2_g7, heatran_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, celesteela_2_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, smeargle_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, victini_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, necrozma_1_g7, necrozma_2_g7, krookodile_1_g7, heracross_mega_1_g7, diancie_mega_1_g7, deoxys_s_2_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, salazzle_1_g7, whimsicott_1_g7, umbreon_1_g7, zapdos_1_g7, porygon2_1_g7, pyukumuku_1_g7, salamence_1_g7, swampert_mega_1_g7, gallade_mega_1_g7, togekiss_1_g7, togekiss_2_g7, infernape_1_g7, type_null_1_g7, vaporeon_1_g7, tapu_bulu_1_g7, rotom_heat_1_g7, serperior_1_g7, kartana_3_g7, tapu_lele_3_g7];
audino_mega_1_g7.lmatchups = [celesteela_2_g7, gyarados_mega_5_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, terrakion_1_g7, whimsicott_1_g7, salazzle_1_g7, gyarados_mega_3_g7, metagross_mega_1_g7, metagross_mega_2_g7, manaphy_1_g7, kommoo_1_g7, jumpluff_1_g7, medicham_mega_1_g7, tapu_lele_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, magnezone_1_g7, meloetta_1_g7, garchomp_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, krookodile_1_g7, crustle_1_g7, illumise_1_g7, greninja_2_g7, kartana_2_g7, blacephalon_1_g7, aron_1_g7, smeargle_1_g7, gyarados_mega_4_g7, mew_2_g7, raikou_1_g7, weavile_1_g7, charizard_mega_x_3_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, metagross_mega_3_g7, porygonz_4_g7, hoopau_3_g7, diggersby_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, porygonz_5_g7];
altaria_mega_1_g7.lmatchups = [kommoo_1_g7, togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, greninja_4_g7, venusaur_mega_2_g7, swampert_mega_1_g7, deoxys_s_2_g7, aron_1_g7, volcarona_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, magearna_2_g7, salazzle_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, manaphy_1_g7, kyurem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, blastoise_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, heatran_1_g7, chansey_1_g7, venusaur_mega_1_g7, primarina_1_g7, naganadel_1_g7, genesect_1_g7, magearna_1_g7, porygonz_1_g7, tapu_lele_1_g7, slowbro_mega_1_g7, greninja_1_g7, mew_1_g7, meloetta_1_g7, magnezone_1_g7, aegislash_1_g7, gardevoir_mega_1_g7, volcarona_1_g7, clefable_1_g7, porygonz_2_g7, vivillon_1_g7, porygonz_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, genesect_3_g7, greninja_5_g7, nihilego_1_g7, porygonz_4_g7, greninja_6_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
altaria_mega_2_g7.lmatchups = [kommoo_1_g7, togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, greninja_4_g7, venusaur_mega_2_g7, deoxys_s_2_g7, volcarona_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, mew_1_g7, magearna_2_g7, salazzle_1_g7, audino_mega_1_g7, aegislash_1_g7, raikou_1_g7, mew_2_g7, kyurem_1_g7, naganadel_1_g7, magearna_1_g7, manaphy_1_g7, greninja_1_g7, slowbro_mega_1_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, altaria_mega_1_g7, meloetta_1_g7, heatran_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, blastoise_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, clefable_1_g7, tapu_fini_2_g7, victini_2_g7, blacephalon_1_g7, aron_1_g7, smeargle_1_g7, slowbro_mega_2_g7, porygonz_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, nihilego_1_g7, porygonz_4_g7, greninja_6_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
aegislash_1_g7.lmatchups = [kommoo_1_g7, gyarados_mega_5_g7, greninja_4_g7, volcarona_2_g7, swampert_mega_1_g7, donphan_2_g7, hoopau_2_g7, porygon2_1_g7, umbreon_1_g7, audino_mega_1_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, manaphy_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, porygonz_1_g7, golem_1_g7, sableye_mega_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, tyranitar_mega_1_g7, meloetta_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_y_g7, dragonite_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, donphan_1_g7, volcarona_1_g7, porygonz_2_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, type_null_1_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, donphan_3_g7, dragonite_6_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
magnezone_1_g7.lmatchups = [dragonite_2_g7, zeraora_1_g7, landorus_therian_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, volcarona_2_g7, haxorus_2_g7, pheromosa_2_g7, umbreon_1_g7, garchomp_2_g7, whimsicott_1_g7, salazzle_1_g7, raikou_1_g7, shedinja_1_g7, smeargle_1_g7, sawk_1_g7, medicham_mega_1_g7, krookodile_1_g7, incineroar_1_g7, haxorus_1_g7, golem_1_g7, victini_1_g7, garchomp_1_g7, tyranitar_mega_1_g7, naganadel_1_g7, kommoo_1_g7, aegislash_1_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, dragonite_1_g7, metagross_mega_1_g7, metagross_mega_2_g7,jumpluff_1_g7, lopunny_mega_1_g7, donphan_1_g7, vivillon_1_g7, weavile_1_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, garchomp_3_g7, jumpluff_2_g7, entei_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, greninja_6_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, donphan_3_g7, zeraora_4_g7, registeel_2_g7];
magnezone_2_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_4_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_2_g7, jumpluff_1_g7,donphan_1_g7, donphan_2_g7, altaria_mega_2_g7, aegislash_1_g7, garchomp_1_g7, garchomp_2_g7, smeargle_1_g7, tyranitar_mega_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_2_g7, victini_1_g7, raikou_1_g7, krookodile_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, sawk_1_g7, vivillon_1_g7, shedinja_1_g7, whimsicott_1_g7, umbreon_1_g7, swampert_mega_1_g7, garchomp_3_g7, jumpluff_2_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, greninja_6_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, registeel_2_g7];
magnezone_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_4_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_6_g7, donphan_1_g7, aegislash_1_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, smeargle_1_g7, tyranitar_mega_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, volcarona_2_g7, victini_1_g7, raikou_1_g7, krookodile_1_g7, incineroar_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, sawk_1_g7, vivillon_1_g7, shedinja_1_g7, salazzle_1_g7, whimsicott_1_g7, umbreon_1_g7, swampert_mega_1_g7, infernape_1_g7, rotom_heat_1_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, registeel_2_g7, medicham_mega_1_g7];
meloetta_1_g7.lmatchups = [jumpluff_1_g7, gyarados_mega_5_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, volcarona_2_g7, hoopau_2_g7, pyukumuku_1_g7, terrakion_1_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, greninja_2_g7, sawk_1_g7, medicham_mega_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, ferrothorn_1_g7, celesteela_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, genesect_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magnezone_1_g7, volcarona_1_g7, vivillon_1_g7, weavile_1_g7, zeraora_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, metagross_mega_3_g7, dragonite_5_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7];
meloetta_2_g7.lmatchups = [smeargle_1_g7, gyarados_mega_5_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_3_g7, genesect_1_g7, genesect_2_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, porygonz_1_g7, porygonz_3_g7, aegislash_1_g7, magnezone_1_g7, aron_1_g7, heatran_1_g7, heatran_2_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, volcarona_2_g7, sableye_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, heracross_mega_1_g7, durant_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, shedinja_1_g7, terrakion_1_g7, umbreon_1_g7, porygon2_1_g7, carracosta_1_g7, weavile_1_g7, type_null_1_g7, slaking_1_g7, genesect_3_g7, nihilego_1_g7, metagross_mega_3_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7];
aron_1_g7.lmatchups = [togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, dragonite_3_g7, gallade_mega_1_g7, swampert_mega_1_g7, haxorus_2_g7, pheromosa_2_g7, garchomp_2_g7, magearna_2_g7, terrakion_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, salazzle_1_g7, mew_2_g7, blacephalon_1_g7, porygonz_1_g7, kommoo_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, charizard_mega_x_2_g7, jumpluff_1_g7, medicham_mega_1_g7,gardevoir_mega_1_g7, aegislash_1_g7, magnezone_1_g7, mew_1_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, celesteela_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, primarina_1_g7, blastoise_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, kartana_1_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, crustle_1_g7, illumise_1_g7, greninja_2_g7, victini_2_g7, weavile_1_g7, porygonz_3_g7, infernape_1_g7, zeraora_2_g7, magnezone_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, tapu_bulu_1_g7, landorus_therian_3_g7, talonflame_1_g7, metagross_mega_3_g7, porygonz_4_g7, sableye_mega_2_g7, zeraora_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
mew_1_g7.lmatchups = [jumpluff_1_g7, togekiss_1_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_3_g7, swampert_mega_1_g7, volcarona_2_g7, salamence_1_g7, hoopau_2_g7, pyukumuku_1_g7, pheromosa_3_g7, umbreon_1_g7, garchomp_2_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, mew_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, greninja_2_g7, manaphy_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, durant_1_g7, crustle_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, heatran_1_g7, garchomp_1_g7, tyranitar_mega_1_g7, gardevoir_mega_1_g7, aegislash_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, dragonite_1_g7, porygonz_1_g7, greninja_1_g7, tapu_lele_1_g7, slowbro_mega_1_g7, meloetta_1_g7, volcarona_1_g7, clefable_1_g7, vivillon_1_g7, slowbro_mega_2_g7, weavile_1_g7, porygonz_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, greninja_5_g7, metagross_mega_3_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, zapdos_1_g7, dragonite_6_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7];
mew_2_g7.lmatchups = [gyarados_mega_5_g7, greninja_4_g7, tyranitar_mega_1_g7, dragonite_3_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pheromosa_3_g7, terrakion_1_g7, whimsicott_1_g7, darmanitan_1_g7, salazzle_1_g7, raikou_1_g7, charizard_mega_x_g7, kommoo_1_g7, jumpluff_1_g7, greninja_1_g7, porygonz_1_g7, aegislash_1_g7, magnezone_1_g7, garchomp_1_g7, zeraora_1_g7, archeops_1_g7, victini_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, kartana_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, durant_1_g7, blaziken_mega_1_g7, illumise_1_g7, greninja_2_g7, blacephalon_1_g7, genesect_2_g7, weavile_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, type_null_1_g7, meloetta_2_g7, garchomp_3_g7, jumpluff_2_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, serperior_1_g7, lucario_mega_1_g7, kartana_3_g7, greninja_7_g7, porygonz_5_g7];
lopunny_mega_1_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, landorus_therian_2_g7, kommoo_1_g7, venusaur_mega_2_g7, gallade_mega_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, pheromosa_3_g7, pheromosa_2_g7, magearna_2_g7, whimsicott_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, shedinja_1_g7, altaria_mega_2_g7, victini_2_g7, tapu_fini_2_g7, illumise_1_g7, sawk_1_g7, manaphy_1_g7, krookodile_1_g7, heracross_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, blaziken_mega_1_g7, blastoise_mega_1_g7, zeraora_1_g7, victini_1_g7, charizard_mega_x_2_g7, necrozma_1_g7, mawile_mega_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, primarina_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, magearna_1_g7, slowbro_mega_1_g7,landorus_therian_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, tapu_lele_1_g7, mew_1_g7, meloetta_1_g7, altaria_mega_1_g7, donphan_1_g7, clefable_1_g7, porygonz_2_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, metagross_mega_4_g7, donphan_3_g7, porygonz_5_g7];
heatran_1_g7.lmatchups = [registeel_1_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, hoopau_2_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, terrakion_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, blacephalon_1_g7, tapu_fini_2_g7, greninja_2_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, kyurem_1_g7, krookodile_1_g7, hoopau_1_g7, magnezone_1_g7, durant_1_g7, crustle_1_g7, blaziken_mega_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, sableye_mega_1_g7, garchomp_1_g7, chansey_1_g7, tyranitar_mega_1_g7, primarina_1_g7, tapu_fini_1_g7, kommoo_1_g7, meloetta_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, dragonite_1_g7, porygonz_1_g7, slowbro_mega_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, vivillon_1_g7, porygonz_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, jumpluff_2_g7, vaporeon_1_g7, greninja_5_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, zapdos_1_g7, lucario_mega_1_g7, greninja_7_g7, registeel_2_g7];
heatran_2_g7.lmatchups = [registeel_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, hoopau_2_g7, haxorus_2_g7, araquanid_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, altaria_mega_2_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, blacephalon_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, metagross_mega_2_g7, metagross_mega_1_g7, dragonite_1_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7, jumpluff_1_g7, greninja_2_g7, greninja_1_g7, medicham_mega_1_g7,tapu_lele_1_g7, donphan_1_g7, magnezone_1_g7, lopunny_mega_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, vivillon_1_g7, gyarados_mega_4_g7, porygonz_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, metagross_mega_3_g7, volcanion_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, metagross_mega_4_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, greninja_7_g7, registeel_2_g7];
heatran_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, dragonite_1_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_3_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7, greninja_6_g7, greninja_7_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, donphan_3_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, zeraora_4_g7, victini_1_g7, sableye_mega_1_g7, sableye_mega_2_g7, blacephalon_1_g7, raikou_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, hoopau_3_g7, haxorus_1_g7, haxorus_2_g7, durant_1_g7, sawk_1_g7, blaziken_mega_1_g7, darmanitan_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, zapdos_1_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, infernape_1_g7, vaporeon_1_g7, nihilego_1_g7, volcanion_1_g7, rotom_heat_1_g7];
garchomp_1_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, krookodile_1_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, donphan_2_g7, salamence_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, whimsicott_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, altaria_mega_2_g7, genesect_2_g7, greninja_2_g7, dragonite_2_g7, illumise_1_g7, sawk_1_g7, kyurem_1_g7, genesect_1_g7, heracross_mega_1_g7, haxorus_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, kartana_1_g7, celesteela_1_g7, naganadel_1_g7, primarina_1_g7, kommoo_1_g7, donphan_1_g7, altaria_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, dragonite_1_g7, slowbro_mega_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, clefable_1_g7, porygonz_2_g7, weavile_1_g7, type_null_1_g7, meloetta_2_g7, garchomp_3_g7, jumpluff_2_g7, tapu_bulu_1_g7, landorus_therian_3_g7, greninja_5_g7, metagross_mega_3_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, serperior_1_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, porygonz_5_g7];
garchomp_2_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, magearna_1_g7, magearna_2_g7, dragonite_2_g7, genesect_1_g7, genesect_2_g7, landorus_therian_1_g7, medicham_mega_1_g7,slowbro_mega_2_g7, slowbro_mega_1_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_2_g7, altaria_mega_1_g7, aegislash_1_g7, meloetta_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, necrozma_1_g7, kartana_1_g7, krookodile_1_g7, hoopau_1_g7, clefable_1_g7, illumise_1_g7, porygonz_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, genesect_3_g7, metagross_mega_3_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, diggersby_1_g7, metagross_mega_4_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
garchomp_3_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, landorus_therian_1_g7, landorus_therian_2_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_1_g7, meloetta_2_g7, lopunny_mega_1_g7, heatran_1_g7, garchomp_2_g7, chansey_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, venusaur_mega_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, sableye_mega_1_g7, necrozma_1_g7, necrozma_2_g7, krookodile_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, illumise_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, togekiss_2_g7, weavile_1_g7, type_null_1_g7, jumpluff_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, metagross_mega_3_g7, dragonite_5_g7, greninja_6_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, porygonz_5_g7];
ferrothorn_1_g7.lmatchups = [mew_2_g7, celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, donphan_2_g7, volcarona_2_g7, salamence_1_g7, hoopau_2_g7, pheromosa_3_g7, pheromosa_2_g7, magearna_2_g7, darmanitan_1_g7, salazzle_1_g7, audino_mega_1_g7, raikou_1_g7, altaria_mega_2_g7, genesect_2_g7, smeargle_1_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, dragonite_2_g7, medicham_mega_1_g7, kyurem_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, durant_1_g7, blaziken_mega_1_g7, victini_1_g7, sableye_mega_1_g7, genesect_1_g7, pinser_mega_1_g7, necrozma_1_g7, kartana_1_g7, heatran_1_g7, garchomp_1_g7, celesteela_1_g7, kommoo_1_g7, naganadel_1_g7, aegislash_1_g7, altaria_mega_1_g7, magnezone_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, slowbro_mega_1_g7,landorus_therian_1_g7, mew_1_g7, volcarona_1_g7, vivillon_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, garchomp_3_g7, entei_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, rotom_heat_1_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, kartana_3_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
chansey_1_g7.lmatchups = [celesteela_2_g7, venusaur_mega_2_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_2_g7, terrakion_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, krookodile_1_g7, heracross_mega_1_g7, durant_1_g7, blaziken_mega_1_g7, zeraora_1_g7, meloetta_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, garchomp_1_g7, ferrothorn_1_g7, magearna_1_g7, tapu_lele_1_g7,jumpluff_1_g7, lopunny_mega_1_g7, magnezone_1_g7, kommoo_1_g7, tapu_fini_1_g7, tyranitar_mega_1_g7, vivillon_1_g7, weavile_1_g7, charizard_mega_x_3_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, porygonz_4_g7, sableye_mega_2_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, kartana_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
celesteela_1_g7.lmatchups = [celesteela_2_g7, greninja_4_g7, venusaur_mega_2_g7, carracosta_1_g7, volcarona_2_g7, salamence_1_g7, hoopau_2_g7, pyukumuku_1_g7, magearna_2_g7, whimsicott_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, salazzle_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, greninja_2_g7, manaphy_1_g7, incineroar_1_g7, hoopau_1_g7, deoxys_s_1_g7, blaziken_mega_1_g7, blastoise_mega_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, heatran_1_g7, tapu_fini_1_g7, primarina_1_g7, naganadel_1_g7, kommoo_1_g7, genesect_1_g7, altaria_mega_1_g7, magnezone_1_g7, mew_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, porygonz_1_g7, slowbro_mega_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, volcarona_1_g7, vivillon_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
celesteela_2_g7.lmatchups = [umbreon_1_g7, naganadel_1_g7, dragonite_2_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, manaphy_1_g7, kommoo_1_g7, genesect_1_g7, landorus_therian_1_g7, jumpluff_1_g7, greninja_2_g7, medicham_mega_1_g7,magnezone_1_g7, meloetta_1_g7, mew_1_g7, mew_2_g7, heatran_1_g7, heatran_2_g7, smeargle_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, blastoise_mega_1_g7, zeraora_1_g7, volcarona_1_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, raikou_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, blaziken_mega_1_g7, vivillon_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, magearna_2_g7, hoopau_2_g7, volcarona_2_g7, araquanid_1_g7, carracosta_1_g7, dragonite_4_g7, greninja_4_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, magnezone_2_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
aggron_mega_1_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, pyukumuku_1_g7, umbreon_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, salazzle_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, aron_1_g7, smeargle_1_g7, victini_2_g7, tapu_fini_2_g7, illumise_1_g7, medicham_mega_1_g7, kyurem_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, heatran_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, primarina_1_g7, kommoo_1_g7, donphan_1_g7, altaria_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, porygonz_1_g7, slowbro_mega_1_g7,jumpluff_1_g7, landorus_therian_1_g7, mew_1_g7, magnezone_1_g7, donphan_1_g7, vivillon_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, jumpluff_2_g7, vaporeon_1_g7, sableye_mega_2_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, kartana_3_g7, heatran_3_g7, registeel_2_g7];
venusaur_mega_1_g7.lmatchups = [celesteela_2_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, deoxys_s_2_g7, volcarona_2_g7, hoopau_2_g7, magearna_2_g7, audino_mega_1_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, kartana_2_g7, blacephalon_1_g7, victini_2_g7, dragonite_2_g7, medicham_mega_1_g7, kyurem_1_g7, hoopau_1_g7, durant_1_g7, deoxys_s_1_g7, archeops_1_g7, victini_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, kartana_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, celesteela_1_g7, kommoo_1_g7, genesect_1_g7, charizard_mega_y_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, porygonz_1_g7, tapu_lele_1_g7,mew_1_g7, meloetta_1_g7, aegislash_1_g7, gardevoir_mega_1_g7, volcarona_1_g7, magnezone_1_g7, vivillon_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, slaking_1_g7, landorus_therian_3_g7, genesect_3_g7, nihilego_1_g7, metagross_mega_3_g7, sableye_mega_2_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, metagross_mega_4_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
venusaur_mega_2_g7.lmatchups = [victini_1_g7, celesteela_2_g7, aron_1_g7, krookodile_1_g7, kartana_1_g7, kyurem_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_2_g7, charizard_mega_y_g7, manaphy_1_g7, kommoo_1_g7, medicham_mega_1_g7,slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_1_g7, gardevoir_mega_1_g7, audino_mega_1_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, mew_1_g7, mew_2_g7, garchomp_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, archeops_1_g7, volcarona_1_g7, victini_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, raikou_1_g7, hoopau_1_g7, deoxys_s_1_g7, vivillon_1_g7, salazzle_1_g7, terrakion_1_g7, hoopau_2_g7, volcarona_2_g7, pyukumuku_1_g7, deoxys_s_2_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, nihilego_1_g7, metagross_mega_3_g7, porygonz_4_g7, sableye_mega_2_g7, hoopau_3_g7, registeel_1_g7, magnezone_3_g7, lucario_mega_1_g7, kartana_3_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
smeargle_1_g7.lmatchups = [landorus_therian_2_g7, greninja_4_g7, gallade_mega_1_g7, deoxys_s_2_g7, salamence_1_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, terrakion_1_g7, whimsicott_1_g7, darmanitan_1_g7, salazzle_1_g7, raikou_1_g7, mew_2_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, charizard_mega_x_g7, charizard_mega_y_g7, manaphy_1_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, medicham_mega_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, lopunny_mega_1_g7, garchomp_1_g7, tapu_fini_1_g7, archeops_1_g7, zeraora_1_g7, volcarona_1_g7, pinser_mega_1_g7, kartana_1_g7, kartana_2_g7, haxorus_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, blaziken_mega_1_g7, blacephalon_1_g7, genesect_2_g7, weavile_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, porygonz_4_g7, greninja_6_g7, rotom_heat_1_g7, zeraora_3_g7, serperior_1_g7, metagross_mega_4_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, tapu_lele_3_g7, porygonz_5_g7];
tyranitar_mega_1_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, gallade_mega_1_g7, swampert_mega_1_g7, donphan_2_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, greninja_2_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, krookodile_1_g7, heracross_mega_1_g7, durant_1_g7, blaziken_mega_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, garchomp_1_g7, ferrothorn_1_g7, celesteela_1_g7, aggron_mega_1_g7, primarina_1_g7, tapu_fini_1_g7, kommoo_1_g7, genesect_1_g7, gardevoir_mega_1_g7, donphan_1_g7, altaria_mega_1_g7, lopunny_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, tapu_lele_1_g7, slowbro_mega_1_g7,landorus_therian_1_g7, volcarona_1_g7, clefable_1_g7, infernape_1_g7, type_null_1_g7, gardevoir_mega_2_g7, garchomp_3_g7, tapu_bulu_1_g7, landorus_therian_3_g7, genesect_3_g7, metagross_mega_3_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, kartana_3_g7, greninja_7_g7, registeel_2_g7];
tapu_fini_1_g7.lmatchups = [venusaur_mega_2_g7, deoxys_s_2_g7, donphan_2_g7, hoopau_2_g7, araquanid_1_g7, terrakion_1_g7, salazzle_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, kyurem_1_g7, deoxys_s_1_g7, zeraora_1_g7, victini_1_g7, pinser_mega_1_g7, kartana_1_g7, garchomp_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, charizard_mega_y_g7, metagross_mega_1_g7, porygonz_1_g7, tapu_lele_1_g7, slowbro_mega_1_g7, mew_1_g7, magnezone_1_g7, altaria_mega_1_g7, gardevoir_mega_1_g7, genesect_1_g7, naganadel_1_g7, porygonz_2_g7, porygonz_3_g7, charizard_mega_x_3_g7, zeraora_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, tapu_bulu_1_g7, landorus_therian_3_g7, genesect_3_g7, nihilego_1_g7, metagross_mega_3_g7, volcanion_1_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, tapu_lele_3_g7, porygonz_5_g7];
tapu_fini_2_g7.lmatchups = [venusaur_mega_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, whimsicott_1_g7, salazzle_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, aron_1_g7, kartana_2_g7, heatran_2_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, genesect_1_g7, jumpluff_1_g7, slowbro_mega_1_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, magnezone_1_g7, meloetta_1_g7, mew_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, zeraora_1_g7, pinser_mega_1_g7, necrozma_1_g7, kartana_1_g7, hoopau_1_g7, heracross_mega_1_g7, crustle_1_g7, clefable_1_g7, porygonz_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, tapu_bulu_1_g7, genesect_3_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, tapu_lele_3_g7, registeel_2_g7, registeel_2_g7, porygonz_5_g7];
primarina_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, venusaur_mega_2_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, hoopau_2_g7, pyukumuku_1_g7, porygon2_1_g7, magearna_2_g7, whimsicott_1_g7, salazzle_1_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, smeargle_1_g7, kartana_2_g7, heatran_2_g7, tapu_fini_2_g7, manaphy_1_g7, kyurem_1_g7, hoopau_1_g7, heracross_mega_1_g7, zeraora_1_g7, necrozma_1_g7, kartana_1_g7, ferrothorn_1_g7, chansey_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, porygonz_1_g7, tapu_lele_1_g7, greninja_1_g7, jumpluff_1_g7, mew_1_g7, meloetta_1_g7, gardevoir_mega_1_g7, genesect_1_g7, naganadel_1_g7, clefable_1_g7, magnezone_1_g7, porygonz_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, volcanion_1_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, tapu_lele_3_g7, registeel_2_g7, registeel_2_g7];
blastoise_mega_1_g7.lmatchups = [jumpluff_1_g7, togekiss_2_g7, togekiss_1_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, gallade_mega_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, magearna_2_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, smeargle_1_g7, kartana_2_g7, heatran_2_g7, tapu_fini_2_g7, medicham_mega_1_g7, manaphy_1_g7, kyurem_1_g7, hoopau_1_g7, heracross_mega_1_g7, archeops_1_g7, volcarona_1_g7, zeraora_1_g7, sableye_mega_1_g7, necrozma_1_g7, kartana_1_g7, chansey_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, primarina_1_g7, tapu_fini_1_g7, kommoo_1_g7, gardevoir_mega_1_g7, aegislash_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_2_g7, magearna_1_g7, metagross_mega_1_g7, porygonz_1_g7, tapu_lele_1_g7, greninja_1_g7, mew_1_g7, meloetta_1_g7, magnezone_1_g7, clefable_1_g7, vivillon_1_g7, porygonz_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, porygonz_4_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, tapu_lele_3_g7, registeel_2_g7, registeel_2_g7];
archeops_1_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, garchomp_2_g7, magearna_2_g7, darmanitan_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, raikou_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, kartana_2_g7, tapu_fini_2_g7, greninja_2_g7, illumise_1_g7, sawk_1_g7, krookodile_1_g7, haxorus_1_g7, golem_1_g7, crustle_1_g7, deoxys_s_1_g7, blaziken_mega_1_g7, zeraora_1_g7, kartana_1_g7, mawile_mega_1_g7, ferrothorn_1_g7, garchomp_1_g7, aggron_mega_1_g7, celesteela_1_g7, chansey_1_g7, naganadel_1_g7, tapu_fini_1_g7, tyranitar_mega_1_g7, magnezone_1_g7, aegislash_1_g7, donphan_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, slowbro_mega_1_g7,greninja_1_g7, porygonz_2_g7, weavile_1_g7, zeraora_2_g7, type_null_1_g7, magnezone_2_g7, metagross_mega_3_g7, greninja_6_g7, zeraora_3_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, registeel_2_g7, registeel_2_g7, porygonz_5_g7];
zeraora_1_g7.lmatchups = [landorus_therian_2_g7, gardevoir_mega_1_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, whimsicott_1_g7, shedinja_1_g7, altaria_mega_2_g7, aron_1_g7, kartana_2_g7, victini_2_g7, dragonite_2_g7, illumise_1_g7, kyurem_1_g7, krookodile_1_g7, incineroar_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, mawile_mega_1_g7, necrozma_1_g7, kartana_1_g7, ferrothorn_1_g7, garchomp_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, venusaur_mega_1_g7, kommoo_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, dragonite_1_g7, donphan_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, tapu_lele_1_g7,landorus_therian_1_g7, aegislash_1_g7, altaria_mega_1_g7, clefable_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, dragonite_5_g7, sableye_mega_2_g7, diggersby_1_g7, serperior_1_g7, metagross_mega_4_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7];
zeraora_2_g7.lmatchups = [kyurem_1_g7, magearna_1_g7, dragonite_1_g7, dragonite_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, landorus_therian_1_g7, landorus_therian_2_g7,porygonz_2_g7, gardevoir_mega_1_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, ferrothorn_1_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tyranitar_mega_1_g7, victini_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, golem_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, clefable_1_g7, illumise_1_g7, shedinja_1_g7, whimsicott_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, salamence_1_g7, swampert_mega_1_g7, gallade_mega_1_g7, necrozma_2_g7, type_null_1_g7, gardevoir_mega_2_g7, garchomp_3_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, dragonite_5_g7, sableye_mega_2_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, donphan_3_g7, kartana_3_g7, porygonz_5_g7];
zeraora_3_g7.lmatchups = [kyurem_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, metagross_mega_3_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_2_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7,porygonz_2_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, ferrothorn_1_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tyranitar_mega_1_g7, zeraora_1_g7, zeraora_2_g7, victini_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, deoxys_s_1_g7, blaziken_mega_1_g7, shedinja_1_g7, darmanitan_1_g7, whimsicott_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, salamence_1_g7, swampert_mega_1_g7, gallade_mega_1_g7, type_null_1_g7, entei_1_g7, slaking_1_g7, tapu_bulu_1_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, registeel_2_g7, porygonz_5_g7];
zeraora_4_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_3_g7, kyurem_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, metagross_mega_4_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, dragonite_6_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7,porygonz_2_g7, donphan_1_g7, donphan_2_g7, donphan_3_g7, audino_mega_1_g7, altaria_mega_1_g7, aegislash_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_2_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tyranitar_mega_1_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, necrozma_1_g7, necrozma_2_g7, mawile_mega_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, golem_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, illumise_1_g7, darmanitan_1_g7, whimsicott_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, salamence_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, type_null_1_g7, slaking_1_g7, tapu_bulu_1_g7, registeel_1_g7, diggersby_1_g7, registeel_2_g7, registeel_2_g7, porygonz_5_g7];
volcarona_1_g7.lmatchups = [togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, donphan_2_g7, volcarona_2_g7, salamence_1_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, salazzle_1_g7, audino_mega_1_g7, altaria_mega_2_g7, aron_1_g7, kartana_2_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, sawk_1_g7, medicham_mega_1_g7, kyurem_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, blaziken_mega_1_g7, archeops_1_g7, zeraora_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, dragonite_1_g7,greninja_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, donphan_1_g7, kommoo_1_g7, naganadel_1_g7, primarina_1_g7, tapu_fini_1_g7, aggron_mega_1_g7, chansey_1_g7, garchomp_1_g7, heatran_1_g7, pinser_mega_1_g7, clefable_1_g7, porygonz_2_g7, weavile_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, garchomp_3_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, greninja_6_g7, rotom_heat_1_g7, zeraora_3_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
volcarona_2_g7.lmatchups = [landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, araquanid_1_g7, tyranitar_mega_1_g7, aron_1_g7, gardevoir_mega_1_g7, tapu_lele_1_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, manaphy_1_g7, landorus_therian_1_g7, greninja_1_g7, medicham_mega_1_g7, donphan_1_g7, audino_mega_1_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, aggron_mega_1_g7, smeargle_1_g7, tapu_fini_1_g7, primarina_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, pinser_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_2_g7, incineroar_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, vivillon_1_g7, darmanitan_1_g7, terrakion_1_g7, garchomp_2_g7, pheromosa_2_g7, pheromosa_3_g7, haxorus_2_g7, salamence_1_g7, pyukumuku_1_g7, weavile_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, gardevoir_mega_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, dragonite_5_g7, greninja_6_g7, zeraora_3_g7, diggersby_1_g7, donphan_3_g7, dragonite_6_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
victini_1_g7.lmatchups = [sableye_mega_1_g7, togekiss_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, haxorus_2_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, altaria_mega_2_g7, aron_1_g7, smeargle_1_g7, blacephalon_1_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, sawk_1_g7, manaphy_1_g7, kyurem_1_g7, krookodile_1_g7, incineroar_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, archeops_1_g7, zeraora_1_g7, garchomp_1_g7, heatran_1_g7, tyranitar_mega_1_g7, aggron_mega_1_g7, kommoo_1_g7, aegislash_1_g7, altaria_mega_1_g7, donphan_1_g7, landorus_therian_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, dragonite_1_g7, porygonz_1_g7, slowbro_mega_1_g7,greninja_1_g7, weavile_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, greninja_5_g7, nihilego_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, rotom_heat_1_g7, serperior_1_g7, donphan_3_g7, dragonite_6_g7, greninja_7_g7, registeel_2_g7];
victini_2_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, swampert_mega_1_g7,dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, kyurem_1_g7, charizard_mega_x_2_g7, manaphy_1_g7, jumpluff_1_g7, greninja_1_g7, slowbro_mega_1_g7, porygonz_1_g7, porygonz_2_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, tyranitar_mega_1_g7, tapu_lele_1_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, incineroar_1_g7, hoopau_1_g7, golem_1_g7, diancie_mega_1_g7, crustle_1_g7, clefable_1_g7, greninja_2_g7, tapu_fini_2_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, registeel_2_g7, porygonz_5_g7];
sableye_mega_1_g7.lmatchups = [smeargle_1_g7, kyurem_1_g7, togekiss_2_g7, carracosta_1_g7, volcarona_2_g7, hoopau_2_g7, haxorus_2_g7, pheromosa_3_g7, magearna_2_g7, terrakion_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, altaria_mega_2_g7, tapu_fini_2_g7, manaphy_1_g7, incineroar_1_g7, hoopau_1_g7, diancie_mega_1_g7, blaziken_mega_1_g7, zeraora_1_g7, mawile_mega_1_g7, primarina_1_g7, tapu_fini_1_g7, kommoo_1_g7, gardevoir_mega_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, tapu_lele_1_g7, slowbro_mega_1_g7,lopunny_mega_1_g7, volcarona_1_g7, clefable_1_g7, charizard_mega_x_3_g7, type_null_1_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, tapu_bulu_1_g7, talonflame_1_g7, nihilego_1_g7, volcanion_1_g7, porygonz_4_g7, sableye_mega_2_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, zapdos_1_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, registeel_2_g7];
sableye_mega_2_g7.lmatchups = [gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, magearna_1_g7, magearna_2_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, manaphy_1_g7,tapu_lele_1_g7, tapu_lele_2_g7, porygonz_4_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, audino_mega_1_g7, lopunny_mega_1_g7, smeargle_1_g7, tapu_fini_2_g7, primarina_1_g7, volcarona_1_g7, volcarona_2_g7, mawile_mega_1_g7, raikou_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, hoopau_2_g7, haxorus_1_g7, haxorus_2_g7, diancie_mega_1_g7, deoxys_s_2_g7, blaziken_mega_1_g7, clefable_1_g7, terrakion_1_g7, pyukumuku_1_g7, araquanid_1_g7, togekiss_1_g7, togekiss_2_g7, weavile_1_g7, type_null_1_g7, tapu_bulu_1_g7, talonflame_1_g7, nihilego_1_g7, volcanion_1_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, zapdos_1_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7];
pinser_mega_1_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, deoxys_s_2_g7, salamence_1_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, magearna_2_g7, terrakion_1_g7, whimsicott_1_g7, darmanitan_1_g7, salazzle_1_g7, slowbro_mega_2_g7, raikou_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, blacephalon_1_g7, victini_2_g7, dragonite_2_g7, sawk_1_g7, manaphy_1_g7, incineroar_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, mawile_mega_1_g7, necrozma_1_g7, heatran_1_g7, aggron_mega_1_g7, celesteela_1_g7, tyranitar_mega_1_g7, naganadel_1_g7, primarina_1_g7, genesect_1_g7, meloetta_1_g7, magnezone_1_g7, aegislash_1_g7, altaria_mega_1_g7, donphan_1_g7, mew_1_g7, charizard_mega_x_2_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, slowbro_mega_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, clefable_1_g7, porygonz_2_g7, weavile_1_g7, infernape_1_g7, zeraora_2_g7, type_null_1_g7, meloetta_2_g7, jumpluff_2_g7, entei_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, greninja_5_g7, metagross_mega_3_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, metagross_mega_4_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
necrozma_1_g7.lmatchups = [togekiss_1_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, deoxys_s_2_g7, volcarona_2_g7, hoopau_2_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, greninja_2_g7, manaphy_1_g7, kyurem_1_g7, incineroar_1_g7, victini_1_g7, sableye_mega_1_g7, heatran_1_g7, chansey_1_g7, aggron_mega_1_g7, tapu_fini_1_g7, genesect_1_g7, gardevoir_mega_1_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, dragonite_1_g7, magearna_1_g7, porygonz_1_g7, tapu_lele_1_g7, jumpluff_1_g7, meloetta_1_g7, magnezone_1_g7, aegislash_1_g7, volcarona_1_g7, clefable_1_g7, vivillon_1_g7, weavile_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, genesect_3_g7, greninja_5_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, zapdos_1_g7, dragonite_6_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
necrozma_2_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, charizard_mega_x_3_g7, manaphy_1_g7, kommoo_1_g7, jumpluff_1_g7, greninja_2_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_2_g7, garchomp_1_g7, celesteela_2_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, zeraora_1_g7, volcarona_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, blacephalon_1_g7, raikou_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, illumise_1_g7, vivillon_1_g7, shedinja_1_g7, darmanitan_1_g7, whimsicott_1_g7, terrakion_1_g7, umbreon_1_g7, pyukumuku_1_g7, araquanid_1_g7, carracosta_1_g7, weavile_1_g7, meloetta_2_g7, magnezone_2_g7, jumpluff_2_g7, vaporeon_1_g7, slaking_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, nihilego_1_g7, porygonz_4_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, porygonz_5_g7];
blacephalon_1_g7.lmatchups = [togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, hoopau_2_g7, araquanid_1_g7, porygon2_1_g7, pheromosa_3_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, gyarados_mega_4_g7, raikou_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, porygonz_2_g7, magnezone_1_g7, kartana_1_g7, kyurem_1_g7, naganadel_1_g7, dragonite_2_g7, charizard_mega_x_2_g7, kommoo_1_g7, manaphy_1_g7, landorus_therian_1_g7, greninja_1_g7,donphan_1_g7, meloetta_1_g7, lopunny_mega_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, dragonite_2_g7, greninja_2_g7, tapu_fini_2_g7, dragonite_1_g7, weavile_1_g7, zeraora_2_g7, magnezone_2_g7, vaporeon_1_g7, entei_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, registeel_2_g7];
mawile_mega_1_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, venusaur_mega_2_g7, swampert_mega_1_g7, donphan_2_g7, pheromosa_3_g7, magearna_2_g7, salazzle_1_g7, shedinja_1_g7, genesect_2_g7, smeargle_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, illumise_1_g7, krookodile_1_g7, incineroar_1_g7, blaziken_mega_1_g7, blastoise_mega_1_g7, victini_1_g7, necrozma_1_g7, garchomp_1_g7, heatran_1_g7, aggron_mega_1_g7, celesteela_1_g7, naganadel_1_g7, primarina_1_g7, tapu_fini_1_g7, donphan_1_g7, magnezone_1_g7, aegislash_1_g7, greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, magearna_1_g7, slowbro_mega_1_g7,volcarona_1_g7, vivillon_1_g7, charizard_mega_x_3_g7, infernape_1_g7, magnezone_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, greninja_5_g7, volcanion_1_g7, greninja_6_g7, rotom_heat_1_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, donphan_3_g7, kartana_3_g7, heatran_3_g7, registeel_2_g7];
raikou_1_g7.lmatchups = [landorus_therian_2_g7, dragonite_4_g7, dragonite_3_g7, swampert_mega_1_g7, donphan_2_g7, hoopau_2_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, whimsicott_1_g7, darmanitan_1_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, kommoo_1_g7, landorus_therian_1_g7, greninja_1_g7,tapu_lele_1_g7, porygonz_2_g7, donphan_1_g7, lopunny_mega_1_g7, garchomp_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tyranitar_mega_1_g7, zeraora_1_g7, victini_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, crustle_1_g7, blaziken_mega_1_g7, dragonite_2_g7, aron_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, type_null_1_g7, meloetta_2_g7, garchomp_3_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, dragonite_5_g7, greninja_6_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, donphan_3_g7, zeraora_4_g7, porygonz_5_g7];
kartana_1_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, dragonite_4_g7, carracosta_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, salamence_1_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, magearna_2_g7, darmanitan_1_g7, salazzle_1_g7, raikou_1_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7, kartana_2_g7, heatran_2_g7, victini_2_g7, greninja_2_g7, dragonite_2_g7, illumise_1_g7, sawk_1_g7, kyurem_1_g7, incineroar_1_g7, heracross_mega_1_g7, durant_1_g7, deoxys_s_1_g7, diancie_mega_1_g7, blaziken_mega_1_g7, victini_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, heatran_1_g7, celesteela_1_g7, naganadel_1_g7, kommoo_1_g7, genesect_1_g7, altaria_mega_1_g7, aegislash_1_g7, magnezone_1_g7, landorus_therian_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7,greninja_1_g7, volcarona_1_g7, porygonz_2_g7, charizard_mega_x_3_g7, infernape_1_g7, meloetta_2_g7, magnezone_2_g7, garchomp_3_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, metagross_mega_3_g7, dragonite_5_g7, greninja_6_g7, rotom_heat_1_g7, zeraora_3_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, lucario_mega_1_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, porygonz_5_g7];
kartana_2_g7.lmatchups = [togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, carracosta_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, pheromosa_3_g7, pheromosa_2_g7, magearna_2_g7, darmanitan_1_g7, salazzle_1_g7, raikou_1_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, magearna_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, kommoo_1_g7, genesect_1_g7, landorus_therian_1_g7, greninja_1_g7,porygonz_2_g7, donphan_1_g7, altaria_mega_1_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, mew_1_g7, lopunny_mega_1_g7, garchomp_1_g7, celesteela_1_g7, aggron_mega_1_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, dragonite_2_g7, illumise_1_g7, greninja_2_g7, victini_2_g7, charizard_mega_x_3_g7, meloetta_2_g7, magnezone_2_g7, garchomp_3_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, dragonite_5_g7, greninja_6_g7, zeraora_3_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, registeel_2_g7, porygonz_5_g7];
kartana_3_g7.lmatchups = [kyurem_1_g7, naganadel_1_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_4_g7, dragonite_5_g7, dragonite_6_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_1_g7, genesect_2_g7, genesect_3_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_6_g7, porygonz_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, meloetta_1_g7, meloetta_2_g7, mew_1_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, celesteela_1_g7, celesteela_2_g7, venusaur_mega_1_g7, zeraora_3_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, pinser_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, incineroar_1_g7, heracross_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, blaziken_mega_1_g7, illumise_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, zapdos_1_g7, carracosta_1_g7, togekiss_1_g7, togekiss_2_g7, infernape_1_g7, type_null_1_g7, entei_1_g7, talonflame_1_g7, rotom_heat_1_g7, lucario_mega_1_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, porygonz_5_g7];
krookodile_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, volcarona_2_g7, salamence_1_g7, araquanid_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, altaria_mega_2_g7, genesect_2_g7, smeargle_1_g7, kartana_2_g7, heatran_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, kyurem_1_g7, clefable_1_g7, heracross_mega_1_g7, diancie_mega_1_g7, durant_1_g7, volcarona_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, kartana_1_g7, ferrothorn_1_g7, celesteela_1_g7, genesect_1_g7, venusaur_mega_1_g7, kommoo_1_g7, naganadel_1_g7, primarina_1_g7, tapu_fini_1_g7, gardevoir_mega_1_g7, altaria_mega_1_g7, greninja_1_g7, meloetta_1_g7, jumpluff_1_g7, landorus_therian_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_y_g7, dragonite_1_g7, porygonz_1_g7, porygonz_2_g7, tapu_lele_1_g7, slowbro_mega_1_g7, porygonz_3_g7, infernape_1_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, genesect_3_g7, greninja_5_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, rotom_heat_1_g7, hoopau_3_g7, serperior_1_g7, dragonite_6_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
incineroar_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, donphan_2_g7, pyukumuku_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, terrakion_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, altaria_mega_2_g7, smeargle_1_g7, heatran_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, medicham_mega_1_g7, manaphy_1_g7, kyurem_1_g7, krookodile_1_g7, clefable_1_g7, heracross_mega_1_g7, durant_1_g7, golem_1_g7, archeops_1_g7, blastoise_mega_1_g7, blaziken_mega_1_g7, crustle_1_g7, diancie_mega_1_g7, volcarona_1_g7, primarina_1_g7, tapu_fini_1_g7, tyranitar_mega_1_g7, venusaur_mega_1_g7, chansey_1_g7, garchomp_1_g7, heatran_1_g7, gardevoir_mega_1_g7, kommoo_1_g7, altaria_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, porygonz_1_g7, tapu_lele_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, vivillon_1_g7, infernape_1_g7, magnezone_2_g7, tapu_lele_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, landorus_therian_3_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, greninja_6_g7, hoopau_3_g7, diggersby_1_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, greninja_7_g7, tapu_lele_3_g7];
hoopau_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, volcarona_2_g7, hoopau_2_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, altaria_mega_2_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, heatran_2_g7, dragonite_2_g7, sawk_1_g7, medicham_mega_1_g7, manaphy_1_g7, kyurem_1_g7, krookodile_1_g7, incineroar_1_g7, blaziken_mega_1_g7, heracross_mega_1_g7, diancie_mega_1_g7, durant_1_g7, crustle_1_g7, golem_1_g7, kartana_1_g7, archeops_1_g7, mawile_mega_1_g7, pinser_mega_1_g7, victini_1_g7, volcarona_1_g7, necrozma_1_g7, altaria_mega_1_g7, chansey_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, donphan_1_g7, gardevoir_mega_1_g7, genesect_1_g7, kommoo_1_g7, magnezone_1_g7,gyarados_mega_g7, gyarados_mega_2_g7, charizard_mega_x_2_g7, dragonite_1_g7, magearna_1_g7, porygonz_1_g7, tapu_lele_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, clefable_1_g7, vivillon_1_g7, weavile_1_g7, type_null_1_g7, magnezone_2_g7, gardevoir_mega_2_g7, slaking_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, dragonite_5_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, registeel_2_g7];
hoopau_2_g7.lmatchups = [landorus_therian_2_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, donphan_2_g7, salamence_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, manaphy_1_g7, genesect_2_g7, landorus_therian_1_g7, medicham_mega_1_g7,porygonz_1_g7, gardevoir_mega_1_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, magnezone_1_g7, aron_1_g7, lopunny_mega_1_g7, garchomp_1_g7, chansey_1_g7, aggron_mega_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, volcarona_1_g7, victini_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_2_g7, kartana_1_g7, krookodile_1_g7, incineroar_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, darmanitan_1_g7, terrakion_1_g7, magearna_2_g7, garchomp_2_g7, umbreon_1_g7, pheromosa_3_g7, pheromosa_2_g7, porygon2_1_g7, haxorus_2_g7, weavile_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, type_null_1_g7, magnezone_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, dragonite_5_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, registeel_2_g7];
hoopau_3_g7.lmatchups = [magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, genesect_1_g7, genesect_2_g7, genesect_3_g7, landorus_therian_1_g7, landorus_therian_3_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_2_g7, medicham_mega_1_g7,tapu_lele_1_g7, tapu_lele_2_g7, porygonz_1_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, magnezone_1_g7, magnezone_2_g7, aron_1_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, aggron_mega_1_g7, smeargle_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, victini_1_g7, sableye_mega_2_g7, pinser_mega_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, hoopau_1_g7, hoopau_2_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, vivillon_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, araquanid_1_g7, salamence_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, togekiss_1_g7, togekiss_2_g7, weavile_1_g7, infernape_1_g7, vaporeon_1_g7, slaking_1_g7, tapu_bulu_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, tapu_lele_3_g7];
heracross_mega_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, deoxys_s_2_g7, salamence_1_g7, hoopau_2_g7, garchomp_2_g7, magearna_2_g7, darmanitan_1_g7, salazzle_1_g7, altaria_mega_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, dragonite_2_g7, illumise_1_g7, medicham_mega_1_g7, deoxys_s_1_g7, durant_1_g7, celesteela_1_g7, heatran_1_g7, mawile_mega_1_g7, sableye_mega_1_g7, victini_1_g7, blaziken_mega_1_g7, volcarona_1_g7, archeops_1_g7, necrozma_1_g7, pinser_mega_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, magnezone_1_g7, aegislash_1_g7, gardevoir_mega_1_g7, genesect_1_g7, kommoo_1_g7, altaria_mega_1_g7, mew_1_g7, landorus_therian_1_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_2_g7, porygonz_1_g7, tapu_lele_1_g7,clefable_1_g7, vivillon_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, necrozma_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, slaking_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, metagross_mega_3_g7, volcanion_1_g7, porygonz_4_g7, sableye_mega_2_g7, hoopau_3_g7, diggersby_1_g7, magnezone_3_g7, heatran_3_g7, tapu_lele_3_g7];
haxorus_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, gallade_mega_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, hoopau_2_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, magearna_2_g7, terrakion_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, genesect_2_g7, kartana_2_g7, victini_2_g7, tapu_fini_2_g7, illumise_1_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, blastoise_mega_1_g7, hoopau_1_g7, durant_1_g7, golem_1_g7, crustle_1_g7, sableye_mega_1_g7, tyranitar_mega_1_g7, heatran_1_g7, kartana_1_g7, mawile_mega_1_g7, necrozma_1_g7, venusaur_mega_1_g7, aggron_mega_1_g7, celesteela_1_g7, chansey_1_g7, ferrothorn_1_g7, primarina_1_g7, tapu_fini_1_g7, aegislash_1_g7, altaria_mega_1_g7, donphan_1_g7, genesect_1_g7, landorus_therian_1_g7, lopunny_mega_1_g7, mew_1_g7, meloetta_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, tapu_lele_1_g7, slowbro_mega_1_g7,clefable_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, genesect_3_g7, volcanion_1_g7, registeel_1_g7, metagross_mega_4_g7, donphan_3_g7, registeel_2_g7];
haxorus_2_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, gallade_mega_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, charizard_mega_x_g7, genesect_1_g7, genesect_2_g7, landorus_therian_1_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, medicham_mega_1_g7, slowbro_mega_2_g7, slowbro_mega_1_g7, porygonz_2_g7, donphan_1_g7, audino_mega_1_g7, aegislash_1_g7, meloetta_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, volcarona_1_g7, victini_2_g7, pinser_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, mawile_mega_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, haxorus_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, blaziken_mega_1_g7, illumise_1_g7, salazzle_1_g7, whimsicott_1_g7, terrakion_1_g7, magearna_2_g7, garchomp_2_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, weavile_1_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, slaking_1_g7, landorus_therian_3_g7, genesect_3_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, greninja_6_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, registeel_2_g7, porygonz_5_g7];
golem_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, salamence_1_g7, haxorus_2_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, smeargle_1_g7, tapu_fini_2_g7, illumise_1_g7, medicham_mega_1_g7, kyurem_1_g7, krookodile_1_g7, heracross_mega_1_g7, heatran_1_g7, primarina_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, necrozma_1_g7, tapu_fini_1_g7, tyranitar_mega_1_g7, venusaur_mega_1_g7, aggron_mega_1_g7, celesteela_1_g7, chansey_1_g7, ferrothorn_1_g7, garchomp_1_g7, mawile_mega_1_g7, donphan_1_g7, genesect_1_g7, kommoo_1_g7, altaria_mega_1_g7, lopunny_mega_1_g7, mew_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, dragonite_1_g7, magearna_1_g7, tapu_lele_1_g7, slowbro_mega_1_g7,jumpluff_1_g7, landorus_therian_1_g7, clefable_1_g7, vivillon_1_g7, porygonz_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, tapu_lele_2_g7, jumpluff_2_g7, tapu_bulu_1_g7, landorus_therian_3_g7, sableye_mega_2_g7, donphan_3_g7, kartana_3_g7, tapu_lele_3_g7];
durant_1_g7.lmatchups = [porygonz_2_g7, celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, donphan_2_g7, salamence_1_g7, pyukumuku_1_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, magearna_2_g7, whimsicott_1_g7, darmanitan_1_g7, salazzle_1_g7, raikou_1_g7, genesect_2_g7, aron_1_g7, blacephalon_1_g7, victini_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, illumise_1_g7, sawk_1_g7, manaphy_1_g7, golem_1_g7, zeraora_1_g7, crustle_1_g7, archeops_1_g7, blastoise_mega_1_g7, blaziken_mega_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, garchomp_1_g7, celesteela_1_g7, aggron_mega_1_g7, dragonite_1_g7,greninja_1_g7, jumpluff_1_g7, landorus_therian_1_g7, magnezone_1_g7, aegislash_1_g7, donphan_1_g7, genesect_1_g7, kommoo_1_g7, naganadel_1_g7, primarina_1_g7, zeraora_2_g7, type_null_1_g7, magnezone_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, landorus_therian_3_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, porygonz_5_g7];
diancie_mega_1_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, porygonz_1_g7, venusaur_mega_2_g7, carracosta_1_g7, deoxys_s_2_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_2_g7, garchomp_2_g7, magearna_2_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, aron_1_g7, kartana_2_g7, tapu_fini_2_g7, greninja_2_g7, sawk_1_g7, manaphy_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, zeraora_1_g7, blastoise_mega_1_g7, blaziken_mega_1_g7, crustle_1_g7, venusaur_mega_1_g7, heatran_1_g7, mawile_mega_1_g7, necrozma_1_g7, aggron_mega_1_g7, celesteela_1_g7, chansey_1_g7, ferrothorn_1_g7, primarina_1_g7, tapu_fini_1_g7, genesect_1_g7, mew_1_g7, aegislash_1_g7, magnezone_1_g7, gyarados_mega_g7, gyarados_mega_3_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, tapu_lele_1_g7, slowbro_mega_1_g7, greninja_1_g7, clefable_1_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, genesect_3_g7, metagross_mega_3_g7, greninja_6_g7, zeraora_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7];
deoxys_s_1_g7.lmatchups = [togekiss_1_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, magearna_2_g7, darmanitan_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, shedinja_1_g7, genesect_2_g7, aron_1_g7, victini_2_g7, dragonite_2_g7, manaphy_1_g7, kyurem_1_g7, incineroar_1_g7, hoopau_1_g7, golem_1_g7, crustle_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, victini_1_g7, mawile_mega_1_g7, necrozma_1_g7, chansey_1_g7, ferrothorn_1_g7, aggron_mega_1_g7, primarina_1_g7, donphan_1_g7, gardevoir_mega_1_g7, genesect_1_g7, gyarados_mega_2_g7, charizard_mega_x_2_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, tapu_lele_1_g7, mew_1_g7, meloetta_1_g7, magnezone_1_g7, aegislash_1_g7, clefable_1_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, entei_1_g7, tapu_bulu_1_g7, genesect_3_g7, metagross_mega_3_g7, dragonite_5_g7, sableye_mega_2_g7, hoopau_3_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, donphan_3_g7, tapu_lele_3_g7, registeel_2_g7];
deoxys_s_2_g7.lmatchups = [togekiss_2_g7, celesteela_2_g7, gyarados_mega_5_g7, greninja_4_g7, tapu_lele_1_g7, dragonite_3_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, genesect_1_g7, greninja_1_g7, greninja_2_g7, slowbro_mega_1_g7, gardevoir_mega_1_g7, audino_mega_1_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, tyranitar_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_2_g7, volcarona_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, durant_1_g7, shedinja_1_g7, whimsicott_1_g7, umbreon_1_g7, hoopau_2_g7, volcarona_2_g7, pyukumuku_1_g7, araquanid_1_g7, weavile_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, genesect_3_g7, greninja_5_g7, greninja_6_g7, hoopau_3_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7];
sawk_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, salamence_1_g7, haxorus_2_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, aron_1_g7, victini_2_g7, tapu_fini_2_g7, dragonite_2_g7, sawk_1_g7, blastoise_mega_1_g7, clefable_1_g7, medicham_mega_1_g7, heracross_mega_1_g7, deoxys_s_1_g7, golem_1_g7, blaziken_mega_1_g7, gyarados_mega_g7, donphan_1_g7, sableye_mega_1_g7, ferrothorn_1_g7, kommoo_1_g7, zeraora_1_g7, primarina_1_g7, venusaur_mega_1_g7, mawile_mega_1_g7, necrozma_1_g7, aggron_mega_1_g7, celesteela_1_g7, tapu_fini_1_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, dragonite_1_g7, magearna_1_g7, metagross_mega_2_g7, metagross_mega_1_g7, slowbro_mega_1_g7,mew_1_g7, aegislash_1_g7, altaria_mega_1_g7, charizard_mega_x_3_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, charizard_mega_x_4_g7, metagross_mega_3_g7, sableye_mega_2_g7, metagross_mega_4_g7, donphan_3_g7, dragonite_6_g7];
crustle_1_g7.lmatchups = [, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, umbreon_1_g7, magearna_2_g7, whimsicott_1_g7, gyarados_mega_4_g7, slowbro_mega_2_g7, mew_2_g7, altaria_mega_2_g7, smeargle_1_g7, dragonite_2_g7, illumise_1_g7, sawk_1_g7, medicham_mega_1_g7, krookodile_1_g7, heracross_mega_1_g7, golem_1_g7, blastoise_mega_1_g7, sableye_mega_1_g7, kartana_1_g7, mawile_mega_1_g7, necrozma_1_g7, chansey_1_g7, ferrothorn_1_g7, garchomp_1_g7, aggron_mega_1_g7, primarina_1_g7, kommoo_1_g7, donphan_1_g7, gyarados_mega_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, slowbro_mega_1_g7,landorus_therian_1_g7, magnezone_1_g7, aegislash_1_g7, altaria_mega_1_g7, clefable_1_g7, gyarados_mega_2_g7, type_null_1_g7, magnezone_2_g7, vaporeon_1_g7, metagross_mega_3_g7, sableye_mega_2_g7, zeraora_3_g7, registeel_1_g7, magnezone_3_g7, metagross_mega_4_g7, donphan_3_g7, kartana_3_g7];
blaziken_mega_1_g7.lmatchups = [togekiss_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, garchomp_2_g7, gyarados_mega_4_g7, audino_mega_1_g7, slowbro_mega_2_g7, altaria_mega_2_g7, aron_1_g7, victini_2_g7, tapu_fini_2_g7, dragonite_2_g7, illumise_1_g7, manaphy_1_g7, golem_1_g7, crustle_1_g7, blastoise_mega_1_g7, victini_1_g7, necrozma_1_g7, kommoo_1_g7, garchomp_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, naganadel_1_g7, primarina_1_g7, tapu_fini_1_g7, meloetta_1_g7, magnezone_1_g7, altaria_mega_1_g7, donphan_1_g7, mew_1_g7, landorus_therian_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, dragonite_1_g7, tapu_lele_1_g7,slowbro_mega_1_g7, clefable_1_g7, charizard_mega_x_3_g7, meloetta_2_g7, tapu_lele_2_g7, garchomp_3_g7, vaporeon_1_g7, landorus_therian_3_g7, talonflame_1_g7, volcanion_1_g7, dragonite_5_g7, donphan_3_g7, dragonite_6_g7, tapu_lele_3_g7];
clefable_1_g7.lmatchups = [celesteela_2_g7, tapu_lele_1_g7, venusaur_mega_2_g7, deoxys_s_2_g7, donphan_2_g7, hoopau_2_g7, araquanid_1_g7, magearna_2_g7, salazzle_1_g7, audino_mega_1_g7, slowbro_mega_2_g7, raikou_1_g7, mew_2_g7, shedinja_1_g7, aron_1_g7, smeargle_1_g7, kartana_2_g7, kyurem_1_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, porygonz_1_g7, meloetta_1_g7, aegislash_1_g7, genesect_1_g7, naganadel_1_g7, aggron_mega_1_g7, celesteela_1_g7, ferrothorn_1_g7, heatran_1_g7, kartana_1_g7, mawile_mega_1_g7, victini_1_g7, durant_1_g7, tapu_fini_1_g7, magnezone_1_g7, jumpluff_1_g7, slowbro_mega_1_g7, venusaur_mega_1_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, genesect_3_g7, nihilego_1_g7, metagross_mega_3_g7, volcanion_1_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, lucario_mega_1_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7];
illumise_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, deoxys_s_2_g7, volcarona_2_g7, hoopau_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, magearna_2_g7, terrakion_1_g7, whimsicott_1_g7, gyarados_mega_4_g7, raikou_1_g7, shedinja_1_g7, altaria_mega_2_g7, genesect_2_g7, smeargle_1_g7, blacephalon_1_g7, heatran_2_g7, victini_2_g7, tapu_fini_2_g7, greninja_2_g7, dragonite_2_g7, hoopau_1_g7, incineroar_1_g7, manaphy_1_g7, krookodile_1_g7, clefable_1_g7, deoxys_s_1_g7, diancie_mega_1_g7, blastoise_mega_1_g7, greninja_1_g7, pinser_mega_1_g7, sableye_mega_1_g7, victini_1_g7, volcarona_1_g7, necrozma_1_g7, heatran_1_g7, chansey_1_g7, ferrothorn_1_g7, celesteela_1_g7, venusaur_mega_1_g7, jumpluff_1_g7, mew_1_g7, meloetta_1_g7, magnezone_1_g7, aegislash_1_g7, altaria_mega_1_g7, gardevoir_mega_1_g7, genesect_1_g7, kommoo_1_g7, naganadel_1_g7, primarina_1_g7, tapu_fini_1_g7, tyranitar_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, charizard_mega_y_g7, magearna_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, porygonz_1_g7, porygonz_2_g7, tapu_lele_1_g7, vivillon_1_g7, porygonz_3_g7, infernape_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
vivillon_1_g7.lmatchups = [landorus_therian_2_g7, greninja_4_g7, gallade_mega_1_g7, deoxys_s_2_g7, hoopau_2_g7, haxorus_2_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, salazzle_1_g7, gyarados_mega_4_g7, audino_mega_1_g7, raikou_1_g7, mew_2_g7, altaria_mega_2_g7, gyarados_mega_3_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_y_g7, porygonz_1_g7, porygonz_1_g7, greninja_1_g7, greninja_2_g7, lopunny_mega_1_g7, naganadel_1_g7, primarina_1_g7, tapu_fini_1_g7, tyranitar_mega_1_g7, garchomp_1_g7, kartana_1_g7, kartana_2_g7, pinser_mega_1_g7, sableye_mega_1_g7, volcarona_1_g7, zeraora_1_g7, archeops_1_g7, blaziken_mega_1_g7, crustle_1_g7, deoxys_s_1_g7, diancie_mega_1_g7, durant_1_g7, golem_1_g7, haxorus_1_g7, krookodile_1_g7, manaphy_1_g7, medicham_mega_1_g7, sawk_1_g7, blacephalon_1_g7, weavile_1_g7, infernape_1_g7, zeraora_2_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, registeel_1_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
shedinja_1_g7.lmatchups = [togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, gallade_mega_1_g7, carracosta_1_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, pheromosa_3_g7, umbreon_1_g7, garchomp_2_g7, magearna_2_g7, whimsicott_1_g7, darmanitan_1_g7, salazzle_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, kommoo_1_g7, landorus_therian_1_g7, jumpluff_1_g7, greninja_1_g7,porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, donphan_1_g7, altaria_mega_1_g7, aegislash_1_g7, mew_1_g7, heatran_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, blastoise_mega_1_g7, archeops_1_g7, volcarona_1_g7, victini_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, victini_2_g7, heatran_2_g7, blacephalon_1_g7, genesect_2_g7, aron_1_g7, smeargle_1_g7, vivillon_1_g7, altaria_mega_2_g7, weavile_1_g7, porygonz_3_g7, charizard_mega_x_3_g7, infernape_1_g7, type_null_1_g7, garchomp_3_g7, jumpluff_2_g7, entei_1_g7, slaking_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, rotom_heat_1_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, porygonz_5_g7];
salazzle_1_g7.lmatchups = [landorus_therian_2_g7, gyarados_mega_5_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, volcarona_2_g7, salamence_1_g7, hoopau_2_g7, araquanid_1_g7, porygon2_1_g7, pheromosa_3_g7, pheromosa_2_g7, umbreon_1_g7, garchomp_2_g7, terrakion_1_g7, darmanitan_1_g7, raikou_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_2_g7, dragonite_1_g7, charizard_mega_y_g7, charizard_mega_x_2_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7, greninja_1_g7,slowbro_mega_1_g7, porygonz_2_g7, donphan_1_g7, aegislash_1_g7, meloetta_1_g7, mew_1_g7, lopunny_mega_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, venusaur_mega_1_g7, tyranitar_mega_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, dragonite_2_g7, illumise_1_g7, victini_2_g7, heatran_2_g7, blacephalon_1_g7, slowbro_mega_2_g7, gyarados_mega_4_g7, zeraora_2_g7, meloetta_2_g7, magnezone_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, zapdos_1_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7, porygonz_5_g7];
darmanitan_1_g7.lmatchups = [togekiss_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, porygon2_1_g7, umbreon_1_g7, garchomp_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_x_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, victini_2_g7, sableye_mega_1_g7, necrozma_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, clefable_1_g7, illumise_1_g7, charizard_mega_x_3_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, garchomp_3_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, rotom_heat_1_g7, hoopau_3_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7];
whimsicott_1_g7.lmatchups = [gyarados_mega_5_g7, greninja_4_g7, venusaur_mega_2_g7, donphan_2_g7, volcarona_2_g7, hoopau_2_g7, pheromosa_3_g7, umbreon_1_g7, garchomp_2_g7, jumpluff_1_g7, gyarados_mega_g7, heatran_1_g7, heatran_2_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, naganadel_1_g7, metagross_mega_2_g7, metagross_mega_1_g7, dragonite_2_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, genesect_1_g7, genesect_2_g7, greninja_1_g7, greninja_2_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, ferrothorn_1_g7, venusaur_mega_1_g7, tyranitar_mega_1_g7, volcarona_1_g7, victini_2_g7, victini_1_g7, sableye_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, kartana_2_g7, kartana_1_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, diancie_mega_1_g7, sawk_1_g7, blaziken_mega_1_g7, salazzle_1_g7, darmanitan_1_g7, weavile_1_g7, charizard_mega_x_3_g7, meloetta_2_g7, tapu_lele_2_g7, garchomp_3_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, greninja_6_g7, sableye_mega_2_g7, hoopau_3_g7, diggersby_1_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
terrakion_1_g7.lmatchups = [celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, salamence_1_g7, pheromosa_3_g7, pheromosa_2_g7, garchomp_2_g7, magearna_2_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, manaphy_1_g7, kommoo_1_g7, genesect_1_g7, landorus_therian_1_g7, greninja_1_g7, greninja_2_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, donphan_1_g7, aegislash_1_g7, magnezone_1_g7, mew_1_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, necrozma_1_g7, mawile_mega_1_g7, kartana_2_g7, kartana_1_g7, krookodile_1_g7, heracross_mega_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, blaziken_mega_1_g7, clefable_1_g7, magnezone_2_g7, garchomp_3_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, metagross_mega_3_g7, dragonite_5_g7, greninja_6_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7];
umbreon_1_g7.lmatchups = [togekiss_2_g7, tapu_lele_1_g7, venusaur_mega_2_g7, gallade_mega_1_g7, carracosta_1_g7, volcarona_2_g7, haxorus_2_g7, araquanid_1_g7, pyukumuku_1_g7, pheromosa_3_g7, pheromosa_2_g7, kyurem_1_g7, magearna_1_g7, manaphy_1_g7, kommoo_1_g7, genesect_1_g7, jumpluff_1_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, gardevoir_mega_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_1_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, zeraora_1_g7, volcarona_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_2_g7, krookodile_1_g7, heracross_mega_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, blaziken_mega_1_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, terrakion_1_g7, magearna_2_g7, type_null_1_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, genesect_3_g7, dragonite_5_g7, porygonz_4_g7, sableye_mega_2_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, lucario_mega_1_g7, tapu_lele_3_g7, registeel_2_g7];
pheromosa_2_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, araquanid_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, kommoo_1_g7, genesect_1_g7,slowbro_mega_2_g7, slowbro_mega_1_g7, tapu_lele_1_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, meloetta_1_g7, mew_1_g7, mew_2_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, mawile_mega_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, illumise_1_g7, shedinja_1_g7, darmanitan_1_g7, whimsicott_1_g7, magearna_2_g7, garchomp_2_g7, charizard_mega_x_3_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, vaporeon_1_g7, entei_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, metagross_mega_3_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7];
pheromosa_3_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, gyarados_mega_5_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, carracosta_1_g7, swampert_mega_1_g7, deoxys_s_2_g7, donphan_2_g7, araquanid_1_g7, pyukumuku_1_g7, charizard_mega_x_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, manaphy_1_g7, kommoo_1_g7, tapu_lele_1_g7, gardevoir_mega_1_g7, donphan_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, aron_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, victini_1_g7, victini_2_g7, pinser_mega_1_g7, necrozma_1_g7, heracross_mega_1_g7, golem_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, darmanitan_1_g7, magearna_2_g7, garchomp_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, entei_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, dragonite_5_g7, sableye_mega_2_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7, tapu_lele_3_g7];
zapdos_1_g7.lmatchups = [naganadel_1_g7, metagross_mega_3_g7, dragonite_3_g7, dragonite_5_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_1_g7, genesect_3_g7, landorus_therian_1_g7, jumpluff_1_g7, jumpluff_2_g7,tapu_lele_1_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_3_g7, porygonz_4_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, magnezone_2_g7, magnezone_3_g7, meloetta_1_g7, meloetta_2_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, smeargle_1_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, volcarona_1_g7, victini_1_g7, victini_2_g7, raikou_1_g7, krookodile_1_g7, hoopau_2_g7, heracross_mega_1_g7, haxorus_1_g7, haxorus_2_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, vivillon_1_g7, whimsicott_1_g7, terrakion_1_g7, umbreon_1_g7, salamence_1_g7, carracosta_1_g7, type_null_1_g7, entei_1_g7, slaking_1_g7, nihilego_1_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, zeraora_4_g7, tapu_lele_3_g7, registeel_2_g7];
porygon2_1_g7.lmatchups = [jumpluff_1_g7, togekiss_2_g7, celesteela_2_g7, venusaur_mega_2_g7, gallade_mega_1_g7, deoxys_s_2_g7, volcarona_2_g7, araquanid_1_g7, pyukumuku_1_g7, kyurem_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, manaphy_1_g7, kommoo_1_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, audino_mega_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, zeraora_1_g7, volcarona_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_2_g7, kartana_1_g7, incineroar_1_g7, hoopau_1_g7, heracross_mega_1_g7, durant_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, whimsicott_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, infernape_1_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, slaking_1_g7, tapu_bulu_1_g7, nihilego_1_g7, porygonz_4_g7, sableye_mega_2_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, kartana_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
pyukumuku_1_g7.lmatchups = [celesteela_2_g7, gyarados_mega_5_g7, dragonite_3_g7, sableye_mega_1_g7, hoopau_2_g7, haxorus_2_g7, araquanid_1_g7, aegislash_1_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, charizard_mega_x_g7, kommoo_1_g7, jumpluff_1_g7, greninja_2_g7, medicham_mega_1_g7, porygonz_1_g7, audino_mega_1_g7, magnezone_1_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_2_g7, ferrothorn_1_g7, venusaur_mega_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, pinser_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, heracross_mega_1_g7, blaziken_mega_1_g7, vivillon_1_g7, salazzle_1_g7, whimsicott_1_g7, terrakion_1_g7, pheromosa_2_g7, weavile_1_g7, zeraora_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, garchomp_3_g7, jumpluff_2_g7, slaking_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, talonflame_1_g7, nihilego_1_g7, metagross_mega_3_g7, dragonite_5_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7];
araquanid_1_g7.lmatchups = [landorus_therian_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, carracosta_1_g7, salamence_1_g7, haxorus_2_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, dragonite_2_g7, manaphy_1_g7, jumpluff_1_g7, medicham_mega_1_g7,porygonz_1_g7, donphan_1_g7, magnezone_1_g7, aegislash_1_g7, aron_1_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, pinser_mega_1_g7, necrozma_1_g7, raikou_1_g7, kartana_2_g7, kartana_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, diancie_mega_1_g7, sawk_1_g7, crustle_1_g7, vivillon_1_g7, whimsicott_1_g7, terrakion_1_g7, weavile_1_g7, zeraora_2_g7, type_null_1_g7, magnezone_2_g7, tapu_lele_2_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, talonflame_1_g7, nihilego_1_g7, dragonite_5_g7, rotom_heat_1_g7, zeraora_3_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, zapdos_1_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7];
salamence_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, swampert_mega_1_g7, deoxys_s_2_g7, hoopau_1_g7, heatran_1_g7, naganadel_1_g7, magearna_1_g7, dragonite_2_g7, genesect_2_g7, genesect_1_g7, jumpluff_1_g7, greninja_1_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_2_g7, chansey_1_g7, venusaur_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, victini_2_g7, sableye_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, incineroar_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, crustle_1_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, shedinja_1_g7, whimsicott_1_g7, magearna_2_g7, umbreon_1_g7, pheromosa_3_g7, pheromosa_2_g7, porygon2_1_g7, haxorus_2_g7, pyukumuku_1_g7, weavile_1_g7, porygonz_3_g7, necrozma_2_g7, type_null_1_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, tapu_bulu_1_g7, genesect_3_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, registeel_1_g7, magnezone_3_g7, kartana_3_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
swampert_mega_1_g7.lmatchups = [porygonz_2_g7, jumpluff_2_g7, togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, gyarados_mega_5_g7, venusaur_mega_2_g7, gallade_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, kommoo_1_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_1_g7, audino_mega_1_g7, altaria_mega_2_g7, mew_2_g7, heatran_2_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, venusaur_mega_1_g7, smeargle_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, volcarona_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, kartana_1_g7, kartana_2_g7, heracross_mega_1_g7, diancie_mega_1_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, shedinja_1_g7, whimsicott_1_g7, umbreon_1_g7, porygon2_1_g7, pyukumuku_1_g7, araquanid_1_g7, deoxys_s_2_g7, necrozma_2_g7, type_null_1_g7, tapu_bulu_1_g7, talonflame_1_g7, sableye_mega_2_g7, diggersby_1_g7, serperior_1_g7, lucario_mega_1_g7, kartana_3_g7, porygonz_5_g7];
carracosta_1_g7.lmatchups = [gyarados_mega_5_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, gallade_mega_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, dragonite_2_g7, manaphy_1_g7, kommoo_1_g7, jumpluff_1_g7, greninja_1_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, smeargle_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, necrozma_1_g7, raikou_1_g7, heracross_mega_1_g7, haxorus_1_g7, clefable_1_g7, vivillon_1_g7, whimsicott_1_g7, garchomp_2_g7, porygon2_1_g7, haxorus_2_g7, salamence_1_g7, pyukumuku_1_g7, swampert_mega_1_g7, infernape_1_g7, zeraora_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, dragonite_5_g7, sableye_mega_2_g7, zeraora_3_g7, serperior_1_g7, donphan_3_g7, dragonite_6_g7];
gallade_mega_1_g7.lmatchups = [togekiss_2_g7, togekiss_1_g7, celesteela_2_g7, landorus_therian_2_g7, greninja_4_g7, venusaur_mega_2_g7, dragonite_4_g7, dragonite_3_g7, naganadel_1_g7, magearna_1_g7, dragonite_2_g7, dragonite_1_g7, kommoo_1_g7, genesect_1_g7, landorus_therian_1_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, slowbro_mega_2_g7, slowbro_mega_1_g7, tapu_lele_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, mew_1_g7, mew_2_g7, venusaur_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, necrozma_1_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, hoopau_1_g7, heracross_mega_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, clefable_1_g7, illumise_1_g7, salazzle_1_g7, whimsicott_1_g7, magearna_2_g7, garchomp_2_g7, salamence_1_g7, pyukumuku_1_g7, araquanid_1_g7, deoxys_s_2_g7, infernape_1_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, jumpluff_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, landorus_therian_3_g7, talonflame_1_g7, greninja_5_g7, volcanion_1_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, greninja_7_g7, tapu_lele_3_g7, porygonz_5_g7];
togekiss_1_g7.lmatchups = [registeel_1_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, jumpluff_1_g7, medicham_mega_1_g7, slowbro_mega_2_g7, slowbro_mega_1_g7, gardevoir_mega_1_g7, audino_mega_1_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, meloetta_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, aggron_mega_1_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, archeops_1_g7, zeraora_1_g7, victini_1_g7, sableye_mega_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_2_g7, durant_1_g7, diancie_mega_1_g7, blaziken_mega_1_g7, clefable_1_g7, vivillon_1_g7, salazzle_1_g7, whimsicott_1_g7, terrakion_1_g7, magearna_2_g7, umbreon_1_g7, haxorus_2_g7, hoopau_2_g7, volcarona_2_g7, pyukumuku_1_g7, carracosta_1_g7, celesteela_2_g7, zeraora_2_g7, necrozma_2_g7, type_null_1_g7, magnezone_2_g7, garchomp_3_g7, slaking_1_g7, landorus_therian_3_g7, talonflame_1_g7, nihilego_1_g7, metagross_mega_3_g7, rotom_heat_1_g7, zeraora_3_g7, diggersby_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, zeraora_4_g7, registeel_2_g7];
togekiss_2_g7.lmatchups = [registeel_1_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, charizard_mega_y_g7, manaphy_1_g7, genesect_1_g7, genesect_2_g7, jumpluff_1_g7, greninja_2_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, audino_mega_1_g7, aegislash_1_g7, magnezone_1_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, mew_2_g7, heatran_1_g7, heatran_2_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, smeargle_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, archeops_1_g7, zeraora_1_g7, volcarona_1_g7, necrozma_1_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_2_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, clefable_1_g7, vivillon_1_g7, shedinja_1_g7, salazzle_1_g7, whimsicott_1_g7, terrakion_1_g7, magearna_2_g7, hoopau_2_g7, volcarona_2_g7, pyukumuku_1_g7, carracosta_1_g7, venusaur_mega_2_g7, celesteela_2_g7, porygonz_3_g7, infernape_1_g7, zeraora_2_g7, necrozma_2_g7, meloetta_2_g7, magnezone_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, genesect_3_g7, talonflame_1_g7, nihilego_1_g7, metagross_mega_3_g7, volcanion_1_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, zeraora_4_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
weavile_1_g7.lmatchups = [crustle_1_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, naganadel_1_g7, magearna_1_g7, magearna_2_g7, charizard_mega_x_2_g7, kommoo_1_g7, genesect_1_g7, genesect_2_g7, landorus_therian_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, porygonz_2_g7, donphan_1_g7, donphan_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, lopunny_mega_1_g7, garchomp_2_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, zeraora_1_g7, sableye_mega_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, blaziken_mega_1_g7, clefable_1_g7, salazzle_1_g7, darmanitan_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, porygon2_1_g7, swampert_mega_1_g7, carracosta_1_g7, togekiss_1_g7, togekiss_2_g7, charizard_mega_x_3_g7, infernape_1_g7, zeraora_2_g7, type_null_1_g7, magnezone_2_g7, vaporeon_1_g7, entei_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, greninja_5_g7, greninja_6_g7, zeraora_3_g7, registeel_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
infernape_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_2_g7, jumpluff_1_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, porygonz_2_g7, gardevoir_mega_1_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, chansey_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, blacephalon_1_g7, raikou_1_g7, kartana_2_g7, hoopau_1_g7, haxorus_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, blaziken_mega_1_g7, clefable_1_g7, salazzle_1_g7, darmanitan_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, swampert_mega_1_g7, togekiss_1_g7, zeraora_2_g7, necrozma_2_g7, meloetta_2_g7, tapu_lele_2_g7, gardevoir_mega_2_g7, garchomp_3_g7, jumpluff_2_g7, vaporeon_1_g7, entei_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, talonflame_1_g7, nihilego_1_g7, metagross_mega_3_g7, dragonite_5_g7, sableye_mega_2_g7, zeraora_3_g7, registeel_1_g7, zapdos_1_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
type_null_1_g7.lmatchups = [tapu_lele_1_g7, tapu_lele_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_3_g7, manaphy_1_g7, kommoo_1_g7, jumpluff_1_g7, greninja_2_g7, medicham_mega_1_g7, porygonz_1_g7, gardevoir_mega_1_g7, audino_mega_1_g7, magnezone_1_g7, aron_1_g7, mew_1_g7, lopunny_mega_1_g7, celesteela_2_g7, smeargle_1_g7, tapu_fini_1_g7, zeraora_1_g7, volcarona_1_g7, necrozma_2_g7, blacephalon_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, blaziken_mega_1_g7, illumise_1_g7, vivillon_1_g7, salazzle_1_g7, whimsicott_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, carracosta_1_g7, gallade_mega_1_g7, togekiss_2_g7, magnezone_2_g7, gardevoir_mega_2_g7, vaporeon_1_g7, tapu_bulu_1_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, nihilego_1_g7, volcanion_1_g7, porygonz_4_g7, serperior_1_g7, magnezone_3_g7, lucario_mega_1_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
vaporeon_1_g7.lmatchups = [gyarados_mega_3_g7, gyarados_mega_4_g7, kyurem_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, kommoo_1_g7, jumpluff_1_g7, jumpluff_2_g7, magnezone_1_g7, magnezone_2_g7, mew_2_g7, ferrothorn_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, smeargle_1_g7, tapu_fini_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_1_g7, sableye_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, hoopau_1_g7, hoopau_2_g7, heracross_mega_1_g7, vivillon_1_g7, shedinja_1_g7, whimsicott_1_g7, pyukumuku_1_g7, tapu_bulu_1_g7, volcanion_1_g7, dragonite_5_g7, sableye_mega_2_g7, rotom_heat_1_g7, zeraora_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, registeel_2_g7];
entei_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_3_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, meloetta_1_g7, meloetta_2_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, sableye_mega_1_g7, necrozma_1_g7, necrozma_2_g7, krookodile_1_g7, hoopau_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, crustle_1_g7, clefable_1_g7, vivillon_1_g7, terrakion_1_g7, umbreon_1_g7, porygon2_1_g7, pyukumuku_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, togekiss_1_g7, togekiss_2_g7, type_null_1_g7, vaporeon_1_g7, salamence_1_g7, slaking_1_g7, landorus_therian_3_g7, greninja_5_g7, nihilego_1_g7, volcanion_1_g7, porygonz_4_g7, greninja_6_g7, sableye_mega_2_g7, diggersby_1_g7, donphan_3_g7, dragonite_6_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7];
slaking_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, landorus_therian_1_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, magnezone_1_g7, magnezone_2_g7, aron_1_g7, lopunny_mega_1_g7, heatran_1_g7, garchomp_1_g7, chansey_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, venusaur_mega_2_g7, zeraora_2_g7, sableye_mega_1_g7, pinser_mega_1_g7, mawile_mega_1_g7, incineroar_1_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, illumise_1_g7, salazzle_1_g7, whimsicott_1_g7, pheromosa_2_g7, pheromosa_3_g7, salamence_1_g7, swampert_mega_1_g7, gallade_mega_1_g7, weavile_1_g7, infernape_1_g7, type_null_1_g7, vaporeon_1_g7, ferrothorn_1_g7, greninja_5_g7, metagross_mega_3_g7, dragonite_5_g7, greninja_6_g7, sableye_mega_2_g7, registeel_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
tapu_bulu_1_g7.lmatchups = [kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_4_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, genesect_1_g7, genesect_2_g7, greninja_1_g7, greninja_4_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, donphan_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, mew_1_g7, heatran_1_g7, heatran_2_g7, garchomp_2_g7, garchomp_3_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, archeops_1_g7, volcarona_1_g7, victini_1_g7, victini_2_g7, pinser_mega_1_g7, blacephalon_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, incineroar_1_g7, hoopau_2_g7, haxorus_2_g7, durant_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, salazzle_1_g7, darmanitan_1_g7, togekiss_1_g7, infernape_1_g7, entei_1_g7, slaking_1_g7, landorus_therian_3_g7, charizard_mega_x_4_g7, genesect_3_g7, talonflame_1_g7, greninja_5_g7, nihilego_1_g7, metagross_mega_3_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, greninja_6_g7, rotom_heat_1_g7, diggersby_1_g7, serperior_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, dragonite_6_g7, kartana_3_g7, heatran_3_g7, porygonz_5_g7];
talonflame_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, charizard_mega_x_g7, charizard_mega_x_3_g7, manaphy_1_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7, greninja_2_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_2_g7, porygonz_3_g7, donphan_1_g7, donphan_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, meloetta_1_g7, meloetta_2_g7, mew_1_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, victini_1_g7, victini_2_g7, necrozma_1_g7, raikou_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, terrakion_1_g7, porygon2_1_g7, salamence_1_g7, carracosta_1_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, nihilego_1_g7, volcanion_1_g7, dragonite_5_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, magnezone_3_g7, zapdos_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
nihilego_1_g7.lmatchups = [dragonite_5_g7, gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, metagross_mega_1_g7, metagross_mega_2_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, manaphy_1_g7, landorus_therian_1_g7, landorus_therian_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7, medicham_mega_1_g7,tapu_lele_1_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, meloetta_1_g7, aron_1_g7, mew_1_g7, lopunny_mega_1_g7, heatran_2_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, ferrothorn_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, tyranitar_mega_1_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, pinser_mega_1_g7, necrozma_1_g7, mawile_mega_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, hoopau_1_g7, hoopau_2_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, weavile_1_g7, vaporeon_1_g7, slaking_1_g7, metagross_mega_3_g7, greninja_6_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, magnezone_3_g7, metagross_mega_4_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, kartana_3_g7, zeraora_4_g7, greninja_7_g7, registeel_2_g7];
volcanion_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, charizard_mega_x_2_g7, charizard_mega_x_4_g7, kommoo_1_g7, landorus_therian_2_g7, landorus_therian_3_g7, jumpluff_1_g7, jumpluff_2_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_2_g7, magnezone_1_g7, magnezone_2_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, mew_1_g7, mew_2_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, smeargle_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_2_g7, necrozma_2_g7, blacephalon_1_g7, raikou_1_g7, kartana_1_g7, hoopau_1_g7, hoopau_2_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, vivillon_1_g7, salazzle_1_g7, terrakion_1_g7, pheromosa_3_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, swampert_mega_1_g7, togekiss_1_g7, slaking_1_g7, nihilego_1_g7, medicham_mega_1_g7, dragonite_5_g7, porygonz_4_g7, rotom_heat_1_g7, zeraora_3_g7, hoopau_3_g7, diggersby_1_g7, magnezone_3_g7, zapdos_1_g7, lucario_mega_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, tapu_lele_3_g7, porygonz_5_g7];
rotom_heat_1_g7.lmatchups = [kyurem_1_g7, naganadel_1_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7, greninja_6_g7, medicham_mega_1_g7,tapu_lele_2_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, porygonz_4_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, chansey_1_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, tyranitar_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, volcarona_2_g7, victini_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, necrozma_2_g7, blacephalon_1_g7, raikou_1_g7, kartana_2_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, vivillon_1_g7, salazzle_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, weavile_1_g7, infernape_1_g7, type_null_1_g7, entei_1_g7, slaking_1_g7, nihilego_1_g7, zeraora_3_g7, hoopau_3_g7, registeel_1_g7, diggersby_1_g7, serperior_1_g7, zapdos_1_g7, lucario_mega_1_g7, dragonite_6_g7, zeraora_4_g7, greninja_7_g7, tapu_lele_3_g7, registeel_2_g7, porygonz_5_g7];
registeel_1_g7.lmatchups = [gyarados_mega_2_g7, gyarados_mega_3_g7, dragonite_5_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_3_g7, jumpluff_1_g7, greninja_2_g7, medicham_mega_1_g7,donphan_1_g7, donphan_2_g7, audino_mega_1_g7, meloetta_1_g7, mew_2_g7, lopunny_mega_1_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, zeraora_1_g7, volcarona_2_g7, victini_1_g7, pinser_mega_1_g7, necrozma_2_g7, blacephalon_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, incineroar_1_g7, heracross_mega_1_g7, haxorus_2_g7, deoxys_s_2_g7, sawk_1_g7, blaziken_mega_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, pyukumuku_1_g7, araquanid_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, entei_1_g7, tapu_bulu_1_g7, talonflame_1_g7, volcanion_1_g7, diggersby_1_g7, lucario_mega_1_g7, donphan_3_g7, greninja_7_g7, heatran_3_g7, registeel_2_g7];
registeel_2_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, dragonite_1_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, manaphy_1_g7, kommoo_1_g7, landorus_therian_1_g7, landorus_therian_3_g7, jumpluff_1_g7, greninja_2_g7, greninja_7_g7, medicham_mega_1_g7,donphan_1_g7, donphan_2_g7, donphan_3_g7, audino_mega_1_g7, meloetta_1_g7, mew_2_g7, heatran_3_g7, garchomp_1_g7, smeargle_1_g7, tapu_fini_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, victini_1_g7, pinser_mega_1_g7, necrozma_2_g7, blacephalon_1_g7, raikou_1_g7, kartana_1_g7, kartana_3_g7, incineroar_1_g7, heracross_mega_1_g7, golem_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, illumise_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, swampert_mega_1_g7, gallade_mega_1_g7, tapu_bulu_1_g7, talonflame_1_g7, volcanion_1_g7, diggersby_1_g7, lucario_mega_1_g7];
diggersby_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, dragonite_1_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, manaphy_1_g7, genesect_3_g7, landorus_therian_2_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7, greninja_6_g7, medicham_mega_1_g7, slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, porygonz_4_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, aron_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, garchomp_1_g7, garchomp_3_g7, celesteela_1_g7, aggron_mega_1_g7, smeargle_1_g7, volcarona_1_g7, victini_1_g7, pinser_mega_1_g7, blacephalon_1_g7, kartana_1_g7, kartana_2_g7, krookodile_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, illumise_1_g7, vivillon_1_g7, darmanitan_1_g7, terrakion_1_g7, pheromosa_2_g7, pheromosa_3_g7, salamence_1_g7, carracosta_1_g7, gallade_mega_1_g7, weavile_1_g7, infernape_1_g7, type_null_1_g7, slaking_1_g7, lucario_mega_1_g7, donphan_3_g7, kartana_3_g7, greninja_7_g7, heatran_3_g7, tapu_lele_3_g7, porygonz_5_g7];
serperior_1_g7.lmatchups = [kyurem_1_g7, naganadel_1_g7, dragonite_3_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_1_g7, genesect_2_g7, genesect_3_g7, greninja_1_g7, greninja_4_g7, greninja_6_g7, porygonz_2_g7, audino_mega_1_g7, lopunny_mega_1_g7, ferrothorn_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, volcarona_1_g7, volcarona_2_g7, blacephalon_1_g7, kartana_2_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, heracross_mega_1_g7, deoxys_s_1_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, vivillon_1_g7, salazzle_1_g7, darmanitan_1_g7, pheromosa_2_g7, pheromosa_3_g7, salamence_1_g7, togekiss_1_g7, talonflame_1_g7, volcanion_1_g7, registeel_1_g7, zeraora_4_g7, heatran_3_g7, registeel_2_g7, porygonz_5_g7];
lucario_mega_1_g7.lmatchups = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, kommoo_1_g7, genesect_2_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_4_g7, greninja_5_g7, greninja_6_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, porygonz_3_g7, porygonz_4_g7, donphan_1_g7, donphan_2_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, mew_1_g7, lopunny_mega_1_g7, garchomp_2_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, tapu_fini_2_g7, primarina_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, pinser_mega_1_g7, necrozma_1_g7, necrozma_2_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, hoopau_1_g7, hoopau_2_g7, heracross_mega_1_g7, haxorus_1_g7, golem_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, pheromosa_2_g7, pheromosa_3_g7, zapdos_1_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, carracosta_1_g7, entei_1_g7, talonflame_1_g7, serperior_1_g7, donphan_3_g7, dragonite_6_g7, zeraora_4_g7, heatran_3_g7];

//pokemon list
let pokemon_list_gen7 = [gyarados_mega_g7, gyarados_mega_2_g7, gyarados_mega_3_g7, gyarados_mega_4_g7, gyarados_mega_5_g7, kyurem_1_g7, naganadel_1_g7, metagross_mega_1_g7, metagross_mega_2_g7, metagross_mega_3_g7, metagross_mega_4_g7, magearna_1_g7, magearna_2_g7, dragonite_1_g7, dragonite_2_g7, dragonite_3_g7, dragonite_4_g7, dragonite_5_g7, dragonite_6_g7, charizard_mega_y_g7, charizard_mega_x_g7, charizard_mega_x_2_g7, charizard_mega_x_3_g7, charizard_mega_x_4_g7, manaphy_1_g7, kommoo_1_g7, genesect_1_g7, genesect_2_g7, genesect_3_g7, landorus_therian_1_g7, landorus_therian_2_g7, landorus_therian_3_g7, jumpluff_1_g7, jumpluff_2_g7, greninja_1_g7, greninja_2_g7, greninja_4_g7, greninja_5_g7, greninja_6_g7, greninja_7_g7, medicham_mega_1_g7,slowbro_mega_1_g7, slowbro_mega_2_g7, tapu_lele_1_g7, tapu_lele_2_g7, tapu_lele_3_g7, porygonz_1_g7, porygonz_2_g7, porygonz_3_g7, porygonz_4_g7, porygonz_5_g7, gardevoir_mega_1_g7, gardevoir_mega_2_g7, donphan_1_g7, donphan_2_g7, donphan_3_g7, audino_mega_1_g7, altaria_mega_1_g7, altaria_mega_2_g7, aegislash_1_g7, magnezone_1_g7, magnezone_2_g7, magnezone_3_g7, meloetta_1_g7, meloetta_2_g7, aron_1_g7, mew_1_g7, mew_2_g7, lopunny_mega_1_g7, heatran_1_g7, heatran_2_g7, heatran_3_g7, garchomp_1_g7, garchomp_2_g7, garchomp_3_g7, ferrothorn_1_g7, chansey_1_g7, celesteela_1_g7, celesteela_2_g7, aggron_mega_1_g7, venusaur_mega_1_g7, venusaur_mega_2_g7, smeargle_1_g7, tyranitar_mega_1_g7, tapu_fini_1_g7, tapu_fini_2_g7, primarina_1_g7, blastoise_mega_1_g7, archeops_1_g7, zeraora_1_g7, zeraora_2_g7, zeraora_3_g7, zeraora_4_g7, volcarona_1_g7, volcarona_2_g7, victini_1_g7, victini_2_g7, sableye_mega_1_g7, sableye_mega_2_g7, pinser_mega_1_g7, necrozma_1_g7, necrozma_2_g7, blacephalon_1_g7, mawile_mega_1_g7, raikou_1_g7, kartana_1_g7, kartana_2_g7, kartana_3_g7, krookodile_1_g7, incineroar_1_g7, hoopau_1_g7, hoopau_2_g7, hoopau_3_g7, heracross_mega_1_g7, haxorus_1_g7, haxorus_2_g7, golem_1_g7, durant_1_g7, diancie_mega_1_g7, deoxys_s_1_g7, deoxys_s_2_g7, sawk_1_g7, crustle_1_g7, blaziken_mega_1_g7, clefable_1_g7, illumise_1_g7, vivillon_1_g7, shedinja_1_g7, salazzle_1_g7, darmanitan_1_g7, whimsicott_1_g7, terrakion_1_g7, umbreon_1_g7, pheromosa_2_g7, pheromosa_3_g7, zapdos_1_g7, porygon2_1_g7, pyukumuku_1_g7, araquanid_1_g7, salamence_1_g7, swampert_mega_1_g7, carracosta_1_g7, gallade_mega_1_g7, togekiss_1_g7, togekiss_2_g7, weavile_1_g7, infernape_1_g7, type_null_1_g7, vaporeon_1_g7, entei_1_g7, slaking_1_g7, tapu_bulu_1_g7, talonflame_1_g7, nihilego_1_g7, volcanion_1_g7, rotom_heat_1_g7, registeel_1_g7, registeel_2_g7, diggersby_1_g7, serperior_1_g7, lucario_mega_1_g7];


//random teams mons
let rand1 = new pokemon("", "Weavile", "Leftovers", "Jolly", "252 HP / 4 Atk / 252 Spe", "Pressure", "Protect", "Substitute", "Icicle Crash", "Spite");
let rand2 = new pokemon("", "Klinklang", "Occa Berry", "Adamant", "160 HP / 244 Atk / 104 Spe", "Clear Body", "Substitute", "Magnet Rise", "Shift Gear", "Gear Grind");
let rand3 = new pokemon("", "Sawk", "Iapapa Berry", "Adamant", "252 Atk / 4 SpD / 252 Spe", "Sturdy", "Close Combat", "Poison Jab", "Taunt", "Rock Slide");
let rand4 = new pokemon("", "Kyurem", "Haban Berry", "Modest", "40 HP / 252 SpA / 80 SpD / 136 Spe", "Pressure", "Freeze-Dry", "Draco Meteor", "Laser Focus", "Glaciate");
let rand5 = new pokemon("", "Clefable", "Babiri Berry", "Bold", "248 HP / 228 Def / 32 Spe", "Magic Guard", "Counter", "Soft-Boiled", "Moonblast", "Cosmic Power");
let rand6 = new pokemon("", "Liepard", "Bright Powder", "Impish", "248 HP / 8 Atk / 252 Def", "Prankster", "Swagger", "Protect", "Substitute", "Throat Chop");
let rand7 = new pokemon("", "Incineroar", "Rocky Helmet", "Impish", "200 HP / 36 Atk / 252 Def / 20 Spe", "Intimidate", "Bulk Up", "Flare Blitz", "Darkest Lariat", "Flame Charge");
let rand8 = new pokemon("", "Zeraora", "Air Balloon", "Jolly", "252 Atk / 4 SpD / 252 Spe", "Volt Absorb", "Substitute", "Plasma Fists", "Close Combat", "Outrage");
let rand9 = new pokemon("", "Silvally", "Fairy Memory", "Careful", "252 HP / 4 Atk / 252 SpD", "RKS System", "Rest", "Multi-Attack", "Snarl", "Rain Dance");
let rand10 = new pokemon("", "Reuniclus", "Life Orb", "Modest", "248 HP / 136 SpA / 124 SpD", "Magic Guard", "Psychic", "Shadow Ball", "Laser Focus", "Recover");
let rand11 = new pokemon("", "Charizard", "Petaya Berry", "Timid", "76 HP / 12 Def / 168 SpA / 252 Spe", "Blaze", "Substitute", "Blast Burn", "Air Slash", "Sunny Day");
let rand13 = new pokemon("", "Vespiquen", "Sitrus Berry", "Calm", "248 HP / 84 SpD / 176 Spe", "Pressure", "Defend Order", "Roost", "Infestation", "Toxic");
let rand14 = new pokemon("", "Magikarp", "Leftovers", "Bold", "252 HP / 4 Atk / 252 Def", "Swift Swim", "Celebrate", "Happy Hour", "Splash", "Tackle");
let rand15 = new pokemon("", "Feebas", "Binding Band", "Modest", "252 HP / 252 SpA / 4 SpD", "Swift Swim", "Hypnosis", "Mirror Coat", "Whirlpool", "Brine");
let rand16 = new pokemon("", "Silvally", "Grass Memory", "Adamant", "252 HP / 92 Atk / 32 Def / 80 SpD / 52 Spe", "RKS System", "Swords Dance", "Multi-Attack", "Imprison", "Iron Defense");
let rand17 = new pokemon("", "Silvally", "Bug Memory", "Careful", "252 HP / 44 Def / 208 SpD / 4 Spe", "RKS System", "Rest", "Parting Shot", "Iron Defense", "Multi-Attack");
let rand18 = new pokemon("", "Silvally", "Dark Memory", "Adamant", "252 HP / 112 Atk / 52 Def / 68 SpD / 24 Spe", "RKS System", "Tailwind", "Multi-Attack", "Outrage", "Snarl");
let rand19 = new pokemon("", "Silvally", "Electric Memory", "Bold","248 HP / 72 Def / 168 SpD / 20 Spe", "RKS System", "Rest", "Parting Shot", "Thunderbolt", "Ice Beam");
let rand20 = new pokemon("", "Silvally", "Fire Memory", "Careful", "252 HP / 80 Def / 176 SpD", "RKS System", "Rest", "Swords Dance", "Parting Shot", "Multi-Attack");
let rand21 = new pokemon("", "Silvally", "Dragon Memory", "Impish", "252 HP / 192 Def / 64 Spe", "RKS System", "Imprison", "Multi-Attack", "Iron Defense", "Rest");
let rand22 = new pokemon("", "Silvally", "Fighting Memory", "Impish", "232 HP / 96 Atk / 176 Def / 4 Spe", "RKS System", "Parting Shot", "Iron Defense", "Multi-Attack", "Rest");
let rand23 = new pokemon("", "Milotic", "Flame Orb", "Bold", "252 HP / 252 Def / 4 SpD", "Marvel Scale", "Hypnosis", "Recover", "Surf", "Coil");
let rand24 = new pokemon("", "Silvally", "Flying Memory", "Adamant", "96 HP / 252 Atk / 4 SpD / 156 Spe", "RKS System", "Swords Dance", "Multi-Attack", "Flame Charge", "Iron Defense");
let rand25 = new pokemon("", "Silvally", "Ghost Memory", "Adamant", "32 HP / 252 Atk / 4 SpD / 220 Spe", "RKS System", "Rest", "Parting Shot", "Multi-Attack", "Ice Fang");
let rand26 = new pokemon("", "Silvally", "Ground Memory", "Impish", "232 HP / 96 Atk / 176 Def / 4 Spe", "RKS System", "Rest", "Iron Defense", "Multi-Attack", "Snarl");
let rand27 = new pokemon("", "Ninjask", "Liechi Berry", "Adamant", "4 HP / 252 Atk / 252 Spe","Speed Boost", "Flail", "Protect", "Substitute", "Acrobatics");
let rand28 = new pokemon("", "Silvally", "Ice Memory", "Impish", "248 HP / 252 Def / 8 Spe", "RKS System", "Rest", "Iron Defense", "Multi-Attack", "Snarl");
let rand29 = new pokemon("", "Silvally", "Poison Memory", "Careful", "248 HP / 140 Def / 120 SpD", "RKS System", "Multi-Attack", "Iron Defense", "Swords Dance", "Rest");
let rand30 = new pokemon("", "Silvally", "Psychic Memory", "Impish", "248 HP / 220 Def / 40 Spe", "RKS System", "Rest", "Iron Defense", "Multi-Attack", "Imprison");
let rand31 = new pokemon("", "Silvally", "Rock Memory", "Careful", "252 HP / 56 Def / 176 SpD / 24 Spe", "RKS System", "Rest", "Snarl", "Swords Dance", "Multi-Attack");
let rand32 = new pokemon("", "Silvally", "Steel Memory", "Impish", "248 HP / 252 Def / 8 Spe", "RKS System", "Rest", "Parting Shot", "Multi-Attack", "Flame Charge");
let rand33 = new pokemon("", "Silvally", "Throat Spray", "Modest", "112 HP / 248 SpA / 4 SpD / 144 Spe", "RKS System", "Metal Sound", "Snarl", "Hyper Beam", "Hyper Voice");
let rand34 = new pokemon("", "Tyranitar", "Weakness Policy", "Careful", "252 HP / 4 SpD / 252 Spe", "Sand Stream", "Stone Edge", "Iron Head", "Snarl", "Poison Jab");
let rand35 = new pokemon("", "Excadrill", "Assault Vest", "Jolly", "108 Atk / 148 SpD / 252 Spe", "Mold Breaker", "Earthquake", "Iron Head", "Stomping Tantrum", "Poison Jab");
let rand36 = new pokemon("", "Sylveon", "Power Herb", "Relaxed", "52 HP / 248 Def / 208 SpA", "Pixilate", "Skull Bash", "Hyper Voice", "Hyper Beam", "Fake Tears");
let rand37 = new pokemon("", "Trevenant", "Choice Band", "Adamant", "208 HP / 252 Atk / 48 Spe", "Frisk", "Horn Leech", "Wood Hammer", "Phantom Force", "Shadow Claw");
let rand38 = new pokemon("", "Sylveon", "Choice Band", "Adamant", "136 HP / 252 Atk / 76 Def / 44 Spe", "Pixilate", "Quick Attack", "Giga Impact", "Double Edge", "Double Kick");
let rand39 = new pokemon("", "Mew", "Normalium Z", "Calm", "248 HP / 176 Def / 84 SpD", "Synchronize", "Thunder Wave", "Light Screen", "Reflect", "Transform");
let rand40 = new pokemon("", "Ursaring", "Normalium Z", "Careful", "248 HP / 64 Atk / 192 SpD / 4 Spe", "Guts", "Yawn", "Protect", "Belly Drum", "Double-Edge");
let rand41 = new pokemon("", "Jynx", "Fightinium Z", "Timid", "252 SpA / 4 SpD / 252 Spe", "Dry Skin", "Substitute", "Lovely Kiss", "Ice Beam", "Focus Blast");
let rand42 = new pokemon("", "Tangrowth", "Firium Z", "Timid", "248 HP / 8 SpD / 252 Spe", "Chlorophyll", "Sunny Day", "Sleep Powder", "Substitute", "Leech Seed");
let rand43 = new pokemon("", "Tangrowth", "Rockium Z", "Impish", "248 HP / 144 Def / 116 Spe", "Chlorophyll", "Sleep Powder", "Rock Slide", "Power Whip", "Synthesis");
let rand44 = new pokemon("", "Gengar", "Choice Specs", "Timid", "252 SpA / 4 SpD / 252 Spe", "Cursed Body", "Shadow Ball", "Sludge Wave", "Dazzling Gleam", "Focus Blast");
let rand45 = new pokemon("", "Hydreigon", "Petaya Berry", "Timid", "252 SpA / 4 SpD / 252 Spe", "levitate", "Belch", "Substitute", "Dark Pulse", "Draco Meteor");
let rand46 = new pokemon("", "Hydreigon", "Choice Specs", "Timid", "252 SpA / 4 SpD / 252 Spe", "Levitate", "Draco Meteor", "Dark Pulse", "Hidden Power Rock", "Fire Blast");
let rand47 = new pokemon("", "Meowstic", "Normalium Z", "Calm", "248 HP / 176 Def / 84 SpD", "Prankster", "Charm", "Confide", "Rest", "Psychic");
let rand48 = new pokemon("", "Murkrow", "Eviolite", "Bold", "248 HP / 252 Def / 8 Spe", "Prankster", "Feather Dance", "Roost", "Dark Pulse", "Taunt");
let rand49 = new pokemon("", "Volbeat", "Normalium Z", "Calm", "252 HP / 4 Def / 252 SpD", "Prankster", "Infestation", "Confide", "Roost", "Encore");
let rand50 = new pokemon("", "Lycanroc-Dusk", "Lycanium Z", "Jolly", "252 Atk / 80 SpD / 176 Spe", "Tough Claws", "Stone Edge", "Snarl", "Drill Run", "Taunt");
let rand51 = new pokemon("", "Sawsbuck", "Choice Scarf", "Adamant", "252 Atk / 4 SpD / 252 Spe", "Serene Grace", "Headbutt", "Jump Kick", "Megahorn", "Horn Leech");
let rand52 = new pokemon("", "Togekiss", "Normalium Z", "Calm", "252 HP / 100 Def / 40 SpA / 88 SpD / 28 Spe", "Serene Grace", "Air Slash", "Thunder Wave", "Lucky Chant", "Roost");
let rand53 = new pokemon("", "Meloetta", "Bright Powder", "Bold", "252 HP / 156 Def / 100 Spe", "Serene Grace", "Rest", "Teeter Dance", "Thunder Wave", "Snore");
let rand54 = new pokemon("", "Treecko", "Custap Berry", "Naive", "1 HP", "Overgrow", "Endure", "Grass Whistle", "Quick Attack", "Endeavor");
let rand55 = new pokemon("", "Zapdos", "Choice Specs", "Modest", "252 HP / 208 SpA / 48 SpD", "Pressure", "Thunderbolt", "Hidden Power Ice", "Heat Wave", "Air Cutter");
let rand56 = new pokemon("", "Arceus", "Psychium Z", "Jolly", "252 HP / 4 Atk / 252 Spe", "Multitype", "Rest", "Cosmic Pwer", "Will-O-Wisp", "Cut");
let rand57 = new pokemon("", "Dialga", "Psychium Z", "Timid", "4 HP / 252 SpA / 252 Spe", "Pressure", "Heal Block", "Roar Of Time", "Toxic", "");
let rand58 = new pokemon("", "Arceus", "Rockium Z", "Lonely", "252 Atk / 4 SpA / 252 Spe", "Multitype", "Stone Edge", "Brine", "Bullet Seed", "Silver Wind");


let randMons = [rand1, rand2, rand3, rand4, rand5, rand6, rand7, rand8, rand9, rand10, rand11,  rand13, rand14, rand15, rand16, rand17, rand18, rand19, rand20, rand21, rand22, rand23, rand24, rand25, rand26, rand27, rand28, rand29, rand30, rand31, rand32, rand33, rand34, rand35, rand36, rand37, rand38, rand39, rand40, rand41, rand42, rand43, rand44, rand45, rand46, rand47, rand48, rand49, rand50, rand51, rand52, rand53, rand54, rand55, rand56, rand57, rand58];

let custommon1 = new pokemon("", "", "custom", "", "", "", "", "", "", "");
let custommon2 = new pokemon("", "", "custom", "", "", "", "", "", "", "");
let custommon3 = new pokemon("", "", "custom", "", "", "", "", "", "", "");
let custommon4 = new pokemon("", "", "custom", "", "", "", "", "", "", "");
let custommon5 = new pokemon("", "", "custom", "", "", "", "", "", "", "");
let custommon6 = new pokemon("", "", "custom", "", "", "", "", "", "", "");
let customMons = [custommon1, custommon2, custommon3, custommon4, custommon5, custommon6];
custommon1.lmatchups = [];
custommon2.lmatchups = [];
custommon3.lmatchups = [];
custommon4.lmatchups = [];
custommon5.lmatchups = [];
custommon6.lmatchups = [];
let customMonNum = 0;


let nameList = ["It's Joever", "Iced", "boof pack", "toenails", "YongYea", "Asian Shofu", "sawk on deez", "crinje", "demon", "Choice Banded", "2015shofu", "bus***yVGC", "Choice Specs", "Scarfed God", "Shofu's Disciple", "White Shofu", "Magma's Grandma", "They/them pu**y", "08h4i3orejkewf", "prnt.sc/ucd2ah", "SOLARFLARE MODE", "kris is a furry", "GO STOOPID(derek", "DEREKT.COM", "Carelessly Soulful", "cunnyroach island", "ango swag swag", "og swag diet", "almost autistic", "XANDER", "funky bellybutton", "mental ward and me", "celebi and me", "ICE AND THE CAT", "jizzlamed", "boipucci", "mr. worldwide", "THE CALIPH", "stunt animal", "stunned animal", "LambToTheSlaugher", "one too many...", "prnt.sc/ucdj7o", "taskforce", "lucy massage", "elsajeanfanclub", "train girl", "bull girl", "malonged", "extreme pass", "Mantike", "cockroacher", "roadkill", "after nut thots", "penor flavored", "dickspin", "cockroach noises", "ann frank mukbang", "prnt.sc/ucdkei", "Mufat", "08h4i3orejkewf", "prnt.sc/ucd2ah", "Carelessly Soulful", "cunnyroach island", "derektheking2010", "DEREKT.COM", "GO STOOPID(derek", "SOLARFLARE MODE", "prnt.sc/ucd2ah", "lustrous", "purgatory", "The Lovers", "juno is in love", "clumsy angel", "balamb garden", "FIGHTING GAMES", "hibiscus", "KING SLIME", "sweeties", "rapunz", "guardian", "jello", "a ghost chant", "dreamland", "DREAMLAND", "eternia", "fairy festival", "monkey bars", "sunflower", "shimada", "kapio", "monogatari", "sabbath", "pretty", "warrior of light", "gotta blast", "deja vu", "purple genes", "POCKETS PREGNANT", "READY TO EAT", "growing pains", "romeo must die", "prnt.sc/ualzzd", "SASHA ON SASHA", "prnt.sc/uam078", "just because", "hey bonita", "dance with me", "DANCE WITH ME", "all natural", "flight to france", "jupiter jazz", "rising sun", "catch a wave", "fantasy and you", "horoscopes", "with the bro", "bag and i go", "JET TO THE WEST", "ROSE GOLD", "SPACE COUPE", "high fashino", "WRIST ICE CUP", "COUPE MTND", "feet to the fire", "poggie woggies", "hell of a guy", "MOROCCO", "derek (2019 peak)", "derek (crossdressi", "derek (as a girl)", "derek (gamer girl)", "scoop you up", "maki (trans)", "MOTORCYCLE PATCHES", "how u feel", "HYDRALAZINE", "HEMLIBR", "missin california", "late nights", "see u on ft", "DIPROLENE", "elsa jean", "2015 swag", "2014 derek", "busy day", "skies are safe", "half serbians", "derek comfy", "prnt.sc/uamb42", "prnt.sc/uambat", "robynlovers", "alicelovers", "2018 kaif", "cruxgang", "I D E N I T Y", "close the door", "da duh da duns", "2020 joindate", "dmax apologist", "give you the bump", "curbed", "law is lawless", "Coffin Nails", "HIT ME", "how many mentions?", "yessir", "%BKC: hold on", "call me", "LATINA LOVE", "flygon's typing", "SEB2DRIPPY", "seb2drippy", "prnt.sc/uamsse", "15 in brazil", "FREE QUAR", "dog walker", "248 mood", "ginger magic", "based and redpilled", "4 different women", "SECRET BASE(D)", "with my bros", "KAMI CLOUDS", "gfjsdfsdfsdgfj", "iworqhrhewr", "i eat babies", "me irl", "ur mom irl", "poopypants69", "derek's sexbot", "samantha", "just fly", "voicemail", "top down", "top off", "mirage", "I DON'T SLEEP", "shdw", "faded faded", "BAM 2X", "gohar (chad mode)", "latinalover312", "bought a drop top", "TOUNGE WRESTLE", "POCKETS PREGNANT", "norton commander", "aya", "mama gohar", "papa gohar", "fidanzata di rainy", "PANE ALLE PAPERE", "GIRA DA QUANDO", "MACCHINA GIALLA", "AUTOBLU", "BULLI PER STRADA", "ORE PICCOLE", "butthole", "GUCCI GANG", "DAME SUS MONOS", "little baby bubbie", "wolfgang (rare)", "hija de erica", "milan (romanian)", "LRseXC", "smokin catpiss :3", "milena", "prnt.sc/ucctvx", "prnt.sc/uccu5e", "CEO of chip", "derekbot9000", "gohar's mom (hot)", "casket", "smile like", "you deserve this", "got your passport", "a long time ago", "TREASURE ISLAND", "SNOW ISLAND", "pirate life", "GALLEON", "sailing home", "Nick Cage", "shane dawson", "-igga", "prnt.sc/uccvxz", "prnt.sc/uccwar", "sice (malding)", "prnt.sc/uccwol", "later citur pollu", "mexican discord gf", "de tijuana", "bricks on bricks", "eblurb effect", "U CAU CAU", "swan lake", "cocktails", "sd sdsd((sss))", "poopy butthole", "AZALI", "to The MOON", "Coochie Milk", "flipper", "calibrate", "bitemynails", "*quietly boyqueefs", "spo.ink/ngas", "spo.ink/dforderek", "666lurb666", "MOLLYONMYWRIST1", "el gotard", "MyChoppaMalicious", "MyChoppaLGBTQIA+", "da wifie", "love myself", "zorthodontist", "eject packin", "PURPLE UMBRELLA", "dinosaurs in love", "Groomer Chungus", "Joeverqwil", "1v1 rico", "Protect wasiangenocide31", "menkiss emoji", "Finchinator", "mayocide", "Toxic Flinch", "KLINK", "Matinee", "stay gold", "Libtard", "OPPS ARE POO", "europoor", "shadowboxer", "rellia r34", "Funny Doggie", "ONE PUNCH", "JANITOR", "Kaiferson Hubert", "maki mouse", "bite my nails", "lightbeamers"]

let ffaAdd = false;
//list of teams for finding teams
let team_list = [];
//list of chosen mons
let got_mons = [];
let got_mons_2 = [];
let got_mons_3 = [];

//opponent loss lists
let opponent_loss_1 = [];
let opponent_loss_2 = [];
let opponent_loss_3 = [];
//team text variable
let team = "";
//gen variable
let gen7 = false;

//create the mon blocks
function createDiv(poke, pos) {
    let div = document.createElement("div");
    div.setAttribute('id', pos.toString(10));
    div.setAttribute('class', 'pokemon');
    div.setAttribute("onclick", "add(this.id)");
    document.getElementById("monElements").appendChild(div);
    let a = document.createElement('a');
    a.setAttribute('class', 'monInfo');
    a.setAttribute('href', '#');
    a.innerHTML = poke.name;
    document.getElementById(pos.toString(10)).appendChild(a);
    let pn = document.createElement("p");
    pn.setAttribute('class', 'monInfo');
    pn.innerHTML = poke.ability;
    document.getElementById(pos.toString(10)).appendChild(pn);
    let p = document.createElement("p");
    p.setAttribute('class', 'monInfo');
    p.innerHTML = poke.item + ",&nbsp;" + poke.nature;
    document.getElementById(pos.toString(10)).appendChild(p);
    let p1 = document.createElement("p");
    p1.setAttribute('class', 'monInfo');
    p1.innerHTML = poke.evs;
    document.getElementById(pos.toString(10)).appendChild(p1);
    let p2 = document.createElement("p");
    p2.setAttribute('class', 'monInfo');
    p2.innerHTML = poke.move1 + "&nbsp;&nbsp;&nbsp;" + poke.move2;
    document.getElementById(pos.toString(10)).appendChild(p2);
    let p3 = document.createElement("p");
    p3.setAttribute('class', 'monInfo');
    p3.innerHTML = poke.move3 + "&nbsp;&nbsp;&nbsp;" + poke.move4;
    document.getElementById(pos.toString(10)).appendChild(p3);
}

function createMons() {
    for (let i = 0; i < pokemon_list.length; i++) {
        createDiv(pokemon_list[i], i);
    }
}

function scrollToTop() {
    window.scrollTo(0, 0);
}

//switching to gen7
let backupPokemonList = [];
for (let i = 0; i < pokemon_list.length; i++) {
    backupPokemonList.push(pokemon_list[i]);
}

function switchGen(num) {
    if (num === 1) {
        console.log("gen7");
        resetList();
        while (pokemon_list.length > 0) {
            pokemon_list.splice(0, 1);
        }
        console.log(pokemon_list);
        for (let i = 0; i < pokemon_list_gen7.length; i++) {
            pokemon_list.push(pokemon_list_gen7[i]);
        }
        console.log(pokemon_list);
        let mons = document.getElementById('monElements');
        let printed = mons.querySelectorAll('div.pokemon');
        let i = 0;
        while (i < printed.length) {
        printed[i].parentNode.removeChild(printed[i]);
        i++;
        }
        createMons();
        gen7 = true;
    } else {
        console.log("gen8");
        resetList();
        while (pokemon_list.length > 0) {
            pokemon_list.splice(0, 1);
        }
        console.log(pokemon_list);
        for (let i = 0; i < backupPokemonList.length; i++) {
            pokemon_list.push(backupPokemonList[i]);
        }
        console.log(pokemon_list);
        let mons = document.getElementById('monElements');
        let printed = mons.querySelectorAll('div.pokemon');
        let i = 0;
        while (i < printed.length) {
        printed[i].parentNode.removeChild(printed[i]);
        i++;
        }
        createMons();
        gen7 = false;
    }
}

function switchGen2(num) {
    if (num === 1) {
        console.log("gen7");
        resetList();
        while (pokemon_list.length > 0) {
            pokemon_list.splice(0, 1);
        }
        console.log(pokemon_list);
        for (let i = 0; i < pokemon_list_gen7.length; i++) {
            pokemon_list.push(pokemon_list_gen7[i]);
        }
        for (let i = 0; i < randMons.length; i++) {
            pokemon_list.push(randMons[i]);
            console.log(randMons[i].name + " added");
        }
        console.log(pokemon_list);
        gen7 = true;
    } else {
        console.log("gen8");
        resetList();
        while (pokemon_list.length > 0) {
            pokemon_list.splice(0, 1);
        }
        console.log(pokemon_list);
        for (let i = 0; i < backupPokemonList.length; i++) {
            pokemon_list.push(backupPokemonList[i]);
        }
        for (let i = 0; i < randMons.length; i++) {
            pokemon_list.push(randMons[i]);
            console.log(randMons[i].name + " added");
        }
        console.log(pokemon_list);
        gen7 = false;
    }
}

function switchGen3(num) {
    if (num === 1) {
        console.log("gen7");
        resetList();
        while (pokemon_list.length > 0) {
            pokemon_list.splice(0, 1);
        }
        console.log(pokemon_list);
        for (let i = 0; i < pokemon_list_gen7.length; i++) {
            pokemon_list.push(pokemon_list_gen7[i]);
        }
        console.log(pokemon_list);
        gen7 = true;

    } else {
        console.log("gen8");
        resetList();
        while (pokemon_list.length > 0) {
            pokemon_list.splice(0, 1);
        }
        console.log(pokemon_list);
        for (let i = 0; i < backupPokemonList.length; i++) {
            pokemon_list.push(backupPokemonList[i]);
        }
        console.log(pokemon_list);
        gen7 = false;
    }
}

//add or remove mons from the chosen mons list
let onBuilderSix = false;
let addTheMon = true;
let addToBeat = false;
let addToDisregard = false;
let clickerPage = false;
let ffateam = false;

function changeBuilderSix(choiceTwo) {
    if (choiceTwo === 1) {
        addTheMon = true;
        addToBeat = false;
        addToDisregard = false;
        console.log("1");
    } else if (choiceTwo === 2) {
        addTheMon = false;
        addToBeat = true;
        addToDisregard = false;
        console.log("2");
    } else if (choiceTwo === 3) {
        addTheMon = false;
        addToBeat = false;
        addToDisregard = true;
        console.log("3");
    }
}

let limit = 0;
let checkLim = 0;

function add(n) {
    checkLim++;
    let mon_names = '';
    isIn = false;
    let spot;
    if (onBuilderSix === false && clickerPage === false) {
        console.log("default");
        for (let i = 0; i < got_mons.length; i++) {
            if (pokemon_list[n] === got_mons[i]) {
                isIn = true;
                spot = i;
                break;
            }
        }
        if (isIn === false) {
            got_mons.push(pokemon_list[n]);
        } else {
            got_mons.splice(spot,1);
            checkLim -= 2;
        } 
        for (let i = 0; i < got_mons.length; i++) {
            if (i === 0) {
                mon_names += got_mons[i].objn;
            } else {
                mon_names += ", " + got_mons[i].objn;
            }
        }
        document.getElementById('list').innerHTML = mon_names;
    } else if (onBuilderSix) {
        console.log("ds");
        if (addTheMon === true) {
            for (let i = 0; i < got_mons.length; i++) {
                if (pokemon_list[n] === got_mons[i]) {
                    isIn = true;
                    spot = i;
                    break;
                }
            }
            if (got_mons.length != 1) {
                got_mons.push(pokemon_list[n]);
            } else {
                got_mons.splice(0, 1);
                got_mons.push(pokemon_list[n]);
            }
            document.getElementById('list').innerHTML = pokemon_list[n].objn;
        } else if (addToBeat === true) {
            for (let i = 0; i < got_mons_2.length; i++) {
                if (pokemon_list[n] === got_mons_2[i]) {
                    isIn = true;
                    spot = i;
                    break;
                }
            }
            let used = false;
            for (let i = 0; i < got_mons_3.length; i++) {
                if (pokemon_list[n] === got_mons_3[i]) {
                    used = true;
                }
            }
            if (!used) {
                if (isIn === false) {
                    got_mons_2.push(pokemon_list[n]);
                } else {
                    got_mons_2.splice(spot,1);
                } 
                for (let i = 0; i < got_mons_2.length; i++) {
                    if (i === 0) {
                        mon_names += got_mons_2[i].objn;
                    } else {
                        mon_names += ", " + got_mons_2[i].objn;
                    }
                }
                document.getElementById('list2').innerHTML = mon_names;
            }
        } else if (addToDisregard === true) {
            for (let i = 0; i < got_mons_3.length; i++) {
                if (pokemon_list[n] === got_mons_3[i]) {
                    isIn = true;
                    spot = i;
                    break;
                }
            }
            let used = false;
            for (let i = 0; i < got_mons_2.length; i++) {
                if (pokemon_list[n] === got_mons_2[i]) {
                    used = true;
                }
            }
            if (!used) {
                if (isIn === false) {
                    got_mons_3.push(pokemon_list[n]);
                } else {
                    got_mons_3.splice(spot,1);
                } 
                for (let i = 0; i < got_mons_3.length; i++) {
                    if (i === 0) {
                        mon_names += got_mons_3[i].objn;
                    } else {
                        mon_names += ", " + got_mons_3[i].objn;
                    }
                }
                document.getElementById('list3').innerHTML = mon_names;
            }
        }
    }
    if (clickerPage) {
        console.log("ewg");
        let contOne = false;
        let contTwo = false;
        if (got_mons.length === 3) {
            contOne = true;
        } 
        if (got_mons_2.length === 3) {
            contTwo = true;
        }
        if (addTheMon) {
            for (let i = 0; i < got_mons.length; i++) {
                if (pokemon_list[n] === got_mons[i]) {
                    isIn = true;
                    spot = i;
                    break;
                }
            }
            if (isIn) {
                got_mons.splice(spot, 1);
            } else if (!contOne) {
                got_mons.push(pokemon_list[n]);
            }

            for (let i = 0; i < got_mons.length; i++) {
                if (i === 0) {
                    mon_names += got_mons[i].objn;
                } else {
                    mon_names += ", " + got_mons[i].objn;
                }
            }
            document.getElementById('list').innerHTML = mon_names;
        } else if (addToBeat) {
            for (let i = 0; i < got_mons_2.length; i++) {
                if (pokemon_list[n] === got_mons_2[i]) {
                    isIn = true;
                    spot = i;
                    break;
                }
            }
            console.log("poop");
            if (isIn) {
                got_mons_2.splice(spot, 1);
            } else if (!contTwo) {
                got_mons_2.push(pokemon_list[n]);
            }
            for (let i = 0; i < got_mons_2.length; i++) {
                if (i === 0) {
                    mon_names += got_mons_2[i].objn;
                } else {
                    mon_names += ", " + got_mons_2[i].objn;
                }
            }
            document.getElementById('list2').innerHTML = mon_names;
        }
    }
    if (limit === 1 && checkLim === 1) {
        monMU();
    } else if (limit === 3 && checkLim === 3) {
        teamMU();
    }
}

//print a mon
function printMon(x) {
    let p = document.createElement('p');
    p.setAttribute('class', 'printed');
    p.innerHTML = TeamTextMaker(x);
    document.getElementById('main').appendChild(p);
}

//print a team
function printTeam(x, y, z) {
    changeRotom(true);
    let p = document.createElement('p');
    p.setAttribute('class', 'printed');
    let teamMons = [x, y, z]
    let team = "=== [gen81v1] " + x.name + " " + y.name + " " + z.name + " ===<br><br>";
    for (let mons = 0; mons < teamMons.length; mons++) {
        team += TeamTextMaker(teamMons[mons]);
    }
    p.innerHTML = team;
    changeRotom(false);
    document.getElementById('main').appendChild(p);
}
//check duplicate team
function duplicate(x, y, z) {
    for (let ii = 0; ii < team_list.length; ii++) {
        if ((x === team_list[ii][0] || x === team_list[ii][1] || x === team_list[ii][2]) && (y === team_list[ii][0] || y === team_list[ii][1] || y === team_list[ii][2]) && (z === team_list[ii][0] || z === team_list[ii][1] || z === team_list[ii][2])) {
            return true;
        }
    }
    return false;
}
function duplicateCteam(x, y) {
    for (let ii = 0; ii < team_list.length; ii++) {
        if ((x === team_list[ii][0] || x === team_list[ii][1]) && (y === team_list[ii][0] || y === team_list[ii][1])) {
            return true;
        }
    }
    return false;
}

function resetCteam() {
    document.getElementById('beatFound').style.display = 'none';
    document.getElementById('foundList').style.display = 'none';
}
function resetCteam2() {
    document.getElementById('foundList').style.display = 'none';
}
//start the cteam function
function startCteam() {
    let restartEvent = document.getElementById('restart');

    let opponent_loss_1 = [];
    document.getElementById("monElements").style.display = 'none';
    let numMons = 0
    for (let i = 0; i < got_mons.length; i ++) {
        numMons++;
        for (let j = 0; j < got_mons[i].lmatchups.length; j++) {
            opponent_loss_1.push(got_mons[i].lmatchups[j]);
        }
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        let lossCheck = 0;
        for (let j = 0; j < opponent_loss_1.length; j++) {
            if (pokemon_list[i] === opponent_loss_1[j]) {
                lossCheck++;
            }
        }
        if (numMons === lossCheck) {
           printMon(pokemon_list[i]);
           got_mons_2.push(pokemon_list[i]);
        }
    }
    document.getElementById('start').style.display = 'none';
    document.getElementById('restart').style.display = 'block';
    document.getElementById('beatFound').style.display = 'block';
    document.getElementById('foundList').style.display = 'block';
}

//beat mons that are found in the cteam, ordered by score
function beatFound() {
    let main = document.getElementById('main');
    let printed = main.querySelectorAll('p.printed');
    let i = 0;
    while (i < printed.length) {
        printed[i].parentNode.removeChild(printed[i]);
        i++;
    }
    let tempList = [];
    for (let i = 0; i < pokemon_list.length; i++) {
        tempList.push(pokemon_list[i]);
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        pokemon_list[i].fails = [];
        let score = 0;
        for (let j = 0; j < got_mons_2.length; j++) {
            let fail = false;
            for (let k = 0; k < got_mons_2[j].lmatchups.length; k++) {
                if (got_mons_2[j].lmatchups[k] === pokemon_list[i]) {
                    fail = true;
                    break;
                }
            }
            if (!fail) {
                pokemon_list[i].fails.push(got_mons_2[j]);
                score++
            }
        }
        pokemon_list[i].score = score;
    }
    while (tempList.length > 0) {
        let high = 0;
        let highestScore = tempList[0].score;
        for (let i = 0; i < tempList.length; i++) {
            if (tempList[i].score < highestScore) {
                high = i;
                highestScore = tempList[i].score;
            }
        }
        console.log(high);
        got_mons_3.push(tempList[high]);
        tempList.splice(high, 1);
    }

    console.log("ass");
    for (let i = 0; i < got_mons_3.length; i++) {
        printBeatFound(got_mons_3[i], got_mons_3[i].fails);
    }
    while (got_mons_2.length > 0) {
        got_mons_2.splice(0, 1);
    }
    while (got_mons_3.length > 0) {
        got_mons_3.splice(0, 1);
    }
    while (tempList.length > 0) {
        tempList.splice(0, 1);
    }
}

//print beatfound
function printBeatFound(x, y) {
    let abbr = "Doesn't cover: ";
    for (let j = 0; j < y.length; j++) {
        if (j === 0) {
            abbr += y[j].objn;
        } else {
            abbr += ", " + y[j].objn;
        }
    }
    let p = document.createElement('p');
    p.setAttribute('class', 'printed');
    text = TeamTextMaker(x);

    p.innerHTML = "<abbr title=\"" + abbr + "\">" + text + "</abbr><br><br>"; 
    text = "";

    document.getElementById('main').appendChild(p);
}


//start the cteam function
function startCteam2() {
    team_list = [];
    let restartEvent = document.getElementById('restart');
    let opponent_loss_1 = [];
    document.getElementById("monElements").style.display = 'none';
    for (let i = 0; i < pokemon_list.length; i++) {
        let lossCheck = 0;
        for (let j = 0; j < pokemon_list.length; j++) {
            let teamFail = true;
            for (let k = 0; k < got_mons.length; k++) {
                let beats = false;
                
                for (let l = 0; l < got_mons[k].lmatchups.length; l++) {
                    if (got_mons[k].lmatchups[l] === pokemon_list[i] || got_mons[k].lmatchups[l] === pokemon_list[j]) {
                        beats = true;
                        break;
                    }
                }
                if (beats === false) {
                    teamFail = false;
                    break;
                }
            }
            if (teamFail === true) {
                let one = i.toString(10);
                let two = j.toString(10);
                let id = one + two;
                let used = false;
                for (let team = 0; team < team_list.length; team++) {
                    if (duplicateCteam(pokemon_list[i], pokemon_list[j]) === false) {
                        team_list.push([pokemon_list[i], pokemon_list[j]]);
                    } else {
                        used = true;
                    }
                }
                if (used === false) {
                    printCteam2(pokemon_list[i], pokemon_list[j], id);
                }
            }
        }
    }
    document.getElementById('start').style.display = 'none';
    document.getElementById('restart').style.display = 'block';
    document.getElementById('foundList').style.display = 'block';
}

function printCteam2(x, y, id) {
    let p = document.createElement('p');
    p.setAttribute('class', 'printed');
    if (x != aromatisse_1 || x != aegislash_1 || x != rhyperior_1 || x != conkeldurr_1 || x != conkeldurr_2  || x != steelix_1) {
        p.innerHTML = x.name + " @ " + x.item + "<br>Ability: " + x.ability + "<br>EVs: " + x.evs + "<br>" + x.nature + " Nature<br>- " + x.move1 + "<br>- " + x.move2 + "<br>- " + x.move3 + "<br>- " + x.move4 + "<br><br>"; 
    } else if (x === aromatisse_1 || x === aegislash_1 || x === rhyperior_1 || x === conkeldurr_1 || x === conkeldurr_2  || x === steelix_1) {
        p.innerHTML = x.name + " @ " + x.item + "<br>Ability: " + x.ability + "<br>EVs: " + x.evs + "<br>" + x.nature + " Nature<br>IVs: 0 Spe<br>- " + x.move1 + "<br>- " + x.move2 + "<br>- " + x.move3 + "<br>- " + x.move4 + "<br><br>"; 
    }
    let p2 = document.createElement('p');
    p2.setAttribute('class', 'printed');
    if (y != aromatisse_1 || y != aegislash_1 || y != rhyperior_1 || y != conkeldurr_1 || y != conkeldurr_2  || y != steelix_1) {
        p2.innerHTML = y.name + " @ " + y.item + "<br>Ability: " + y.ability + "<br>EVs: " + y.evs + "<br>" + y.nature + " Nature<br>- " + y.move1 + "<br>- " + y.move2 + "<br>- " + y.move3 + "<br>- " + y.move4 + "<br><br>"; 
    } else if (y === aromatisse_1 || y === aegislash_1 || y === rhyperior_1 || y === conkeldurr_1 || y === conkeldurr_2  || y === steelix_1) {
        p2.innerHTML = y.name + " @ " + y.item + "<br>Ability: " + y.ability + "<br>EVs: " + y.evs + "<br>" + y.nature + " Nature<br>IVs: 0 Spe<br>- " + y.move1 + "<br>- " + y.move2 + "<br>- " + y.move3 + "<br>- " + y.move4 + "<br><br>"; 
    }
    let div = document.createElement('div');
    div.setAttribute('id', id);
    div.setAttribute('class','printed');
    let br = document.createElement('br');
    br.setAttribute('class','printed');
    document.getElementById('main').appendChild(br);
    document.getElementById('main').appendChild(div);
    document.getElementById(id).style.border = '2px solid whitesmoke';
    document.getElementById(id).style.display = 'inline-block';
    document.getElementById(id).style.borderRadius = '10px';
    document.getElementById(id).appendChild(p);
    document.getElementById(id).appendChild(p2);
}

//reset page
function reset(mons) {
    opponent_loss_1 = [];
    opponent_loss_2 = [];
    opponent_loss_3 = [];
    team_list = [];
    document.getElementById('start').style.display = 'block';
    document.getElementById('restart').style.display = 'none';
    if (mons === true) {
        document.getElementById('monElements').style.display = 'block';
    }
    let main = document.getElementById('main');
    let printed = main.querySelectorAll('p.printed');
    let i = 0;
    while (i < printed.length) {
        printed[i].parentNode.removeChild(printed[i]);
        i++;
    }
}  

function resetList() {
    got_mons = [];
    got_mons_2 = [];
    got_mons_3 = [];
    document.getElementById('list').innerHTML = '';
    if (clickerPage) {
        document.getElementById('list2').innerHTML = '';
        customMonNum = 0;
        custommon1.lmatchups = [];
        custommon2.lmatchups = [];
        custommon3.lmatchups = [];
        custommon4.lmatchups = [];
        custommon5.lmatchups = [];
        custommon6.lmatchups = [];
    }
    if (onBuilderSix) {
        document.getElementById('list2').innerHTML = '';
        document.getElementById('list3').innerHTML = '';
    }
    addAllBool = false;
}

function resetMus() {
    opponent_loss_1 = [];
    opponent_loss_2 = [];
    opponent_loss_3 = [];
    got_mons = [];
    got_mons_2 = [];
    document.getElementById('restart').style.display = 'none';
    document.getElementById('list').innerHTML = '';
    document.getElementById('monElements').style.display = 'block';
    let main = document.getElementById('main');
    let printed = main.querySelectorAll('p.printed');
    let i = 0;
    while (i < printed.length) {
        printed[i].parentNode.removeChild(printed[i]);
        i++;
    }
    checkLim = 0;
}

function changeRotom(bool) {
    if (!gen7) {
        if (bool === true) {
            rotom_heat_1.name =  "Rotom-Heat";
            rotom_heat_2.name =  "Rotom-Heat";
            rotom_heat_3.name =  "Rotom-Heat";
            rotom_wash_1.name = "Rotom-Wash";
            rotom_wash_2.name = "Rotom-Wash";
            darmanitan_1.name = "Darmanitan";
        }
        else {
            rotom_heat_1.name = "Rotom";
            rotom_heat_2.name = "Rotom";
            rotom_heat_3.name = "Rotom";
            rotom_wash_1.name = "Rotom";
            rotom_wash_2.name = "Rotom";
            darmanitan_1.name = "Darmanitan-Galar";
        }
    } else {
        if (bool === true) {
            charizard_mega_x_g7.name = "Charizard-X";
            charizard_mega_x_2_g7.name = "Charizard-X";
            charizard_mega_x_3_g7.name = "Charizard-X";
            charizard_mega_x_4_g7.name = "Charizard-X";
            charizard_mega_y_g7.name = "Charizard-Y";
            charizard_mega_y_2_g7.name = "Charizard-Y";
        }
        else {
            charizard_mega_x_g7.name = "Charizard";
            charizard_mega_x_2_g7.name = "Charizard";
            charizard_mega_x_3_g7.name = "Charizard";
            charizard_mega_x_4_g7.name = "Charizard";
            charizard_mega_y_g7.name = "Charizard";
            charizard_mega_y_2_g7.name = "Charizard";
        }
    }
}

let addAllBool = false;
function addAll() {
    if (addAllBool === false) {
        for (let i = 0; i < pokemon_list.length; i++) {
            let isIn = false;
            for (let j = 0; j < got_mons.length; j++) {
                if (pokemon_list[i] === got_mons[j]) {
                    isIn = true;
                }
            }
            if (!isIn) {
                got_mons.push(pokemon_list[i]);
            }
        }
        let mon_names = "";
        for (let i = 0; i < got_mons.length; i++) {
            if (i === 0) {
                mon_names += got_mons[i].objn;
            } else {
                mon_names += ", " + got_mons[i].objn;
            }
        }
        document.getElementById('list').innerHTML = mon_names;
        addAllBool = true;
    }
}


function printTourTeam(x, y, z, fails, closes) {
    let p = document.createElement('p');
    p.setAttribute('class', 'printed');
    let teamMons = [x, y, z];
    let abbr = "Loses to: ";
    for (let j = 0; j < fails.length; j++) {
        if (j === 0) {
            abbr += fails[j].objn;
        } else {
            abbr += ", " + fails[j].objn;
        }
    }
    abbr += "\nGets 2.5-0d by: ";
    for (let j = 0; j < closes.length; j++) {
        if (j === 0) {
            abbr += closes[j].objn;
        } else {
            abbr += ", " + closes[j].objn;
        }
    }
    let team = "<abbr title=\"" + abbr + "\">=== [gen61v1] " + x.name + " " + y.name + " " + z.name + " ===<br><br>";
    for (let mons = 0; mons < teamMons.length; mons++) {
        team += TeamTextMaker(teamMons[mons]);
    }
    p.innerHTML = team + "</abbr>";
    document.getElementById('main').appendChild(p);
}

let teraTypes = ["Fire", "Water", "Grass", "Bug", "Poison", "Flying", "Psychic", "Normal", "Dark", "Steel", "Dragon", "Electric", "Ground", "Fighting", "Rock", "Ice", "Fairy", "Ghost"];

//make mon text to print out (for every print)
function TeamTextMaker(curMon) {
    if (!gen7) {
        let text;
        let nick = Math.floor(Math.random()*nameList.length);
        if (curMon.name ===  "Kingler") {
            text = "KINGLER CONQUEST";
        } else {
            text = nameList[nick]
        }
        text += " (" + curMon.name + ") @ "+ curMon.item + "<br>Ability: " + curMon.ability;
        if (Math.random() > .94) {
            text += "<br>Shiny: Yes"
        }
        text += "<br>Tera Type: " + teraTypes[Math.floor(Math.random()*teraTypes.length)];
        text += "<br>EVs: " + curMon.evs + "<br>" + curMon.nature + " Nature<br>";
        if (curMon === crustle_2) {
            text += "IVs: 28 Spe<br> ";
        } else if (curMon === steelix_1 || curMon === aegislash_2 || curMon === aegislash_1 || curMon === rhyperior_1 || curMon === conkeldurr_1 || curMon === conkeldurr_2) {
            text += "IVs: 0 Spe<br> ";
        }
        if (curMon.move1 != "Tera Blast " && curMon.move2 != "Tera Blast " && curMon.move3 != "Tera Blast " && curMon.move4!= "Tera Blast ") {
            if (Math.random()*100 > 86) {
                let whichMove = Math.floor(Math.random()*100);
                console.log(curMon);
                if (whichMove < 25) {
                    console.log("move1");
                    curMon.move1 = "Tera Blast ";
                } else if (whichMove < 50) {
                    console.log("move2");
                    curMon.move2 = "Tera Blast ";
                } else if (whichMove < 75) {
                    console.log("move3");
                    curMon.move3 = "Tera Blast ";
                } else {
                    console.log("move4");
                    curMon.move4 = "Tera Blast ";
                }
                console.log("TERA BLAST!!!");
            }
        }
        text += "- " + curMon.move1 + "<br>- " + curMon.move2 + "<br>- " + curMon.move3 + "<br>- " + curMon.move4 + "<br><br>";
        return text;
    } else {
        let text = curMon.name + " @ " + curMon.item + "<br>Ability: " + curMon.evs + "<br>EVs: " + curMon.ability + "<br>" + curMon.nature + " Nature<br>";
        
        /*if (curMon === riolu_1_g7) {
            text += "IVs: 0 Spe<br> ";
        }*/
        text += "- " + curMon.move1 + "<br>- " + curMon.move2 + "<br>- " + curMon.move3 + "<br>- " + curMon.move4 + "<br><br>";
        return text;
    }
}

function printMonMu(x, y) {
    let p = document.createElement('p');
    p.setAttribute('class', 'printed');
    if (y === "w") {
        p.setAttribute('id', 'win');
    } else if (y === "l") {
        p.setAttribute('id', 'lose');
    } else {
        p.setAttribute('id', 'm');
    }
    p.innerHTML = x.name + " @ " + x.item + "<br>Ability: " + x.ability + "<br>EVs: " + x.evs + "<br>" + x.nature + " Nature" + "<br>- " + x.move1 + "<br>- " + x.move2 + "<br>- " + x.move3 + "<br>- " + x.move4 + "<br><br>"; 
    document.getElementById('main').appendChild(p);
}

function monMU() {
    document.getElementById("monElements").style.display = 'none';
    document.getElementById('restart').style.display = 'block';
    let p = document.createElement('p');
    p.innerHTML = "loss (red), win (green), neither (yellow)";
    p.setAttribute('class', 'printed');
    document.getElementById('main').appendChild(p);
    for (let i = 0; i < got_mons[0].lmatchups.length; i++) {
        printMonMu(got_mons[0].lmatchups[i], "l");
        got_mons_2.push(got_mons[0].lmatchups[i]);
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        for (let j = 0; j < pokemon_list[i].lmatchups.length; j++) {
            if (pokemon_list[i].lmatchups[j] === got_mons[0]) {
                printMonMu(pokemon_list[i], "w");
                got_mons_2.push(pokemon_list[i]);
                break;
            } 
        }
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        let used = false;
        for (let j = 0; j < got_mons_2.length; j++) {
            if (pokemon_list[i] === got_mons_2[j]) {
                used = true;
                break;
            }
        }
        if (used === false) {
            printMonMu(pokemon_list[i], "m");
        }
    }
}

function teamMU() {
    let opponent_loss_1 = [];
    document.getElementById("monElements").style.display = 'none';
    let numMons = 0
    for (let i = 0; i < pokemon_list.length; i++) {
        let lossCheck = 0;
        for (let j = 0; j < opponent_loss_1.length; j++) {
            if (pokemon_list[i] === opponent_loss_1[j]) {
                lossCheck++;
            }
        }
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        for (let j = 0; j < pokemon_list[i].lmatchups.length; j++) {
            if (pokemon_list[i].lmatchups[j] === got_mons[0] || pokemon_list[i].lmatchups[j] === got_mons[1] || pokemon_list[i].lmatchups[j] === got_mons[2]) {
                opponent_loss_1.push(pokemon_list[i]);
                break;
            } 
        }
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        let used = false;
        for (let j = 0; j < opponent_loss_1.length; j ++) {
            if (pokemon_list[i] === opponent_loss_1[j]) {
                used = true;
                break;
            }
        }
        if (used === false) {
            printMonMu(pokemon_list[i], "m");
        }
    }
    document.getElementById('restart').style.display = 'block'; 
}

//teambuilder7
function teambuilder5() {
    document.getElementById("monElements").style.display = 'none';
    let temp_list = pokemon_list;
    let foundTeams = 0;
    let total = 0;
    let lowestScore = 0;
    let mustBeatScore;
    for (let i = 0; i < pokemon_list.length; i++) {
        pokemon_list[i].disregard = false;
        total++;
    }
    for (let i = 0; i < got_mons_3.length; i++) {
        got_mons_3[i].disregard = true;
        total--;
    }
    for (let i = 0; i < pokemon_list.length; i++) {
        pokemon_list[i].mustBeat = false;
        total++;
    }
    for (let i = 0; i < got_mons_2.length; i++) {
        got_mons_2[i].mustBeat = true;
        total--;
    }
    let minScore = 0;
    for (let i = 0; i < pokemon_list.length; i++) {
        if (pokemon_list.length - 2 === i) {
            break;
        }
        console.log(pokemon_list[i].objn);
        for (let j = i + 1; j < pokemon_list.length; j++) {
            if (pokemon_list[i].name != pokemon_list[j].name) {
                for (let k = i + 2; k < pokemon_list.length; k++) {
                    if ((pokemon_list[k].name != pokemon_list[j].name && pokemon_list[k].name != pokemon_list[i].name)) {
                        let checkZard = true;
                        let teamScore = 0;
                        let team_pass = true;
                        let available = total;
                        if (checkZard) {
                            for (let checkBeat = 0; checkBeat < pokemon_list.length; checkBeat++) {
                                if ((teamScore + available) < minScore) {
                                    team_pass = false;
                                    break;
                                }
                                let disregard = false;
                                if (pokemon_list[checkBeat].disregard) {
                                    disregard = true;
                                }
                                if (!disregard) {
                                    available--;
            
                                    if (pokemon_list[checkBeat].mustBeat) {
                                        mustBeatScore = teamScore;
                                    }
                                    for (let loss = 0; loss < pokemon_list[checkBeat].lmatchups.length; loss++) {
                                        if (pokemon_list[checkBeat].lmatchups[loss] === pokemon_list[i] || pokemon_list[checkBeat].lmatchups[loss] === pokemon_list[j] || pokemon_list[checkBeat].lmatchups[loss] === pokemon_list[k]) {
                                            teamScore += 1;
                                            break;
                                        }
                                    }
                                    if (pokemon_list[checkBeat].mustBeat && mustBeatScore == teamScore) {
                                        team_pass = false;
                                    }
                                }
                            }
                        } else {
                            team_pass = false;
                        }
                        if (team_pass === true) {
                            if (foundTeams === 0) {
                                foundTeams++;
                                lowestScore = teamScore;
                                team_list.push([pokemon_list[i], pokemon_list[j], pokemon_list[k], teamScore]);
                            } else if (team_list.length > 19) {
                                if (teamScore > lowestScore) {
                                    if (duplicate(pokemon_list[i], pokemon_list[j], pokemon_list[k]) === false) {
                                        team_list.push([pokemon_list[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                        while (true) {
                                            let amount = 1;
                                            let lowTeam = team_list[0][3];
                                            for (let x = 0; x < team_list.length; x++) {
                                                if (team_list[x][3] < lowTeam) {
                                                    amount = 1;
                                                    lowTeam = team_list[x][3];
                                                } else if (team_list[x][3] === lowTeam) {
                                                    amount++
                                                }
                                            }
                                            if (team_list.length - amount > 19) {
                                                for (let del = 0; del < team_list.length; del++) {
                                                    if (team_list[del][3] === lowTeam) {
                                                        team_list.splice(del, 1);
                                                        del--;
                                                    }
                                                }
                                            } else {
                                                break;
                                            }
                                        }
                                        lowestScore = team_list[0][3];
                                        for (let x = 0; x < team_list.length; x++) {
                                            if (team_list[x][3] < lowestScore) {
                                                lowestScore = team_list[x][3];
                                            }
                                        }
                                    }
                                } else if (teamScore === lowestScore) {
                                    if (duplicate(pokemon_list[i], pokemon_list[j], pokemon_list[k]) === false) {
                                        team_list.push([pokemon_list[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                    }
                                }
                            } else {
                                if (duplicate(pokemon_list[i], pokemon_list[j], pokemon_list[k]) === false) {
                                    foundTeams++;
                                    team_list.push([pokemon_list[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                }
                                for (let lwst = 0; lwst < team_list.length; lwst++) {
                                    if (team_list[lwst][3] < lowestScore) {
                                        lowestScore = team_list[lwst][3];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (foundTeams > 0) {
        //losses / 2.5-0s
        for (let i = 0; i < team_list.length; i++) {
            let fails = [];
            let close = [];
            teamProblems(team_list[i][0], team_list[i][1], team_list[i][2], fails, close, i);
        }

        while (true) {
            let highestScore = team_list[0][3];
            let highestTeam = 0;
            for (let i = 0; i < team_list.length; i++) {
                if (team_list[i][3] > highestScore) {
                    highestScore = team_list[i][3];
                    highestTeam = i;
                }
            }
            console.log(team_list[highestTeam][3])
            printTourTeam(team_list[highestTeam][0], team_list[highestTeam][1], team_list[highestTeam][2], team_list[highestTeam][3], team_list[highestTeam][4], team_list[highestTeam][5]);
            team_list.splice(highestTeam, 1);
            if (team_list.length === 0) {
                break;
            }
        }
    }
    document.getElementById('start').style.display = 'none';
    document.getElementById('restart').style.display = 'block';
    pokemon_list = temp_list;
}


//teambuilder 8
function teambuilder8() {
    if (got_mons.length === 0) {
        alert("Add a mon to build around");
    }
    else {
        document.getElementById("monElements").style.display = 'none';
        let beatTotal = 0;
        let disregardTotal = 0;
        //give disregarded pokemon disregard property
        for (let i = 0; i < pokemon_list.length; i++) {
            let disregard = false;
            for (let j = 0; j < got_mons_3.length; j++) {
                if (pokemon_list[i] === got_mons_3[j]) {
                    disregard = true;
                    pokemon_list[i].disregard = true;
                    disregardTotal += 1;
                    break;
                }
            }
            if (!disregard) {
                pokemon_list[i].disregard = false;
            }
        }
        //give need beat pokemon that property
        for (let i = 0; i < pokemon_list.length; i++) {
            let beat = false;
            for (let j = 0; j < got_mons_3.length; j++) {
                if (pokemon_list[i] === got_mons_3[j]) {
                    beat = true;
                    pokemon_list[i].beat = true;
                    beatTotal += 1;
                    break;
                }
            }
            if (!beat) {
                pokemon_list[i].beat = false;
            }
        }
        let totalScore = 0;
        //find total score possible
        for (let i = 0; i < pokemon_list.length; i++) {
            if (!pokemon_list[i].disregard || !pokemon_list[i].beat) {
                totalScore += 1;
            }
        }
        console.log("totalScore: " + totalScore);
        let beatHas = false;
        if (got_mons_2.length > 0) {
            beatHas = true;
        }
        let minScore = 0;
        let all = [];
        //start looking for teams
        for (let i = 0; i < got_mons.length; i++) {
            console.log(got_mons[i].objn);
            for (let j = 0; j < pokemon_list.length; j++) {
                if (got_mons[i].name != pokemon_list[j].name) {
                    if ( j === pokemon_list.length-1) {
                        break;
                    }
                    for (let k = j + 1; k < pokemon_list.length; k++) {
                            if ((pokemon_list[k].name != pokemon_list[j].name && pokemon_list[k].name != got_mons[i].name)) {
                                let checkZard = true;
                            let teamScore = 0;
                            let scoreAvailable = totalScore - disregardTotal;
                            let check1 = true;
                            if (hardZardAnswer && !checkZard) {
                                check1 = false;
                            }
                            //makes sure the team can beat need beat
                            if (beatHas === true) {
                                for (let m = 0; m < got_mons_2.length; m++) {
                                    let beats = false;
                                    for (let n = 0; n < got_mons_2[m].lmatchups.length; n++) {
                                        if (got_mons_2[m].lmatchups[n] === got_mons[i] || got_mons_2[m].lmatchups[n] === pokemon_list[j] || got_mons_2[m].lmatchups[n] === pokemon_list[k]) {
                                            beats = true;
                                            break;
                                        }
                                    }
                                    if (!beats) {
                                        check1 = false;
                                        break;
                                    }
                                }
                            }
                            if (check1) {
                                //going through checking if the team beats each mon
                                for (let l = 0; l < pokemon_list.length; l++) {
                                    if ((teamScore + scoreAvailable) > minScore) {
                                        //move to next mon if current is disregarded
                                        let ignore = false;
                                        if (pokemon_list[l].disregard === true) {
                                            ignore = true;
                                            let check = false;
                                            for (let m = 0; m < pokemon_list[l].lmatchups.length; m++) {
                                                if (pokemon_list[l].lmatchups[m] === got_mons[i] || pokemon_list[l].lmatchups[m] === pokemon_list[k] || pokemon_list[l].lmatchups[m] === pokemon_list[j]) {
                                                    check = true;
                                                    break;
                                                }
                                            }
                                            if (!check) {
                                                all.push(pokemon_list[l]);
                                            }
                                        }
                                        //check to see if the team can beat the mon
                                        if (!ignore) {
                                            scoreAvailable -= 1;
                                            for (let m = 0; m < pokemon_list[l].lmatchups.length; m++) {
                                                let beat = false;
                                                if (pokemon_list[l].lmatchups[m] === got_mons[i] || pokemon_list[l].lmatchups[m] === pokemon_list[k] || pokemon_list[l].lmatchups[m] === pokemon_list[j]) {
                                                    teamScore += 1;
                                                    break;
                                                }
                                                if (!beat) {
                                                    all.push(pokemon_list[l]);
                                                }
                                            }
                                        }
                                    }
                                }
                                //adding teams to the list
                                if (team_list.length < 10) {
                                    console.log("less than 10 " + got_mons[i].objn + " " + pokemon_list[j].objn + " " + pokemon_list[k].objn + " " + teamScore);
                                    if (team_list.length === 0) {
                                        team_list.push([got_mons[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                    } else {
                                        if (duplicate(got_mons[i], pokemon_list[j], pokemon_list[k]) === false) {
                                            team_list.push([got_mons[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                        }
                                    }
                                } else {
                                    let lowestScore = team_list[0][3];
                                    for (let team = 0; team < team_list.length; team++) {
                                        if (lowestScore > team_list[team][3]) {
                                            lowestScore = team_list[team][3];
                                        }
                                    }
                                    minScore = lowestScore;
                                    if (teamScore > lowestScore) {
                                        console.log("greater than lowest " + got_mons[i].objn + " " + pokemon_list[j].objn + " " + pokemon_list[k].objn + " " + teamScore);
                                        if (duplicate(got_mons[i], pokemon_list[j], pokemon_list[k]) === false) {
                                            team_list.push([got_mons[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                        }
                                        let numLowestTeams = 0;
                                        for (let n = 0; n < team_list.length; n++) {
                                            if (team_list[n][3] === lowestScore) {
                                                numLowestTeams += 1;
                                            }
                                        }
                                        if (!((team_list.length - numLowestTeams) < 10)) {
                                            for (let o = 0; o < team_list.length; o++) {
                                                if (team_list[o][3] === lowestScore) {
                                                    team_list.splice(o, 1);
                                                }
                                            }
                                        }
                                    }
                                    else if (teamScore >= lowestScore) {
                                        console.log("equal to lowest " + got_mons[i].objn + " " + pokemon_list[j].objn + " " + pokemon_list[k].objn + " " + teamScore);
                                        if (duplicate(got_mons[i], pokemon_list[j], pokemon_list[k]) === false) {
                                            team_list.push([got_mons[i], pokemon_list[j], pokemon_list[k], teamScore]);
                                        }
                                    }
                                }
                            }            
                        }
                    }
                }
            }
        }
        if (team_list.length > 0) {
            //losses / 2.5-0s
            for (let i = 0; i < team_list.length; i++) {
                let fails = [];
                let close = []
                teamProblems(team_list[i][0], team_list[i][1], team_list[i][2], fails, close, i);
            }
     
            while (true) {
                let highestScore = team_list[0][3];
                let highestTeam = 0;
                for (let i = 0; i < team_list.length; i++) {
                    if (team_list[i][3] > highestScore) {
                        highestScore = team_list[i][3];
                        highestTeam = i;
                    }
                }
                console.log(highestScore);
                printTourTeam(team_list[highestTeam][0], team_list[highestTeam][1], team_list[highestTeam][2], team_list[highestTeam][3], team_list[highestTeam][4], team_list[highestTeam][5]);
                team_list.splice(highestTeam, 1);
                if (team_list.length === 0) {
                    break;
                }
            }
        }
        document.getElementById('start').style.display = 'none';
        document.getElementById('restart').style.display = 'block';
    }
}

function addMon() {
    let obj = prompt("mon object name: ");
    let name = prompt("mon name: ");
    let item = prompt("item: ");
    let nature = prompt("Nature: ");
    let evs = prompt("Evs: ");
    let ability = prompt("Ability: ");
    let move1 = prompt("move1: ");
    let move2 = prompt("move2: ");
    let move3 = prompt("move3: ");
    let move4 = prompt("move4: ");
    let newmon = new pokemon(obj, name, item, nature, evs, ability, move1, move2, move3, move4);
    newmon.lmatchups = [];
    for (let i = 0; i < pokemon_list.length; i++) {
        while (true) {
            let mu = prompt("vs " + pokemon_list[i].objn + "; does new mon win, lose or 50/50");
            if (mu.toLowerCase() === "w") {
                pokemon_list[i].lmatchups.push(newmon);
                break;
            } else if (mu.toLowerCase() === "l") {
                newmon.lmatchups.push(pokemon_list[i]);
                break;
            } else if (mu.toLowerCase() === "m") {
                let l = 0;
                break;
            }
        }
    }

    pokemon_list.push(newmon);

    let p = document.createElement('p');
    p.innerHTML = "let " + obj + " = new pokemon(\"" + obj + "\", \"" + name + "\", \"" + item + "\", \"" + nature + "\", \"" + ability + "\", \"" + evs + "\", \"" + move1 + "\", \"" + move2 + "\", \"" + move3 + "\", \"" + move4 + "\");";
    p.setAttribute('class', 'printed');
    document.getElementById('main').appendChild(p);
    let p1 = document.createElement('p');
    p1.setAttribute('class', 'printed');
    p1.setAttribute('id', 'loss');
    document.getElementById('main').appendChild(p1);
    let losses = "";
    for (let i = 0; i < pokemon_list.length; i++) {
        losses += pokemon_list[i].objn + ".lmatchups = [";
        let last = pokemon_list[i].lmatchups.length;
        for (let j = 0; j < pokemon_list[i].lmatchups.length; j++) {
            if (j === 0) {
                losses += pokemon_list[i].lmatchups[j].objn;
            } else {
                losses += ", " + pokemon_list[i].lmatchups[j].objn;
            }
        }
        losses += "];<br>"
    }
    p1.innerHTML = losses;

    let mons = "//pokemon list<br>let pokemon_list = [";
    for (let i = 0; i < pokemon_list.length; i++) {
        if (i === 0) {
            mons += pokemon_list[i].objn;
        } else {
            mons += ", " + pokemon_list[i].objn;
        }
    }
    mons += "];"
    let p2 = document.createElement('p');
    p2.setAttribute('class', 'printed');
    p2.setAttribute('id', 'loss');
    document.getElementById('main').appendChild(p2);
    p2.innerHTML = mons;

    document.getElementById('start').style.display = 'none';
}

function addFFAMon() {
    let obj = prompt("mon object name: ");
    let name = prompt("mon name: ");
    let item = prompt("item: ");
    let ability = prompt("Ability: ");
    let evs = prompt("Evs: ");
    let nature = prompt("Nature: ");
    let move1 = prompt("move1: ");
    let move2 = prompt("move2: ");
    let move3 = prompt("move3: ");
    let move4 = prompt("move4: ");
    let newmon = new pokemon(obj, name, item, nature, evs, ability, move1, move2, move3, move4);
    let p = document.createElement('p');
    p.innerHTML = "let " + obj + " = new pokemon(\"" + obj + "\", \"" + name + "\", \"" + item + "\", \"" + nature + "\", \"" + ability + "\", \"" + evs + "\", \"" + move1 + "\", \"" + move2 + "\", \"" + move3 + "\", \"" + move4 + "\");";
    p.setAttribute('class', 'printed');
    document.getElementById('main').appendChild(p);
    ffamons.push(newmon);

    let mons = "//pokemon list<br>let ffamons = [";
    for (let i = 0; i < ffamons.length; i++) {
        if (i === 0) {
            mons += ffamons[i].objn;
        } else {
            mons += ", " + ffamons[i].objn;
        }
    }
    mons += "];"
    let p2 = document.createElement('p');
    p2.setAttribute('class', 'printed');
    p2.setAttribute('id', 'loss');
    document.getElementById('main').appendChild(p2);
    p2.innerHTML = mons;

    document.getElementById('start').style.display = 'none';
}

function randomTeam() {
    let pokeOne = pokemon_list[Math.floor(Math.random()*pokemon_list.length)];
    while (true) {
        let pokeTwo = pokemon_list[Math.floor(Math.random()*pokemon_list.length)];
        let pokeThree = pokemon_list[Math.floor(Math.random()*pokemon_list.length)];
        if (pokeTwo.name != pokeOne.name && pokeOne.name != pokeThree.name && pokeTwo.name != pokeThree.name) {
            printTeam(pokeOne, pokeTwo, pokeThree);
            break;
        }
    }
    document.getElementById('restart').style.display = 'block';
}

function randomTeam2() {
    let pokeOne = ffamons[Math.floor(Math.random()*ffamons.length)];
    let random = Math.floor(Math.random() * 4)
    console.log("random: " + random);
    while (true) {
        console.log("loop");
        let pokeTwo = ffamons[Math.floor(Math.random()*ffamons.length)];
        let pokeThree = ffamons[Math.floor(Math.random()*ffamons.length)];
        let pokeFour = ffamons[Math.floor(Math.random()*ffamons.length)];
        let pokeFive = ffamons[Math.floor(Math.random()*ffamons.length)];
        let pokeSix = ffamons[Math.floor(Math.random()*ffamons.length)];
        let team = [pokeOne, pokeTwo, pokeThree, pokeFour, pokeFive, pokeSix];
        let dupes = false;
        for (let x = 0; x < team.length; x++) {
            for (let y = 0; y < team.length; y++) {
                if (team[y].name === team[x].name && x != y) {
                    dupes = true;
                    break;
                }
            }
            if (dupes) {
                break;
            }
        }
        let removal = false;
        if (random > 1) {
            for (let x = 0; x < team.length; x++) {
                if (team[x].move1 === "Defog " || team[x].move1 === "Rapid Spin" || team[x].move1 === "Defog") {
                    removal = true;
                    break;
                } else if (team[x].move2 === "Defog " || team[x].move2 === "Rapid Spin" || team[x].move2 === "Defog") {
                    removal = true;
                    break;
                } else if (team[x].move3 === "Defog " || team[x].move3 === "Rapid Spin" || team[x].move3 === "Defog") {
                    removal = true;
                    break;
                } else if (team[x].move4 === "Defog " || team[x].move4 === "Rapid Spin" || team[x].move4 === "Defog") {
                    removal = true;
                    break;
                }
            }
        }
        if (random < 2) {
            removal = true;
        }
        if (!dupes && removal) {
            let text = "=== [gen8FFA] " + pokeOne.name + " " + pokeTwo.name + " " + pokeThree.name + " ===<br><br>";
            text += pokeOne.name + " @ " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].item + "<br>Ability: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].ability + "<br>EVs: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].evs + "<br>" + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].nature + " Nature<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move1 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move2 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move3 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move4 + "<br><br>";
            text += pokeTwo.name + " @ " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].item + "<br>Ability: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].ability + "<br>EVs: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].evs + "<br>" + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].nature + " Nature<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move1 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move2 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move3 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move4 + "<br><br>";
            text += pokeThree.name + " @ " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].item + "<br>Ability: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].ability + "<br>EVs: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].evs + "<br>" + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].nature + " Nature<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move1 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move2 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move3 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move4 + "<br><br>";
            text += pokeFour.name + " @ " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].item + "<br>Ability: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].ability + "<br>EVs: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].evs + "<br>" + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].nature + " Nature<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move1 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move2 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move3 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move4 + "<br><br>";
            text += pokeFive.name + " @ " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].item + "<br>Ability: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].ability + "<br>EVs: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].evs + "<br>" + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].nature + " Nature<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move1 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move2 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move3 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move4 + "<br><br>";
            text += pokeSix.name + " @ " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].item + "<br>Ability: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].ability + "<br>EVs: " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].evs + "<br>" + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].nature + " Nature<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move1 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move2 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move3 + "<br>- " + pokemon_list[Math.floor(Math.random()*pokemon_list.length)].move4 + "<br><br>";
            let p = document.createElement('p');
            p.setAttribute('class', 'printed');
            p.innerHTML = text;
            document.getElementById('main').appendChild(p);

            document.getElementById('restart').style.display = 'block';
            break;
        }
    }
    document.getElementById('restart').style.display = 'block';
}


