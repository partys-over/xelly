<?php

$g1 = "Kingler @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 192 HP / 252 Atk / 64 Spe
Adamant Nature
- Protect
- Liquidation
- Knock Off
- Swords Dance
";
$g10 = "Goldeen @ Eviolite
Ability: Lightning Rod
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Bold Nature
- Aqua Ring
- Protect
- Curse
- Muddy Water
";
$g19 = "Toxapex @ Black Sludge
Ability: Merciless
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Toxic Spikes
- Recover
- Poison Jab
- Liquidation
";
$g28 = "Audino @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 SpD
Careful Nature
- Knock Off
- Body Slam
- Power-Up Punch
- Drain Punch
";
$g37 = "Necrozma @ Red Card
Ability: Prism Armor
Tera Type: &
EVs: 128 Def / 252 SpA / 128 SpD
Modest Nature
- Calm Mind
- Photon Geyser
- Heat Wave
- Earth Power
";
$g46 = "Duosion @ Eviolite
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 200 Def / 60 SpD
Bold Nature
- Recover
- Protect
- Night Shade
- Pain Split
";
$g55 = "Darmanitan-Galar @ Assault Vest
Ability: Gorilla Tactics
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe
Careful Nature
- Icicle Crash
- Flare Blitz
- Earthquake
- U-turn
";
$g64 = "Cradily @ Big Root
Ability: Storm Drain
Tera Type: &
EVs: 252 HP / 252 SpA
Modest Nature
- Leech Seed
- Protect
- Meteor Beam
- Giga Drain
";
$g73 = "Cobalion @ Leftovers
Ability: Justified
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Jolly Nature
- Thunder Wave
- Protect
- Iron Head
- Volt Switch
";
$g82 = "Rillaboom @ Big Root
Ability: Grassy Surge
Tera Type: &
EVs: 252 HP
Sassy Nature
- Grassy Glide
- Leech Seed
- Protect
- Boomburst
";
$g91 = "Wartortle @ Eviolite
Ability: Rain Dish
Tera Type: &
EVs: 248 HP / 128 Def / 4 SpA / 128 SpD
Bold Nature
- Fake Out
- Aqua Ring
- Rain Dance
- Muddy Water
";
$g100 = "Beheeyem @ Weakness Policy
Ability: Analytic
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 SpA
Modest Nature
- Trick Room
- Recover
- Shadow Ball
- Psychic
";
$g110 = "Urshifu-Rapid-Strike @ Metronome
Ability: Unseen Fist
Tera Type: &
EVs: 128 HP / 4 Atk / 124 SpD / 252 Spe
Serious Nature
- Substitute
- Focus Punch
- Protect
- Surging Strikes
";
$g119 = "Pinsir @ Life Orb
Ability: Moxie
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- X-Scissor
- High Horsepower
- Close Combat
- Knock Off
";
$g128 = "Wishiwashi-School @ Leftovers
Ability: Schooling
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe
Modest Nature
- Protect
- U-turn
- Muddy Water
- Ice Beam
";
$g137 = "Corviknight @ Heavy Duty Boots
Ability: Pressure
Tera Type: &
EVs: 252 HP
Relaxed Nature
- Defog
- Iron Defense
- Body Press
- Roost
";
$g146 = "Krookodile @ Assault Vest
Ability: Intimidate
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 SpD
Careful Nature
- Knock Off
- High Horsepower
- Bulldoze
- Rock Slide
";
$g156 = "Krookodile @ Life Orb
Ability: Intimdate
Tera Type: &
EVs: 252 SpA / 252 Spe
Modest Nature
- Earth Power
- Dark Pulse
- Dragon Pulse
- Icinerate
";
$g165 = "Aggron @ Weakness Policy
Ability: Sturdy
Tera Type: &
EVs: 252 Atk / 252 Def / 4 Spe
Adamant Nature
- Head Smash
- Rock Polish
- Heavy Slam
- Taunt
";
$g174 = "Tornadus-Therian @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Defog
- Heat Wave
- Hurricane
- Knock Off
";
$g183 = "Cincinno @ Kings Rock
Ability: Skill Link
Tera Type: &
EVs: 252 Def / 252 SpD
Relaxed Nature
- Tail Slap
- Bullet Seed
- Rock Blast
- Triple Axel
";
$g192 = "Calyrex @ Choice Band
Ability: Unnerve
Tera Type: &
EVs: 176 HP / 200 Atk / 4 SpD / 128 Spe
Adamant Nature
- Seed Bomb
- Zen Headbutt
- Bullet Seed
- Giga Impact
";
$g201 = "Flapple @ Choice Specs
Ability: Ripen
Tera Type: &
EVs: 252 HP / 252 SpA
Modest Nature
- Giga Drain
- Draco Meteor
- Air Slash
- Dragon Breath
";
$g210 = "Klefki @ Leftovers
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 SpD
Calm Nature
- Thunder Wave
- Spikes
- Flash Cannon
- Dazzling Gleam
";
$g219 = "Silvally @ Choice Band
Ability: RKS System
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- Explosion
- Self-Destruct
-
-
";
$g228 = "Moltres @ Heavy-Duty Boots
Ability: Flame Body
Tera Type: &
EVs: 200 HP / 200 SpA / 108 Spe
Modest Nature
- Sunny Day
- Fire Blast
- Solar Beam
- Scorching Sands
";
$g237 = "Suicune @ Life Orb
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Atk
Adamant Nature
- Waterfall
- Extreme Speed
- Crunch
- Curse
";
$g246 = "Dragonite @ Heavy-Duty Boots
Ability: Multiscale
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Thunder Wave
- Roost
- Fire Spin
- Breaking Swipe
";
$g255 = "Bisharp @ Chople Berry
Ability: Defiant
Shiny: Yes
Tera Type: &
EVs: 248 HP / 252 SpD
Sassy Nature
- Metal Burst
- Sucker Punch
- Thunder Wave
- Steel Beam
";
$g265 = "Garchomp @ Leftovers
Ability: Rough Skin
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Stealth Rock
- Earthquake
- Dragon Claw
- Scale Shot
";
$g275 = "Oranguru @ Room Service
Ability: Inner Focus
Tera Type: &
EVs: 252 Def / 252 SpA
Trick Room Nature
- Pain Split
- Nasty Plot
- Extrasensory
- Trick Room
";
$g284 = "Dunsparce @ Sitrus Berry
Ability: Serene Grace
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Adamant Nature
- Glare
- Stealth Rock
- Headbutt
- Roost
";
$g293 = "Piloswine @ Eviolite
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 252 Atk
Adamant Nature
- Stealth Rock
- Avalanche
- Earthquake
- Ice Shard
";
$g302 = "Tyranitar @ Sitrus Berry
Ability: Sand Stream
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Stealth Rock
- Rock Polish
- Rock Slide
- Crunch
";
$g311 = "Heatran @ Assault Vest
Ability: Flash Fire
Tera Type: &
EVs: 252 HP / 200 SpA
Modest Nature
- Flamethrower
- Flash Cannon
- Earth Power
- Magma Storm
";
$g320 = "Politoed @ Life Orb
Ability: Drizzle
Tera Type: &
EVs: 252 SpA / 252 Spe
Modest Nature
- Hydro Pump
- Muddy Water
- Ice Beam
- Icy Wind
";
$g329 = "Kyurem @ Never-Melt Ice
Ability: Pressure
Tera Type: &
EVs: 200 SpA
Timid Nature
- Ice Beam
- Freeze-Dry
- Glaciate
- Earth Power
";
$g338 = "Roselia @ Eviolite
Ability: Natural Cure
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Spikes
- Toxic Spikes
- Sleep Powder
- Leaf Storm
";
$g348 = "Meowstic-F @ Life Orb
Ability: Competitive
Tera Type: &
EVs: 128 Atk / 252 SpA / 128 Spe
Modest Nature
- Psychic
- Shadow Ball
- Dark Pulse
- Sucker Punch
";
$g357 = "Aurorus @ Focus sash
Ability: Snow Warning
Tera Type: &
EVs: 64 Atk / 252 Def / 96 SpA / 96 Spe
Bold Nature
- Blizzard
- Aurora Veil
- Discharge
- Dragon Tail
";
$g366 = "Raichu @ Shuca Berry
Ability: Static
Tera Type: &
EVs: 248 HP / 188 SpD / 72 Spe
Timid Nature
- Fake Out
- Encore
- Knock Off
- Discharge
";
$g375 = "Mew @ Sitrus Berry
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Stealth Rock
- Spikes
- Toxic Spikes
- Super Fang
";
$g384 = "Mew @ Leftovers
Ability: Synchronize
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Bold Nature
- Stealth Rock
- Spikes
- Roar
- Dragon Tail
";
$g394 = "Scrafty @ Roseli Berry
Ability: Intimidate
Tera Type: &
EVs: 252 Def / 252 SpD
Careful Nature
- Knock Off
- Close Combat
- Iron Tail
- Dragon Tail
";
$g403 = "Cofagrigus @ Leftovers
Ability: Mummy
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Toxic Spikes
- Will-O-Wisp
- Hex
- Pain Split
";
$g413 = "Wigglytuff @ Blunder Policy
Ability: Competitive
Tera Type: &
EVs: 252 Def / 128 SpA / 128 SpD
Modest Nature
- Blizzard
- Thunder
- Fire Blast
- Dazzling Gleam
";
$g422 = "Regieleki @ Sitrus BErry
Ability: Transistor
Shiny: Yes
Tera Type: &
EVs: 128 Atk / 128 Def / 252 Spe
Jolly Nature
- Wild Charge
- Extreme Speed
- Acrobatics
- Rapid Spin
";
$g432 = "Lunatone @ Weakness Policy
Ability: Levitate
Tera Type: &
EVs: 128 HP / 252 Def / 128 SpD
Calm Nature
- Moonlight
- Stealth Rock
- Cosmic Power
- Stored Power
";
$g441 = "Ferroseed @ Eviolite
Ability: Iron Barbs
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Leech Seed
- Protect
- Stealth Rock
- Thunder Wave
";
$g450 = "Arctovish @ Icy Rock
Ability: Slush Rush
Tera Type: &
EVs: 252 Atk / 40 Def / 40 SpD / 128 Spe
Adamant Nature
- Hail
- Fishious Rend
- Icicle Crash
- Dive
";
$g459 = "Roserade @ Black Sludge
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Sleep Powder
- Toxic Spikes
- Sludge Bomb
- Leaf Storm
";
$g468 = "Spectrier @ Choice Specs
Ability: Grim Neigh
Tera Type: &
EVs: 252 Spa / 252 Spe
Modest Nature
- Shadow Ball
- Dark Pulse
-
-
";
$g477 = "Marowak @ Thick Club
Ability: Lightning Rod
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- Bonemerang
- Rock Slide
- Knock Off
- Stealth Rock
";
$g486 = "Regidrago @ Dragon Fang
Ability: Dragons Maw
Tera Type: &
EVs: 96 Atk / 96 Def / 96 SpA / 96 SpD / 96 Spe
Serious Nature
- Outrage
- Draco Meteor
- Dragon Energy
- Scale Shot
";
$g495 = "Vanilluxe @ Normal Gem
Ability: Snow Warning
Tera Type: &
EVs: 252 Atk / 184 SpA / 72 Spe
Adamant Nature
- Aurora Veil
- Blizzard
- Freeze-Dry
- Explosion
";
$g504 = "Ninetales @ Heavy-Duty Boots
Ability: Drought
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Solar Beam
- Heat Wave
- Will-O-Wisp
- Inferno
";
$g513 = "Togekiss @ Salac Berry
Ability: Serene Grace
Tera Type: &
EVs: 4 HP / 60 SpA / 252 Spe
Timid Nature
- Substitute
- Air Slash
- Tailwind
- Roost
";
$g522 = "Bouffalant @ Assault Vest
Ability: Reckless
Tera Type: &
EVs: 252 Atk / 100 Def / 96 SpD
Brave Nature
- Head Charge
- Close Combat
- High Horsepower
- Megahorn
";
$g531 = "Skarmory @ Custap Berry
Ability: Sturdy
Shiny: Yes
Tera Type: &
EVs: 252 HP / 232 Def / 24 Spe
Impish Nature
- Spikes
- Stealth Rock
- Brave Bird
- Roost
";
$g541 = "Skarmory @ Maranga Berry
Ability: Sturdy
Tera Type: &
EVs: 252 HP / 232 SpD / 24 Spe
Calm Nature
- Defog
- Roost
- Iron Defense
- Body Press
";
$g550 = "Cresselia @ Weakness Policy
Ability: Levitate
Tera Type: &
EVs: 252 Def / 252 SpA
Modest Nature
- Calm Mind
- Psychic
- Moonblast
- Energy Ball
";
$g559 = "Zygarde @ Soft Sand
Ability: Aura Break
Tera Type: &
EVs: 252 HP / 252 Atk
Adamant Nature
- Lands Wrath
- Thousand Arrows
- Thousand Waves
- Dig
";
$g568 = "Mandibuzz @ Heavy-Duty Boots
Ability: Overcoat
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Defog
- Knock Off
- Roost
- Toxic
";
$g577 = "Carracosta @ Power Herb
Ability: Solid Rock
Tera Type: &
EVs: 128 SpA / 252 Spe
Timid Nature
- Shell Smash
- Meteor Beam
- Muddy Water
- Protect
";
$g586 = "Azumarill @ Sitrus Berry
Ability: Sap Sipper
Tera Type: &
EVs: 252 HP / 4 Atk / 144 Def / 108 SpD
Sassy Nature
- Perish Song
- Whirlpool
- Dive
- Rest
";
$g595 = "Lickilicky @ Assault Vest
Ability: Oblivious
Tera Type: &
EVs: 252 Atk / 252 SpA
Modest Nature
- Flamethrower
- Ice Beam
- Thunderbolt
- Dragon Tail
";
$g604 = "Hydreigon @ Leftovers
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Nasty Plot
- Dragon Pulse
- Dark Pulse
- Defog
";
$g614 = "Duraludon @ Weakness Policy
Ability: Stalwart
Tera Type: &
EVs: 128 HP / 128 SpA / 252 Spe
Timid Nature
- Draco Meteor
- Flash Cannon
- Steel Beam
- Thunder Wave
";
$g623 = "Reuniclus @ Leftovers
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Psychic
- Pain Split
- Focus Blast
- Thunder Wave
";
$g632 = "Basculin @ Choice Band
Ability: Adaptability
Tera Type: &
EVs: 128 Atk / 64 Def / 64 SpD / 252 Spe
Jolly Nature
- Liquidation
- Head Smash
- Flip Turn
- Zen Headbutt
";
$g641 = "Celebi @ Big Root
Ability: Natural Cure
Tera Type: &
EVs: 128 HP / 252 SpA
Modest Nature
- Imprison
- Protect
- Recover
- Leech Seed
";
$g650 = "Rotom-Wash @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Defog
- Volt Switch
- Hydro Pump
- Pain Split
";
$g659 = "Sirfetch’d @ Leek
Ability: Scrappy
Tera Type: &
EVs: 128 HP / 52 Atk / 252 Spe
Jolly Nature
- Detect
- Meteor Assault
- Close Combat
- Knock Off
";
$g668 = "Rotom-Heat @ Heavy-Duty Boots
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Overheat
- Volt Switch
- Nasty Plot
- Discharge
";
$g677 = "Cramorant @ Wacan Berry
Ability: Gulp Missile
Tera Type: &
EVs: 200 HP / 100 SpA / 128 Spe
Modest Nature
- Surf
- Brave Bird
- Icy Wind
- Roost
";
$g686 = "Omastar @ Assault Vest
Ability: Shell Armor
Tera Type: &
EVs: 132 HP / 168 SpA / 208 SpD
Modest Nature
- Scald
- Meteor Beam
- Knock Off
- Ice Beam
";
$g695 = "Golett @ Eviolite
Ability: No Guard
Tera Type: &
EVs: 248 HP / 60 Atk / 100 Def / 100 SpD
Adamant Nature
- Dynamic Punch
- Ice Punch
- Icy Wind
- Stomping Tantrum
";
$g704 = "Hitmontop @ White Herb
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk
Adamant Nature
- Bulk Up
- Agility
- Close Combat
- Stone Edge
";
$g713 = "Grimmsnarl @ Leftovers
Ability: Prankster
Tera Type: &
EVs: 252 Def / 252 SpD
Calm Nature
- Bulk Up
- Sucker Punch
- Spirit Break
- Drain Punch
";
$g722 = "Zapdos @ Heavy-Duty Boots
Ability: Static
Tera Type: &
EVs: 160 SpA / 72 SpD / 252 Spe
Timid Nature
- Defog
- Heat Wave
- Thunderbolt
- Hurricane
";
$g731 = "Swinub @ Focus Sash
Ability: Snow Cloak
Tera Type: &
EVs: 252 Atk
Adamant Nature
- Endeavor
- Protect
- Ice Shard
- Hail
";
$g740 = "Poliwag @ Eviolite
Ability: Water Absorb
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Hypnosis
- Belly Drum
- Waterfall
- Low Kick
";
$g749 = "Butterfree @ Occa Berry
Ability: Tinted Lens
Tera Type: &
EVs: 252 HP / 252 Spe
Bold Nature
- Sleep Powder
- Substitute
- Hurricane
- Bug Buzz
";
$g758 = "Delibird @ Light Clay
Ability: Vital Spirit
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- Fake Out
- Spikes
- Hail
- Aurora Veil
";
$g767 = "Regice @ Metronome
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 200 Spe
Modest Nature
- Ice Beam
- Thunderbolt
- Focus Blast
- Icy Wind
";
$g776 = "Uxie @ Red Card
Ability: Levitate
Tera Type: &
EVs: 40 HP / 252 SpA / 128 Spe
Modest Nature
- Nasty Plot
- Psychic
- Encore
- Shadow Ball
";
$g785 = "Corsola @ Leftovers
Ability: Hustle
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Amnesia
- Curse
- Recover
- Sucker Punch
";
$g794 = "Cofagrigus @ Rocky Helmet
Ability: Mummy
Tera Type: &
EVs: 248 HP / 252 Spe
Modest Nature
- Will-O-Wisp
- Calm Mind
- Shadow Ball
- Hex
";
$g803 = "Clefable @ Life Orb
Ability: Unaware
Tera Type: &
EVs: 52 HP / 252 Atk / 76 Def / 128 SpD
Adamant Nature
- Curse
- Life Dew
- Double-Edge
- Knock Off
";
$g812 = "Turtonator @ Assault Vest
Ability: Shell Armor
Tera Type: &
EVs: 248 HP / 60 SpA / 200 SpD
Modest Nature
- Flamethrower
- Draco Meteor
- Dragon Tail
- Rapid Spin
";
$g821 = "Entei @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 100 SpA
Modest Nature
- Protect
- Dig
- Lava Plume
- Calm Mind
";
$g830 = "Zoroark @ Life Orb
Ability: Illusion
Tera Type: &
EVs: 164 SpA / 252 Spe
Timid Nature
- Nasty Plot
- Dark Pulse
- Flamethrower
- Focus Blast
";
$g839 = "Tornadus @ Muscle Band
Ability: Prankster
Tera Type: &
EVs: 100 Atk / 100 SpD / 252 Spe
Jolly Nature
- Acrobatics
- Fly
- Bulk Up
- Superpower
";
$g848 = "Cloyster @ Kings Rock
Ability: Skill Link
Tera Type: &
EVs: 4 Atk / 252 Def / 252 SpD
Impish Nature
- Shell Smash
- Icicle Spear
- Ice Shard
- Rock Blast
";
$g857 = "Blissey @ Chople Berry
Ability: Healer
Tera Type: &
EVs: 200 Def / 252 Spe
Jolly Nature
- Curse
- Soft-Boiled
- Body Slam
- Counter
";
$g866 = "Cursola @ Kee Berry
Ability: Perish Body
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Strength Sap
- Whirlpool
- Amnesia
- Perish Song
";
$g875 = "Celebi @ Weakness Policy
Ability: Natural Cure
Tera Type: &
EVs: 252 Atk
Adamant Nature
- Swords Dance
- Seed Bomb
- Zen Headbutt
- Sucker Punch
";
$g884 = "Tapu Fini @ Kee Berry
Ability: Misty Surge
Tera Type: &
EVs: 64 SpA
Modest Nature
- Calm Mind
- Draining Kiss
- Muddy Water
- Dive
";
$g893 = "Hatterene @ Leftovers
Ability: Magic Bounce
Tera Type: &
EVs: 248 HP / 252 Def
Bold Nature
- Heal Pulse
- Helping Hand
- Draining Kiss
- Life Dew
";
$g902 = "Politoed @ Leftovers
Ability: Drizzle
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Ice Beam
- Scald
- Detect
- Endeavor
";
$g911 = "Tapu Koko @ Light Clay
Ability: Electric Surge
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
- Discharge
- Light Screen
- Reflect
- Roost
";
$g920 = "Mr. Mime @ Life Orb
Ability: Soundproof
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Encore
- Psychic
- Dazzling Gleam
- Mystical Fire
";
$g929 = "Jynx @ Wide Lens
Ability: Dry Skin
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Lovely Kiss
- Hail
- Blizzard
- Aurora Veil
";
$g938 = "Ninetales-Alola @ Bright Powder
Ability: Snow Cloak
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hypnosis
- Hail
- Blizzard
- Weather Ball
";
$g947 = "Tapu Lele @ Kasib Berry
Ability: Psychic Surge
Tera Type: &
EVs: 128 Def / 4 SpA / 28 Spe
Bold Nature
- Psychic
- Moonblast
- Toxic
- Taunt
";
$g956 = "Sceptile @ Sitrus Berry
Ability: Unburden
Tera Type: &
EVs: 200 Atk / 128 Spe
Adamant Nature
- Swords Dance
- Seed Bomb
- Acrobatics
- Dig
";
$g965 = "Throh @ Leftovers
Ability: Guts
Tera Type: &
EVs: 4 Atk / 252 Def / 252 SpD
Careful Nature
- Protect
- Storm Throw
- Circle Throw
- Bulk Up
";
$g974 = "Wailord @ Choice Scarf
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Water Spout
- Ice Beam
- Scald
- Hydro Pump
";
$g983 = "Appletun @ Petaya Berry
Ability: Thick Fat
Tera Type: &
EVs: 252 Def / 252 SpA
Modest Nature
- Leech Seed
- Draco Meteor
- Apple Acid
- Sucker Punch
";
$g992 = "Noctowl @ Leftovers
Ability: Tinted Lens
Tera Type: &
EVs: 136 Def / 200 SpA / 172 Spe
Modest Nature
- Protect
- Nasty Plot
- Hurricane
- Heat Wave
";
$g1001 = "Zygarde-10% @ Leftovers
Ability: Aura Break
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe
Jolly Nature
- Coil
- Scale Shot
- Protect
- Glare
";
$g1010 = "Cresselia @ Toxic Orb
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Calm Nature
- Trick
- Moonlight
- Psychic
- Thunder Wave
";
$g1019 = "Braviary @ Choice Band
Ability: Sheer Force
Tera Type: &
EVs: 200 Atk / 188 SpD / 120 Spe
Adamant Nature
- Brave Bird
- Superpower
- U-turn
- Slash
";
$g1028 = "Abomasnow @ Focus Sash
Ability: Snow Warning
Tera Type: &
EVs: 200 Def / 252 SpA / 12 SpD / 44 Spe
Modest Nature
- Blizzard
- Giga Drain
- Aurora Veil
- Earth Power
";
$g1037 = "Bronzong @ Sitrus Berry
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Psychic Terrain
- Steel Roller
- Zen Headbutt
- Hypnosis
";
$g1046 = "Armaldo @ Life Orb
Ability: Battle Armor
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Swords Dance
- Stone Edge
- Knock Off
- Aqua Jet
";
$g1055 = "Hippowdon @ Expert Belt
Ability: Sand Stream
Tera Type: &
EVs: 100 HP / 252 Atk / 156 SpD
Brave Nature
- Slack Off
- High Horsepower
- Rock Slide
- Fire Fang
";
$g1064 = "Bronzong @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Protect
- Stealth Rock
- Gyro Ball
- Explosion
";
$g1073 = "Electivire @ Life Orb
Ability: Motor Drive
Tera Type: &
EVs: 200 Atk / 128 Def / 180 Spe
Adamant Nature
- Wild Charge
- Cross Chop
- Power-Up Punch
- Fire Punch
";
$g1082 = "Hitmonchan @ Muscle Band
Ability: Iron Fist
Tera Type: &
EVs: 204 HP / 252 Atk / 52 Spe
Adamant Nature
- Drain Punch
- Ice Punch
- Fire Punch
- Thunder Punch
";
$g1091 = "Incineroar @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Growl
- Parting Shot
- Darkest Lariat
- Flare Blitz
";
$g1100 = "Hitmonchan @ Rocky Helmet
Ability: Iron Fist
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Impish Nature
- Rapid Spin
- Fake Out
- Drain Punch
- Low Sweep
";
$g1109 = "Diggersby @ Normal Gem
Ability: Huge Power
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Horsepower
- Body Slam
- Gunk Shot
- Bounce
";
$g1118 = "Lurantis @ Leftovers
Ability: Contrary
Tera Type: &
EVs: 248 HP / 60 Atk / 200 SpA
Brave Nature
- Leaf Storm
- Superpower
- Synthesis
- Protect
";
$g1127 = "Ditto @ Sitrus Berry
Ability: Imposter
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g1136 = "Dragapult @ Spell Tag
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Spe
Naive Nature
- Will-O-Wisp
- Hex
- U-turn
- Fly
";
$g1145 = "Whiscash @ Leftovers
Ability: Anticipation
Tera Type: &
EVs: 56 Atk / 252 Def / 100 SpD / 100 Spe
Adamant Nature
- Protect
- Dragon Dance
- Dive
- Stomping Tantrum
";
$g1154 = "Shuckle @ Chesto Berry
Ability: Contrary
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Bold Nature
- Shell Smash
- Rest
- Infestation
- Knock Off
";
$g1163 = "Rotom-Wash @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Trick
- Hydro Pump
- Volt Switch
- Will-O-Wisp
";
$g1172 = "Shuckle @ Leftovers
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 252 Spe
Jolly Nature
- Sticky Web
- Stealth Rock
- Infestation
- Toxic
";
$g1181 = "Shuckle @ Leftovers
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Infestation
- Protect
- Toxic
- Rock Slide
";
$g1190 = "Victini @ Heavy-Duty Boots
Ability: Victory Star
Tera Type: &
EVs: 100 HP / 100 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bolt Strike
- Flame Charge
- V-create
- Bounce
";
$g1199 = "Jirachi @ Choice Scarf
Ability: Serene Grace
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Iron Head
- Fire Punch
- Life Dew
- Trick
";
$g1208 = "Perrserker @ Sitrus Berry
Ability: Steely Spirit
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Fake Out
- Iron Head
- Payback
- Play Rough
";
$g1217 = "Blissey @ Leftovers
Ability: Serene Grace
Tera Type: &
EVs: 252 Atk / 200 Def / 56 Spe
Adamant Nature
- Soft-Boiled
- Ice Punch
- Ice Beam
- Blizzard
";
$g1226 = "Blissey @ Choice Specs
Ability: Serene Grace
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Hyper Beam
- Ice Beam
- Flamethrower
- Tri Attack
";
$g1235 = "Chansey @ Eviolite
Ability: Healer
Tera Type: &
EVs: 252 HP / 252 SpD
Calm Nature
- Teleport
- Heal Bell
- Helping Hand
- Soft-Boiled
";
$g1244 = "Skuntank @ Shuca Berry
Ability: Aftermath
Tera Type: &
EVs: 160 Def / 252 SpA / 40 SpD / 56 Spe
Modest Nature
- Dark Pulse
- Sludge Bomb
- Flamethrower
- Defog
";
$g1253 = "Zweilous @ Eviolite
Ability: Hustle
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Bold Nature
- Rest
- Sleep Talk
- Dragon Tail
- Roar
";
$g1262 = "Shedinja @ Heavy-Duty Boots
Ability: Wonder Guard
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 252 Spe
Brave Nature
- Will-O-Wisp
- Sucker Punch
- Shadow Sneak
- Toxic
";
$g1272 = "Kartana @ Assault Vest
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 252 Spe
Timid Nature
- Leaf Blade
- Smart Strike
- Sacred Sword
- Knock Off
";
$g1281 = "Pincurchin @ Leftovers
Ability: Electric Surge
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe
Modest Nature
- Rising Voltage
- Recover
- Scald
- Toxic Spikes
";
$g1290 = "Stonjourner @ Assault Vest
Ability: Power Spot
Tera Type: &
EVs: 128 HP / 128 Atk / 252 SpD
Careful Nature
- Stone Edge
- Body Press
- Heat Crash
- Rock Slide
";
$g1299 = "Araquanid @ Leftovers
Ability: Water Bubble
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- Sticky Web
- Liquidation
- Mirror Coat
- Stockpile
";
$g1308 = "Incineroar @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Fake Out
- Will-O-Wisp
- Darkest Lariat
- Flare Blitz
";
$g1317 = "Shedinja @ Heavy-Duty Boots
Ability: Wonder Guard
Tera Type: &
EVs: 252 Atk / 252 Spe
Brave Nature
- Will-O-Wisp
- Sucker Punch
- Shadow Sneak
- Protect
";
$g1326 = "Regigigas @ Leftovers
Ability: Slow Start
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- Protect
- Substitute
- Body Slam
- High Horsepower
";
$g1335 = "Slowbro-Galar @ Quick Claw
Ability: Quick Draw
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA
Brave Nature
- Belly Drum
- Shell Side Arm
- Earthquake
- Liquidation
";
$g1344 = "Wobbuffet @ Custap Berry
Ability: Telepathy
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Calm Nature
- Counter
- Mirror Coat
- Destiny Bond
- Charm
";
$g1353 = "Lapras @ Weakness Policy
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 216 Def / 40 SpA
Modest Nature
- Freeze-Dry
- Hydro Pump
- Sing
- Mimic
";
$g1362 = "Wobbuffet @ Custap Berry
Ability: Telepathy
Tera Type: &
EVs: 248 HP / 252 Def
Bold Nature
- Counter
- Mirror Coat
- Destiny Bond
- Charm
";
$g1371 = "Lapras @ Sitrus Berry
Ability: Water Absorb
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Waterfall
- Megahorn
- Drill Run
";
$g1380 = "Jirachi @ Weakness Policy
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 252 Spe
Serious Nature
- Cosmic Power
- Stored Power
- Aura Sphere
- Wish
";
$g1389 = "Ribombee @ Focus Sash
Ability: Shield Dust
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Sticky Web
- Moonblast
- Bug Buzz
- Quiver Dance
";
$g1398 = "Kartana @ Focus Sash
Ability: Beast Boost
Tera Type: &
EVs: 4 Atk / 252 SpD / 252 Spe
Jolly Nature
- Knock Off
- Defog
- Tailwind
- Smart Strike
";
$g1407 = "Venusaur @ Leftovers
Ability: Overgrow
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Leech Seed
- Protect
- Substitute
- Giga Drain
";
$g1416 = "Urshifu-Rapid-Strike @ Expert Belt
Ability: Unseen Fist
Tera Type: &
EVs: 128 Atk / 128 SpD / 252 Spe
Jolly Nature
- Surging Strikes
- Brick Break
- Fire Punch
- Ice Punch
";
$g1425 = "Dhelmise @ Rocky Helmet
Ability: Steelworker
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Rapid Spin
- Poltergeist
- Power Whip
- Anchor Shot
";
$g1434 = "Scizor @ Rocky Helmet
Ability: Technician
Tera Type: &
EVs: 248 HP / 252 Def
Impish Nature
- Iron Defense
- Roost
- Struggle Bug
- Fury Cutter
";
$g1443 = "Toxapex @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Poison Jab
- Liquidation
- Knock Off
- Poison Sting
";
$g1452 = "Shiftry @ Life Orb
Ability: Pickpocket
Tera Type: &
EVs: 156 Atk / 252 SpA / 100 Spe
Mild Nature
- Dark Pulse
- Leaf Storm
- Defog
- Sucker Punch
";
$g1461 = "Stunfisk @ Sitrus Berry
Ability: Static
Tera Type: &
EVs: 252 Def / 100 SpA / 156 SpD
Calm Nature
- Stealth Rock
- Discharge
- Earth Power
- Toxic
";
$g1470 = "Rapidash-Galar @ Life Orb
Ability: Pastel Veil
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Psychic
- Play Rough
- Mystical Fire
- Protect
";
$g1479 = "Mr. Mime-Galar @ Eviolite
Ability: Vital Spirit
Tera Type: &
EVs: 248 HP / 200 Def / 60 Spe
Timid Nature
- Taunt
- Healing Wish
- Freeze-Dry
- Hypnosis
";
$g1488 = "Latias @ Colbur Berry
Ability: Levitate
Tera Type: &
EVs: 96 HP / 100 Def / 112 SpA / 100 SpD / 100 Spe
Modest Nature
- Healing Wish
- Calm Mind
- Psychic
- Dragon Pulse
";
$g1497 = "Raikou @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 88 Atk / 252 SpA / 168 Spe
Serious Nature
- Substitute
- Calm Mind
- Thunderbolt
- Dig
";
$g1506 = "Absol @ Chople Berry
Ability: Pressure
Shiny: Yes
Tera Type: &
EVs: 120 HP / 252 Atk / 136 Spe
Adamant Nature
- Knock Off
- Sucker Punch
- Close Combat
- Play Rough
";
$g1516 = "Rotom @ Sitrus Berry
Ability: Levitate
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Defog
- Hex
- Discharge
- Will-O-Wisp
";
$g1525 = "Spiritomb @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Bold Nature
- Calm Mind
- Will-O-Wisp
- Hex
- Protect
";
$g1534 = "Moltres-Galar @ Assault Vest
Ability: Berserk
Tera Type: &
EVs: 100 HP / 252 SpA / 8 SpD / 148 Spe
Modest Nature
- Fiery Wrath
- Air Slash
- Hurricane
- Snarl
";
$g1543 = "Spiritomb @ Sitrus Berry
Ability: Pressure
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Will-O-Wisp
- Pain Split
- Poltergeist
- Sucker Punch
";
$g1552 = "Vespiquen @ Heavy-Duty Boots
Ability: Pressure
Tera Type: &
EVs: 248 HP / 200 Def / 60 SpD
Bold Nature
- Roost
- Defend Order
- Toxic
- Attack Order
";
$g1561 = "Cradily @ Weakness Policy
Ability: Suction Cups
Tera Type: &
EVs: 100 HP / 156 Atk / 252 Spe
Adamant Nature
- Swords Dance
- Stone Edge
- String Shot
- Seed Bomb
";
$g1570 = "Hawlucha @ White Herb
Ability: Unburden
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Close Combat
- Brave Bird
- Swords Dance
- Taunt
";
$g1579 = "Nidoking @ Leftovers
Ability: Poison Point
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Stealth Rock
- Toxic Spikes
- Super Fang
- Bulldoze
";
$g1588 = "Urshifu-Rapid-Strike @ Maranga Berry
Ability: Unseen Fist
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Helping Hand
- Iron Defense
- Taunt
- Rest
";
$g1597 = "Torkoal @ Heavy-Duty Boots
Ability: Drought
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Modest Nature
- Lava Plume
- Stealth Rock
- Rapid Spin
- Shell Smash
";
$g1606 = "Walrein @ Leftovers
Ability: Thick Fat
Tera Type: &
EVs: 248 HP / 200 Def / 60 SpA
Modest Nature
- Super Fang
- Brine
- Icy Wind
- Protect
";
$g1615 = "Genesect-Burn @ Burn Drive
Ability: Download
Shiny: Yes
Tera Type: &
EVs: 44 HP / 200 Atk / 22 Def / 22 SpD / 200 Spe
Relaxed Nature
- Blaze Kick
- Iron Head
- Shift Gear
- Zen Headbutt
";
$g1625 = "Kangaskhan @ Chople Berry
Ability: Scrappy
Tera Type: &
EVs: 248 HP / 236 Atk / 24 Spe
Adamant Nature
- Double-Edge
- Counter
- Fake Out
- Low Kick
";
$g1634 = "Genesect-Douse @ Douse Drive
Ability: Download
Tera Type: &
EVs: 252 Atk / 252 Spe
Jolly Nature
- Techno Blast
- Extreme Speed
- Explosion
- Magic Coat
";
$g1643 = "Shiinotic @ Quick Claw
Ability: Effect Spore
Tera Type: &
EVs: 248 HP / 176 Def / 84 SpA
Modest Nature
- Spore
- Leech Seed
- Moonblast
- Giga Drain
";
$g1652 = "Tentacruel @ Black Sludge
Ability: Rain Dish
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Protect
- Rain Dance
- Scald
- Acid Spray
";
$g1661 = "Pangoro @ Chople Berry
Ability: Iron Fist
Tera Type: &
EVs: 100 HP / 252 Def / 156 SpD
Impish Nature
- Knock Off
- Parting Shot
- Roar
- Low Sweep
";
$g1670 = "Zarude @ Tanga Berry
Ability: Leaf Guard
Tera Type: &
EVs: 196 HP / 4 SpD / 156 Spe
Adamant Nature
- Jungle Healing
- Darkest Lariat
- Bulk Up
- Protect
";
$g1679 = "Runerigus @ Sitrus Berry
Ability: Wandering Spirit
Tera Type: &
EVs: 216 HP / 252 Atk / 40 Spe
Adamant Nature
- Poltergeist
- Toxic Spikes
- Bulldoze
- Thief
";
$g1688 = "Silvally-Bug @ Bug Memory
Ability: RKS System
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Multi-Attack
- U-turn
- Thunder Fang
- Tailwind
";
$g1697 = "Primarina @ Salac Berry
Ability: Torrent
Tera Type: &
EVs: 100 HP / 156 Def / 252 Spe
Timid Nature
- Calm Mind
- Endure
- Scald
- Moonblast
";
$g1706 = "Qwilfish @ Weakness Policy
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 196 Atk / 64 Spe
Adamant Nature
- Swords Dance
- Scale Shot
- Waterfall
- Poison Jab
";
$g1715 = "Dunsparce @ Leftovers
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 72 Atk / 92 Def / 92 SpD
Adamant Nature
- Glare
- Agility
- Rock Slide
- Roost
";
$g1724 = "Decidueye @ Sharp Beak
Ability: Long Reach
Tera Type: &
EVs: 180 HP / 252 Atk / 76 Spe
Adamant Nature
- Synthesis
- Swords Dance
- Brave Bird
- Dual Wingbeat
";
$g1733 = "Poliwrath @ Leftovers
Ability: Swift Swim
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Curse
- Waterfall
- Circle Throw
- Dig
";
$g1742 = "Rapidash @ Sitrus Berry
Ability: Flame Body
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Flare Blitz
- High Horsepower
- Play Rough
";
$g1751 = "Miltank @ Metronome
Ability: Thick Fat
Tera Type: &
EVs: 4 Def / 252 SpD / 252 Spe
Jolly Nature
- Defense Curl
- Rollout
- Heal Bell
- Milk Drink
";
$g1760 = "Pyukumuku @ White Herb
Ability: Innards Out
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Calm Nature
- Light Screen
- Reflect
- Toxic
- Curse
";
$g1769 = "Corvisquire @ Eviolite
Ability: Unnerve
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Impish Nature
- Roost
- Defog
- Fly
- Agility
";
$g1778 = "Thievul @ Life Orb
Ability: Unburden
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Nasty Plot
- Dark Pulse
- Burning Jealousy
- Taunt
";
$g1787 = "Articuno @ Heavy-Duty Boots
Ability: Snow Cloak
Tera Type: &
EVs: 200 HP / 56 SpA / 252 SpD
Modest Nature
- Icy Wind
- Roost
- Ice Beam
- Whirlwind
";
$g1796 = "Lopunny @ Sticky Barb
Ability: Klutz
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Switcheroo
- Thunder Wave
- Charm
- Encore
";
$g1805 = "Cramorant @ Rocky Helmet
Ability: Gulp Missile
Tera Type: &
EVs: 252 HP / 94 Def / 162 SpD
Bold Nature
- Stockpile
- Roost
- Scald
- Spit Up
";
$g1814 = "Manectric @ Choice Specs
Ability: Lightning Rod
Tera Type: &
EVs: 200 SpA / 4 SpD / 252 Spe
Timid Nature
- Volt Switch
- Thunderbolt
- Overheat
- Switcheroo
";
$g1823 = "Vaporeon @ Leftovers
Ability: Water Absorb
Tera Type: &
EVs: 100 HP / 100 Def / 156 SpD
Careful Nature
- Aqua Ring
- Dive
- Curse
- Protect
";
$g1832 = "Trevenant @ Sitrus Berry
Ability: Harvest
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Impish Nature
- Leech Seed
- Ingrain
- Dig
- Substitute
";
$g1841 = "Amoonguss @ Rocky Helmet
Ability: Effect Spore
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe
Modest Nature
- Spore
- Hex
- Giga Drain
- Sludge Bomb
";
$g1850 = "Buzzwole @ Assault Vest
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Leech Life
- Drain Punch
- Thunder Punch
- Bulldoze
";
$g1859 = "Regirock @ Life Orb
Ability: Clear Body
Tera Type: &
EVs: 252 Atk / 252 Spe
Adamant Nature
- Rock Slide
- Earthquake
- Counter
- Stone Edge
";
$g1868 = "Landorus @ Normal Gem
Ability: Sand Force
Tera Type: &
EVs: 128 Def / 128 SpA / 252 Spe
Timid Nature
- Earth Power
- Explosion
- Sludge Wave
- Stealth Rock
";
$g1877 = "Snorlax @ Iapapa Berry
Ability: Gluttony
Tera Type: &
EVs: 22 HP / 200 Def / 22 SpD / 252 Spe
Timid Nature
- Recycle
- Protect
- Substitute
- Toxic
";
$g1886 = "Combusken @ Charcoal
Ability: Speed Boost
Tera Type: &
EVs: 88 HP / 244 Atk / 88 Def / 88 SpD
Adamant Nature
- Blaze Kick
- Low Sweep
- Bulk Up
- Protect
";
$g1895 = "Inteleon @ Scope Lens
Ability: Sniper
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Snipe Shot
- Surf
- Ice Beam
- Focus Energy
";
$g1904 = "Milotic @ Leftovers
Ability: Marvel Scale
Tera Type: &
EVs: 182 HP / 252 Atk / 52 SpD
Careful Nature
- Hypnosis
- Coil
- Aqua Tail
- Recover
";
$g1913 = "Butterfree @ Choice Specs
Ability: Tinted Lens
Tera Type: &
EVs: 252 SpA / 252 Spe
Modest Nature
- Hurricane
- Air Slash
- Bug Buzz
- Psychic
";
$g1922 = "Zeraora @ Magnet
Ability: Volt Absorb
Tera Type: &
EVs: 104 HP / 152 SpA / 252 Spe
Jolly Nature
- Snarl
- Plasma Fists
- Bulk Up
- Taunt
";
$g1931 = "Kingdra @ Scope Lens
Ability: Sniper
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Rain Dance
- Hydro Pump
- Draco Meteor
- Icy Wind
";
$g1940 = "Tsareena @ Heavy-Duty Boots
Ability: Queenly Majesty
Tera Type: &
EVs: 252 HP / 180 Atk / 76 SpD
Careful Nature
- Rapid Spin
- Power Whip
- High Jump Kick
- Toxic
";
$g1949 = "Indeedee-F @ Sitrus Berry
Ability: Psychic Surge
Tera Type: &
EVs: 72 HP / 52 Def / 128 SpA / 4 SpD / 252 Spe
Timid Nature
- Expanding Force
- Heal Pulse
- Protect
- Hyper Voice
";
$g1958 = "Ninetales-Alola @ Light Clay
Ability: Snow Warning
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Timid Nature
- Aurora Veil
- Hypnosis
- Freeze-Dry
- Heal Bell
";
$g1967 = "Calyrex @ Choice Scarf
Ability: Unnerve
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Trick
- Energy Ball
- Expanding Force
- Life Dew
";
$g1976 = "Comfey @ Leftovers
Ability: Triage
Tera Type: &
EVs: 252 HP / 252 SpD
Calm Nature
- Synthesis
- Calm Mind
- Draining Kiss
- Charm
";
$g1985 = "Arctozolt @ Blunder Policy
Ability: Static
Tera Type: &
EVs: 252 Atk / 252 Spe
Adamant Nature
- Blizzard
- Bolt Beak
- Icicle Crash
- Low Kick
";
$g1994 = "Cinderace @ Heavy-Duty Boots
Ability: Libero
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- High Jump Kick
- Pyro Ball
- Taunt
- Super Fang
";
$g2003 = "Pelipper @ Heavy-Duty Boots
Ability: Drizzle
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Defog
- Hurricane
- Surf
- Roost
";
$g2012 = "Nihilego @ Focus Sash
Ability: Beast Boost
Tera Type: &
EVs: 232 Def / 4 SpD / 252 Spe
Timid Nature
- Stealth Rock
- Toxic Spikes
- Power Gem
- Sludge Bomb
";
$g2021 = "Metagross @ Normal Gem
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Explosion
- Meteor Mash
- Stealth Rock
- Toxic
";
$g2030 = "Metagross @ Air Balloon
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Meteor Mash
- Iron Defense
- Body Press
- Bullet Punch
";
$g2039 = "Arcanine @ Expert Belt
Ability: Intimidate
Tera Type: &
EVs: 116 HP / 140 Atk / 252 Spe
Jolly Nature
- Morning Sun
- Play Rough
- Wild Charge
- Flare Blitz
";
$g2048 = "Suicune @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 72 Def / 112 SpA / 72 SpD / 252 Spe
Modest Nature
- Snarl
- Helping Hand
- Scald
- Ice Beam
";
$g2057 = "Gastrodon @ Rocky Helmet
Ability: Storm Drain
Tera Type: &
EVs: 252 Def / 252 SpD
Relaxed Nature
- Stockpile
- Recover
- Sludge Bomb
- Scald
";
$g2066 = "Gothitelle @ Leftovers
Ability: Competitive
Tera Type: &
EVs: 252 HP / 144 Def / 4 SpA / 108 SpD
Calm Nature
- Protect
- Toxic
- Psyshock
- Helping Hand
";
$g2075 = "Grapploct @ Sitrus Berry
Ability: Limber
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Octolock
- Close Combat
- Protect
- Liquidation
";
$g2084 = "Centiskorch @ Assault Vest
Ability: Flash Fire
Tera Type: &
EVs: 248 HP / 252 SpD
Careful Nature
- Fire Lash
- Leech Life
- Power Whip
- Knock Off
";
$g2093 = "Weezing @ Black Sludge
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Will-O-Wisp
- Sludge Bomb
- Pain Split
- Destiny Bond
";
$g2102 = "Weezing-Galar @ Black Sludge
Ability: Neutralizing Gas
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Toxic Spikes
- Sludge Bomb
- Corrosive Gas
- Pain Split
";
$g2111 = "Xatu @ Heavy-Duty Boots
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Defog
- Air Slash
- Psychic
- Roost
";
$g2120 = "Articuno-Galar @ Bright Powder
Ability: Competitive
Tera Type: &
EVs: 64 HP / 64 Def / 64 SpD / 252 Spe
Timid Nature
- Calm Mind
- Future Sight
- Air Slash
- Psycho Shift
";
$g2129 = "Magnezone @ Magnet
Ability: Analytic
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Relaxed Nature
- Thunderbolt
- Curse
- Body Press
- Explosion
";
$g2138 = "Barraskewda @ Choice Band
Ability: Swift Swim
Tera Type: &
EVs: 156 HP / 96 Atk / 4 SpD / 252 Spe
Adamant Nature
- Liquidation
- Drill Run
- Close Combat
- Flip Turn
";
$g2147 = "Coalossal @ Power Herb
Ability: Steam Engine
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Fire Blast
- Meteor Beam
- Ancient Power
- Rock Polish
";
$g2156 = "Azelf @ Focus Sash
Ability: Levitate
Tera Type: &
EVs: 128 Atk / 128 SpA / 252 Spe
Naive Nature
- Stealth Rock
- Explosion
- Psychic
- Flamethrower
";
$g2165 = "Volcanion @ Sitrus Berry
Ability: Water Absorb
Tera Type: &
EVs: 136 HP / 120 Def / 252 Spe
Timid Nature
- Steam Eruption
- Overheat
- Haze
- Scorching Sands
";
$g2174 = "Barbaracle @ White Herb
Ability: Tough Claws
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Shell Smash
- Liquidation
- Brick Break
- Rock Blast
";
$g2183 = "Sigilyph @ Flame Orb
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 252 Spe
Timid Nature
- Psycho Shift
- Air Slash
- Roost
- Defog
";
$g2192 = "Goodra @ Leftovers
Ability: Hydration
Tera Type: &
EVs: 252 HP / 100 SpA / 156 Spe
Bold Nature
- Rain Dance
- Muddy Water
- Life Dew
- Dragon Pulse
";
$g2201 = "Vaporeon @ Lum Berry
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 252 Atk
Adamant Nature
- Flip Turn
- Helping Hand
- Toxic
- Wish
";
$g2210 = "Greedent @ Kee Berry
Ability: Cheek Pouch
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Stuff Cheeks
- Body Press
- Rest
- Super Fang
";
$g2219 = "Beartic @ Never-Melt Ice
Ability: Slush Rush
Tera Type: &
EVs: 8 HP / 252 Atk / 4 SpD / 244 Spe
Adamant Nature
- Hail
- Icicle Crash
- Brick Break
- Liquidation
";
$g2228 = "Lopunny @ Assault Vest
Ability: Klutz
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Switcheroo
- High Jump Kick
- Protect
- Facade
";
$g2237 = "Wigglytuff @ Life Orb
Ability: Competitive
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Hyper Voice
- Flamethrower
- Ice Beam
- Thunderbolt
";
$g2246 = "Falinks @ Expert Belt
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- No Retreat
- Close Combat
- Megahorn
- Zen Headbutt
";
$g2255 = "Persian-Alola @ Rocky Helmet
Ability: Fur Coat
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Fake Out
- Parting Shot
- Toxic
- Knock Off
";
$g2264 = "Krookodile @ Soft Sand
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Naive Nature
- High Horsepower
- Taunt
- Crunch
- Snarl
";
$g2273 = "Corsola-Galar @ Eviolite
Ability: Cursed Body
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Strength Sap
- Will-O-Wisp
- Hex
- Curse
";
$g2282 = "Diancie @ Assault Vest
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 88 Atk / 88 SpA / 80 SpD
Relaxed Nature
- Diamond Storm
- Moonblast
- Mystical Fire
- Draining Kiss
";
$g2291 = "Whimsicott @ Leftovers
Ability: Prankster
Tera Type: &
EVs: 252 HP / 40 Def / 4 SpA / 212 SpD
Bold Nature
- Leech Seed
- Stun Spore
- Taunt
- Moonblast
";
$g2300 = "Bellossom @ Leftovers
Ability: Chlorophyll
Tera Type: &
EVs: 140 HP / 112 SpA / 4 SpD / 252 Spe
Modest Nature
- Sleep Powder
- Quiver Dance
- Giga Drain
- Moonblast
";
$g2309 = "Clawitzer @ Sitrus Berry
Ability: Mega Launcher
Tera Type: &
EVs: 252 HP / 56 Def / 136 SpA / 64 SpD
Modest Nature
- Water Pulse
- Dark Pulse
- Aura Sphere
- Helping Hand
";
$g2318 = "Celesteela @ Big Root
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Relaxed Nature
- Leech Seed
- Giga Drain
- Heavy Slam
- Air Slash
";
$g2327 = "Frosmoth @ Heavy-Duty Boots
Ability: Ice Scales
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Modest Nature
- Air Slash
- Ice Beam
- Bug Buzz
- Quiver Dance
";
$g2337 = "Golisopod @ Assault Vest
Ability: Emergency Exit
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- First Impression
- Sucker Punch
- Aqua Jet
- Leech Life
";
$g2346 = "Tangela @ Eviolite
Ability: Regenerator
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Sleep Powder
- Leech Seed
- Giga Drain
- Synthesis
";
$g2356 = "Bouffalant @ Choice Band
Ability: Reckless
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Head Charge
- Megahorn
- High Horsepower
- Close Combat
";
$g2365 = "Drednaw @ Weakness Policy
Ability: Swift Swim
Tera Type: &
EVs: 144 HP / 200 Atk / 48 SpD / 116 Spe
Adamant Nature
- Rain Dance
- Waterfall
- Stone Edge
- Megahorn
";
$g2374 = "Rotom-Mow @ Iapapa Berry
Ability: Levitate
Tera Type: &
EVs: 112 HP / 48 Def / 156 SpA / 12 SpD / 76 Spe
Modest Nature
- Will-O-Wisp
- Defog
- Volt Switch
- Leaf Storm
";
$g2383 = "Sylveon @ Kee Berry
Ability: Pixilate
Tera Type: &
EVs: 200 Def
Bold Nature
- Calm Mind
- Wish
- Protect
- Hyper Voice
";
$g2392 = "Snorlax @ Choice Band
Ability: Thick Fat
Tera Type: &
EVs: 108 Atk / 68 Def / 124 SpD / 48 Spe
Adamant Nature
- Self-Destruct
- Body Slam
- High Horsepower
- Fire Punch
";
$g2401 = "Zeraora @ Leftovers
Ability: Volt Absorb
Tera Type: &
EVs: 252 HP / 4 Atk / 136 SpA / 116 Spe
Adamant Nature
- Fake Out
- Knock Off
- Snarl
- Volt Switch
";
$g2410 = "Indeedee-F @ Twisted Spoon
Ability: Psychic Surge
Tera Type: &
EVs: 204 Def / 132 SpA / 72 Spe
Modest Nature
- Expanding Force
- Mystical Fire
- Calm Mind
- Aromatherapy
";
$g2419 = "Malamar @ Sitrus Berry
Ability: Contrary
Tera Type: &
EVs: 248 HP / 72 Atk / 180 Def / 8 SpD
Adamant Nature
- Superpower
- Knock Off
- Psycho Cut
- Liquidation
";
$g2428 = "Tangrowth @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 220 HP / 100 Atk / 156 SpD
Adamant Nature
- Power Whip
- Knock Off
- Earthquake
- Rock Tomb
";
$g2437 = "Slowking-Galar @ Red Card
Ability: Regenerator
Tera Type: &
EVs: 80 HP / 200 Atk / 156 Spe
Adamant Nature
- Belly Drum
- Slack Off
- Drain Punch
- Zen Headbutt
";
$g2446 = "Clefable @ Leftovers
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 252 SpD
Calm Nature
- Moonblast
- Moonlight
- Toxic
- Encore
";
$g2455 = "Druddigon @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 156 HP / 200 SpA / 140 Spe
Modest Nature
- Draco Meteor
- Flamethrower
- Focus Blast
- Flash Cannon
";
$g2464 = "Gurdurr @ Eviolite
Ability: Guts
Tera Type: &
EVs: 156 HP / 80 Atk / 200 Def / 24 SpD / 16 Spe
Impish Nature
- Defog
- Knock Off
- Dig
- Drain Punch
";
$g2473 = "Doublade @ Eviolite
Ability: No Guard
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Iron Defense
- Iron Head
- Rest
- Shadow Claw
";
$g2482 = "Landorus-Therian @ Normal Gem
Ability: Intimidate
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stealth Rock
- Explosion
- Earthquake
- Rock Slide
";
$g2492 = "Lunatone @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 208 HP / 124 SpA / 176 SpD
Modest Nature
- Calm Mind
- Psychic
- Ice Beam
- Rest
";
$g2501 = "Magnezone @ Assault Vest
Ability: Magnet Pull
Tera Type: &
EVs: 128 HP / 200 SpA / 108 SpD
Modest Nature
- Flash Cannon
- Steel Beam
- Volt Switch
- Mirror Coat
";
$g2510 = "Necrozma @ Weakness Policy
Ability: Prism Armor
Tera Type: &
EVs: 252 HP / 128 Atk / 128 Spe
Naughty Nature
- Dragon Dance
- Photon Geyser
- Moonlight
- Iron Defense
";
$g2519 = "Dracozolt @ Life Orb
Ability: Hustle
Tera Type: &
EVs: 96 HP / 44 Atk / 144 SpA / 156 Spe
Naughty Nature
- Bolt Beak
- High Horsepower
- Draco Meteor
- Fire Blast
";
$g2528 = "Scizor @ Occa Berry
Ability: Swarm
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- U-turn
- Bullet Punch
- Tailwind
- Roost
";
$g2537 = "Swoobat @ Weakness Policy
Ability: Simple
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Calm Mind
- Psychic
- Air Slash
- Heat Wave
";
$g2546 = "Cleffa @ Eviolite
Ability: Magic Guard
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Toxic
- Amnesia
- Rest
- Seismic Toss
";
$g2556 = "Jirachi @ Leftovers
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 64 Atk / 28 Def / 76 SpD / 88 Spe
Careful Nature
- Stealth Rock
- Thunder Wave
- Iron Head
- Healing Wish
";
$g2565 = "Liepard @ Iapapa Berry
Ability: Prankster
Tera Type: &
EVs: 236 HP / 100 Atk / 64 Def / 108 Spe
Jolly Nature
- Knock Off
- Protect
- Taunt
- U-turn
";
$g2574 = "Nidoqueen @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 80 HP / 200 SpA / 200 Spe
Modest Nature
- Earth Power
- Sludge Bomb
- Ice Beam
- Thunderbolt
";
$g2583 = "Mew @ Sitrus Berry
Ability: Synchronize
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Calm Nature
- Block
- Imprison
- Transform
- Roost
";
$g2592 = "Altaria @ Eject Button
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 252 Spe
Timid Nature
- Perish Song
- Roost
- Defog
- Hurricane
";
$g2601 = "Copperajah @ Expert Belt
Ability: Heavy Metal
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Heavy Slam
- Heat Crash
- Power Whip
- Stealth Rock
";
$g2610 = "Gothitelle @ Iapapa Berry
Ability: Competitive
Tera Type: &
EVs: 200 HP / 36 SpA / 200 Spe
Modest Nature
- Fake Out
- Calm Mind
- Shadow Ball
- Psychic
";
$g2619 = "Scrafty @ Chesto Berry
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Bulk Up
- Rest
- Drain Punch
- Crunch
";
$g2628 = "Blaziken @ Life Orb
Ability: Speed Boost
Tera Type: &
EVs: 156 Atk / 100 SpA / 112 Spe
Lonely Nature
- Overheat
- Close Combat
- Dig
- Thunder Punch
";
$g2637 = "Celebi @ Leftovers
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Heal Bell
- Substitute
- Giga Drain
- Healing Wish
";
$g2646 = "Dubwool @ Maranga Berry
Ability: Fluffy
Tera Type: &
EVs: 156 HP / 80 Def / 200 SpD
Impish Nature
- Cotton Guard
- Rest
- Body Press
- Payback
";
$g2655 = "Cursola @ Red Card
Ability: Perish Body
Tera Type: &
EVs: 56 HP / 200 Def / 152 SpA / 100 Spe
Modest Nature
- Stealth Rock
- Shadow Ball
- Earth Power
- Ice Beam
";
$g2664 = "Claydol @ Leftovers
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 252 HP / 64 Def / 100 SpA / 92 SpD
Quiet Nature
- Rapid Spin
- Earth Power
- Psychic
- Trick Room
";
$g2674 = "Mew @ Life Orb
Ability: Synchronize
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Rain Dance
- Hydro Pump
- Thunder
- Soft-Boiled
";
$g2683 = "Celesteela @ Leftovers
Ability: Beast Boost
Tera Type: &
EVs: 200 HP / 72 Atk / 72 Def / 96 SpD
Careful Nature
- Leech Seed
- Fly
- Substitute
- Skull Bash
";
$g2692 = "Tapu Bulu @ Red Card
Ability: Grassy Surge
Tera Type: &
EVs: 252 HP / 56 Atk / 100 SpD / 100 Spe
Adamant Nature
- Swords Dance
- Horn Leech
- Leech Seed
- Focus Punch
";
$g2701 = "Celesteela @ Power Herb
Ability: Beast Boost
Tera Type: &
EVs: 69 HP / 69 Def / 69 SpA / 69 SpD / 69 Spe
Timid Nature
- Autotomize
- Meteor Beam
- Air Slash
- Flamethrower
";
$g2710 = "Espeon @ Life Orb
Ability: Magic Bounce
Tera Type: &
EVs: 156 HP / 80 SpA / 172 Spe
Modest Nature
- Psychic
- Dazzling Gleam
- Shadow Ball
- Morning Sun
";
$g2719 = "Latios @ Soul Dew
Ability: Levitate
Tera Type: &
EVs: 128 HP / 128 / Def / 80 SpA / 176 Spe
Timid Nature
- Draco Meteor
- Psychic
- Calm Mind
- Protect
";
$g2728 = "Luxray @ Sitrus Berry
Ability: Intimidate
Tera Type: &
EVs: 92 HP / 200 Atk / 200 Spe
Adamant Nature
- Wild Charge
- Fire Fang
- Ice Fang
- Play Rough
";
$g2737 = "Avalugg @ Maranga Berry
Ability: Sturdy
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Iron Defense
- Body Press
- Recover
- Avalanche
";
$g2746 = "Rotom-Frost @ Chople Berry
Ability: Levitate
Tera Type: &
EVs: 80 HP / 200 SpA / 200 Spe
Modest Nature
- Nasty Plot
- Thunderbolt
- Thunder
- Blizzard
";
$g2755 = "Archeops @ Sitrus Berry
Ability: Defeatist
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Impish Nature
- Tailwind
- Roost
- Acrobatics
- Stealth Rock
";
$g2764 = "Archeops @ Power Herb
Ability: Defeatist
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Protect
- Meteor Beam
- Air Slash
- Earth Power
";
$g2773 = "Accelgor @ Focus Sash
Ability: Unburden
Tera Type: &
EVs: 56 HP / 200 SpA / 252 Spe
Timid Nature
- Spikes
- Bug Buzz
- Final Gambit
- Encore
";
$g2782 = "Flygon @ Life Orb
Ability: Levitate
Tera Type: &
EVs: 156 Atk / 236 SpA / 100 Spe
Mild Nature
- Earth Power
- Draco Meteor
- Fire Blast
- Dig
";
$g2791 = "Zapdos @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Protect
- Substitute
- Toxic
- Thunderbolt
";
$g2800 = "Eldegoss @ Leftovers
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Rapid Spin
- Aromatherapy
- Giga Drain
- Leech Seed
";
$g2809 = "Silvally-Ice @ Ice Memory
Ability: RKS System
Tera Type: &
EVs: 160 HP / 200 Atk / 100 Spe
Adamant Nature
- Defog
- Swords Dance
- Multi-Attack
- Thunder Fang
";
$g2818 = "Crawdaunt @ Chople Berry
Ability: Adaptability
Tera Type: &
EVs: 100 HP / 160 Atk / 200 Spe
Jolly Nature
- Knock Off
- Liquidation
- Close Combat
- Dragon Dance
";
$g2827 = "Dugtrio-Alola @ Leftovers
Ability: Tangling Hair
Tera Type: &
EVs: 252 HP / 100 Def / 156 Spe
Jolly Nature
- Protect
- Dig
- Mud-Slap
- Toxic
";
$g2836 = "Kyurem-Black @ Rocky Helmet
Ability: Teravolt
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Icicle Spear
- Scale Shot
- Roost
- Helping Hand
";
$g2845 = "Machamp @ Life Orb
Ability: No Guard
Tera Type: &
EVs: 56 HP / 252 Atk / 200 Spe
Adamant Nature
- Dynamic Punch
- High Horsepower
- Ice Punch
- Bullet Punch
";
$g2854 = "Aggron @ Life Orb
Ability: Rock Head
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Head Smash
- Iron Head
- Ice Punch
- Autotomize
";
$g2863 = "Mantine @ Heavy-Duty Boots
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Roost
- Defog
- Scald
- Hurricane
";
$g2872 = "Conkeldurr @ Heavy-Duty Boots
Ability: Iron Fist
Tera Type: &
EVs: 248 HP / 36 Atk / 224 SpD
Sassy Nature
- Defog
- Detect
- Drain Punch
- Payback
";
$g2881 = "Blissey @ Leftovers
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Relaxed Nature
- Hail
- Blizzard
- Ice Punch
- Soft-Boiled
";
$g2890 = "Clawitzer @ Life Orb
Ability: Mega Launcher
Tera Type: &
EVs: 100 HP / 252 SpA / 100 Spe
Modest Nature
- Water Pulse
- Dragon Pulse
- Aura Sphere
- Dive
";
$g2899 = "Volcanion @ Wiki Berry
Ability: Water Absorb
Shiny: Yes
Tera Type: &
EVs: 200 HP / 156 Def / 4 SpA
Bold Nature
- Steam Eruption
- Defog
- Haze
- Will-O-Wisp
";
$g2909 = "Silvally-Poison @ Poison Memory
Ability: RKS System
Tera Type: &
EVs: 156 Atk / 200 SpA / 100 Spe
Serious Nature
- Work Up
- Multi-Attack
- Grass Pledge
- Flamethrower
";
$g2918 = "Mew @ Choice Scarf
Ability: Synchronize
Tera Type: &
EVs: 200 HP / 69 Def / 69 SpD
Bold Nature
- Trick
- Soft-Boiled
- Defog
- Seismic Toss
";
$g2927 = "Drapion @ Leftovers
Ability: Battle Armor
Tera Type: &
EVs: 200 HP / 108 / SpD / 200 Spe
Bold Nature
- Knock Off
- Iron Defense
- Protect
- Toxic Spikes
";
$g2936 = "Aegislash @ Sitrus Berry
Ability: Stance Change
Tera Type: &
EVs: 200 HP / 80 SpA / 140 SpD / 4 Spe
Modest Nature
- Kings Shield
- Destiny Bond
- Shadow Ball
- Flash Cannon
";
$g2945 = "Kyurem-Black @ Life Orb
Ability: Teravolt
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Rain Dance
- Sunny Day
- Hail
- Weather Ball
";
$g2954 = "Zapdos-Galar @ Sitrus Berry
Ability: Defiant
Tera Type: &
EVs: 100 Atk / 152 Def / 152 SpD / 100 Spe
Jolly Nature
- Bulk Up
- Acrobatics
- Thunderous Kick
- U-turn
";
$g2963 = "Landorus-Therian @ Power Herb
Ability: Intimidate
Tera Type: &
EVs: 188 HP / 252 Atk / 60 Spe
Adamant Nature
- U-turn
- Defog
- Stealth Rock
- Fly
";
$g2972 = "Whimsicott @ Sitrus Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 132 Def / 124 SpD
Careful Nature
- U-turn
- Defog
- Knock Off
- Tailwind
";
$g2981 = "Stunfisk-Galar @ Leftovers
Ability: Mimicry
Shiny: Yes
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD
Careful Nature
- Stealth Rock
- Dig
- Yawn
- Bulldoze
";
$g2991 = "Glaceon @ Leftovers
Ability: Snow Cloak
Shiny: Yes
Tera Type: &
EVs: 200 HP / 24 Def / 72 SpA / 192 SpD
Calm Nature
- Ice Beam
- Yawn
- Dig
- Protect
";
$g3001 = "Tapu Koko @ Electric Seed
Ability: Electric Surge
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Discharge
- Roost
- Volt Switch
- Grass Knot
";
$g3010 = "Chandelure @ Life Orb
Ability: Flash Fire
Tera Type: &
EVs: 200 HP / 48 SpA / 156 Spe
Modest Nature
- Calm Mind
- Shadow Ball
- Fire Blast
- Energy Ball
";
$g3019 = "Reuniclus @ Life Orb
Ability: Magic Guard
Shiny: Yes
Tera Type: &
EVs: 156 HP / 100 Def / 96 SpA
Modest Nature
- Trick Room
- Shadow Ball
- Psychic
- Focus Blast
";
$g3029 = "Toxtricity-Low-Key @ Life Orb
Ability: Punk Rock
Shiny: Yes
Tera Type: &
EVs: 8 HP / 100 Atk / 100 Def / 100 SpA / 100 SpD / 100 Spe
Rash Nature
- Overdrive
- Boomburst
- Taunt
- Drain Punch
";
$g3039 = "Blastoise @ Life Orb
Ability: Torrent
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Shell Smash
- Liquidation
- Ice Punch
- Brick Break
";
$g3048 = "Mew @ Light Clay
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Naive Nature
- Hail
- Aurora Veil
- Blizzard
- Explosion
";
$g3057 = "Kabutops @ Life Orb
Ability: Swift Swim
Shiny: Yes
Tera Type: &
EVs: 200 HP / 200 Atk / 108 Spe
Adamant Nature
- Swords Dance
- Stone Edge
- Rapid Spin
- Waterfall
";
$g3067 = "Persian-Alola @ Leftovers
Ability: Fur Coat
Tera Type: &
EVs: 200 HP / 100 Atk / 200 Spe
Jolly Nature
- Fake Out
- Dig
- Knock Off
- Toxic
";
$g3076 = "Weavile @ Life Orb
Ability: Pressure
Tera Type: &
EVs: 100 HP / 200 Atk / 80 Def / 4 SpD / 100 Spe
Jolly Nature
- Fake Out
- Knock Off
- Triple Axel
- Taunt
";
$g3085 = "Mew @ Life Orb
Ability: Synchronize
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psychic Terrain
- Expanding Force
- Nasty Plot
- Soft-Boiled
";
$g3094 = "Silvally-Water @ Water Memory
Ability: RKS System
Shiny: Yes
Tera Type: &
EVs: 184 HP / 192 Atk / 100 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Explosion
- Psychic Fangs
";
$g3104 = "Pelipper @ Choice Band
Ability: Drizzle
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Liquidation
- Fly
- Gunk Shot
- Seed Bomb
";
$g3113 = "Umbreon @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 80 Def / 92 SpA / 84 SpD
Modest Nature
- Snarl
- Toxic
- Moonlight
- Foul Play
";
$g3122 = "Entei @ Assault Vest
Ability: Pressure
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Sacred Fire
- Crunch
- Stomping Tantrum
- Extreme Speed
";
$g3131 = "Druddigon @ Leftovers
Ability: Rough Skin
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Stealth Rock
- Glare
- Dragon Tail
- Fire Punch
";
$g3140 = "Guzzlord @ White Herb
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 252 SpA
Quiet Nature
- Draco Meteor
- Crunch
- Sludge Wave
- Drain Punch
";
$g3149 = "Naganadel @ Focus Sash
Ability: Beast Boost
Tera Type: &
EVs: 52 HP / 204 SpA / 252 Spe
Timid Nature
- Sludge Wave
- Dragon Pulse
- Spikes
- Toxic Spikes
";
$g3158 = "Alcremie @ Rocky Helmet
Ability: Aroma Veil
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Decorate
- Dazzling Gleam
- Recover
- Mystical Fire
";
$g3167 = "Cryogonal @ Heavy-Duty Boots
Ability: Levitate
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
- Rapid Spin
- Freeze-Dry
- Recover
- Toxic
";
$g3176 = "Obstagoon @ Flame Orb
Ability: Reckless
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Obstruct
- Knock Off
- Facade
- Switcheroo
";
$g3185 = "Mimikyu @ Life Orb
Ability: Disguise
Tera Type: &
EVs: 132 HP / 120 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Play Rough
- Shadow Sneak
- Wood Hammer
";
$g3194 = "Orbeetle @ Leftovers
Ability: Frisk
Tera Type: &
EVs: 252 HP / 80 Def / 176 SpD
Calm Nature
- Calm Mind
- Psyshock
- Sticky Web
- Iron Defense
";
$g3203 = "Gothorita @ Eviolite
Ability: Shadow Tag
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Calm Mind
- Psyshock
- Rest
- Shadow Ball
";
$g3212 = "Quagsire @ Leftovers
Ability: Unaware
Tera Type: &
EVs: 252 HP / 252 SpD
Bold Nature
- Recover
- Liquidation
- High Horsepower
- Toxic
";
$g3221 = "Pheromosa @ Life Orb
Ability: Beast Boost
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Close Combat
- Ice Beam
- Bug Buzz
- Poison Jab
";
$g3230 = "Registeel @ Leftovers
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 180 Def / 76 SpD
Calm Nature
- Stealth Rock
- Body Press
- Block
- Toxic
";
$g3239 = "Bewear @ Assault Vest
Ability: Fluffy
Tera Type: &
EVs: 252 HP / 4 Atk / 28 Def / 224 SpD
Adamant Nature
- Close Combat
- High Horsepower
- Body Slam
- Ice Punch
";
$g3248 = "Stakataka @ Red Card
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Body Press
- Gyro Ball
- Trick Room
- Rock Slide
";
$g3257 = "Dragalge @ Assault Vest
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 4 Atk / 140 SpA / 112 Spe
Modest Nature
- Dragon Pulse
- Sludge Wave
- Scale Shot
- Flip Turn
";
$g3266 = "Aegislash @ Leftovers
Ability: Stance Change
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Close Combat
- Kings Shield
- Shadow Claw
- Iron Head
";
$g3275 = "Eiscue @ Heavy-Duty Boots
Ability: Ice Face
Tera Type: &
EVs: 252 Atk / 252 Spe
Adamant Nature
- Belly Drum
- Icicle Crash
- Waterfall
- Head Smash
";
$g3284 = "Azelf @ Red Card
Ability: Levitate
Tera Type: &
EVs: 200 SpA / 100 SpD / 156 Spe
Modest Nature
- Dazzling Gleam
- Psychic
- Grass Knot
- Fire Blast
";
$g3293 = "Rillaboom @ Salac Berry
Ability: Overgrow
Tera Type: &
EVs: 36 HP / 200 Atk / 16 Def / 224 SpA / 16 SpD / 16 Spe
Adamant Nature
- Swords Dance
- Wood Hammer
- Substitute
- Drain Punch
";
$g3302 = "Sawk @ Muscle Band
Ability: Sturdy
Tera Type: &
EVs: 80 HP / 164 Atk / 196 Spe
Adamant Nature
- Close Combat
- Stone Edge
- Ice Punch
- Dig
";
$g3311 = "Zygarde @ Choice Specs
Ability: Aura Break
Tera Type: &
EVs: 64 HP / 120 SpA / 72 SpD / 252 Spe
Timid Nature
- Core Enforcer
- Scorching Sands
- Shock Wave
- Focus Blast
";
$g3320 = "Galvantula @ Heavy-Duty Boots
Ability: Compound Eyes
Tera Type: &
EVs: 40 HP / 200 SpA / 196 Spe
Timid Nature
- Sticky Web
- Bug Buzz
- Thunder
- String Shot
";
$g3329 = "Dugtrio-Alola @ Bright Powder
Ability: Sand Veil
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Mud-Slap
- Sandstorm
- High Horsepower
- Screech
";
$g3338 = "Dragalge @ Red Card
Ability: Poison Point
Tera Type: &
EVs: 196 HP / 196 Def / 80 SpA / 20 Spe
Calm Nature
- Toxic Spikes
- Hydro Pump
- Draco Meteor
- Sludge Bomb
";
$g3347 = "Rotom-Fan @ Heavy-Duty Boots
Ability: Levitate
Tera Type: &
EVs: 192 HP / 80 Def / 196 Spe
Timid Nature
- Will-O-Wisp
- Volt Switch
- Air Slash
- Pain Split
";
$g3356 = "Lapras @ Maranga Berry
Ability: Shell Armor
Tera Type: &
EVs: 252 HP / 28 Atk / 228 Spe
Jolly Nature
- Dragon Dance
- Waterfall
- Outrage
- Iron Tail
";
$g3365 = "Glastrier @ Choice Band
Ability: Chilling Neigh
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Close Combat
- Icicle Crash
- Megahorn
- High Horsepower
";
$g3374 = "Sandslash @ Bright Powder
Ability: Sand Veil
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Naughty Nature
- Mud-Slap
- Curse
- Dig
- Sandstorm
";
$g3383 = "Cinccino @ Kings Rock
Ability: Skill Link
Tera Type: &
EVs: 252 Atk / 252 Spe
Hasty Nature
- Tail Slap
- Bullet Seed
- Rock Blast
- Dig
";
$g3392 = "Exeggutor-Alola @ Sitrus Berry
Ability: Harvest
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Sunny Day
- Wood Hammer
- Dragon Hammer
- Superpower
";
$g3401 = "Tyrantrum @ Life Orb
Ability: Rock Head
Tera Type: &
EVs: 100 HP / 196 Atk / 100 Spe
Adamant Nature
- Head Smash
- Superpower
- Outrage
- Ice Fang
";
$g3410 = "Corviknight @ Wide Lens
Ability: Pressure
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Hurricane
- Steel Beam
- Nasty Plot
- Roost
";
$g3419 = "Lycanroc-Dusk @ Life Orb
Ability: Tough Claws
Tera Type: &
EVs: 156 Atk / 80 Def / 40 SpD / 176 Spe
Jolly Nature
- Accelerock
- Stone Edge
- Swords Dance
- Close Combat
";
$g3428 = "Dedenne @ Sitrus Berry
Ability: Cheek Pouch
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- Nuzzle
- Dig
- Super Fang
- Volt Switch
";
$g3437 = "Mienshao @ Muscle Band
Ability: Regenerator
Tera Type: &
EVs: 140 HP / 112 Atk / 4 SpD / 252 Spe
Jolly Nature
- Fake Out
- High Jump Kick
- U-turn
- Knock Off
";
$g3446 = "Xurkitree @ Assault Vest
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 100 SpA / 156 SpD
Modest Nature
- Electroweb
- Thunderbolt
- Energy Ball
- Volt Switch
";
$g3455 = "Registeel @ Chesto Berry
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 100 Def / 20 SpD
Careful Nature
- Amnesia
- Iron Defense
- Body Press
- Rest
";
$g3464 = "Hitmontop @ Choice Band
Ability: Technician
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Bullet Punch
- Triple Axel
- Close Combat
- Sucker Punch
";
$g3473 = "Mr. Mime-Galar @ Throat Spray
Ability: Vital Spirit
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psyshock
- Screech
- Substitute
- Hypnosis
";
$g3482 = "Slowpoke @ Eviolite
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Calm Mind
- Scald
- Slack Off
- Stored Power
";
$g3491 = "Magmar @ Eviolite
Ability: Flame Body
Tera Type: &
EVs: 52 HP / 100 Atk / 156 SpA / 200 Spe
Timid Nature
- Will-O-Wisp
- Fire Blast
- Protect
- Metronome
";
$g3500 = "Silvally-Fighting @ Fighting Memory
Ability: RKS System
Tera Type: &
EVs: 100 HP / 200 Atk / 100 SpD / 40 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Defog
- Crunch
";
$g3509 = "Drifblim @ Flame Orb
Ability: Flare Boost
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Shadow Ball
- Air Cutter
- Calm Mind
- Thunderbolt
";
$g3518 = "Silvally-Dragon @ Dragon Memory
Ability: RKS System
Tera Type: &
EVs: 56 HP / 200 Atk / 156 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Iron Head
- Fire Fang
";
$g3527 = "Tentacruel @ Assault Vest
Ability: Liquid Ooze
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Acid Spray
- Sludge Wave
- Hydro Pump
- Mirror Coat
";
$g3536 = "Dragonite @ Choice Band
Ability: Multiscale
Tera Type: &
EVs: 96 HP / 156 Atk / 200 Spe
Adamant Nature
- Dragon Claw
- Dual Wingbeat
- Rock Slide
- Fire Punch
";
$g3545 = "Tangrowth @ Heat Rock
Ability: Chlorophyll
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Sunny Day
- Solar Blade
- Stomping Tantrum
";
$g3554 = "Haxorus @ Life Orb
Ability: Mold Breaker
Tera Type: &
EVs: 96 HP / 164 Atk / 200 Spe
Naughty Nature
- Dragon Dance
- Dragon Claw
- Close Combat
- Poison Jab
";
$g3563 = "Dragapult @ Choice Specs
Ability: Infiltrator
Tera Type: &
EVs: 140 HP / 112 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Shadow Ball
- U-turn
- Flamethrower
";
$g3572 = "Tauros @ Life Orb
Ability: Intimidate
Tera Type: &
EVs: 200 Atk / 56 Def / 200 Spe
Adamant Nature
- Close Combat
- Double-Edge
- Lash Out
- High Horsepower
";
$g3581 = "Porygon-Z @ Leftovers
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Recover
- Tri Attack
- Shadow Ball
- Magic Coat
";
$g3590 = "Exploud @ Life Orb
Ability: Scrappy
Tera Type: &
EVs: 200 Atk / 252 Spe
Adamant Nature
- Double-Edge
- Ice Punch
- Fire Punch
- Thunder Punch
";
$g3599 = "Heracross @ Life Orb
Ability: Guts
Tera Type: &
EVs: 96 HP / 200 Atk / 124 Spe
Adamant Nature
- Megahorn
- Close Combat
- Stone Edge
- Knock Off
";
$g3608 = "Blaziken @ Salac Berry
Ability: Blaze
Tera Type: &
EVs: 128 Atk / 128 SpA / 252 Spe
Hasty Nature
- Focus Punch
- Substitute
- Overheat
- Flare Blitz
";
$g3617 = "Dusclops @ Eviolite
Ability: Pressure
Shiny: Yes
Tera Type: &
EVs: 4 HP / 252 Def / 252 SpD
Relaxed Nature
- Haze
- Will-O-Wisp
- Pain Split
- Night Shade
";
$g3627 = "Zarude @ Life Orb
Ability: Leaf Guard
Tera Type: &
EVs: 64 HP / 200 Atk / 80 SpD / 164 Spe
Adamant Nature
- Bulk Up
- Darkest Lariat
- Power Whip
- Rock Slide
";
$g3636 = "Latias @ Roseli Berry
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Calm Nature
- Psychic
- Recover
- Light Screen
- Draco Meteor
";
$g3645 = "Heliolisk @ Bright Powder
Ability: Sand Veil
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sandstorm
- Parabolic Charge
- Discharge
- Glare
";
$g3654 = "Salamence @ Life Orb
Ability: Intimidate
Tera Type: &
EVs: 180 HP / 200 SpA / 84 Spe
Modest Nature
- Draco Meteor
- Fire Blast
- Hurricane
- Roost
";
$g3663 = "Salamence @ Life Orb
Ability: Moxie
Tera Type: &
EVs: 80 HP / 200 Atk / 156 Spe
Adamant Nature
- Dragon Dance
- Outrage
- Dual Wingbeat
- Brick Break
";
$g3672 = "Starmie @ Heavy-Duty Boots
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Rapid Spin
- Recover
- Scald
- Psychic
";
$g3681 = "Tyranitar @ Leftovers
Ability: Sand Stream
Tera Type: &
EVs: 200 HP / 100 Def / 56 SpD / 68 Spe
Impish Nature
- Thunder Wave
- Stone Edge
- Dig
- Dragon Dance
";
$g3690 = "Lapras @ Damp Rock
Ability: Hydration
Tera Type: &
EVs: 248 HP / 8 Atk / 200 SpD
Careful Nature
- Perish Song
- Rain Dance
- Rest
- Whirlpool
";
$g3699 = "Vikavolt @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Bug Buzz
- Thunderbolt
- Sticky Web
- Thunder Wave
";
$g3708 = "Kommo-o @ Sitrus Berry
Ability: Bulletproof
Tera Type: &
EVs: 200 Atk / 200 SpA / 56 Spe
Nature
- Clangorous Soul
- Clanging Scales
- Close Combat
- Iron Head
";
$g3717 = "Primarina @ Muscle Band
Ability: Torrent
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Play Rough
- Aqua Jet
- Triple Axel
- Iron Tail
";
$g3726 = "Blacephalon @ Life Orb
Ability: Beast Boost
Tera Type: &
EVs: 100 HP / 200 SpA / 184 Spe
Modest Nature
- Calm Mind
- Shadow Ball
- Fire Blast
- Encore
";
$g3735 = "Gourgeist-Super @ Life Orb
Ability: Frisk
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Brave Nature
- Poltergeist
- Power Whip
- Explosion
- Trick Room
";
$g3744 = "Toxicroak @ Life Orb
Ability: Dry Skin
Tera Type: &
EVs: 196 Atk / 40 Def / 232 Spe
Adamant Nature
- Swords Dance
- Gunk Shot
- Drain Punch
- Sucker Punch
";
$g3753 = "Snorlax @ Choice Band
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 252 Atk
Adamant Nature
- Self-Destruct
- Heat Crash
- Heavy Slam
- High Horsepower
";
$g3762 = "Klefki @ Mental Herb
Ability: Prankster
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Defog
- Toxic
- Substitute
- Draining Kiss
";
$g3772 = "Amoonguss @ Leftovers
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Spore
- Giga Drain
- Sludge Bomb
- Synthesis
";
$g3781 = "Crobat @ Heavy-Duty Boots
Ability: Infiltrator
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Brave Bird
- U-turn
- Defog
- Roost
";
$g3791 = "Crobat @ Sitrus Berry
Ability: Infiltrator
Tera Type: &
EVs: 252 HP / 68 SpA / 4 SpD / 184 Spe
Modest Nature
- Nasty Plot
- Sludge Bomb
- Air Slash
- Roost
";
$g3800 = "Scolipede @ Focus Sash
Ability: Speed Boost
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Protect
- Megahorn
- Poison Jab
- Toxic Spikes
";
$g3809 = "Cinderace @ Choice Band
Ability: Libero
Tera Type: &
EVs: 76 HP / 176 Def / 4 SpD / 252 Spe
Jolly Nature
- Pyro Ball
- High Jump Kick
- Gunk Shot
- U-turn
";
$g3818 = "Genesect @ Normal Gem
Ability: Download
Tera Type: &
EVs: 172 Atk / 84 SpA / 252 Spe
Mild Nature
- Flash Cannon
- Bug Buzz
- Shift Gear
- Explosion
";
$g3827 = "Regieleki @ Heavy-Duty Boots
Ability: Transistor
Tera Type: &
EVs: 128 Atk / 128 SpA / 252 Spe
Hasty Nature
- Rapid Spin
- Thunderbolt
- Explosion
- Volt Switch
";
$g3836 = "Volcarona @ Heavy-Duty Boots
Ability: Flame Body
Tera Type: &
EVs: 124 HP / 128 SpA / 4 SpD / 252 Spe
Timid Nature
- Flamethrower
- Bug Buzz
- Defog
- Giga Drain
";
$g3845 = "Chandelure @ Leftovers
Ability: Infiltrator
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Substitute
- Calm Mind
- Flamethrower
- Shadow Ball
";
$g3854 = "Flapple @ Life Orb
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Grav Apple
- Sucker Punch
- Dragon Rush
- Dragon Dance
";
$g3863 = "Abomasnow @ Heavy-Duty Boots
Ability: Snow Warning
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Wood Hammer
- Ice Shard
- Ice Punch
- Toxic
";
$g3872 = "Raichu-Alola @ Wise Glasses
Ability: Surge Surfer
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Psychic
- Thunderbolt
- Focus Blast
";
$g3881 = "Victini @ Sitrus Berry
Ability: Victory Star
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Blue Flare
- Psychic
- Will-O-Wisp
- Final Gambit
";
$g3890 = "Darmanitan @ Choice Scarf
Ability: Sheer Force
Tera Type: &
EVs: 156 HP / 96 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flare Blitz
- Trick
- Superpower
- Dig
";
$g3899 = "Braviary @ Heavy-Duty Boots
Ability: Defiant
Tera Type: &
EVs: 252 HP / 172 Atk / 84 Spe
Adamant Nature
- Close Combat
- Brave Bird
- Facade
- Bulk Up
";
$g3908 = "Marowak-Alola @ Thick Club
Ability: Lightning Rod
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flare Blitz
- Flame Charge
- Bonemerang
- Poltergeist
";
$g3917 = "Charizard @ Life Orb
Ability: Solar Power
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sunny Day
- Air Slash
- Heat Wave
- Fire Blast
";
$g3926 = "Gengar @ Focus Sash
Ability: Cursed Body
Tera Type: &
EVs: 144 SpA / 4 SpD / 252 Spe
Timid Nature
- Shadow Ball
- Sludge Bomb
- Destiny Bond
- Thunderbolt
";
$g3935 = "Zeraora @ Expert Belt
Ability: Volt Absorb
Tera Type: &
EVs: 92 HP / 160 Atk / 4 SpD / 252 Spe
Jolly Nature
- Plasma Fists
- Blaze Kick
- Taunt
- Fake Out
";
$g3944 = "Articuno @ Heavy-Duty Boots
Ability: Pressure
Tera Type: &
EVs: 248 HP / 140 Def / 36 SpA / 84 SpD
Modest Nature
- Freeze-Dry
- Air Slash
- Roost
- Haze
";
$g3953 = "Tapu Fini @ Leftovers
Ability: Misty Surge
Tera Type: &
EVs: 196 HP / 56 SpA / 4 SpD / 252 Spe
Timid Nature
- Haze
- Brine
- Moonblast
- Natures Madness
";
$g3962 = "Crustle @ White Herb
Ability: Sturdy
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Shell Smash
- X-Scissor
- Rock Blast
- Stealth Rock
";
$g3971 = "Type: Null @ Eviolite
Ability: Battle Armor
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Iron Defense
- Rest
- Thunder Wave
- Double-Edge
";
$g3980 = "Zygarde @ Maranga Berry
Ability: Aura Break
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Relaxed Nature
- Core Enforcer
- Rest
- Thousand Waves
- Toxic
";
$g3990 = "Gigalith @ Chesto Berry
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Body Press
- Stone Edge
- Curse
- Rest
";
$g3999 = "Clefable @ Leftovers
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 176 SpA / 80 SpD
Calm Nature
- Heal Bell
- Healing Wish
- Moonblast
- Moonlight
";
$g4008 = "Passimian @ Sitrus Berry
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bulk Up
- Close Combat
- Gunk Shot
- Seed Bomb
";
$g4017 = "Pangoro @ Red Card
Ability: Iron Fist
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Drain Punch
- Bulk Up
- Darkest Lariat
- Bullet Punch
";
$g4027 = "Azumarill @ Sitrus Berry
Ability: Huge Power
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Belly Drum
- Aqua Jet
- Play Rough
- Superpower
";
$g4036 = "Azumarill @ Choice Band
Ability: Huge Power
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Waterfall
- Superpower
- Play Rough
- Knock Off
";
$g4045 = "Goodra @ Leftovers
Ability: Sap Sipper
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Dragon Pulse
- Ice Beam
- Power Whip
- Life Dew
";
$g4054 = "Keldeo-Resolute @ Leftovers
Ability: Justified
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Calm Mind
- Surf
- Secret Sword
- Icy Wind
";
$g4063 = "Excadrill @ Liechi Berry
Ability: Sand Rush
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Sandstorm
- High Horsepower
- Iron Head
- Rapid Spin
";
$g4072 = "Excadrill @ Choice Band
Ability: Sand Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Horsepower
- Iron Head
- X-Scissor
- Rock Blast
";
$g4081 = "Tyranitar @ Rocky Helmet
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Taunt
- Stone Edge
- Thunder Wave
- Crunch
";
$g4090 = "Terrakion @ Choice Band
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Rock Slide
- Sacred Sword
- Megahorn
- Stomping Tantrum
";
$g4099 = "Terrakion @ Red Card
Ability: Justified
Tera Type: &
EVs: 28 HP / 224 Atk / 4 SpD / 252 Spe
Jolly Nature
- Sacred Sword
- Stone Edge
- Taunt
- Bulldoze
";
$g4108 = "Virizion @ Leftovers
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Leaf Blade
- Close Combat
- Swords Dance
- Synthesis
";
$g4117 = "Virizion @ Red Card
Ability: Justified
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Calm Mind
- Giga Drain
- Focus Blast
- Air Slash
";
$g4126 = "Carbink @ Chesto Berry
Ability: Clear Body
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Iron Defense
- Body Press
- Moonblast
- Rest
";
$g4135 = "Blacephalon @ Normal Gem
Ability: Beast Boost
Tera Type: &
EVs: 180 Atk / 76 SpA / 252 Spe
Hasty Nature
- Mind Blown
- Shadow Ball
- Will-O-Wisp
- Explosion
";
$g4144 = "Froslass @ Focus Sash
Ability: Cursed Body
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Ice Beam
- Shadow Ball
- Destiny Bond
- Spikes
";
$g4154 = "Haxorus @ Sitrus Berry
Ability: Unnerve
Tera Type: &
EVs: 208 HP / 44 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Dragon Claw
- First Impression
- Poison Jab
";
$g4163 = "Lucario @ Life Orb
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Jump Kick
- Meteor Mash
- Blaze Kick
- Extreme Speed
";
$g4172 = "Ludicolo @ Life Orb
Ability: Swift Swim
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Rain Dance
- Hydro Pump
- Giga Drain
- Leech Seed
";
$g4181 = "Sigilyph @ Life Orb
Ability: Tinted Lens
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Air Slash
- Psychic
- Heat Wave
- Roost
";
$g4190 = "Toxtricity @ Throat Spray
Ability: Punk Rock
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Boomburst
- Overdrive
- Sludge Bomb
- Volt Switch
";
$g4199 = "Slowking @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Psyshock
- Scald
- Slack Off
- Calm Mind
";
$g4208 = "Pyukumuku @ Red Card
Ability: Innards Out
Tera Type: &
EVs: 252 HP / 180 Def / 76 SpD
Calm Nature
- Counter
- Mirror Coat
- Recycle
- Recover
";
$g4217 = "Flareon @ Toxic Orb
Ability: Guts
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Flare Blitz
- Iron Tail
- Superpower
- Protect
";
$g4226 = "Spectrier @ Eject Button
Ability: Grim Neigh
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Shadow Ball
- Dark Pulse
- Taunt
";
$g4235 = "Darmanitan-Galar @ Choice Scarf
Ability: Gorilla Tactics
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Ice Punch
- Fire Punch
- U-turn
- Brick Break
";
$g4244 = "Zoroark @ Life Orb
Ability: Illusion
Tera Type: &
EVs: 168 HP / 84 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Dark Pulse
- Flamethrower
- Grass Knot
";
$g4253 = "Kyurem @ Assault Vest
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Spe
Timid Nature
- Glaciate
- Freeze-Dry
- Dragon Pulse
- Flash Cannon
";
$g4262 = "Grimmsnarl @ Light Clay
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Reflect
- Light Screen
- Thunder Wave
- Darkest Lariat
";
$g4271 = "Tapu Bulu @ Leftovers
Ability: Grassy Surge
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Horn Leech
- Brick Break
- Taunt
- Bulk Up
";
$g4280 = "Zapdos-Galar @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Blaze Kick
- Drill Peck
- Brick Break
- U-turn
";
$g4289 = "Jolteon @ Wise Glasses
Ability: Volt Absorb
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Volt Switch
- Shadow Ball
- Thunder Wave
";
$g4298 = "Lanturn @ Leftovers
Ability: Volt Absorb
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Protect
- Heal Bell
- Scald
- Thunderbolt
";
$g4307 = "Jellicent @ Leftovers
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Calm Nature
- Strength Sap
- Will-O-Wisp
- Hex
- Scald
";
$g4316 = "Octillery @ Leftovers
Ability: Sniper
Tera Type: &
EVs: 252 HP / 116 Def / 4 SpA / 136 SpD
Bold Nature
- Protect
- Substitute
- Scald
- Flamethrower
";
$g4325 = "Dugtrio @ Focus Sash
Ability: Arena Trap
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Horsepower
- Stone Edge
- Sucker Punch
- Hone Claws
";
$g4334 = "Blaziken @ Expert Belt
Ability: Speed Boost
Tera Type: &
EVs: 68 HP / 184 Atk / 4 SpD / 252 Spe
Adamant Nature
- Fire Punch
- Brick Break
- Detect
- U-turn
";
$g4343 = "Bisharp @ Black Glasses
Ability: Defiant
Tera Type: &
EVs: 252 HP / 200 Atk / 56 SpD
Adamant Nature
- Sucker Punch
- Iron Head
- Knock Off
- Stealth Rock
";
$g4352 = "Durant @ Choice Band
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- First Impression
- Iron Head
- Stone Edge
- Stomping Tantrum
";
$g4361 = "Musharna @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 252 Def
Bold Nature
- Calm Mind
- Moonlight
- Psychic
- Heal Bell
";
$g4370 = "Morpeko @ Leftovers
Ability: Hunger Switch
Tera Type: &
EVs: 156 HP / 200 Atk / 140 Spe
Adamant Nature
- Fake Out
- Aura Wheel
- Rapid Spin
- Parting Shot
";
$g4379 = "Thundurus @ Sticky Barb
Ability: Prankster
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bulk Up
- Facade
- U-turn
- Thunder Punch
";
$g4388 = "Crobat @ Sitrus Berry
Ability: Inner Focus
Tera Type: &
EVs: 200 HP / 80 Atk / 196 Spe
Jolly Nature
- Taunt
- Acrobatics
- Super Fang
- Roost
";
$g4397 = "Metagross @ Choice Scarf
Ability: Clear Body
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Meteor Mash
- Zen Headbutt
- Explosion
- Trick
";
$g4406 = "Mandibuzz @ Heavy-Duty Boots
Ability: Big Pecks
Tera Type: &
EVs: 200 HP / 252 SpA / 4 Spe
Modest Nature
- Nasty Plot
- Dark Pulse
- Roost
- Air Slash
";
$g4415 = "Cobalion @ Weakness Policy
Ability: Justified
Tera Type: &
EVs: 40 HP / 200 Atk / 228 Spe
Jolly Nature
- Swords Dance
- Iron Head
- Close Combat
- Reflect
";
$g4424 = "Golbat @ Eviolite
Ability: Infiltrator
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Bold Nature
- Taunt
- Super Fang
- Defog
- Roost
";
$g4433 = "Dragapult @ Sticky Barb
Ability: Infiltrator
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Dragon Darts
- Facade
- Phantom Force
";
$g4442 = "Gallade @ Life Orb
Ability: Justified
Tera Type: &
EVs: 80 HP / 196 Atk / 200 Spe
Adamant Nature
- Swords Dance
- Zen Headbutt
- Close Combat
- Knock Off
";
$g4451 = "Gallade @ Choice Band
Ability: Steadfast
Tera Type: &
EVs: 56 HP / 196 Atk / 200 Spe
Jolly Nature
- Close Combat
- Zen Headbutt
- Knock Off
- Trick
";
$g4460 = "Emolga @ Heavy-Duty Boots
Ability: Static
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- Taunt
- Toxic
- Knock Off
- Roost
";
$g4469 = "Noivern @ Dragon Fang
Ability: Infiltrator
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Dragon Claw
- Dual Wingbeat
- U-turn
";
$g4479 = "Rotom-Heat @ Heavy-Duty Boots
Ability: Levitate
Tera Type: &
EVs: 200 HP / 252 SpA / 48 Spe
Modest Nature
- Volt Switch
- Overheat
- Nasty Plot
- Electroweb
";
$g4488 = "Avalugg @ Assault Vest
Ability: Own Tempo
Tera Type: &
EVs: 200 HP / 56 Atk / 252 SpD
Careful Nature
- Rapid Spin
- Avalanche
- High Horsepower
- Mirror Coat
";
$g4497 = "Silvally-Ice @ Ice Memory
Ability: RKS System
Tera Type: &
EVs: 200 HP / 200 Def / 80 SpD / 8 Spe
Impish Nature
- Multi-Attack
- Toxic
- Snarl
- Rest
";
$g4506 = "Skarmory @ Occa Berry
Ability: Weak Armor
Tera Type: &
EVs: 76 HP / 252 Atk / 180 Spe
Adamant Nature
- Swords Dance
- Iron Head
- Brave Bird
- Drill Peck
";
$g4515 = "Heatmor @ Assault Vest
Ability: Flash Fire
Tera Type: &
EVs: 200 HP / 252 SpA / 56 Spe
Modest Nature
- Fire Blast
- Giga Drain
- Scorching Sands
- Sucker Punch
";
$g4524 = "Sandslash-Alola @ Chople Berry
Ability: Slush Rush
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Impish Nature
- Spikes
- Triple Axel
- Rapid Spin
- Knock Off
";
$g4533 = "Hitmonlee @ Black Belt
Ability: Reckless
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Jump Kick
- Power-Up Punch
- Knock Off
- Rapid Spin
";
$g4542 = "Exeggutor @ Sitrus Berry
Ability: Harvest
Tera Type: &
EVs: 200 HP / 156 Def / 32 SpD / 120 Spe
Bold Nature
- Calm Mind
- Giga Drain
- Psychic
- Stun Spore
";
$g4551 = "Gengar @ Focus Sash
Ability: Cursed Body
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Taunt
- Destiny Bond
- Shadow Ball
- Sludge Wave
";
$g4560 = "Terrakion @ White Herb
Ability: Justified
Tera Type: &
EVs: 200 Atk / 72 Def / 236 Spe
Adamant Nature
- Swords Dance
- Stone Edge
- Close Combat
- Megahorn
";
$g4569 = "Mimikyu @ Spell Tag
Ability: Disguise
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Phantom Force
- Will-O-Wisp
- Play Rough
";
$g4578 = "Slowbro-Galar @ Leftovers
Ability: Quick Draw
Tera Type: &
EVs: 200 HP / 56 Def / 200 SpA / 12 SpD / 28 Spe
Modest Nature
- Nasty Plot
- Shell Side Arm
- Flamethrower
- Dig
";
$g4587 = "Persian @ Life Orb
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Fake Out
- Fury Swipes
- Gunk Shot
- Play Rough
";
$g4596 = "Flygon @ Lum Berry
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Earthquake
- Dig
- Dragon Claw
";
$g4605 = "Mesprit @ Colbur Berry
Ability: Levitate
Tera Type: &
EVs: 200 HP / 200 SpA / 108 Spe
Modest Nature
- Nasty Plot
- Psychic
- Shadow Ball
- Ice Beam
";
$g4614 = "Mesprit @ Colbur Berry
Ability: Levitate
Tera Type: &
EVs: 200 HP / 200 Def / 72 SpD
Bold Nature
- Thunder Wave
- Stealth Rock
- Psyshock
- Toxic
";
$g4623 = "Dragonair @ Eviolite
Ability: Marvel Scale
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Curse
- Rest
- Dragon Tail
- Light Screen
";
$g4632 = "Virizion @ Leftovers
Ability: Justified
Tera Type: &
EVs: 120 HP / 100 Atk / 232 Spe
Jolly Nature
- Taunt
- Synthesis
- Megahorn
- Leaf Blade
";
$g4641 = "Virizion @ Weakness Policy
Ability: Justified
Tera Type: &
EVs: 236 Atk / 232 Spe
Jolly Nature
- Swords Dance
- Leaf Blade
- Close Combat
- Stone Edge
";
$g4650 = "Golurk @ Leftovers
Ability: No Guard
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Dig
- Fly
- Curse
- Dynamic Punch
";
$g4659 = "Indeedee @ Sitrus Berry
Ability: Psychic Surge
Tera Type: &
EVs: 200 SpA / 244 Spe
Modest Nature
- Encore
- Expanding Force
- Psychic
- Mystical Fire
";
$g4668 = "Gardevoir @ Kee Berry
Ability: Trace
Tera Type: &
EVs: 156 HP / 200 SpA / 120 Spe
Modest Nature
- Calm Mind
- Psyshock
- Moonblast
- Mystical Fire
";
$g4677 = "Froslass @ Colbur Berry
Ability: Snow Cloak
Tera Type: &
EVs: 192 HP / 100 Atk / 216 Spe
Jolly Nature
- Taunt
- Spikes
- Poltergeist
- Triple Axel
";
$g4686 = "Talonflame @ Heavy-Duty Boots
Ability: Gale Wings
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Taunt
- Will-O-Wisp
- Roost
- Brave Bird
";
$g4695 = "Leafeon @ Leftovers
Ability: Leaf Guard
Shiny: Yes
Tera Type: &
EVs: 96 HP / 216 Atk / 164 Spe
Adamant Nature
- Swords Dance
- Leaf Blade
- Dig
- Knock Off
";
$g4705 = "Klinklang @ Kings Rock
Ability: Clear Body
Tera Type: &
EVs: 248 HP / 116 Atk / 124 Spe
Adamant Nature
- Magnet Rise
- Thunder Wave
- Shift Gear
- Gear Grind
";
$g4714 = "Rillaboom @ Grassy Seed
Ability: Grassy Surge
Tera Type: &
EVs: 200 HP / 60 Atk / 128 Spe
Adamant Nature
- Grassy Glide
- U-turn
- Acrobatics
- Taunt
";
$g4723 = "Silvally-Dark @ Dark Memory
Ability: RKS System
Tera Type: &
EVs: 232 HP / 96 Def / 108 SpD / 68 Spe
Adamant Nature
- Thunder Wave
- Multi-Attack
- Parting Shot
- Iron Head
";
$g4732 = "Octillery @ Leftovers
Ability: Sniper
Tera Type: &
EVs: 236 HP / 252 SpA / 20 Spe
Modest Nature
- Energy Ball
- Hydro Pump
- Fire Blast
- Ice Beam
";
$g4741 = "Xatu @ Leftovers
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Thunder Wave
- Roost
- Calm Mind
- Stored Power
";
$g4750 = "Drampa @ Maranga Berry
Ability: Berserk
Tera Type: &
EVs: 200 HP / 108 Def / 200 Spe
Modest Nature
- Thunder Wave
- Roost
- Dragon Pulse
- Flamethrower
";
$g4759 = "Cottonee @ Eviolite
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Defog
- Leech Seed
- Toxic
- Knock Off
";
$g4768 = "Golduck @ Wiki Berry
Ability: Cloud Nine
Tera Type: &
EVs: 156 HP / 252 SpA / 100 Spe
Modest Nature
- Calm Mind
- Hydro Pump
- Ice Beam
- Psychic
";
$g4777 = "Lilligant @ Kee Berry
Ability: Own Tempo
Tera Type: &
EVs: 240 HP / 100 Def / 28 SpD / 128 Spe
Timid Nature
- Quiver Dance
- Giga Drain
- Nature Power
- Synthesis
";
$g4786 = "Pangoro @ Scope Lens
Ability: Mold Breaker
Tera Type: &
EVs: 60 HP / 252 Atk / 196 Spe
Adamant Nature
- Focus Energy
- Knock Off
- Close Combat
- Parting Shot
";
$g4795 = "Jolteon @ Leftovers
Ability: Volt Absorb
Tera Type: &
EVs: 200 HP / 156 Def / 76 SpD / 56 Spe
Timid Nature
- Thunder Wave
- Volt Switch
- Dig
- Toxic
";
$g4804 = "Scolipede @ Silver Powder
Ability: Speed Boost
Tera Type: &
EVs: 236 HP / 232 Atk / 12 Spe
Adamant Nature
- Swords Dance
- Megahorn
- Poison Jab
- Aqua Tail
";
$g4813 = "Marowak-Alola @ Thick Club
Ability: Lightning Rod
Shiny: Yes
Tera Type: &
EVs: 232 HP / 100 Atk / 64 SpD / 88 Spe
Adamant Nature
- Stealth Rock
- Poltergeist
- Flare Blitz
- Bonemerang
";
$g4823 = "Zarude @ Miracle Seed
Ability: Leaf Guard
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Growth
- Giga Drain
- Dark Pulse
- Jungle Healing
";
$g4832 = "Unfezant @ Scope Lens
Ability: Super Luck
Tera Type: &
EVs: 236 HP / 184 Atk / 72 Spe
Adamant Nature
- Dual Wingbeat
- Night Slash
- Hypnosis
- Roost
";
$g4841 = "Porygon2 @ Choice Scarf
Ability: Download
Tera Type: &
EVs: 84 HP / 172 Def / 252 Spe
Timid Nature
- Trick
- Recover
- Ice Beam
- Tri Attack
";
$g4850 = "Rhyperior @ Weakness Policy
Ability: Solid Rock
Tera Type: &
EVs: 48 Atk / 220 SpD / 220 Spe
Adamant Nature
- Rock Polish
- Swords Dance
- Stone Edge
- High Horsepower
";
$g4859 = "Clefairy @ Eviolite
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Relaxed Nature
- Calm Mind
- Moonblast
- Soft-Boiled
- Knock Off
";
$g4868 = "Rhyperior @ Passho Berry
Ability: Lightning Rod
Tera Type: &
EVs: 72 Atk / 200 Def / 200 SpD
Adamant Nature
- Stealth Rock
- Dragon Tail
- Rock Slide
- High Horsepower
";
$g4877 = "Garbodor @ Sitrus Berry
Ability: Aftermath
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Spikes
- Toxic Spikes
- Pain Split
- Gunk Shot
";
$g4886 = "Starmie @ Wiki Berry
Ability: Analytic
Tera Type: &
EVs: 232 HP / 200 SpA / 36 Spe
Modest Nature
- Rapid Spin
- Hydro Pump
- Ice Beam
- Thunderbolt
";
$g4895 = "Tornadus @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Taunt
- Nasty Plot
- Defog
- Hurricane
";
$g4904 = "Excadrill @ Red Card
Ability: Mold Breaker
Tera Type: &
EVs: 156 HP / 244 Atk / 108 Spe
Adamant Nature
- Swords Dance
- Rapid Spin
- High Horsepower
- Iron Head
";
$g4913 = "Gyarados @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Muddy Water
- Fire Blast
- Thunderbolt
- Toxic
";
$g4922 = "Raichu-Alola @ Choice Specs
Ability: Surge Surfer
Tera Type: &
EVs: 232 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Volt Switch
- Psychic
- Grass Knot
";
$g4931 = "Linoone @ Iapapa Berry
Ability: Gluttony
Tera Type: &
EVs: 156 HP / 200 Atk / 80 Def / 44 Spe
Adamant Nature
- Belly Drum
- Extreme Speed
- Throat Chop
- Protect
";
$g4940 = "Porygon2 @ Eviolite
Ability: Trace
Tera Type: &
EVs: 252 HP / 168 Def / 4 SpA / 84 SpD
Sassy Nature
- Discharge
- Recover
- Trick Room
- Ice Beam
";
$g4949 = "Porygon2 @ Choice Specs
Ability: Download
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Tri Attack
- Ice Beam
- Thunderbolt
- Teleport
";
$g4958 = "Genesect @ Life Orb
Ability: Download
Tera Type: &
EVs: 252 Atk / 96 SpA / 148 Spe
Hasty Nature
- Techno Blast
- Ice Beam
- Extreme Speed
- Thunderbolt
";
$g4967 = "Rotom-Fan @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 136 HP / 252 SpA / 96 Spe
Modest Nature
- Discharge
- Air Slash
- Pain Split
- Nasty Plot
";
$g4976 = "Slurpuff @ Sitrus Berry
Ability: Unburden
Tera Type: &
EVs: 100 HP / 252 Atk / 156 Spe
Adamant Nature
- Belly Drum
- Play Rough
- Facade
- Drain Punch
";
$g4985 = "Stoutland @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 232 HP / 72 Atk / 172 Spe
Adamant Nature
- Yawn
- Strength
- Dig
- Work Up
";
$g4994 = "Silvally-Ghost @ Ghost Memory
Ability: RKS System
Tera Type: &
EVs: 144 HP / 192 Atk / 108 Spe
Adamant Nature
- Thunder Wave
- Multi-Attack
- Explosion
- Parting Shot
";
$g5003 = "Silvally-Electric @ Electric Memory
Ability: RKS System
Tera Type: &
EVs: 84 HP / 168 Atk / 224 Spe
Jolly Nature
- Defog
- Multi-Attack
- Icy Wind
- U-turn
";
$g5012 = "Aromatisse @ Iapapa Berry
Ability: Aroma Veil
Tera Type: &
EVs: 112 HP / 156 Def / 200 SpA
Modest Nature
- Trick Room
- Nasty Plot
- Dazzling Gleam
- Moonblast
";
$g5021 = "Seismitoad @ Leftovers
Ability: Poison Touch
Tera Type: &
EVs: 100 HP / 112 Atk / 200 Def / 56 SpD
Adamant Nature
- Power-Up Punch
- Dig
- Power Whip
- Liquidation
";
$g5030 = "Mamoswine @ Bright Powder
Ability: Snow Cloak
Tera Type: &
EVs: 200 HP / 56 Atk / 252 Def
Impish Nature
- Hail
- High Horsepower
- Rest
- Light Screen
";
$g5039 = "Seismitoad @ Leftovers
Ability: Water Absorb
Tera Type: &
EVs: 108 HP / 200 Def / 64 SpD / 92 Spe
Impish Nature
- Stealth Rock
- Muddy Water
- Knock Off
- Toxic
";
$g5048 = "Venusaur @ Life Orb
Ability: Chlorophyll
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Sunny Day
- Giga Drain
- Sludge Bomb
- Weather Ball
";
$g5057 = "Naganadel @ Red Card
Ability: Beast Boost
Tera Type: &
EVs: 80 HP / 160 SpA / 244 Spe
Timid Nature
- Nasty Plot
- Sludge Bomb
- Dragon Pulse
- Fire Blast
";
$g5066 = "Tapu Koko @ Electric Seed
Ability: Electric Surge
Tera Type: &
EVs: 200 HP / 100 Def / 56 SpA / 100 Spe
Timid Nature
- Thief
- Calm Mind
- Thunderbolt
- Roost
";
$g5075 = "Torkoal @ Heavy-Duty Boots
Ability: Drought
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Stealth Rock
- Rapid Spin
- Lava Plume
- Yawn
";
$g5084 = "Scyther @ Heavy-Duty Boots
Ability: Technician
Tera Type: &
EVs: 232 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Dual Wingbeat
- Roost
- U-turn
";
$g5093 = "Shelgon @ Eviolite
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 252 Def
Impish Nature
- Rest
- Sleep Talk
- Dragon Dance
- Dragon Claw
";
$g5102 = "Shelgon @ Eviolite
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Bold Nature
- Rest
- Sleep Talk
- Dragon Breath
- Roar
";
$g5111 = "Druddigon @ Assault Vest
Ability: Rough Skin
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Dragon Tail
- Gunk Shot
- Sucker Punch
- Dragon Claw
";
$g5120 = "Silvally-Ground @ Ground Memory
Ability: RKS System
Tera Type: &
EVs: 200 HP / 200 Def / 52 Spe
Impish Nature
- Thunder Wave
- Multi-Attack
- Defog
- U-turn
";
$g5129 = "Flapple @ Life Orb
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Protect
- Grav Apple
- U-turn
- Sucker Punch
";
$g5138 = "Silvally-Fairy @ Fairy Memory
Ability: RKS System
Tera Type: &
EVs: 200 HP / 68 Atk / 196 SpD
Careful Nature
- Defog
- Multi-Attack
- Parting Shot
- Toxic
";
$g5147 = "Heatran @ Normal Gem
Ability: Flash Fire
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flame Charge
- Heat Crash
- Heavy Slam
- Explosion
";
$g5156 = "Silvally-Fire @ Fire Memory
Ability: RKS System
Tera Type: &
EVs: 200 Atk / 232 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Explosion
- Protect
";
$g5165 = "Silvally-Grass @ Grass Memory
Ability: RKS System
Tera Type: &
EVs: 100 HP / 200 Atk / 140 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Ice Fang
- U-turn
";
$g5174 = "Volcanion @ Normal Gem
Ability: Water Absorb
Tera Type: &
EVs: 32 HP / 232 Atk / 220 Spe
Adamant Nature
- Flame Charge
- Flare Blitz
- Liquidation
- Explosion
";
$g5183 = "Silvally-Flying @ Flying Memory
Ability: RKS System
Tera Type: &
EVs: 120 HP / 200 Atk / 92 SpA / 32 Spe
Brave Nature
- Thunder Wave
- Multi-Attack
- Flamethrower
- Defog
";
$g5192 = "Silvally-Psychic @ Psychic Memory
Ability: RKS System
Tera Type: &
EVs: 56 HP / 200 Atk / 200 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Crunch
- Explosion
";
$g5201 = "Absol @ Scope Lens
Ability: Super Luck
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Night Slash
- Sucker Punch
- Close Combat
";
$g5211 = "Silvally-Rock @ Rock Memory
Ability: RKS System
Tera Type: &
EVs: 200 HP / 196 Def / 84 SpD
Impish Nature
- Defog
- Multi-Attack
- U-turn
- Toxic
";
$g5220 = "Silvally-Steel @ Steel Memory
Ability: RKS System
Tera Type: &
EVs: 232 HP / 200 Atk / 48 Spe
Adamant Nature
- Swords Dance
- Multi-Attack
- Double-Edge
- Flame Charge
";
$g5229 = "Alakazam @ Life Orb
Ability: Magic Guard
Tera Type: &
EVs: 200 SpA / 4 SpD / 200 Spe
Timid Nature
- Nasty Plot
- Focus Blast
- Energy Ball
- Psyshock
";
$g5238 = "Carbink @ Leftovers
Ability: Clear Body
Tera Type: &
EVs: 248 HP / 156 Def / 52 SpD
Bold Nature
- Stealth Rock
- Toxic
- Protect
- Moonblast
";
$g5247 = "Gigalith @ Maranga Berry
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Iron Defense
- Body Press
- Rest
- Sleep Talk
";
$g5256 = "Swampert @ Leftovers
Ability: Damp
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Bulk Up
- High Horsepower
- Waterfall
- Stealth Rock
";
$g5265 = "Scizor @ Leftovers
Ability: Technician
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Bullet Punch
- Bug Bite
- Roost
- Defog
";
$g5274 = "Gyarados @ Assault Vest
Ability: Moxie
Tera Type: &
EVs: 104 HP / 104 Atk / 4 SpD / 252 Spe
Jolly Nature
- Waterfall
- Power Whip
- Scale Shot
- Iron Head
";
$g5283 = "Gyarados @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 124 HP / 128 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Waterfall
- Iron Head
- Power Whip
";
$g5292 = "Swampert @ Leftovers
Ability: Torrent
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Flip Turn
- High Horsepower
- Waterfall
- Stealth Rock
";
$g5302 = "Meowstic @ Light Clay
Ability: Prankster
Tera Type: &
EVs: 248 HP / 136 Def / 8 SpA / 116 SpD
Calm Nature
- Light Screen
- Reflect
- Thunder Wave
- Psychic
";
$g5311 = "Sceptile @ White Herb
Ability: Unburden
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Leaf Storm
- Detect
- Focus Blast
- Dragon Pulse
";
$g5320 = "Sandaconda @ Sitrus Berry
Ability: Sand Spit
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Stealth Rock
- Iron Defense
- Body Press
- High Horsepower
";
$g5329 = "Hippowdon @ Rocky Helmet
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- High Horsepower
- Slack Off
- Body Press
- Stealth Rock
";
$g5338 = "Kartana @ Red Card
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Leaf Blade
- Knock Off
- Sacred Sword
- Aerial Ace
";
$g5347 = "Riolu @ Eviolite
Ability: Prankster
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD
Calm Nature
- Screech
- Detect
- Toxic
- Helping Hand
";
$g5356 = "Purrloin @ Focus Sash
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Protect
- Screech
- Fake Tears
- Thunder Wave
";
$g5365 = "Mew @ Sitrus Berry
Ability: Synchronize
Tera Type: &
EVs: 240 HP / 12 SpA / 4 SpD / 252 Spe
Timid Nature
- Gravity
- Hypnosis
- Psychic
- Roost
";
$g5374 = "Cresselia @ Red Card
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Calm Mind
- Psychic
- Moonlight
- Trick
";
$g5383 = "Cresselia @ Flame Orb
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Psycho Shift
- Moonlight
- Helping Hand
- Psyshock
";
$g5392 = "Corviknight @ Sitrus Berry
Ability: Mirror Armor
Tera Type: &
EVs: 248 HP / 8 Atk / 52 Def / 200 SpD
Impish Nature
- Iron Head
- Brave Bird
- Roost
- Defog
";
$g5401 = "Sableye @ Leftovers
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Will-O-Wisp
- Recover
- Knock Off
- Detect
";
$g5410 = "Sableye @ Choice Scarf
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Trick
- Will-O-Wisp
- Mean Look
- Recover
";
$g5419 = "Ferrothorn @ Leftovers
Ability: Iron Barbs
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Stealth Rock
- Spikes
- Thunder Wave
- Body Press
";
$g5428 = "Polteageist @ White Herb
Ability: Weak Armor
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Shell Smash
- Shadow Ball
- Stored Power
- Giga Drain
";
$g5437 = "Volcarona @ Life Orb
Ability: Swarm
Tera Type: &
EVs: 64 Def / 188 SpA / 4 SpD / 252 Spe
Modest Nature
- Quiver Dance
- Bug Buzz
- Flamethrower
- Giga Drain
";
$g5446 = "Whimsicott @ Choice Scarf
Ability: Prankster
Tera Type: &
EVs: 252 HP / 8 Def / 248 SpD
Bold Nature
- Switcheroo
- Moonblast
- Leech Seed
- U-turn
";
$g5455 = "Heracross @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Protect
- Fling
- Megahorn
- Close Combat
";
$g5464 = "Archeops @ Choice Band
Ability: Defeatist
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Head Smash
- Dual Wingbeat
- Switcheroo
- Roost
";
$g5473 = "Steelix @ Life Orb
Ability: Sturdy
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Rock Polish
- High Horsepower
- Iron Head
- Body Press
";
$g5482 = "Toxapex @ Black Sludge
Ability: Regenerator
Shiny: Yes
Tera Type: &
EVs: 252 HP / 20 Def / 236 SpD
Bold Nature
- Block
- Toxic
- Recover
- Scald
";
$g5492 = "Landorus @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 72 Def / 180 SpA / 4 SpD / 252 Spe
Timid Nature
- Earth Power
- Sludge Wave
- Weather Ball
- U-turn
";
$g5501 = "Suicune @ Life Orb
Ability: Pressure
Tera Type: &
EVs: 88 HP / 200 SpA / 140 Spe
Modest Nature
- Calm Mind
- Hydro Pump
- Air Slash
- Ice Beam
";
$g5510 = "Kyurem-Black @ Eject Button
Ability: Teravolt
Tera Type: &
EVs: 120 Atk / 136 SpA / 252 Spe
Jolly Nature
- Dragon Dance
- Dragon Claw
- Icicle Spear
- Earth Power
";
$g5519 = "Slowbro @ Red Card
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Slack Off
- Body Press
- Teleport
- Scald
";
$g5528 = "Appletun @ Leftovers
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 140 Def / 4 SpA / 112 SpD
Calm Nature
- Leech Seed
- Recover
- Apple Acid
- Dragon Pulse
";
$g5537 = "Slowking-Galar @ Choice Specs
Ability: Regenerator
Tera Type: &
EVs: 200 HP / 48 Def / 220 SpA
Modest Nature
- Eerie Spell
- Sludge Bomb
- Fire Blast
- Muddy Water
";
$g5546 = "Tapu Koko @ Heavy-Duty Boots
Ability: Electric Surge
Tera Type: &
EVs: 200 HP / 108 SpA / 200 Spe
Timid Nature
- Defog
- Roost
- Thunderbolt
- U-turn
";
$g5555 = "Slowbro-Galar @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 144 Def / 4 SpA / 108 SpD
Bold Nature
- Thunder Wave
- Shell Side
- Slack Off
- Psychic
";
$g5564 = "Blastoise @ Wiki Berry
Ability: Torrent
Tera Type: &
EVs: 200 HP / 100 Def / 120 SpA / 48 SpD
Bold Nature
- Fake Out
- Dive
- Haze
- Muddy Water
";
$g5573 = "Cofagrigus @ Leftovers
Ability: Mummy
Tera Type: &
EVs: 200 HP / 128 Def / 124 SpD
Bold Nature
- Haze
- Knock Off
- Shadow Ball
- Pain Split
";
$g5582 = "Weezing-Galar @ Black Sludge
Ability: Neutralizing Gas
Tera Type: &
EVs: 200 HP / 100 Def / 164 SpD
Bold Nature
- Toxic -
- Strange Steam
- Fire Blast
- Sludge Bomb
";
$g5591 = "Articuno-Galar @ Sitrus Berry
Ability: Competitive
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Calm Mind
- Recover
- Air Slash
- Freezing Glare
";
$g5600 = "Latias @ Soul Dew
Ability: Levitate
Tera Type: &
EVs: 76 HP / 176 SpA / 4 SpD / 252 Spe
Timid Nature
- Calm Mind
- Psyshock
- Mystical Fire
- Mist Ball
";
$g5609 = "Latios @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Trick
- Recover
- Dragon Pulse
- Mystical Fire
";
$g5618 = "Dragapult @ Life Orb
Ability: Infiltrator
Tera Type: &
EVs: 160 HP / 92 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Darts
- Dragon Dance
- Psychic Fangs
- Phantom Force
";
$g5627 = "Volcanion @ Sitrus Berry
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 112 SpA / 148 SpD
Modest Nature
- Steam Eruption
- Overheat
- Sludge Bomb
- Haze
";
$g5636 = "Latias @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Defog
- Recover
- Psychic
- Mystical Fire
";
$g5645 = "Drifblim @ Leftovers
Ability: Aftermath
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Strength Sap
- Defog
- Will-O-Wisp
- Hex
";
$g5654 = "Togekiss @ Sitrus Berry
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 160 Def / 96 SpD
Calm Nature
- Thunder Wave
- Roost
- Air Slash
- Twister
";
$g5663 = "Chansey @ Eviolite
Ability: Healer
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Toxic
- Soft-Boiled
- Seismic Toss
- Curse
";
$g5672 = "Tornadus-Therian @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Defog
- Hurricane
- Focus Blast
- Nasty Plot
";
$g5681 = "Landorus-Therian @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 116 HP / 136 Atk / 4 SpD / 252 Spe
Jolly Nature
- Defog
- Dig
- Knock Off
- Stone Edge
";
$g5690 = "Mawile @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Sucker Punch
- Super Fang
- Protect
- Play Rough
";
$g5699 = "Sharpedo @ Life Orb
Ability: Speed Boost
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Protect
- Waterfall
- Crunch
- Flip Turn
";
$g5708 = "Mudsdale @ Maranga Berry
Ability: Stamina
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Body Press
- High Horsepower
- Rest
- Sleep Talk
";
$g5717 = "Regice @ Leftovers
Ability: Clear Body
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Def
Bold Nature
- Ice Beam
- Frost Breath
- Ancient Power
- Protect
";
$g5727 = "Vileplume @ Black Sludge
Ability: Effect Spore
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Leech Seed
- Moonlight
- Toxic
- Giga Drain
";
$g5736 = "Metapod @ Eviolite
Ability: Shed Skin
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Sassy Nature
- Iron Defense
- String Shot
- Electroweb
- Bug Bite
";
$g5745 = "Xurkitree @ Choice Scarf
Ability: Beast Boost
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Thunderbolt
- Energy Ball
- Dazzling Gleam
- Discharge
";
$g5754 = "Charjabug @ Eviolite
Ability: Battery
Tera Type: &
EVs: 252 HP / 4 Atk / 60 Def / 192 SpD
Impish Nature
- Spark
- Bug Bite
- Protect
- Sticky Web
";
$g5763 = "Shiftry @ Life Orb
Ability: Chlorophyll
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Knock Off
- Sucker Punch
- Leaf Blade
- Protect
";
$g5772 = "Miltank @ Leftovers
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 252 SpD
Impish Nature
- Heal Bell
- Milk Drink
- Body Slam
- High Horsepower
";
$g5781 = "Pikachu @ Light Ball
Ability: Lightning Rod
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Volt Tackle
- Extreme Speed
- Play Rough
- Grass Knot
";
$g5790 = "Lanturn @ Leftovers
Ability: Volt Absorb
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Discharge
- Protect
- Sucker Punch
- Toxic
";
$g5799 = "Zoroark @ Life Orb
Ability: Illusion
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Dark Pulse
- Calm Mind
- Flamethrower
- Sludge Bomb
";
$g5808 = "Zoroark @ Leftovers
Ability: Illusion
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Protect
- Imprison
- Toxic
- Hex
";
$g5817 = "Garchomp @ Leftovers
Ability: Sand Veil
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Sandstorm
- Dig
- Protect
- Stomping Tantrum
";
$g5826 = "Garchomp @ Life Orb
Ability: Rough Skin
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naive Nature
- Outrage
- Draco Meteor
- Fire Blast
- Stomping Tantrum
";
$g5835 = "Garchomp @ Leftovers
Ability: Rough Skin
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Stealth Rock
- Dragon Tail
- Breaking Swipe
- Toxic
";
$g5844 = "Garchomp @ Razor Claw
Ability: Rough Skin
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Dragon Claw
- Shadow Claw
- Metal Claw
- Hone Claws
";
$g5853 = "Garchomp @ Flame Orb
Ability: Rough Skin
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Fling
- Dragon Breath
- Toxic
- Protect
";
$g5862 = "Victini @ Heavy-Duty Boots
Ability: Victory Star
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Lonely Nature
- V-create
- Bolt Strike
- U-turn
- Glaciate
";
$g5871 = "Garchomp @ Rocky Helmet
Ability: Rough Skin
Tera Type: &
EVs: 100 HP / 80 Atk / 80 Def / 48 SpA / 200 SpD
Sassy Nature
- Rest
- Sleep Talk
- Dragon Breath
- Body Slam
";
$g5880 = "Victini @ Iapapa Berry
Ability: Victory Star
Tera Type: &
EVs: 216 HP / 100 Atk / 28 Def / 136 SpD
Brave Nature
- Trick Room
- V-create
- Bolt Strike
- Power-Up Punch
";
$g5889 = "Victini @ Choice Scarf
Ability: Victory Star
Tera Type: &
EVs: 96 HP / 200 Atk / 4 SpD / 200 Spe
Jolly Nature
- V-create
- U-turn
- Bolt Strike
- Trick
";
$g5898 = "Diggersby @ Assault Vest
Ability: Huge Power
Tera Type: &
EVs: 200 HP / 252 Atk / 40 SpD
Adamant Nature
- Mega Kick
- High Horsepower
- Ice Punch
- Knock Off
";
$g5907 = "Golduck @ Leftovers
Ability: Damp
Tera Type: &
EVs: 248 HP / 252 Def / 4 Spe
Bold Nature
- Muddy Water
- Scald
- Encore
- Dig
";
$g5916 = "Victini @ Heavy-Duty Boots
Ability: Victory Star
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Searing Shot
- Thunderbolt
- Grass Knot
- Blue Flare
";
$g5925 = "Magmortar @ Heavy-Duty Boots
Ability: Flame Body
Tera Type: &
EVs: 96 HP / 252 SpA / 144 Spe
Modest Nature
- Fire Blast
- Thunderbolt
- Psychic
- Flame Charge
";
$g5934 = "Solrock @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Impish Nature
- Will-O-Wisp
- Protect
- Morning Sun
- Rock Slide
";
$g5943 = "Vanilluxe @ Choice Band
Ability: Snow Warning
Tera Type: &
EVs: 120 HP / 252 Atk / 4 SpD / 132 Spe
Adamant Nature
- Aurora Veil
- Icicle Crash
- Explosion
- Ice Shard
";
$g5952 = "Victini @ Weakness Policy
Ability: Victory Star
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sunny Day
- Blue Flare
- Solar Beam
- Stored Power
";
$g5961 = "Gardevoir @ Iapapa Berry
Ability: Trace
Tera Type: &
EVs: 160 HP / 40 Def / 100 SpA / 184 Spe
Modest Nature
- Mystical Fire
- Psychic
- Moonblast
- Pain Split
";
$g5970 = "Sandslash-Alola @ Air Balloon
Ability: Slush Rush
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Swords Dance
- Rapid Spin
- Triple Axel
- Iron Head
";
$g5979 = "Dusclops @ Eviolite
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Helping Hand
- Protect
- Pain Split
- Seismic Toss
";
$g5988 = "Starmie @ Light Clay
Ability: Natural Cure
Tera Type: &
EVs: 96 HP / 160 Atk / 252 Spe
Jolly Nature
- Reflect
- Light Screen
- Flip Turn
- Rapid Spin
";
$g5997 = "Regidrago @ Light Clay
Ability: Dragons Maw
Tera Type: &
EVs: 128 Def / 128 SpD / 252 Spe
Jolly Nature
- Reflect
- Light Screen
- Dragon Claw
- Explosion
";
$g6006 = "Lickilicky @ Iapapa Berry
Ability: Oblivious
Tera Type: &
EVs: 100 HP / 252 Atk / 96 Def / 40 Spe
Adamant Nature
- Swords Dance
- Protect
- Body Slam
- Dig
";
$g6015 = "Magnezone @ Magnet
Ability: Magnet Pull
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Discharge
- Thunderbolt
- Flash Cannon
- Protect
";
$g6024 = "Farfetch’d @ Leek
Ability: Defiant
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Leaf Blade
- Night Slash
- Slash
- Dual Wingbeat
";
$g6033 = "Delibird @ Life Orb
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Jolly Nature
- Defog
- Gunk Shot
- Brave Bird
- Ice Punch
";
$g6042 = "Delibird @ Heavy-Duty Boots
Ability: Vital Spirit
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
- Rapid Spin
- Detect
- Spikes
- Blizzard
";
$g6052 = "Morpeko @ Heavy-Duty Boots
Ability: Hunger Switch
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Rapid Spin
- Aura Wheel
- Seed Bomb
- Parting Shot
";
$g6061 = "Shellder @ Heavy-Duty Boots
Ability: Skill Link
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Rapid Spin
- Shell Smash
- Icicle Spear
- Rock Blast
";
$g6070 = "Blastoise @ Heavy-Duty Boots
Ability: Torrent
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Rapid Spin
- Shell Smash
- Scald
- Aura Sphere
";
$g6079 = "Luxray @ Life Orb
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Psychic Fangs
- Agility
- Wild Charge
- Iron Tail
";
$g6088 = "Chandelure @ Choice Scarf
Ability: Flame Body
Tera Type: &
EVs: 252 SpA / 8 SpD / 248 Spe
Timid Nature
- Flamethrower
- Shadow Ball
- Energy Ball
- Psychic
";
$g6097 = "Kyurem-Black @ Leftovers
Ability: Teravolt
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Fusion Bolt
- Reflect
- Toxic
- Roost
";
$g6106 = "Torkoal @ Heavy-Duty Boots
Ability: Drought
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA
Brave Nature
- Rapid Spin
- Fire Spin
- Flame Wheel
- Gyro Ball
";
$g6115 = "Volcarona @ Life Orb
Ability: Flame Body
Tera Type: &
EVs: 124 HP / 128 SpA / 4 SpD / 252 Spe
Nature
- Quiver Dance
- Fiery Dance
- Hurricane
- Psychic
";
$g6124 = "Tsareena @ Heavy-Duty Boots
Ability: Queenly Majesty
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Rapid Spin
- Teeter Dance
- Triple Axel
- High Jump Kick
";
$g6133 = "Sawk @ Life Orb
Ability: Sturdy
Tera Type: &
EVs: 8 HP / 112 Atk / 136 Def / 252 SpD
Adamant Nature
- Poison Jab
- Close Combat
- Knock Off
- Rock Slide
";
$g6142 = "Toxapex @ Black Sludge
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 112 Def / 144 SpD
Bold Nature
- Muddy Water
- Safeguard
- Recover
- Block
";
$g6151 = "Espeon @ Power Herb
Ability: Magic Bounce
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Def
Naughty Nature
- Psychic Fangs
- Skull Bash
- Morning Sun
- Curse
";
$g6160 = "Garchomp @ Bright Powder
Ability: Sand Veil
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Sandstorm
- Earthquake
- Dragon Rush
- Stone Edge
";
$g6169 = "Gyarados @ Choice Specs
Ability: Intimidate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Mild Nature
- Blizzard
- Hurricane
- Hydro Pump
- Earthquake
";
$g6178 = "Dottler @ Eviolite
Ability: Swarm
Tera Type: &
EVs: 248 HP / 116 Def / 8 SpA / 136 SpD
Calm Nature
- Calm Mind
- Stored Power
- Iron Defense
- Recover
";
$g6187 = "Barraskewda @ Choice Scarf
Ability: Propeller Tail
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flip Turn
- Close Combat
- Psychic Fangs
- Scale Shot
";
$g6196 = "Alakazam @ Choice Scarf
Ability: Magic Guard
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Trick
- Calm Mind
- Psychic
- Dazzling Gleam
";
$g6205 = "Dracozolt @ Choice Specs
Ability: Volt Absorb
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Rash Nature
- Bolt Beak
- Draco Meteor
- Fire Blast
- Discharge
";
$g6214 = "Dusclops @ Eviolite
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Trick Room
- Grudge
- Skitter Smack
- Pain Split
";
$g6223 = "Volcanion @ Heavy-Duty Boots
Ability: Water Absorb
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Flame Charge
- Flamethrower
- Steam Eruption
- Scorching Sands
";
$g6232 = "Inteleon @ Petaya Berry
Ability: Torrent
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Acrobatics
- Snipe Shot
- Substitute
- Dark Pulse
";
$g6241 = "Hatterene @ Leftovers
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Aromatherapy
- Calm Mind
- Psyshock
- Draining Kiss
";
$g6250 = "Hatterene @ Leftovers
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 4 Atk / 172 Def / 80 SpD
Calm Nature
- Nuzzle
- Aromatherapy
- Giga Drain
- Psychic
";
$g6259 = "Magikarp @ Choice Specs
Ability: Swift Swim
Tera Type: &
EVs: 252 SpA / 252 Spe
Rash Nature
- Hydro Pump
- Bounce
- Tackle
- Splash
";
$g6268 = "Dedenne @ Sitrus Berry
Ability: Cheek Pouch
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Nuzzle
- Recycle
- Super Fang
- Grass Knot
";
$g6277 = "Raichu-Alola @ Leftovers
Ability: Surge Surfer
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Nuzzle
- Teeter Dance
- Protect
- Thunderbolt
";
$g6286 = "Dragonite @ Life Orb
Ability: Multiscale
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Draco Meteor
- Fire Blast
- Hurricane
- Dragon Claw
";
$g6295 = "Cinderace @ Choice Scarf
Ability: Libero
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Hyper Beam
- Giga Impact
- Blast Burn
- Bounce
";
$g6304 = "Melmetal @ Assault Vest
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Sassy Nature
- Double Iron Bash
- Discharge
- Body Press
- Ice Punch
";
$g6313 = "Melmetal @ Maranga Berry
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Acid Armor
- Body Press
- Rest
- Sleep Talk
";
$g6322 = "Melmetal @ Choice Band
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Double Iron Bash
- Darkest Lariat
- High Horsepower
- Ice Punch
";
$g6331 = "Melmetal @ Leftovers
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Protect
- Thunder Wave
- Double Iron Bash
- Superpower
";
$g6340 = "Araquanid @ Choice Band
Ability: Water Bubble
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Liquidation
- Leech Life
- Poison Jab
- Crunch
";
$g6349 = "Araquanid @ Leftovers
Ability: Water Bubble
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Liquidation
- Iron Defense
- Toxic
- Rest
";
$g6358 = "Heatran @ Leftovers
Ability: Flash Fire
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Stealth Rock
- Magma Storm
- Toxic
- Protect
";
$g6367 = "Urshifu-Rapid-Strike @ Expert Belt
Ability: Unseen Fist
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Surging Strikes
- Drain Punch
- U-turn
- Fire Punch
";
$g6376 = "Aromatisse @ Sitrus Berry
Ability: Healer
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Wish
- Protect
- Moonblast
- Covet
";
$g6385 = "Blissey @ Heavy-Duty Boots
Ability: Natural Cure
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Wish
- Teleport
- Seismic Toss
- Protect
";
$g6395 = "Umbreon @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Wish
- Detect
- Heal Bell
- Foul Play
";
$g6404 = "Musharna @ Leftovers
Ability: Forewarn
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Thunder Wave
- Helping Hand
- Moonblast
- Moonlight
";
$g6413 = "Lycanroc-Midnight @ Custap Berry
Ability: No Guard
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Close Combat
- Endure
- Endeavor
";
$g6422 = "Aggron @ Custap Berry
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 252 Atk
Adamant Nature
- Endure
- Endeavor
- Heavy Slam
- Stealth Rock
";
$g6431 = "Raboot @ Eviolite
Ability: Libero
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flare Blitz
- High Jump Kick
- Gunk Shot
- Bulk Up
";
$g6440 = "Nihilego @ Black Sludge
Ability: Beast Boost
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Power Gem
- Hex
- Pain Split
- Thunder Wave
";
$g6450 = "Thwackey @ Eviolite
Ability: Grassy Surge
Tera Type: &
EVs: 252 HP / 80 Def / 176 Spe
Jolly Nature
- Knock Off
- Leech Seed
- Substitute
- Protect
";
$g6459 = "Tapu Koko @ Electric Seed
Ability: Electric Surge
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
- Stored Power
- Thief
- Roost
- Calm Mind
";
$g6468 = "Copperajah @ Assault Vest
Ability: Sheer Force
Tera Type: &
EVs: 136 HP / 120 Atk / 252 SpD
Adamant Nature
- Heavy Slam
- Heat Crash
- High Horsepower
- Play Rough
";
$g6477 = "Mew @ Assault Vest
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 140 SpA / 100 SpD / 16 Spe
Calm Nature
- Psyshock
- Draining Kiss
- Flamethrower
- Charge Beam
";
$g6486 = "Guzzlord @ Leftovers
Ability: Beast Boost
Tera Type: &
EVs: 152 Def / 204 SpA / 152 SpD
Quiet Nature
- Dark Pulse
- Draco Meteor
- Gyro Ball
- Protect
";
$g6495 = "Zapdos @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 88 HP / 168 SpA / 252 Spe
Timid Nature
- Charge Beam
- Charge
- Roost
- Substitute
";
$g6504 = "Tornadus @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hurricane
- Knock Off
- Nasty Plot
- U-turn
";
$g6513 = "Cradily @ Power Herb
Ability: Storm Drain
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA
Modest Nature
- Giga Drain
- Meteor Beam
- Recover
- Amnesia
";
$g6522 = "Alakazam @ Life Orb
Ability: Magic Guard
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psychic
- Focus Blast
- Recover
- Calm Mind
";
$g6531 = "Conkeldurr @ Black Belt
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Mach Punch
- Power-Up Punch
- Drain Punch
- Ice Punch
";
$g6540 = "Weavile @ Focus Sash
Ability: Pressure
Tera Type: &
EVs: 32 HP / 224 Atk / 252 Spe
Jolly Nature
- Triple Axel
- Knock Off
- Counter
- Swords Dance
";
$g6549 = "Drakloak @ Eviolite
Ability: Clear Body
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hex
- Thunder
- Flamethrower
- Will-O-Wisp
";
$g6558 = "Gengar @
Ability: Cursed Body
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Shadow Ball
- Sludge Bomb
- Focus Blast
- Thief
";
$g6567 = "Charizard @ Kee Berry
Ability: Blaze
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Mystical Fire
- Beat Up
- Roost
- Roar
";
$g6576 = "Kangaskhan @ Blunder Policy
Ability: Scrappy
Tera Type: &
EVs: 124 HP / 252 Atk / 124 Def / 4 SpD / 4 Spe
Adamant Nature
- Body Slam
- Drain Punch
- Sing
- Roar
";
$g6585 = "Gallade @ Blunder Policy
Ability: Justified
Tera Type: &
EVs: 248 HP / 60 Atk / 60 Def / 80 SpD / 60 Spe
Impish Nature
- Drain Punch
- Rest
- Sing
- Bulk Up
";
$g6594 = "Milcery @ Eviolite
Ability: Aroma Veil
Tera Type: &
EVs: 252 HP / 52 Def / 204 SpD
Calm Nature
- Stored Power
- Helping Hand
- Rest
- Acid Armor
";
$g6603 = "Lunatone @ Power Herb
Ability: Levitate
Tera Type: &
EVs: 188 HP / 68 Def / 252 Spe
Timid Nature
- Stored Power
- Meteor Beam
- Grass Knot
- Calm Mind
";
$g6612 = "Volcanion @ Leftovers
Ability: Water Absorb
Tera Type: &
EVs: 128 HP / 128 SpA / 252 Spe
Timid Nature
- Flamethrower
- Steam Eruption
- Toxic
- Protect
";
$g6621 = "Mew @ Sticky Barb
Ability: Synchronize
Shiny: Yes
Tera Type: &
EVs: 208 HP / 28 Def / 128 SpA / 128 SpD / 16 Spe
Modest Nature
- Psyshock
- Vacuum Wave
- Trick
- Nasty Plot
";
$g6631 = "Marowak @ Thick Club
Ability: Lightning Rod
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Bonemerang
- Knock Off
- Sing
- Protect
";
$g6640 = "Beartic @ Blunder Policy
Ability: Swift Swim
Tera Type: &
EVs: 180 HP / 72 Atk / 4 Def / 252 Spe
Adamant Nature
- Icicle Crash
- Play Rough
- Low Kick
- Blizzard
";
$g6649 = "Genesect @ Leftovers
Ability: Download
Tera Type: &
EVs: 56 HP / 100 Def / 100 SpA / 252 Spe
Timid Nature
- Ice Beam
- Charge Beam
- Substitute
- Protect
";
$g6658 = "Clefable @ Power Herb
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Ice Beam
- Charge Beam
- Meteor Beam
- Soft-Boiled
";
$g6667 = "Klinklang @ Kings Rock
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Gear Grind
- Discharge
- Protect
- Shift Gear
";
$g6676 = "Sableye @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 Def
Bold Nature
- Hex
- Will-O-Wisp
- Quash
- Recover
";
$g6685 = "Thundurus-Therian @ Heavy-Duty Boots
Ability: Volt Absorb
Tera Type: &
EVs: 76 HP / 136 Def / 44 SpA / 252 Spe
Modest Nature
- Thunderbolt
- Dark Pulse
- Role Play
- Defog
";
$g6694 = "Braviary @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 200 HP / 108 Atk / 200 Spe
Adamant Nature
- Crush Claw
- Brave Bird
- Close Combat
- Heat Wave
";
$g6703 = "Tapu Fini @ Choice Scarf
Ability: Misty Surge
Tera Type: &
EVs: 192 HP / 84 Def / 148 SpA / 84 SpD
Modest Nature
- Scald
- Draining Kiss
- Calm Mind
- Trick
";
$g6712 = "Unfezant @ Power Herb
Ability: Super Luck
Tera Type: &
EVs: 28 HP / 228 Atk / 252 Spe
Adamant Nature
- Facade
- Sky Attack
- Psych Up
- Roost
";
$g6721 = "Zeraora @ Assault Vest
Ability: Volt Absorb
Tera Type: &
EVs: 252 HP / 140 SpD / 116 Spe
Calm Nature
- Thunderbolt
- Aura Sphere
- Knock Off
- Volt Switch
";
$g6730 = "Zarude @ Assault Vest
Ability: Leaf Guard
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Power Whip
- Darkest Lariat
- Close Combat
- Rock Slide
";
$g6739 = "Terrakion @ Custap Berry
Ability: Justified
Tera Type: &
EVs: 44 HP / 212 Atk / 208 SpD / 44 Spe
Adamant Nature
- Rock Blast
- Close Combat
- Reversal
- Substitute
";
$g6748 = "Slowking-Galar @ Black Sludge
Ability: Regenerator
Tera Type: &
EVs: 172 HP / 4 Def / 40 SpA / 40 SpD / 252 Spe
Timid Nature
- Sludge Bomb
- Hex
- Foul Play
- Thunder Wave
";
$g6757 = "Kingdra @ Sitrus Berry
Ability: Sniper
Tera Type: &
EVs: 224 HP / 28 Atk / 200 SpD / 56 Spe
Adamant Nature
- Liquidation
- Double-Edge
- Yawn
- Protect
";
$g6766 = "Celesteela @ Charcoal
Ability: Beast Boost
Tera Type: &
EVs: 144 HP / 252 Atk / 40 Def / 72 SpD
Adamant Nature
- Flame Charge
- Rest
- Leech Seed
- Sleep Talk
";
$g6775 = "Tauros @ Power Herb
Ability: Sheer Force
Tera Type: &
EVs: 208 Atk / 48 Def / 252 Spe
Jolly Nature
- Body Slam
- High Horsepower
- Megahorn
- Skull Bash
";
$g6784 = "Mawile @ Occa Berry
Ability: Sheer Force
Tera Type: &
EVs: 252 HP / 72 Atk / 44 Def / 140 SpD
Adamant Nature
- Iron Head
- Play Rough
- Knock Off
- Metal Burst
";
$g6793 = "Gourgeist-Small @ Leftovers
Ability: Frisk
Tera Type: &
EVs: 20 HP / 236 SpA / 252 Spe
Timid Nature
- Shadow Ball
- Charge Beam
- Leech Seed
- Protect
";
$g6802 = "Linoone-Galar @
Ability: Pickup
Tera Type: &
EVs: 148 HP / 108 Atk / 252 Spe
Jolly Nature
- Knock Off
- Gunk Shot
- Parting Shot
- Protect
";
$g6811 = "Registeel @ Assault Vest
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 28 Atk / 40 Def / 188 SpD
Careful Nature
- Iron Head
- Power-Up Punch
- Earthquake
- Counter
";
$g6820 = "Celebi @ Grassy Seed
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 16 Atk / 200 Def / 40 SpD
Impish Nature
- Grassy Glide
- Sucker Punch
- Swords Dance
- Grassy Terrain
";
$g6829 = "Kyurem-Black @ Weakness Policy
Ability: Teravolt
Tera Type: &
EVs: 72 HP / 164 Def / 20 SpA / 252 Spe
Timid Nature
- Draco Meteor
- Ice Beam
- Weather Ball
- Sunny Day
";
$g6838 = "Zapdos @ Heavy-Duty Boots
Ability: Static
Tera Type: &
EVs: 176 HP / 148 Def / 36 SpA / 148 Spe
Timid Nature
- Thunderbolt
- Weather Ball
- Hail
- Roost
";
$g6847 = "Metagross @ Custap Berry
Ability: Clear Body
Tera Type: &
EVs: 240 HP / 12 Atk / 4 Def / 12 SpA / 240 SpD
Brave Nature
- Meteor Mash
- Brick Break
- Psychic
- Explosion
";
$g6856 = "Gardevoir @ Pixie Plate
Ability: Trace
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Psychic
- Moonblast
- Destiny Bond
- Thunder Wave
";
$g6865 = "Volcarona @ Rocky Helmet
Ability: Swarm
Tera Type: &
EVs: 80 HP / 176 Def / 252 Spe
Timid Nature
- Bug Buzz
- Psychic
- Will-O-Wisp
- Roost
";
$g6874 = "Latias @ Rocky Helmet
Ability: Levitate
Tera Type: &
EVs: 204 HP / 188 Def / 44 SpD / 72 Spe
Timid Nature
- Dragon Breath
- Mystical Fire
- Reflect
- Recover
";
$g6883 = "Togetic @ Eviolite
Ability: Super Luck
Tera Type: &
EVs: 252 HP / 116 Def / 56 SpA / 16 SpD / 68 Spe
Bold Nature
- Draining Kiss
- Fire Blast
- Stored Power
- Nasty Plot
";
$g6892 = "Torracat @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 56 Def / 200 SpA / 252 Spe
Timid Nature
- Overheat
- Toxic
- Protect
- Parting Shot
";
$g6901 = "Pincurchin @ Custap Berry
Ability: Electric Surge
Tera Type: &
EVs: 252 HP / 108 Def / 108 SpA / 40 SpD
Relaxed Nature
- Rising Voltage
- Scald
- Sucker Punch
- Toxic Spikes
";
$g6910 = "Blissey @ Assault Vest
Ability: Serene Grace
Tera Type: &
EVs: 72 HP / 252 Def / 112 SpA / 72 SpD
Bold Nature
- Hyper Voice
- Flamethrower
- Psychic
- Charge Beam
";
$g6919 = "Malamar @ Sitrus Berry
Ability: Contrary
Tera Type: &
EVs: 80 HP / 48 Atk / 128 SpD / 252 Spe
Jolly Nature
- Thief
- Superpower
- Toxic
- Protect
";
$g6928 = "Tapu Bulu @ Choice Scarf
Ability: Grassy Surge
Tera Type: &
EVs: 40 HP / 216 Atk / 252 Spe
Adamant Nature
- Wood Hammer
- Close Combat
- Darkest Lariat
- Stone Edge
";
$g6937 = "Kyurem-Black @ Power Herb
Ability: Teravolt
Tera Type: &
EVs: 220 HP / 20 Atk / 16 Def / 252 Spe
Adamant Nature
- Freeze Shock
- Toxic
- Substitute
- Protect
";
$g6946 = "Darumaka-Galar @ Choice Scarf
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Ice Punch
- Flare Blitz
- Superpower
- U-turn
";
$g6955 = "Goodra @ Figy Berry
Ability: Hydration
Tera Type: &
EVs: 44 HP / 252 Def / 12 SpA / 200 Spe
Bold Nature
- Rest
- Body Press
- Rain Dance
- Acid Armor
";
$g6964 = "Jolteon @ Heavy-Duty Boots
Ability: Volt Absorb
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Electro Ball
- Shadow Ball
- Weather Ball
- Sunny Day
";
$g6973 = "Kyurem-Black @ Assault Vest
Ability: Teravolt
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Adamant Nature
- Toxic
- Roost
- Protect
-
";
$g6982 = "Kommo-o @ Choice Specs
Ability: Bulletproof
Tera Type: &
EVs: 108 HP / 252 SpA / 108 SpD / 40 Spe
Modest Nature
- Draco Meteor
- Clanging Scales
- Focus Blast
- Flash Cannon
";
$g6991 = "Porygon-Z @ Rocky Helmet
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe
Jolly Nature
- Iron Tail
- Recover
- Conversion
- Reflect
";
$g7000 = "Naganadel @ Black Sludge
Ability: Beast Boost
Tera Type: &
EVs: 196 HP / 224 Def / 88 Spe
Bold Nature
- Toxic
- Substitute
- Protect
- Charm
";
$g7009 = "Jirachi @ Power Herb
Ability: Serene Grace
Tera Type: &
EVs: 40 Atk / 252 SpA / 216 Spe
Mild Nature
- Iron Head
- Meteor Beam
- Psyshock
- Substitute
";
$g7018 = "Munchlax @ Eviolite
Ability: Thick Fat
Tera Type: &
EVs: 16 HP / 224 Atk / 188 Def / 80 SpD
Adamant Nature
- Gunk Shot
- Earthquake
- Encore
- Counter
";
$g7027 = "Toxtricity @ Life Orb
Ability: Punk Rock
Tera Type: &
EVs: 136 HP / 192 Atk / 76 SpD / 104 Spe
Adamant Nature
- Shift Gear
- Encore
- Gunk Shot
- Fire Punch
";
$g7036 = "Shuckle @ Custap Berry
Ability: Sturdy
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Power Trick
- Rock Blast
- Reversal
- Endure
";
$g7046 = "Sceptile @ Sitrus Berry
Ability: Unburden
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Leech Seed
- Protect
- Substitute
- Seismic Toss
";
$g7055 = "Dusclops @ Eviolite
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Mean Look
- Disable
- Night Shade
- Pain Split
";
$g7064 = "Skarmory @ Figy Berry
Ability: Sturdy
Tera Type: &
EVs: 252 HP / 52 Def / 204 Spe
Impish Nature
- Torment
- Protect
- Sand Tomb
- Roost
";
$g7073 = "Gengar @ Black Sludge
Ability: Cursed Body
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Reflect Type
- Will-O-Wisp
- Giga Drain
- Sludge Bomb
";
$g7082 = "Buzzwole @ Maranga Berry
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Leech Life
- Bulk Up
- Drain Punch
- Bounce
";
$g7091 = "Buzzwole @ Big Root
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Fell Stinger
- Counter
- Leech Life
- Drain Punch
";
$g7100 = "Thundurus @ Life Orb
Ability: Prankster
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Thunderbolt
- Grass Knot
- Weather Ball
";
$g7109 = "Sirfetch’d @ Chesto Berry
Ability: Steadfast
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Careful Nature
- Body Slam
- Knock Off
- Curse
- Rest
";
$g7118 = "Ditto @ Choice Band
Ability: Imposter
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g7127 = "Ditto @ Choice Scarf
Ability: Imposter
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g7136 = "Ditto @ Choice Specs
Ability: Imposter
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g7145 = "Chansey @ Shell Bell
Ability: Serene Grace
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Thunderbolt
- Flamethrower
- Ice Beam
- Laser Focus
";
$g7154 = "Kartana @ Choice Specs
Ability: Beast Boost
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Giga Drain
- Steel Beam
- Air Slash
- Vacuum Wave
";
$g7163 = "Mew @ Toxic Orb
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Skill Swap
- Helping Hand
- Trick
- Psyshock
";
$g7172 = "Kyurem-Black @ Shell Bell
Ability: Teravolt
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Freeze Shock
- Outrage
- Dragon Claw
- Fusion Bolt
";
$g7181 = "Carvanha @ Leftovers
Ability: Rough Skin
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Toxic
- Protect
- Substitute
- Agility
";
$g7190 = "Jynx @ Sitrus Berry
Ability: Oblivious
Tera Type: &
EVs: 164 HP / 100 SpA / 20 SpD / 224 Spe
Timid Nature
- Taunt
- Calm Mind
- Ice Beam
- Energy Ball
";
$g7199 = "Turtonator @ Air Balloon
Ability: Shell Armor
Tera Type: &
EVs: 88 HP / 252 SpA / 168 Spe
Modest Nature
- Taunt
- Shell Smash
- Draco Meteor
- Overheat
";
$g7208 = "Stunfisk-Galar @ Leftovers
Ability: Mimicry
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Impish Nature
- Pain Split
- Iron Defense
- Thunder Wave
- Bind
";
$g7217 = "Regirock @ Choice Band
Ability: Clear Body
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Adamant Nature
- Stealth Rock
- Curse
- Iron Defense
- Safeguard
";
$g7226 = "Regice @ Leftovers
Ability: Ice Body
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Blizzard
- Curse
- Hail
- Rest
";
$g7235 = "Walrein @ Life Orb
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Substitute
- Ice Fang
- Liquidation
- Swords Dance
";
$g7244 = "Regidrago @ Choice Band
Ability: Dragons Maw
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Outrage
- Fire Fang
- Hammer Arm
- Explosion
";
$g7253 = "Regidrago @ Choice Specs
Ability: Dragons Maw
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Dragon Energy
- Ancient Power
- Snore
- Hyper Beam
";
$g7262 = "Regice @ Flame Orb
Ability: Ice Body
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpA
Quiet Nature
- Ice Beam
- Thunderbolt
- Facade
- Thunder Wave
";
$g7272 = "Regieleki @ Iron Ball
Ability: Transistor
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Rash Nature
- Explosion
- Acrobatics
- Rising Voltage
- Electric Terrain
";
$g7281 = "Heatran @ Choice Band
Ability: Flame Body
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Stone Edge
- Crunch
- Iron Head
- Steel Roller
";
$g7290 = "Dragonair @ Choice Band
Ability: Shed Skin
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Adamant Nature
- Iron Tail
- Skull Bash
- Outrage
- Extreme Speed
";
$g7299 = "Exeggutor-Alola @ Choice Band
Ability: Frisk
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- Explosion
- Dragon Hammer
- Power Whip
- Knock Off
";
$g7308 = "Snorlax @ Rocky Helmet
Tera Type: &
Ability: Gluttony EVs: 252 HP / 252 Def / 4 SpA
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Seismic Toss
- Zap Cannon
- Encore
- Counter
";
$g7317 = "Sandslash-Alola @ Focus Band
Ability: Snow Cloak
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Sassy Nature
- Hail
- Mirror Coat
- Counter
- Metal Burst
";
$g7327 = "Snorlax @ Lansat Berry
Ability: Gluttony
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Body Press
- Substitute
- Recycle
- Rest
";
$g7336 = "Snorlax @ Starf Berry
Ability: Gluttony
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Body Press
- Substitute
- Recycle
- Rest
";
$g7345 = "Tentacruel @ Black Sludge
Ability: Liquid Ooze
Tera Type: &
EVs: 252 HP / 240 SpD / 16 Spe
Careful Nature
- Reflect Type
- Rapid Spin
- Skull Bash
- Reflect
";
$g7354 = "Exeggutor @ Lansat Berry
Ability: Harvest
Tera Type: &
EVs: 4 HP / 124 Def / 4 SpA / 124 SpD / 252 Spe
Timid Nature
- Giga Drain
- Leech Seed
- Sunny Day
- Substitute
";
$g7363 = "Jynx @ Occa Berry
Ability: Oblivious
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe
Timid Nature
- Counter
- Ice Beam
- Lovely Kiss
- Wish
";
$g7372 = "Kingler @ Choice Band
Ability: Sheer Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Liquidation
- Double-Edge
- X-Scissor
- Knock Off
";
$g7381 = "Duosion @ Eviolite
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 124 Def / 132 SpD
Bold Nature
- Stored Power
- Acid Armor
- Calm Mind
- Recover
";
$g7390 = "Moltres-Galar @ Choice Band
Ability: Berserk
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Lash Out
- Sucker Punch
- Brave Bird
- U-turn
";
$g7399 = "Beheeyem @ Choice Specs
Ability: Analytic
Tera Type: &
EVs: 252 Def / 252 SpA / 4 SpD
Quiet Nature
- Dark Pulse
- Psychic
- Psyshock
- Thunderbolt
";
$g7408 = "Zapdos-Galar @ Light Clay
Ability: Defiant
Tera Type: &
EVs: 4 Atk / 252 Def / 252 Spe
Jolly Nature
- Light Screen
- U-turn
- Close Combat
- Brave Bird
";
$g7417 = "Hawlucha @ Starf Berry
Ability: Unburden
Tera Type: &
EVs: 252 HP / 56 Atk / 32 SpA / 168 SpD
Brave Nature
- Acrobatics
- Grass Knot
- Focus Punch
- Roost
";
$g7426 = "Basculin @ Assault Vest
Ability: Adaptability
Tera Type: &
EVs: 24 HP / 24 Atk / 208 SpD / 252 Spe
Adamant Nature
- Waterfall
- Superpower
- Scale Shot
- Flip Turn
";
$g7435 = "Altaria @ Starf Berry
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 212 SpA / 28 SpD / 16 Spe
Modest Nature
- Dragon Breath
- Cotton Guard
- Roost
- Agility
";
$g7444 = "Aegislash @ Assault Vest
Ability: Stance Change
Tera Type: &
EVs: 252 HP / 84 Atk / 172 SpD
Sassy Nature
- Shadow Sneak
- Iron Head
- Close Combat
- Head Smash
";
$g7453 = "Spiritomb @ Custap Berry
Ability: Pressure
Tera Type: &
EVs: 16 HP / 220 Def / 148 SpA / 120 SpD / 4 Spe
Bold Nature
- Hex
- Will-O-Wisp
- Memento
- Pain Split
";
$g7462 = "Milotic @ Starf Berry
Ability: Competitive
Tera Type: &
EVs: 184 HP / 248 Def / 8 SpA / 68 Spe
Modest Nature
- Scald
- Imprison
- Recover
- Protect
";
$g7471 = "Tyranitar @ Shock Drive
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 108 Atk / 4 Def / 108 SpA / 36 SpD
Lonely Nature
- Thunder
- Crunch
- Heavy Slam
- Stealth Rock
";
$g7480 = "Weezing-Galar @ Custap Berry
Ability: Levitate
Tera Type: &
EVs: 44 HP / 252 SpA / 148 SpD / 64 Spe
Modest Nature
- Strange Steam
- Fire Blast
- Will-O-Wisp
- Pain Split
";
$g7489 = "Copperajah @ Choice Specs
Ability: Sheer Force
Shiny: Yes
Tera Type: &
EVs: 64 HP / 16 Atk / 168 Def / 200 SpA / 60 SpD
Quiet Nature
- Flash Cannon
- Earth Power
- Stealth Rock
- Power Whip
";
$g7499 = "Sandslash-Alola @ Assault Vest
Ability: Snow Cloak
Tera Type: &
EVs: 240 HP / 76 Atk / 20 Def / 172 SpD
Impish Nature
- Triple Axel
- Iron Tail
- Mirror Coat
- Rapid Spin
";
$g7508 = "Rapidash-Galar @ Kee Berry
Ability: Pastel Veil
Tera Type: &
EVs: 180 HP / 8 Def / 68 SpA / 252 Spe
Timid Nature
- Stored Power
- Mystical Fire
- Morning Sun
- Calm Mind
";
$g7517 = "Tornadus @ Flame Orb
Ability: Prankster
Tera Type: &
EVs: 132 HP / 252 Atk / 16 Def / 108 Spe
Adamant Nature
- Acrobatics
- Superpower
- Fling
- U-turn
";
$g7526 = "Diancie @ Normal Gem
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 244 Atk / 12 Def
Adamant Nature
- Diamond Storm
- Explosion
- Stealth Rock
- Protect
";
$g7535 = "Hippowdon @ Normal Gem
Ability: Sand Stream
Shiny: Yes
Tera Type: &
EVs: 224 HP / 20 Atk / 252 SpD / 12 Spe
Adamant Nature
- Earthquake
- Giga Impact
- Roar
- Slack Off
";
$g7545 = "Suicune @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 44 Def / 212 SpD
Sassy Nature
- Scald
- Crunch
- Rest
- Curse
";
$g7554 = "Diancie @ Leftovers
Ability: Clear Body
Tera Type: &
EVs: 68 HP / 232 Def / 52 SpA / 156 Spe
Bold Nature
- Stored Power
- Body Press
- Rock Polish
- Calm Mind
";
$g7563 = "Reuniclus @ Choice Band
Ability: Magic Guard
Tera Type: &
EVs: 84 HP / 204 Atk / 220 Def
Brave Nature
- Psychic
- Focus Punch
- Recover
- Trick
";
$g7572 = "Jirachi @ Expert Belt
Ability: Serene Grace
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Water Pulse
- Shock Wave
- Ancient Power
- Protect
";
$g7581 = "Togetic @ Eviolite
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 60 Def / 196 Spe
Timid Nature
- Ancient Power
- Air Cutter
- Thunder Wave
- Roost
";
$g7590 = "Terrakion @ Life Orb
Ability: Justified
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Focus Blast
- Air Slash
- Protect
- Calm Mind
";
$g7599 = "Rhyperior @ Choice Scarf
Ability: Solid Rock
Tera Type: &
EVs: 216 Atk / 40 SpD / 252 Spe
Jolly Nature
- High Horsepower
- Stone Edge
- Megahorn
- Superpower
";
$g7608 = "Hatterene @ Custap Berry
Ability: Magic Bounce
Tera Type: &
EVs: 144 HP / 200 Def / 140 SpA / 8 SpD / 16 Spe
Calm Nature
- Psychic
- Draining Kiss
- Healing Wish
- Calm Mind
";
$g7617 = "Gyarados @ Chesto Berry
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 100 SpD / 156 Spe
Adamant Nature
- Waterfall
- Double-Edge
- Rest
- Dragon Dance
";
$g7626 = "Ferrothorn @ Eject Pack
Ability: Iron Barbs
Tera Type: &
EVs: 252 HP / 20 Atk / 16 Def / 220 SpD
Brave Nature
- Power Whip
- Gyro Ball
- Knock Off
- Curse
";
$g7635 = "Spiritomb @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Dark Pulse
- Will-O-Wisp
- Rest
- Calm Mind
";
$g7644 = "Spiritomb @ Rocky Helmet
Ability: Pressure
Tera Type: &
EVs: 196 HP / 100 Def / 100 SpA / 100 SpD / 12 Spe
Modest Nature
- Icy Wind
- Destiny Bond
- Grudge
- Memento
";
$g7653 = "Seismitoad @ Life Orb
Ability: Swift Swim
Tera Type: &
EVs: 180 HP / 200 Atk / 16 Def / 112 Spe
Adamant Nature
- Liquidation
- Ice Punch
- Power Whip
- Rain Dance
";
$g7662 = "Celesteela @ Choice Band
Ability: Beast Boost
Tera Type: &
EVs: 248 HP / 104 Atk / 144 SpD / 12 Spe
Adamant Nature
- Heavy Slam
- Earthquake
- Megahorn
- Flame Charge
";
$g7671 = "Mimikyu @ Choice Scarf
Ability: Disguise
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Shadow Claw
- Play Rough
- Drain Punch
- Trick
";
$g7680 = "Mew @ Salac Berry
Ability: Synchronize
Tera Type: &
EVs: 84 HP / 168 Def / 4 SpA / 252 Spe
Bold Nature
- Scald
- Body Press
- Reflect Type
- Soft-Boiled
";
$g7689 = "Rotom-Heat @ Adrenaline Orb
Ability: Levitate
Tera Type: &
EVs: 196 HP / 28 Def / 48 SpA / 8 SpD / 228 Spe
Modest Nature
- Thunderbolt
- Overheat
- Discharge
- Nasty Plot
";
$g7698 = "Volcanion @ Life Orb
Ability: Water Absorb
Tera Type: &
EVs: 160 Atk / 160 SpA / 188 Spe
Naughty Nature
- Flare Blitz
- Steam Eruption
- Explosion
- Flame Charge
";
$g7707 = "Jellicent @ Heavy-Duty Boots
Ability: Water Absorb
Tera Type: &
EVs: 108 HP / 252 Def / 148 SpA
Relaxed Nature
- Water Spout
- Shadow Ball
- Recover
- Trick Room
";
$g7716 = "Vulpix-Alola @ Eviolite
Ability: Snow Warning
Tera Type: &
EVs: 252 HP / 192 Def / 64 SpD
Calm Nature
- Foul Play
- Roar
- Heal Bell
- Protect
";
$g7725 = "Azelf @ Black Glasses
Ability: Levitate
Tera Type: &
EVs: 252 HP / 72 Atk / 164 Def / 20 SpD
Relaxed Nature
- Knock Off
- Magic Room
- Wonder Room
- Trick Room
";
$g7734 = "Nidoking @ Black Sludge
Ability: Poison Point
Tera Type: &
EVs: 96 HP / 180 Atk / 52 SpD / 180 Spe
Jolly Nature
- Double-Edge
- Sand Tomb
- Substitute
- Protect
";
$g7743 = "Exeggutor-Alola @ Eject Pack
Ability: Frisk
Tera Type: &
EVs: 252 HP / 68 Def / 188 SpA
Modest Nature
- Draco Meteor
- Knock Off
- Synthesis
- Protect
";
$g7752 = "Necrozma @ Sitrus Berry
Ability: Prism Armor
Tera Type: &
EVs: 12 HP / 244 SpA / 252 Spe
Timid Nature
- Stored Power
- Earth Power
- Power Gem
- Cosmic Power
";
$g7761 = "Mew @ Choice Scarf
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Transform
- U-turn
- Soft-Boiled
- Trick
";
$g7770 = "Mew @ Starf Berry
Ability: Synchronize
Tera Type: &
EVs: 228 HP / 196 Def / 84 Spe
Impish Nature
- Body Press
- Skitter Smack
- High Horsepower
- Soft-Boiled
";
$g7779 = "Aegislash @ Life Orb
Ability: Stance Change
Tera Type: &
EVs: 248 HP / 40 Atk / 220 SpA
Quiet Nature
- Flash Cannon
- Shadow Ball
- Close Combat
- Kings Shield
";
$g7788 = "Charizard @ Life Orb
Ability: Blaze
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Fire Blast
- Hurricane
- Focus Blast
- Protect
";
$g7797 = "Kangaskhan @ Assault Vest
Ability: Scrappy
Tera Type: &
EVs: 252 HP / 144 Atk / 112 Spe
Adamant Nature
- Last Resort
- Fake Out
-
-
";
$g7806 = "Kartana @ Leftovers
Ability: Beast Boost
Tera Type: &
EVs: 88 Atk / 212 SpD / 208 Spe
Jolly Nature
- Last Resort
- Protect
- Swords Dance
-
";
$g7815 = "Kartana @ Weakness Policy
Ability: Beast Boost
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 92 Def / 160 Spe
Adamant Nature
- Leaf Blade
- Sacred Sword
- Toxic
- Iron Defense
";
$g7825 = "Rhyperior @ Lum Berry
Ability: Solid Rock
Tera Type: &
EVs: 56 HP / 200 Atk / 252 Def
Impish Nature
- Earthquake
- Rock Blast
- Payback
- Megahorn
";
$g7834 = "Porygon2 @ Choice Scarf
Ability: Download
Tera Type: &
EVs: 120 HP / 40 SpA / 180 SpD / 168 Spe
Calm Nature
- Hyper Beam
- Ice Beam
- Trick
- Recover
";
$g7843 = "Butterfree @ Heavy-Duty Boots
Ability: Compound Eyes
Tera Type: &
EVs: 156 HP / 120 Def / 188 SpA / 8 SpD / 36 Spe
Modest Nature
- Hurricane
- Draining Kiss
- Sleep Powder
- Iron Defense
";
$g7852 = "Alcremie-Salted-Cream @ Leftovers
Ability: Sweet Veil
Tera Type: &
EVs: 236 HP / 20 SpA / 252 Spe
Timid Nature
- Draining Kiss
- Mystical Fire
- Calm Mind
- Acid Armor
";
$g7861 = "Zapdos @ Power Herb
Ability: Pressure
Tera Type: &
EVs: 252 Atk / 252 SpA / 4 Spe
Naive Nature
- Thunderbolt
- Sky Attack
- Heat Wave
- U-turn
";
$g7870 = "Polteageist-Antique @ Leftovers
Ability: Cursed Body
Tera Type: &
EVs: 64 HP / 104 Def / 156 SpA / 20 SpD / 100 Spe
Modest Nature
- Protect
- Shell Smash
- Shadow Ball
- Giga Drain
";
$g7879 = "Golduck @ Leftovers
Ability: Cloud Nine
Shiny: Yes
Tera Type: &
EVs: 248 HP / 156 Def / 84 SpD / 20 Spe
Bold Nature
- Scald
- Encore
- Protect
- Dig
";
$g7889 = "Hippowdon @ Kee Berry
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Earthquake
- Yawn
- Slack Off
- Stealth Rock
";
$g7898 = "Lombre @ Eviolite
Ability: Swift Swim
Tera Type: &
EVs: 252 HP / 252 Def
Bold Nature
- Counter
- Encore
- Rain Dance
- Synthesis
";
$g7907 = "Electabuzz @ Choice Specs
Ability: Static
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Volt Switch
- Psychic
- Focus Blast
";
$g7916 = "Darmanitan-Galar @ Liechi Berry
Ability: Zen Mode
Tera Type: &
EVs: 188 Atk / 68 Def / 40 SpD / 200 Spe
Adamant Nature
- Substitute
- Protect
- Icicle Crash
- Reversal
";
$g7925 = "Absol @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Spe
Nature
- Thunder Wave
- Will-O-Wisp
- Toxic
- Protect
";
$g7934 = "Porygon @ Eviolite
Ability: Trace
Tera Type: &
EVs: 248 HP / 104 Def / 156 SpD
Calm Nature
- Protect
- Recover
- Discharge
- Tri Attack
";
$g7943 = "Exeggutor-Alola @ Life Orb
Ability: Frisk
Tera Type: &
EVs: 252 Atk / 252 SpA
Brave Nature
- Leaf Storm
- Dragon Hammer
- Ancient Power
- Trick Room
";
$g7952 = "Farfetch’d @ Leek
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Protect
- Swords Dance
- Agility
- Fly
";
$g7961 = "Scorbunny @ Life Orb
Ability: Libero
Tera Type: &
EVs: 252 Atk / 252 Spe
Adamant Nature
- High Jump Kick
- Blaze Kick
- Gunk Shot
- U-turn
";
$g7970 = "Porygon @ Eviolite
Ability: Download
Tera Type: &
EVs: 84 HP / 48 SpA / 124 SpD / 252 Spe
Timid Nature
- Tri Attack
- Defense Curl
- Thunder Wave
- Recover
";
$g7979 = "Linoone-Galar @ Eviolite
Ability: Pickup
Tera Type: &
EVs: 100 HP / 156 Def / 252 Spe
Jolly Nature
- Protect
- Knock Off
- Parting Shot
- Dig
";
$g7988 = "Barbaracle @
Ability: Pickpocket
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Helping Hand
- Toxic
- Protect
- Taunt
";
$g7997 = "Abomasnow @ Custap Berry
Ability: Snow Warning
Tera Type: &
EVs: 228 HP / 56 Atk / 56 Def / 56 SpA / 56 SpD / 56 Spe
Nature
- Wood Hammer
- Ice Shard
- Aurora Veil
- Swords Dance
";
$g8006 = "Weavile @ Choice Specs
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Dark Pulse
- Ice Beam
- Blizzard
- Surf
";
$g8015 = "Ditto @ Red Card
Ability: Imposter
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g8024 = "Wigglytuff @ Blunder Policy
Ability: Competitive
Tera Type: &
EVs: 252 Def / 252 SpD
Quiet Nature
- Zap Cannon
- Dynamic Punch
- Sing
- Blizzard
";
$g8033 = "Torkoal @ Salac Berry
Ability: Drought
Tera Type: &
EVs: 56 Atk / 200 SpA / 252 Spe
Naive Nature
- Shell Smash
- Fire Blast
- Solar Beam
- Stone Edge
";
$g8042 = "Regieleki @ Air Balloon
Ability: Transistor
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Magnet Rise
- Screech
- Giga Impact
- Explosion
";
$g8051 = "Rolycoly @ Eviolite
Ability: Flash Fire
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Impish Nature
- Protect
- Spikes
- Rapid Spin
- Rock Blast
";
$g8060 = "Malamar @ Rocky Helmet
Ability: Suction Cups
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Topsy-Turvy
- Taunt
- Destiny Bond
- Knock Off
";
$g8069 = "Weavile @
Ability: Pickpocket
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Focus Punch
- Endure
- Ice Punch
- Knock Off
";
$g8078 = "Thundurus @ Aguav Berry
Ability: Prankster
Tera Type: &
EVs: 248 HP / 88 Def / 172 SpD
Bold Nature
- Toxic
- Protect
- Substitute
- Thunderbolt
";
$g8087 = "Shelmet @ Eviolite
Ability: Overcoat
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Recover
- Spikes
- Body Slam
- Yawn
";
$g8097 = "Clefable @ Rocky Helmet
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 156 Def / 92 SpD / 8 Spe
Calm Nature
- Moonblast
- Thunder Wave
- Soft-Boiled
- Stealth Rock
";
$g8106 = "Kangaskhan @ Normal Gem
Ability: Early Bird
Tera Type: &
EVs: 128 HP / 220 Atk / 128 Def / 32 Spe
Adamant Nature
- Double-Edge
- Fake Out
- Thief
- Hammer Arm
";
$g8115 = "Clefairy @ Life Orb
Ability: Magic Guard
Tera Type: &
EVs: 216 HP / 252 SpA / 40 Spe
Modest Nature
- Moonblast
- Soft-Boiled
- Fire Blast
- Thunderbolt
";
$g8124 = "Kyurem @ Kings Rock
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Ice Beam
- Earth Power
- Fling
";
$g8133 = "Clefairy @ Eviolite
Ability: Magic Guard
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Moonblast
- Soft-Boiled
- Thunder Wave
- Knock Off
";
$g8142 = "Clefairy @ Eviolite
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Defense Curl
- Soft-Boiled
- Seismic Toss
- Thunder Wave
";
$g8151 = "Ditto @ Assault Vest
Ability: Imposter
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g8160 = "Moltres @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 248 HP / 228 Def / 32 Spe
Bold Nature
- Substitute
- Roost
- Flamethrower
- Fly
";
$g8169 = "Krabby @ Eviolite
Ability: Sheer Force
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Liquidation
- Protect
- Dig
- Knock Off
";
$g8178 = "Genesect @ Assault Vest
Ability: Download
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe
Careful Nature
- Leech Life
- U-turn
- Electroweb
- Iron Head
";
$g8187 = "Silvally-Steel @ Steel Memory
Ability: RKS System
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Rest
- Sleep Talk
- Multi-Attack
- Swords Dance
";
$g8196 = "Silvally-Bug @ Bug Memory
Ability: RKS System
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Modest Nature
- Swords Dance
- Iron Defense
- Rest
- Multi-Attack
";
$g8205 = "Sandslash @ Leftovers
Ability: Sand Veil
Tera Type: &
EVs: 220 HP / 4 Atk / 164 Def / 80 SpD / 40 Spe
Impish Nature
- Stealth Rock
- Spikes
- Dig
- Rapid Spin
";
$g8214 = "Omastar @ Leftovers
Ability: Weak Armor
Tera Type: &
EVs: 252 HP / 252 SpD
Calm Nature
- Stealth Rock
- Spikes
- Toxic Spikes
- Scald
";
$g8223 = "Gastrodon @ Leftovers
Ability: Storm Drain
Tera Type: &
EVs: 252 HP / 140 Def / 116 SpD
Calm Nature
- Scald
- Recover
- Counter
- Mirror Coat
";
$g8232 = "Calyrex @ Life Orb
Ability: Unnerve
Tera Type: &
EVs: 252 SpA / 252 Spe
Modest Nature
- Psychic Terrain
- Expanding Force
- Calm Mind
- Heal Pulse
";
$g8241 = "Bewear @ Assault Vest
Ability: Fluffy
Tera Type: &
EVs: 4 Atk / 252 Def / 252 SpD
Careful Nature
- Drain Punch
- Bulldoze
- Body Slam
- Ice Punch
";
$g8250 = "Latios @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Defog
- Roost
- Trick
";
$g8259 = "Silvally-Poison @ Poison Memory
Ability: RKS System
Tera Type: &
EVs: 252 HP / 4 Atk / 56 Def / 196 SpD
Sassy Nature
- Multi-Attack
- Flamethrower
- Toxic
- Protect
";
$g8268 = "Latias @ Assault Vest
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 44 Def / 160 SpA / 148 SpD / 132 Spe
Timid Nature
- Draco Meteor
- Psychic
- Mystical Fire
- Aura Sphere
";
$g8278 = "Ditto @ Quick Powder
Ability: Limber
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Transform
-
-
-
";
$g8287 = "Jirachi @ Power Herb
Ability: Serene Grace
Tera Type: &
EVs: 16 HP / 16 Def / 212 SpA / 16 SpD / 248 Spe
Timid Nature
- Meteor Beam
- Shadow Ball
- Thunder Wave
- Imprison
";
$g8296 = "Metagross @ Weakness Policy
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 16 Atk / 240 SpD
Adamant Nature
- Meteor Mash
- Zen Headbutt
- Earthquake
- Bullet Punch
";
$g8305 = "Landorus-Therian @ Lum Berry
Ability: Intimidate
Tera Type: &
EVs: 100 HP / 116 SpA / 40 SpD / 252 Spe
Calm Nature
- Earth Power
- Sludge Bomb
- Gravity
- Calm Mind
";
$g8314 = "Victini @ Magnet
Ability: Victory Star
Tera Type: &
EVs: 252 Atk / 252 SpA / 4 SpD
Serious Nature
- Bolt Strike
- Thunder
- Charge Beam
- Thunder Wave
";
$g8323 = "Aggron @ Protective Pads
Ability: Sturdy
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Heavy Slam
- Toxic
- Endeavor
- Substitute
";
$g8332 = "Guzzlord @ Lum Berry
Ability: Beast Boost
Tera Type: &
EVs: 168 Def / 88 SpA / 252 SpD
Modest Nature
- Dark Pulse
- Belch
- Corrosive Gas
- Rest
";
$g8341 = "Mew @ Rocky Helmet
Ability: Synchronize
Tera Type: &
EVs: 228 HP / 60 Def / 196 SpD / 24 Spe
Calm Nature
- Sleep Talk
- Toxic
- Corrosive Gas
- Rest
";
$g8350 = "Bronzong @ Chesto Berry
Ability: Levitate
Tera Type: &
EVs: 252 HP / 188 Def / 68 SpA
Bold Nature
- Expanding Force
- Rest
- Calm Mind
- Psychic Terrain
";
$g8359 = "Nihilego @ Chesto Berry
Ability: Beast Boost
Tera Type: &
EVs: 212 HP / 252 Def / 44 Spe
Modest Nature
- Meteor Beam
- Rest
- Corrosive Gas
- Protect
";
$g8368 = "Wailord @ Kee Berry
Ability: Pressure
Tera Type: &
EVs: 252 Def / 252 SpD
Impish Nature
- Toxic
- Amnesia
- Rest
- Aqua Ring
";
$g8377 = "Togekiss @ Flame Orb
Ability: Serene Grace
Tera Type: &
EVs: 240 HP / 188 Def / 52 SpA / 28 Spe
Modest Nature
- Air Slash
- Fling
- Covet
- Roost
";
$g8386 = "Tapu Koko @ Leftovers
Ability: Electric Surge
Tera Type: &
EVs: 56 HP / 200 SpA / 252 Spe
Timid Nature
- Thunderbolt
- Toxic
- Taunt
- Roost
";
$g8395 = "Aegislash @ Adrenaline Orb
Ability: Stance Change
Tera Type: &
EVs: 204 HP / 48 Atk / 4 SpD / 252 Spe
Jolly Nature
- Iron Head
- Close Combat
- Kings Shield
- Swords Dance
";
$g8404 = "Incineroar @ Liechi Berry
Ability: Blaze
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Jolly Nature
- Blaze Kick
- Acrobatics
- Flame Charge
- Substitute
";
$g8413 = "Qwilfish @ Lum Berry
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Aqua Jet
- Poison Jab
- Rest
- Curse
";
$g8422 = "Qwilfish @ Spell Tag
Ability: Intimidate
Tera Type: &
EVs: 28 Def / 228 SpA / 252 Spe
Timid Nature
- Hex
- Toxic Spikes
- Thunder Wave
- Destiny Bond
";
$g8431 = "Qwilfish @ Life Orb
Ability: Swift Swim
Tera Type: &
EVs: 168 HP / 200 Atk / 140 SpD
Brave Nature
- Aqua Tail
- Explosion
- Spikes
- Rain Dance
";
$g8440 = "Growlithe @ Eviolite
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 208 Def / 48 SpD
Bold Nature
- Fire Blast
- Fire Spin
- Morning Sun
- Protect
";
$g8449 = "Victini @ Leftovers
Ability: Victory Star
Tera Type: &
EVs: 28 HP / 200 Atk / 28 SpA / 252 Spe
Naive Nature
- Blue Flare
- Bolt Strike
- Encore
- Substitute
";
$g8458 = "Diancie @ Weakness Policy
Ability: Clear Body
Tera Type: &
EVs: 204 HP / 84 Atk / 48 SpA / 172 Spe
Nature
- Diamond Storm
- Moonblast
- Mystical Fire
- Rock Polish
";
$g8467 = "Salamence @ Red Card
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Outrage
- Roost
- Iron Defense
- Dragon Dance
";
$g8476 = "Accelgor @ Eject Button
Ability: Hydration
Tera Type: &
EVs: 60 HP / 24 Atk / 252 Def / 4 SpD / 168 Spe
Adamant Nature
- Spikes
- Toxic Spikes
- Drain Punch
- Skitter Smack
";
$g8485 = "Gastrodon-East @ Eject Pack
Ability: Storm Drain
Tera Type: &
EVs: 208 HP / 252 Def / 48 SpA
Quiet Nature
- Muddy Water
- Clear Smog
- Recover
- Curse
";
$g8494 = "Azelf @ Assault Vest
Ability: Levitate
Tera Type: &
EVs: 252 HP / 100 SpA / 156 Spe
Modest Nature
- Psychic
- Shadow Ball
- Knock Off
- Charge Beam
";
$g8503 = "Azelf @ Sticky Barb
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Psychic
- Encore
- Taunt
- Trick
";
$g8512 = "Spectrier @ Red Card
Ability: Grim Neigh
Shiny: Yes
Tera Type: &
EVs: 172 HP / 252 Def / 84 Spe
Quiet Nature
- Hex
- Will-O-Wisp
- Taunt
- Calm Mind
";
$g8522 = "Tornadus @ Red Card
Ability: Prankster
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Acrobatics
- Knock Off
- Defog
- Bulk Up
";
$g8531 = "Spectrier @ Leftovers
Ability: Grim Neigh
Tera Type: &
EVs: 216 HP / 144 Def / 36 SpA / 112 Spe
Timid Nature
- Shadow Ball
- Phantom Force
- Substitute
- Calm Mind
";
$g8540 = "Volcanion @ Choice Specs
Ability: Water Absorb
Tera Type: &
EVs: 108 HP / 252 SpA / 148 Spe
Modest Nature
- Focus Blast
- Sleep Talk
- Steam Eruption
-
";
$g8549 = "Xurkitree @ Kee Berry
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 140 Def / 116 SpA
Modest Nature
- Discharge
- Ingrain
- Protect
- Calm Mind
";
$g8558 = "Zygarde @ Chesto Berry
Ability: Aura Break
Tera Type: &
EVs: 252 HP / 44 Atk / 112 SpD / 100 Spe
Careful Nature
- High Horsepower
- Rest
- Dragon Dance
- Coil
";
$g8567 = "Shellos @ Eviolite
Ability: Sticky Hold
Tera Type: &
EVs: 240 HP / 112 Atk / 120 Def / 36 SpD
Adamant Nature
- Dive
- Clear Smog
- Curse
- Recover
";
$g8576 = "Shellos @ Eviolite
Ability: Sticky Hold
Tera Type: &
EVs: 252 Def / 232 SpD / 24 Spe
Calm Nature
- Scald
- Toxic
- Pain Split
- Yawn
";
$g8585 = "Gigalith @ Weakness Policy
Ability: Sand Stream
Tera Type: &
EVs: 196 HP / 60 Atk / 252 Spe
Adamant Nature
- Rock Slide
- Iron Head
- Stomping Tantrum
- Rock Polish
";
$g8594 = "Hawlucha @ Kee Berry
Ability: Unburden
Tera Type: &
EVs: 252 HP / 252 Def
Impish Nature
- Body Press
- Encore
- Bulk Up
- Roost
";
$g8603 = "Goodra @ Red Card
Ability: Hydration
Tera Type: &
EVs: 232 HP / 96 Def / 164 SpA / 4 SpD / 12 Spe
Modest Nature
- Dragon Pulse
- Thunder
- Rest
- Rain Dance
";
$g8612 = "Nidoking @ Fossilized Fish
Ability: Sheer Force
Tera Type: &
EVs: 100 HP / 100 Def / 200 SpA / 12 SpD / 96 Spe
Timid Nature
- Focus Blast
- Ice Beam
- Stealth Rock
- Protect
";
$g8621 = "Kommo-o @ Quick Claw
Ability: Bulletproof
Tera Type: &
EVs: 72 HP / 152 Atk / 24 Def / 8 SpD / 252 Spe
Jolly Nature
- Drain Punch
- Poison Jab
- Stealth Rock
- Swords Dance
";
$g8630 = "Azumarill @ Quick Claw
Ability: Huge Power
Tera Type: &
EVs: 48 HP / 252 Atk / 172 Def / 8 SpD / 28 Spe
Adamant Nature
- Play Rough
- Knock Off
- Substitute
- Belly Drum
";
$g8639 = "Slowbro-Galar @ Quick Claw
Ability: Quick Draw
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe
Quiet Nature
- Psychic
- Amnesia
- Slack Off
- Iron Defense
";
$g8648 = "Slowbro @ Quick Claw
Ability: Oblivious
Tera Type: &
EVs: 164 HP / 252 Def / 20 SpA / 72 SpD
Relaxed Nature
- Scald
- Body Press
- Slack Off
- Iron Defense
";
$g8657 = "Slowbro-Galar @ Focus Band
Ability: Quick Draw
Tera Type: &
EVs: 52 HP / 216 Atk / 204 SpA / 36 SpD
Quiet Nature
- Psychic
- Ice Beam
- Earthquake
- Nasty Plot
";
$g8666 = "Scolipede @ Life Orb
Ability: Speed Boost
Tera Type: &
EVs: 152 HP / 252 Atk / 12 Def / 4 SpD / 88 Spe
Adamant Nature
- Megahorn
- Poison Jab
- Dig
- Protect
";
$g8675 = "Whirlipede @ Eviolite
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 140 Def / 116 SpD
Adamant Nature
- Endeavor
- Poison Jab
- Substitute
- Protect
";
$g8684 = "Scrafty @ Cell Battery
Ability: Intimidate
Tera Type: &
EVs: 24 Atk / 232 SpD / 252 Spe
Jolly Nature
- Knock Off
- Drain Punch
- Stone Edge
- Fake Out
";
$g8693 = "Ferrothorn @ Cell Battery
Ability: Iron Barbs
Tera Type: &
EVs: 220 HP / 136 Atk / 4 Def / 96 SpD / 52 Spe
Careful Nature
- Power Whip
- Knock Off
- Leech Seed
- Curse
";
$g8702 = "Blacephalon @ Eject Pack
Ability: Beast Boost
Tera Type: &
EVs: 32 Def / 236 SpA / 240 Spe
Timid Nature
- Overheat
- Recycle
- Hypnosis
- Protect
";
$g8711 = "Polteageist @ Eject Pack
Ability: Cursed Body
Tera Type: &
EVs: 24 Def / 248 SpA / 4 SpD / 232 Spe
Timid Nature
- Shadow Ball
- Giga Drain
- Protect
- Shell Smash
";
$g8720 = "Espeon @ Starf Berry
Ability: Magic Bounce
Tera Type: &
EVs: 16 HP / 100 Def / 168 SpA / 68 SpD / 156 Spe
Modest Nature
- Psyshock
- Shadow Ball
- Substitute
- Morning Sun
";
$g8729 = "Suicune @ Starf Berry
Ability: Pressure
Tera Type: &
EVs: 204 HP / 76 SpA / 228 Spe
Modest Nature
- Scald
- Rest
- Calm Mind
- Aqua Ring
";
$g8738 = "Corviknight @ Life Orb
Ability: Pressure
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Modest Nature
- Nasty Plot
- Flash Cannon
- Hurricane
- Hyper Beam
";
$g8747 = "Altaria @ Leftovers
Ability: Cloud Nine
Tera Type: &
EVs: 220 HP / 252 Def / 8 SpD / 28 Spe
Bold Nature
- Fire Spin
- Perish Song
- Defog
- Roost
";
$g8756 = "Altaria @ Heavy-Duty Boots
Ability: Natural Cure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Fire Spin
- Rest
- Perish Song
";
$g8765 = "Altaria @ Heavy-Duty Boots
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD
Bold Nature
- Fire Spin
- Perish Song
- Cotton Guard
- Roost
";
$g8774 = "Regigigas @ Leftovers
Ability: Slow Start
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Mega Kick
- Toxic
- Substitute
- Protect
";
$g8783 = "Regigigas @ Liechi Berry
Ability: Slow Start
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Crush Grip
- Psych Up
- Substitute
- Protect
";
$g8793 = "Regigigas @ Kee Berry
Ability: Slow Start
Tera Type: &
EVs: 176 HP / 148 Def / 184 SpD
Impish Nature
- Body Press
- Rest
- Facade
- Heat Crash
";
$g8802 = "Regigigas @ Leftovers
Ability: Slow Start
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Facade
- Crush Grip
- Heat Crash
- Protect
";
$g8812 = "Regigigas @ Choice Scarf
Ability: Slow Start
Tera Type: &
EVs: 224 Atk / 32 Def / 252 Spe
Jolly Nature
- Body Slam
- Body Press
- Drain Punch
- Knock Off
";
$g8821 = "Regigigas @ Life Orb
Ability: Slow Start
Tera Type: &
EVs: 252 HP / 20 Atk / 40 SpD / 196 Spe
Adamant Nature
- Mega Punch
- Stone Edge
- Fire Punch
- Protect
";
$g8830 = "Eldegoss @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Rapid Spin
- Cotton Guard
- Leaf Tornado
- Rest
";
$g8839 = "Sliggoo @ Eviolite
Ability: Hydration
Tera Type: &
EVs: 228 HP / 12 Atk / 16 Def / 252 SpD
Careful Nature
- Outrage
- Rain Dance
- Curse
- Rest
";
$g8848 = "Whiscash @ Air Balloon
Ability: Hydration
Tera Type: &
EVs: 188 HP / 68 Def / 252 SpA
Modest Nature
- Weather Ball
- Earth Power
- Rest
- Rain Dance
";
$g8857 = "Lapras @ Kee Berry
Ability: Hydration
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Ice Beam
- Body Press
- Rest
- Rain Dance
";
$g8866 = "Vaporeon @ Mystic Water
Ability: Hydration
Tera Type: &
EVs: 84 HP / 248 Def / 100 SpA / 76 Spe
Bold Nature
- Scald
- Acid Armor
- Rest
- Rain Dance
";
$g8875 = "Vaporeon @ Leftovers
Ability: Hydration
Tera Type: &
EVs: 84 HP / 244 Atk / 72 Def / 108 SpD
Careful Nature
- Last Resort
- Curse
- Rest
- Rain Dance
";
$g8884 = "Tangrowth @ Rocky Helmet
Ability: Regenerator
Tera Type: &
EVs: 228 HP / 80 Atk / 64 Def / 136 SpD
Impish Nature
- Seed Bomb
- Earthquake
- Pain Split
- Rage Powder
";
$g8893 = "Lapras @ Rocky Helmet
Ability: Hydration
Tera Type: &
EVs: 124 HP / 236 Def / 32 SpA / 116 SpD
Sassy Nature
- Hydro Pump
- Toxic
- Rest
- Rain Dance
";
$g8902 = "Mamoswine @ Choice Band
Ability: Thick Fat
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Horsepower
- Icicle Crash
- Knock Off
- Ice Shard
";
$g8911 = "Sawk @ Life Orb
Ability: Mold Breaker
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Close Combat
- Knock Off
- Poison Jab
- Dig
";
$g8920 = "Bisharp @ Life Orb
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Knock Off
- Iron Head
- Sucker Punch
- Protect
";
$g8929 = "Celebi @ Life Orb
Ability: Natural Cure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Giga Drain
- Psychic
- Earth Power
- Nasty Plot
";
$g8938 = "Nidoking @ Wide Lens
Ability: Sheer Force
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Earth Power
- Sludge Bomb
- Ice Beam
- Focus Energy
";
$g8947 = "Gigalith @ Air Balloon
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 24 Atk / 132 Def / 32 SpD / 68 Spe
Impish Nature
- Body Press
- Iron Defense
- Stealth Rock
- Bulldoze
";
$g8956 = "Gigalith @ Air Balloon
Ability: Sand Stream
Tera Type: &
EVs: 112 HP / 244 Atk / 24 Def / 128 SpD
Adamant Nature
- Stone Edge
- Earthquake
- Stealth Rock
- Protect
";
$g8965 = "Heatran @ Eject Pack
Ability: Flame Body
Tera Type: &
EVs: 252 SpA / 8 SpD / 248 Spe
Modest Nature
- Flamethrower
- Earth Power
- Overheat
- Stealth Rock
";
$g8974 = "Hitmontop @ Eject Pack
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 144 Atk / 92 SpD / 24 Spe
Careful Nature
- Close Combat
- Sucker Punch
- Rapid Spin
- Protect
";
$g8983 = "Kabutops @ Heavy-Duty Boots
Ability: Swift Swim
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Stone Edge
- Aqua Tail
- Rapid Spin
- Flip Turn
";
$g8992 = "Hitmontop @ Chesto Berry
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Close Combat
- Triple Axel
- Rest
- Rapid Spin
";
$g9001 = "Hitmonchan @ Life Orb
Ability: Iron Fist
Tera Type: &
EVs: 20 HP / 252 Atk / 92 Def / 144 Spe
Adamant Nature
- Drain Punch
- Thunder Punch
- Rapid Spin
- Bulk Up
";
$g9010 = "Weezing-Galar @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Strange Steam
- Will-O-Wisp
- Corrosive Gas
- Defog
";
$g9019 = "Mew @ Adrenaline Orb
Ability: Synchronize
Tera Type: &
EVs: 192 HP / 252 SpA / 64 Spe
Modest Nature
- Ice Beam
- Thunderbolt
- Flamethrower
- Nasty Plot
";
$g9028 = "Dubwool @ Adrenaline Orb
Ability: Bulletproof
Tera Type: &
EVs: 188 HP / 68 Def / 252 Spe
Impish Nature
- Body Press
- Copycat
- Rest
- Cotton Guard
";
$g9037 = "Ninetales @ Adrenaline Orb
Ability: Drought
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Fire Blast
- Solar Beam
- Substitute
- Nasty Plot
";
$g9046 = "Snorlax @ Sitrus Berry
Ability: Immunity
Tera Type: &
EVs: 168 HP / 80 Atk / 252 Def / 4 SpD / 4 Spe
Impish Nature
- Body Press
- Gunk Shot
- Crunch
- Stockpile
";
$g9055 = "Munchlax @ Custap Berry
Ability: Gluttony
Tera Type: &
EVs: 76 HP / 212 Atk / 220 Def
Adamant Nature
- Double-Edge
- Earthquake
- Self-Destruct
- Belly Drum
";
$g9064 = "Aromatisse @ Sitrus Berry
Ability: Aroma Veil
Tera Type: &
EVs: 244 HP / 152 Def / 112 SpA
Modest Nature
- Moonblast
- Encore
- Protect
- Trick Room
";
$g9073 = "Keldeo @ Choice Scarf
Ability: Justified
Tera Type: &
EVs: 36 HP / 252 SpA / 220 Spe
Modest Nature
- Hydro Pump
- Focus Blast
- Secret Sword
- Flip Turn
";
$g9082 = "Garchomp @ Assault Vest
Ability: Rough Skin
Tera Type: &
EVs: 240 HP / 104 Atk / 40 Def / 124 SpD
Adamant Nature
- Outrage
- Earthquake
- Poison Jab
- Flamethrower
";
$g9091 = "Togekiss @ Mental Herb
Ability: Serene Grace
Tera Type: &
EVs: 248 HP / 16 Def / 56 SpA / 180 SpD / 8 Spe
Calm Nature
- Thunder Wave
- Air Slash
- Encore
- Roost
";
$g9100 = "Hydreigon @ Haban Berry
Ability: Levitate
Tera Type: &
EVs: 252 HP / 40 SpA / 128 SpD / 88 Spe
Timid Nature
- Draco Meteor
- Dark Pulse
- Nasty Plot
- Taunt
";
$g9109 = "Krookodile @ Wide Lens
Ability: Moxie
Tera Type: &
EVs: 148 HP / 104 Atk / 4 SpD / 252 Spe
Jolly Nature
- High Horsepower
- Knock Off
- Low Kick
- Focus Energy
";
$g9118 = "Slowbro-Galar @ Weakness Policy
Ability: Quick Draw
Tera Type: &
EVs: 156 HP / 216 Def / 136 SpA
Relaxed Nature
- Shell Side
- Flamethrower
- Yawn
- Endure
";
$g9127 = "Munchlax @ Eviolite
Ability: Thick Fat
Tera Type: &
EVs: 16 HP / 224 Atk / 188 Def / 80 SpD
Adamant Nature
- Gunk Shot
- Earthquake
- Encore
- Counter
";
$g9136 = "Zapdos-Galar @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 24 HP / 220 Atk / 12 SpD / 252 Spe
Jolly Nature
- Thunderous Kick
- Brave Bird
- Low Sweep
- U-turn
";
$g9145 = "Gardevoir @ Leftovers
Ability: Trace
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Moonblast
- Encore
- Disable
- Protect
";
$g9154 = "Lucario @ Weakness Policy
Ability: Steadfast
Tera Type: &
EVs: 72 HP / 252 Atk / 4 SpD / 180 Spe
Adamant Nature
- Extreme Speed
- Close Combat
- Endure
- Swords Dance
";
$g9163 = "Persian @ Sitrus Berry
Ability: Technician
Tera Type: &
EVs: 244 HP / 120 Atk / 68 Def / 76 Spe
Jolly Nature
- Covet
- Sing
- Protect
- Hone Claws
";
$g9172 = "Golduck @ Wacan Berry
Ability: Damp
Tera Type: &
EVs: 184 HP / 20 Atk / 52 SpD / 252 Spe
Jolly Nature
- Aqua Tail
- Zen Headbutt
- Hypnosis
- Hone Claws
";
$g9181 = "Golduck @ Sitrus Berry
Ability: Swift Swim
Tera Type: &
EVs: 188 HP / 252 Atk / 4 SpD / 64 Spe
Adamant Nature
- Waterfall
- Low Kick
- Encore
- Rain Dance
";
$g9190 = "Rotom-Wash @ Wacan Berry
Ability: Levitate
Tera Type: &
EVs: 104 HP / 148 Def / 100 SpA / 56 SpD / 100 Spe
Bold Nature
- Volt Switch
- Hydro Pump
- Trick
- Pain Split
";
$g9199 = "Cresselia @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 144 HP / 112 SpA / 252 Spe
Timid Nature
- Psychic
- Moonblast
- Moonlight
- Calm Mind
";
$g9208 = "Cresselia @ Choice Band
Ability: Levitate
Tera Type: &
EVs: 20 HP / 236 Atk / 252 SpD
Careful Nature
- Zen Headbutt
- Toxic
- Trick
- Moonlight
";
$g9217 = "Cresselia @ Assault Vest
Ability: Levitate
Tera Type: &
EVs: 252 HP / 56 SpA / 200 SpD
Calm Nature
- Psyshock
- Moonblast
- Ice Beam
- Charge Beam
";
$g9226 = "Cresselia @ Light Clay
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Toxic
- Moonlight
- Reflect
- Light Screen
";
$g9235 = "Zeraora @ Shuca Berry
Ability: Volt Absorb
Tera Type: &
EVs: 72 HP / 252 SpA / 8 SpD / 176 Spe
Quiet Nature
- Thunderbolt
- Aura Sphere
- Grass Knot
- Knock Off
";
$g9244 = "Celesteela @ Weakness Policy
Ability: Beast Boost
Tera Type: &
EVs: 204 HP / 16 Atk / 104 SpD / 184 Spe
Careful Nature
- Heavy Slam
- Double-Edge
- Earthquake
- Autotomize
";
$g9253 = "Pelipper @ Leftovers
Ability: Drizzle
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe
Timid Nature
- Scald
- Defog
- Aqua Ring
- Stockpile
";
$g9262 = "Rillaboom @ Liechi Berry
Ability: Overgrow
Tera Type: &
EVs: 132 HP / 252 Atk / 124 Spe
Adamant Nature
- Wood Hammer
- Grassy Glide
- Grassy Terrain
- Substitute
";
$g9271 = "Cradily @ Assault Vest
Ability: Suction Cups
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Sludge Bomb
- Infestation
- Giga Drain
- Mirror Coat
";
$g9280 = "Raikou @ Assault Vest
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Volt Switch
- Aura Sphere
- Shadow Ball
";
$g9289 = "Roserade @ Micle Berry
Ability: Natural Cure
Shiny: Yes
Tera Type: &
EVs: 192 Def / 64 SpA / 252 Spe
Timid Nature
- Leaf Storm
- Extrasensory
- Sleep Powder
- Substitute
";
$g9299 = "Comfey @ Kebia Berry
Ability: Triage
Tera Type: &
EVs: 252 HP / 140 Def / 116 SpA
Modest Nature
- Draining Kiss
- Stored Power
- Growth
- Sunny Day
";
$g9308 = "Duraludon @ Shuca Berry
Ability: Stalwart
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Timid Nature
- Draco Meteor
- Flash Cannon
- Stealth Rock
- Steel Beam
";
$g9317 = "Duraludon @ Chople Berry
Ability: Stalwart
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Timid Nature
- Draco Meteor
- Flash Cannon
- Stealth Rock
- Steel Beam
";
$g9326 = "Zygarde @ Leftovers
Ability: Aura Break
Tera Type: &
EVs: 252 HP / 60 Def / 196 Spe
Impish Nature
- Spite
- Thousand Waves
- Haze
- Glare
";
$g9335 = "Scrafty @ Leftovers
Ability: Shed Skin
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Beat Up
- Spite
- Rest
- Iron Defense
";
$g9345 = "Scrafty @ Life Orb
Ability: Moxie
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Poison Jab
- Close Combat
- Beat Up
- Dragon Dance
";
$g9354 = "Charizard @ Life Orb
Ability: Solar Power
Tera Type: &
EVs: 100 HP / 252 SpA / 156 Spe
Modest Nature
- Blast Burn
- Mud-Slap
- Solar Beam
- Sunny Day
";
$g9363 = "Weavile @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Icicle Crash
- Knock Off
- Ice Shard
- Protect
";
$g9372 = "Barraskewda @ Life Orb
Ability: Swift Swim
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Liquidation
- Close Combat
- Ice Fang
- Flip Turn
";
$g9381 = "Stonjourner @ Red Card
Ability: Power Spot
Tera Type: &
EVs: 156 HP / 44 Atk / 240 SpD / 68 Spe
Careful Nature
- Stone Edge
- Heat Crash
- Stealth Rock
- Protect
";
$g9390 = "Celebi @ Choice Scarf
Ability: Natural Cure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Giga Drain
- Aura Sphere
- Trick
- Nasty Plot
";
$g9399 = "Kingdra @ Red Card
Ability: Sniper
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naughty Nature
- Waterfall
- Draco Meteor
- Iron Head
- Dragon Dance
";
$g9408 = "Flygon @ Liechi Berry
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Earthquake
- Flail
- Substitute
- Dragon Dance
";
$g9417 = "Flygon @ Life Orb
Ability: Levitate
Tera Type: &
EVs: 136 HP / 120 Atk / 32 Def / 4 SpD / 216 Spe
Jolly Nature
- Earthquake
- First Impression
- Defog
- Roost
";
$g9426 = "Darmanitan @ Flame Orb
Ability: Zen Mode
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Fling
- Burning Jealousy
- Will-O-Wisp
- Substitute
";
$g9435 = "Darmanitan @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flare Blitz
- Fire Punch
- U-turn
- Protect
";
$g9444 = "Slowbro @ Life Orb
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Quiet Nature
- Scald
- Psychic
- Fire Blast
- Earthquake
";
$g9453 = "Archeops @ Sharp Beak
Ability: Defeatist
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Sky Attack
- Stealth Rock
- Aqua Tail
";
$g9463 = "Flygon @ Life Orb
Ability: Levitate
Tera Type: &
EVs: 88 Atk / 168 SpA / 252 Spe
Naive Nature
- Earthquake
- Draco Meteor
- Fire Blast
- Defog
";
$g9472 = "Primarina @ Expert Belt
Ability: Torrent
Tera Type: &
EVs: 228 HP / 88 Def / 188 SpA / 4 SpD
Modest Nature
- Calm Mind
- Hydro Pump
- Energy Ball
- Psychic
";
$g9481 = "Throh @ Leftovers
Ability: Mold Breaker
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Pain Split
- Circle Throw
- Toxic
- Mat Block
";
$g9490 = "Arcanine @ Heavy-Duty Boots
Ability: Intimidate
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 96 Def / 156 Spe
Adamant Nature
- Extreme Speed
- Will-O-Wisp
- Morning Sun
- Teleport
";
$g9500 = "Dragonite @ Life Orb
Ability: Multiscale
Tera Type: &
EVs: 204 HP / 80 Atk / 16 Def / 208 SpA
Brave Nature
- Mimic
- Draco Meteor
- Roost
- Dragon Dance
";
$g9509 = "Dragonite @ Bright Powder
Ability: Multiscale
Tera Type: &
EVs: 116 HP / 192 Atk / 200 SpD
Careful Nature
- Dual Wingbeat
- Reflect
- Roost
- Dragon Dance
";
$g9518 = "Dragalge @ Leftovers
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Sludge Bomb
- Focus Blast
- Rest
- Acid Armor
";
$g9527 = "Landorus-Therian @ Chesto Berry
Ability: Intimidate
Tera Type: &
EVs: 28 HP / 60 Atk / 168 SpD / 252 Spe
Jolly Nature
- Earthquake
- Knock Off
- Rest
- U-turn
";
$g9536 = "Venusaur @ Black Sludge
Ability: Overgrow
Tera Type: &
EVs: 252 HP / 184 Def / 12 SpD / 60 Spe
Bold Nature
- Earth Power
- Leech Seed
- Block
- Protect
";
$g9545 = "Sigilyph @ Focus Sash
Ability: Magic Guard
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Air Slash
- Roost
- Defog
- Calm Mind
";
$g9554 = "Rotom @ Adrenaline Orb
Ability: Levitate
Tera Type: &
EVs: 144 HP / 8 Def / 184 SpA / 172 Spe
Timid Nature
- Hex
- Will-O-Wisp
- Defog
- Pain Split
";
$g9563 = "Salamence @ Charti Berry
Ability: Intimidate
Tera Type: &
EVs: 228 HP / 216 Atk / 28 Def / 36 Spe
Adamant Nature
- Dual Wingbeat
- Brick Break
- Defog
- Dragon Dance
";
$g9572 = "Tyranitar @ Lum Berry
Ability: Sand Stream
Tera Type: &
EVs: 96 HP / 156 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Crunch
- High Horsepower
- Dragon Dance
";
$g9581 = "Tyranitar @ Weakness Policy
Ability: Sand Stream
Tera Type: &
EVs: 96 HP / 252 Atk / 160 Spe
Adamant Nature
- Stone Edge
- Crunch
- Thunder Punch
- Dragon Dance
";
$g9590 = "Hitmonlee @ Wide Lens
Ability: Limber
Tera Type: &
EVs: 56 HP / 212 Atk / 240 Spe
Adamant Nature
- Superpower
- Knock Off
- Rapid Spin
- Focus Energy
";
$g9599 = "Corviknight @ Snowball
Ability: Pressure
Tera Type: &
EVs: 248 HP / 104 Atk / 84 Def / 72 Spe
Impish Nature
- Brave Bird
- Defog
- Roost
- Protect
";
$g9608 = "Kyurem @ Eject Pack
Ability: Pressure
Tera Type: &
EVs: 72 HP / 100 Def / 40 SpA / 100 SpD / 196 Spe
Modest Nature
- Draco Meteor
- Ice Beam
- Earth Power
- Roost
";
$g9617 = "Dracozolt @ Eject Pack
Ability: Hustle
Tera Type: &
EVs: 208 Atk / 48 SpA / 252 Spe
Naive Nature
- Bolt Beak
- High Horsepower
- Draco Meteor
- Fire Blast
";
$g9626 = "Tapu Fini @ Sticky Barb
Ability: Misty Surge
Tera Type: &
EVs: 248 HP / 92 Def / 68 SpA / 8 SpD / 92 Spe
Relaxed Nature
- Scald
- Natures Madness
- Defog
- Trick
";
$g9635 = "Latias @ Coba Berry
Ability: Levitate
Tera Type: &
EVs: 92 HP / 160 SpA / 4 SpD / 252 Spe
Timid Nature
- Ice Beam
- Thunderbolt
- Roost
- Reflect Type
";
$g9644 = "Moltres @ Power Herb
Ability: Pressure
Tera Type: &
EVs: 248 HP / 72 Def / 20 SpA / 8 SpD / 160 Spe
Modest Nature
- Fire Blast
- Solar Beam
- Defog
- Roost
";
$g9653 = "Armaldo @ Heavy-Duty Boots
Ability: Battle Armor
Tera Type: &
EVs: 80 HP / 168 Atk / 36 SpD / 224 Spe
Adamant Nature
- Rock Blast
- Knock Off
- Rapid Spin
- Swords Dance
";
$g9662 = "Spectrier @ Kee Berry
Ability: Grim Neigh
Tera Type: &
EVs: 92 HP / 172 Def / 56 SpA / 188 Spe
Modest Nature
- Shadow Ball
- Will-O-Wisp
- Rest
- Calm Mind
";
$g9671 = "Jirachi @ Snowball
Ability: Serene Grace
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Iron Head
- Zen Headbutt
- Stealth Rock
- Protect
";
$g9680 = "Lickilicky @ Chople Berry
Ability: Cloud Nine
Tera Type: &
EVs: 248 HP / 32 Atk / 180 Def / 48 SpD
Careful Nature
- Body Press
- Dragon Tail
- Counter
- Protect
";
$g9689 = "Jirachi @ Mago Berry
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 224 SpD / 32 Spe
Calm Nature
- Steel Beam
- Toxic
- Encore
- Substitute
";
$g9698 = "Silvally-Rock @ Rock Memory
Ability: RKS System
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naive Nature
- Multi-Attack
- Ice Beam
- Flame Charge
- Swords Dance
";
$g9707 = "Dragonite @ Custap Berry
Ability: Multiscale
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Draco Meteor
- Fire Blast
- Defog
- Roost
";
$g9716 = "Centiskorch @ Heavy-Duty Boots
Ability: Flash Fire
Tera Type: &
EVs: 180 HP / 76 Atk / 252 Spe
Jolly Nature
- Fire Lash
- Fire Spin
- Smokescreen
- Substitute
";
$g9725 = "Milcery @ Flame Orb
Ability: Sweet Veil
Tera Type: &
EVs: 228 HP / 252 Def / 28 SpA
Bold Nature
- Fling
- Draining Kiss
- Aromatherapy
- Rest
";
$g9734 = "Cinderace @ Luminous Moss
Ability: Blaze
Tera Type: &
EVs: 28 HP / 252 Atk / 228 SpD
Adamant Nature
- Pyro Ball
- Low Kick
- Sucker Punch
- Bulk Up
";
$g9743 = "Amoonguss @ Maranga Berry
Ability: Effect Spore
Tera Type: &
EVs: 168 HP / 100 Def / 240 SpD
Calm Nature
- Toxic
- Spore
- Synthesis
- Defense Curl
";
$g9752 = "Honedge @ Eviolite
Ability: No Guard
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Destiny Bond
- Shadow Sneak
- Solar Blade
- Toxic
";
$g9761 = "Skuntank @ Blunder Policy
Ability: Aftermath
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Dark Pulse
- Smog
- Defog
- Nasty Plot
";
$g9770 = "Honedge @ Custap Berry
Ability: No Guard
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Iron Head
- Close Combat
- Endure
- Swords Dance
";
$g9779 = "Lycanroc-Midnight @ Blunder Policy
Ability: No Guard
Tera Type: &
EVs: 196 HP / 240 Atk / 16 SpD / 56 Spe
Jolly Nature
- Stone Edge
- Close Combat
- Mega Kick
- Stealth Rock
";
$g9788 = "Aegislash @ Custap Berry
Ability: Stance Change
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Iron Head
- Close Combat
- Endure
- Swords Dance
";
$g9797 = "Crustle @ Power Herb
Ability: Sturdy
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Stone Edge
- X-Scissor
- Solar Blade
- Shell Smash
";
$g9806 = "Grapploct @ Leftovers
Ability: Technician
Tera Type: &
EVs: 252 HP / 212 Atk / 44 Def
Impish Nature
- Drain Punch
- Dive
- Octolock
- Protect
";
$g9815 = "Dunsparce @ Liechi Berry
Ability: Serene Grace
Tera Type: &
EVs: 68 HP / 184 Atk / 4 Def / 252 Spe
Jolly Nature
- Headbutt
- Pain Split
- Glare
- Substitute
";
$g9824 = "Entei @ Choice Specs
Ability: Pressure
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Eruption
- Sacred Fire
- Solar Beam
- Iron Head
";
$g9833 = "Palossand @ Leftovers
Ability: Water Compaction
Tera Type: &
EVs: 240 HP / 68 Def / 16 SpA / 184 SpD
Bold Nature
- Earth Power
- Hypnosis
- Shore Up
- Gravity
";
$g9842 = "Exeggcute @ Eviolite
Ability: Chlorophyll
Tera Type: &
EVs: 248 HP / 4 SpA / 164 SpD / 92 Spe
Modest Nature
- Giga Drain
- Sludge Bomb
- Sleep Powder
- Gravity
";
$g9851 = "Scolipede @ Liechi Berry
Ability: Swarm
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Megahorn
- Poison Jab
- Dig
- Substitute
";
$g9860 = "Zapdos @ Kings Rock
Ability: Pressure
Tera Type: &
EVs: 116 HP / 164 SpA / 228 Spe
Timid Nature
- Discharge
- Hurricane
- Heat Wave
- Roost
";
$g9869 = "Diancie @ Kings Rock
Ability: Clear Body
Tera Type: &
EVs: 196 Atk / 60 Def / 252 Spe
Jolly Nature
- Diamond Storm
- Body Press
- Stealth Rock
- Rock Polish
";
$g9878 = "Naganadel @ Kings Rock
Ability: Beast Boost
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Draco Meteor
- Sludge Wave
- Heat Wave
- Nasty Plot
";
$g9887 = "Primarina @ Kings Rock
Ability: Liquid Voice
Tera Type: &
EVs: 212 HP / 44 SpA / 252 Spe
Timid Nature
- Dazzling Gleam
- Hyper Voice
- Icy Wind
- Calm Mind
";
$g9896 = "Keldeo @ Kings Rock
Ability: Justified
Tera Type: &
EVs: 192 Def / 60 SpA / 4 SpD / 252 Spe
Timid Nature
- Scald
- Secret Sword
- Muddy Water
- Calm Mind
";
$g9905 = "Bisharp @ Custap Berry
Ability: Defiant
Tera Type: &
EVs: 112 HP / 252 Atk / 16 Def / 4 SpD / 124 Spe
Adamant Nature
- Iron Head
- Knock Off
- Endure
- Swords Dance
";
$g9914 = "Lopunny @ Toxic Orb
Ability: Cute Charm
Tera Type: &
EVs: 85 HP / 85 Atk / 85 Def / 85 SpA / 85 SpD / 85 Spe
Jolly Nature
- Healing Wish
- Switcheroo
- Facade
- Close Combat
";
$g9923 = "Regidrago @ Kings Rock
Ability: Dragons Maw
Tera Type: &
EVs: 100 Atk / 4 SpA / 152 SpD / 252 Spe
Lonely Nature
- Draco Meteor
- Breaking Swipe
- Dragon Energy
- Dragon Dance
";
$g9932 = "Indeedee @ Kings Rock
Ability: Psychic Surge
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Expanding Force
- Mystical Fire
- Psych Up
- Protect
";
$g9941 = "Tapu Bulu @ Grassy Seed
Ability: Grassy Surge
Tera Type: &
EVs: 80 HP / 128 Atk / 52 Def / 8 SpA / 240 Spe
Bashful Nature
- Horn Leech
- Stored Power
- Calm Mind
- Swords Dance
";
$g9950 = "Zygarde @ Maranga Berry
Ability: Aura Break
Tera Type: &
EVs: 152 HP / 196 Atk / 56 Def / 104 SpD
Adamant Nature
- Extreme Speed
- Thousand Waves
- Rest
- Coil
";
$g9959 = "Milotic @ Leftovers
Ability: Competitive
Tera Type: &
EVs: 52 HP / 252 Def / 176 SpA / 4 SpD / 24 Spe
Bold Nature
- Scald
- Mimic
- Recover
- Aqua Ring
";
$g9968 = "Dracozolt @ Leftovers
Ability: Hustle
Tera Type: &
EVs: 252 HP / 48 Atk / 4 SpD / 204 Spe
Adamant Nature
- Bolt Beak
- High Horsepower
- Facade
- Protect
";
$g9977 = "Spiritomb @ Weakness Policy
Ability: Pressure
Tera Type: &
EVs: 196 HP / 40 Atk / 88 Def / 136 SpA / 44 SpD / 4 Spe
Bold Nature
- Hex
- Will-O-Wisp
- Pain Split
- Calm Mind
";
$g9986 = "Porygon2 @ Metronome
Ability: Download
Tera Type: &
EVs: 116 HP / 172 SpA / 220 SpD
Calm Nature
- Tri Attack
- Thunder Wave
- Pain Split
- Substitute
";
$g9995 = "Porygon2 @ Eviolite
Ability: Download
Tera Type: &
EVs: 116 HP / 172 SpA / 220 SpD
Calm Nature
- Tri Attack
- Thunder Wave
- Pain Split
- Substitute
";
$g10004 = "Haxorus @ Weakness Policy
Ability: Mold Breaker
Tera Type: &
EVs: 88 HP / 32 Atk / 244 SpD / 144 Spe
Adamant Nature
- Dragon Claw
- Close Combat
- Poison Jab
- Dragon Dance
";
$g10013 = "Dragonite @ Kings Rock
Ability: Multiscale
Tera Type: &
EVs: 192 HP / 140 Atk / 80 SpA / 44 SpD / 52 Spe
Hasty Nature
- Dual Wingbeat
- Scale Shot
- Heat Wave
- Roost
";
$g10022 = "Volcanion @ Weakness Policy
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Fire Blast
- Steam Eruption
- Defog
- Protect
";
$g10031 = "Gastrodon @ Kee Berry
Ability: Sticky Hold
Tera Type: &
EVs: 128 HP / 252 Def / 100 SpA / 28 Spe
Bold Nature
- Muddy Water
- Sand Tomb
- Recover
- Amnesia
";
$g10040 = "Sylveon @ Eject Pack
Ability: Cute Charm
Tera Type: &
EVs: 252 HP / 200 Def / 56 SpD
Calm Nature
- Moonblast
- Curse
- Wish
- Protect
";
$g10049 = "Gengar @ Blunder Policy
Ability: Cursed Body
Tera Type: &
EVs: 136 HP / 252 SpA / 4 SpD / 116 Spe
Modest Nature
- Hex
- Sludge Bomb
- Hypnosis
- Nasty Plot
";
$g10058 = "Torkoal @ Assault Vest
Ability: Drought
Tera Type: &
EVs: 252 HP / 36 SpA / 220 SpD
Calm Nature
- Fire Blast
- Solar Beam
- Scorching Sands
- Clear Smog
";
$g10067 = "Hitmontop @ Psychic Seed
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Close Combat
- Triple Axel
- Thief
- Rapid Spin
";
$g10076 = "Hydreigon @ Scope Lens
Ability: Levitate
Tera Type: &
EVs: 8 HP / 32 Atk / 220 SpA / 248 Spe
Modest Nature
- Draco Meteor
- Dark Pulse
- Scale Shot
- Focus Energy
";
$g10085 = "Mew @ Kee Berry
Ability: Synchronize
Tera Type: &
EVs: 212 HP / 44 Def / 24 SpA / 184 SpD / 44 Spe
Modest Nature
- Stored Power
- Scale Shot
- Soft-Boiled
- Cosmic Power
";
$g10094 = "Tapu Lele @ Psychic Seed
Ability: Psychic Surge
Tera Type: &
EVs: 28 HP / 252 Def / 36 SpA / 40 SpD / 152 Spe
Modest Nature
- Draining Kiss
- Fling
- Thief
- Iron Defense
";
$g10103 = "Tapu Fini @ Flame Orb
Ability: Telepathy
Tera Type: &
EVs: 204 HP / 76 Def / 220 SpD / 8 Spe
Timid Nature
- Scald
- Ice Beam
- Fling
- Protect
";
$g10112 = "Altaria @ Assault Vest
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 112 Atk / 112 SpA / 32 SpD
Gentle Nature
- Hurricane
- Draco Meteor
- Fire Blast
- Bulldoze
";
$g10121 = "Bouffalant @ Custap Berry
Ability: Reckless
Tera Type: &
EVs: 132 HP / 124 Atk / 252 SpA
Quiet Nature
- Head Charge
- Belch
- Taunt
- Swords Dance
";
$g10130 = "Salamence @ Scope Lens
Ability: Intimidate
Tera Type: &
EVs: 32 HP / 124 Atk / 12 Def / 124 SpA / 92 SpD / 124 Spe
Mild Nature
- Draco Meteor
- Dual Wingbeat
- Dragon Dance
- Focus Energy
";
$g10139 = "Azumarill @ Chilan Berry
Ability: Huge Power
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Play Rough
- Perish Song
- Substitute
- Protect
";
$g10148 = "Heliolisk @ Leftovers
Ability: Dry Skin
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Timid Nature
- Thunderbolt
- Breaking Swipe
- Grass Knot
- Protect
";
$g10157 = "Sylveon @ Chesto Berry
Ability: Pixilate
Tera Type: &
EVs: 228 HP / 252 Def / 28 SpA
Bold Nature
- Hyper Voice
- Endure
- Yawn
- Rest
";
$g10166 = "Corviknight @ Kee Berry
Ability: Pressure
Tera Type: &
EVs: 160 HP / 252 SpA / 96 Spe
Modest Nature
- Steel Beam
- Nasty Plot
- Roost
- Agility
";
$g10175 = "Porygon2 @ Power Herb
Ability: Download
Tera Type: &
EVs: 20 HP / 252 Atk / 236 SpA
Relaxed Nature
- Hyper Beam
- Skull Bash
- Recover
- Substitute
";
$g10184 = "Pinsir @ Leftovers
Ability: Hyper Cutter
Tera Type: &
EVs: 220 Atk / 72 SpD / 216 Spe
Jolly Nature
- Swords Dance
- Substitute
- Earthquake
- Rock Tomb
";
$g10193 = "Zapdos @ Choice Specs
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Thunderbolt
- Sleep Talk
-
-
";
$g10202 = "Nidoqueen @ Assault Vest
Ability: Poison Point
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA
Brave Nature
- Poison Jab
- Thunderbolt
- High Horsepower
- Beat Up
";
$g10211 = "Gardevoir @ Leftovers
Ability: Trace
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Moonblast
- Encore
- Disable
- Protect
";
$g10220 = "Magnezone @ Expert Belt
Ability: Sturdy
Tera Type: &
EVs: 220 HP / 4 Def / 252 SpA / 32 Spe
Modest Nature
- Thunderbolt
- Body Press
- Magnet Rise
- Iron Defense
";
$g10229 = "Eldegoss @ Yache Berry
Ability: Cotton Down
Tera Type: &
EVs: 232 HP / 48 Def / 228 Spe
Bold Nature
- Leech Seed
- Sleep Powder
- Cotton Guard
- Giga Drain
";
$g10238 = "Eldegoss @ Tanga Berry
Ability: Cotton Down
Tera Type: &
EVs: 184 HP / 48 Def / 8 SpA / 20 SpD / 248 Spe
Modest Nature
- Leech Seed
- Sleep Powder
- Sunny Day
- Weather Ball
";
$g10247 = "Celebi @ Heavy-Duty Boots
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 220 SpD / 36 Spe
Calm Nature
- Leaf Storm
- Stealth Rock
- Recover
- U-turn
";
$g10256 = "Articuno-Galar @ Colbur Berry
Ability: Competitive
Tera Type: &
EVs: 164 HP / 88 SpA / 4 SpD / 252 Spe
Timid Nature
- Dream Eater
- Hypnosis
- Substitute
- Calm Mind
";
$g10265 = "Ninetales @ Weakness Policy
Ability: Drought
Tera Type: &
EVs: 236 Def / 20 SpA / 252 Spe
Timid Nature
- Flamethrower
- Solar Beam
- Flame Charge
- Calm Mind
";
$g10274 = "Tapu Bulu @ Occa Berry
Ability: Grassy Surge
Shiny: Yes
Tera Type: &
EVs: 252 HP / 56 Atk / 116 SpD / 84 Spe
Adamant Nature
- Wood Hammer
- Rock Slide
- Swords Dance
- Protect
";
$g10284 = "Arctozolt @ Choice Specs
Ability: Volt Absorb
Tera Type: &
EVs: 188 HP / 252 SpA / 8 SpD / 60 Spe
Modest Nature
- Thunderbolt
- Freeze-Dry
- Hydro Pump
- Blizzard
";
$g10293 = "Archeops @ Leftovers
Ability: Defeatist
Tera Type: &
EVs: 64 Atk / 192 Def / 252 Spe
Jolly Nature
- Stone Edge
- Hone Claws
- Iron Defense
- Roost
";
$g10302 = "Clefable @ Focus Sash
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Fire Blast
- Thunder Wave
- Stealth Rock
- Soft-Boiled
";
$g10311 = "Jellicent @ Focus Sash
Ability: Cursed Body
Tera Type: &
EVs: 252 HP / 136 SpA / 120 Spe
Timid Nature
- Scald
- Night Shade
- Strength Sap
- Taunt
";
$g10320 = "Rotom-Fan @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 208 Def / 48 SpD
Bold Nature
- Foul Play
- Sucker Punch
- Thunder Wave
- Pain Split
";
$g10329 = "Lucario @ Normal Gem
Ability: Justified
Tera Type: &
EVs: 16 HP / 156 Atk / 84 SpD / 252 Spe
Adamant Nature
- Close Combat
- Extreme Speed
- Roar
- Swords Dance
";
$g10338 = "Riolu @ Custap Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Substitute
- Dig
- Copycat
- Endure
";
$g10347 = "Volcanion @ Assault Vest
Ability: Water Absorb
Tera Type: &
EVs: 232 HP / 56 SpA / 220 SpD
Modest Nature
- Overheat
- Steam Eruption
- Sludge Bomb
- Fire Spin
";
$g10356 = "Zapdos-Galar @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 24 HP / 220 Atk / 12 SpD / 252 Spe
Jolly Nature
- Thunderous Kick
- Brave Bird
- Low Sweep
- Counter
";
$g10365 = "Azumarill @ Custap Berry
Ability: Huge Power
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Lonely Nature
- Play Rough
- Superpower
- Endure
- Belly Drum
";
$g10374 = "Riolu @ Salac Berry
Ability: Prankster
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Dig
- Copycat
- Endure
";
$g10383 = "Incineroar @ Choice Band
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- U-turn
- Iron Head
- Earthquake
- Knock Off
";
$g10392 = "Gigalith @ Assault Vest
Ability: Sand Stream
Tera Type: &
EVs: 128 HP / 92 Atk / 252 SpD / 36 Spe
Careful Nature
- Stone Edge
- Heavy Slam
- Earthquake
- Sand Tomb
";
$g10401 = "Tauros @ Choice Scarf
Ability: Sheer Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Body Slam
- Close Combat
- Iron Tail
- Throat Chop
";
$g10410 = "Squirtle @ Eviolite
Ability: Torrent
Shiny: Yes
Tera Type: &
EVs: 252 HP / 224 Def / 20 SpA / 12 SpD
Relaxed Nature
- Muddy Water
- Yawn
- Rapid Spin
- Fake Out
";
$g10420 = "Dewpider @ Choice Band
Ability: Water Bubble
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Liquidation
- Leech Life
- Sticky Web
- Mirror Coat
";
$g10429 = "Bisharp @ Salac Berry
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Iron Head
- Knock Off
- Stealth Rock
- Substitute
";
$g10438 = "Zapdos-Galar @ Sitrus Berry
Ability: Defiant
Tera Type: &
EVs: 172 HP / 44 Atk / 36 Def / 4 SpD / 252 Spe
Jolly Nature
- Low Kick
- Dual Wingbeat
- Stomping Tantrum
- Bulk Up
";
$g10447 = "Glastrier @ Leftovers
Ability: Chilling Neigh
Tera Type: &
EVs: 252 HP / 16 Atk / 240 Spe
Jolly Nature
- Icicle Spear
- Body Press
- Substitute
- Iron Defense
";
$g10456 = "Escavalier @ Assault Vest
Ability: Shell Armor
Tera Type: &
EVs: 252 HP / 76 Def / 180 SpD
Relaxed Nature
- Megahorn
- Iron Head
- Razor Shell
- Metal Burst
";
$g10465 = "Silvally-Grass @ Grass Memory
Ability: RKS System
Shiny: Yes
Tera Type: &
EVs: 148 HP / 252 Def / 12 SpA / 96 Spe
Bold Nature
- Multi-Attack
- Heat Wave
- Iron Defense
- Rest
";
$g10475 = "Kingdra @ Leftovers
Ability: Swift Swim
Shiny: Yes
Tera Type: &
EVs: 72 HP / 112 Atk / 56 Def / 108 SpD / 160 Spe
Adamant Nature
- Breaking Swipe
- Disable
- Protect
- Dragon Dance
";
$g10485 = "Tornadus-Therian @ Chesto Berry
Ability: Regenerator
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Acrobatics
- Knock Off
- Rest
- Bulk Up
";
$g10494 = "Spiritomb @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 204 HP / 252 Atk / 52 SpD
Adamant Nature
- Shadow Sneak
- Pain Split
- Torment
- Protect
";
$g10503 = "Weezing @ Leftovers
Ability: Neutralizing Gas
Tera Type: &
EVs: 252 HP / 20 Def / 220 SpD / 16 Spe
Bold Nature
- Sludge Bomb
- Pain Split
- Torment
- Protect
";
$g10512 = "Gardevoir @ Wide Lens
Ability: Synchronize
Tera Type: &
EVs: 64 HP / 236 SpA / 208 Spe
Modest Nature
- Dream Eater
- Sing
- Torment
- Substitute
";
$g10521 = "Jolteon @ Wide Lens
Ability: Volt Absorb
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Thunder
- Sing
- Shadow Ball
- Charge Beam
";
$g10530 = "Chansey @ Eviolite
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 240 Def / 16 Spe
Impish Nature
- Counter
- Stealth Rock
- Wish
- Teleport
";
$g10539 = "Diancie @ Kee Berry
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 108 Def / 40 SpA / 108 SpD
Quiet Nature
- Diamond Storm
- Draining Kiss
- Body Press
- Calm Mind
";
$g10548 = "Heatran @ Power Herb
Ability: Flash Fire
Tera Type: &
EVs: 208 HP / 36 SpA / 12 SpD / 252 Spe
Timid Nature
- Fire Blast
- Solar Beam
- Toxic
- Stealth Rock
";
$g10557 = "Charizard @ Power Herb
Ability: Blaze
Tera Type: &
EVs: 244 Atk / 252 SpA / 12 Spe
Naive Nature
- Flamethrower
- Fly
- Solar Beam
- Substitute
";
$g10566 = "Talonflame @ Maranga Berry
Ability: Flame Body
Tera Type: &
EVs: 228 HP / 136 Def / 32 SpD / 112 Spe
Impish Nature
- Acrobatics
- Toxic
- Taunt
- Roost
";
$g10575 = "Magneton @ Choice Specs
Ability: Magnet Pull
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Flash Cannon
- Toxic
- Volt Switch
";
$g10584 = "Gastrodon @ Choice Specs
Ability: Storm Drain
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Hydro Pump
- Earth Power
- Muddy Water
- Clear Smog
";
$g10593 = "Scizor @ Kee Berry
Ability: Technician
Tera Type: &
EVs: 104 HP / 80 Atk / 56 Def / 16 SpD / 252 Spe
Jolly Nature
- Bullet Punch
- Swords Dance
- Sunny Day
- Morning Sun
";
$g10602 = "Darmanitan-Galar @ Choice Band
Ability: Gorilla Tactics
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- U-turn
- Sleep Talk
-
-
";
$g10611 = "Swoobat @ Salac Berry
Ability: Simple
Tera Type: &
EVs: 148 HP / 40 Def / 252 SpA / 68 Spe
Modest Nature
- Giga Drain
- Endeavor
- Substitute
- Nasty Plot
";
$g10620 = "Swoobat @ Starf Berry
Ability: Simple
Tera Type: &
EVs: 148 HP / 80 Def / 28 SpA / 252 Spe
Modest Nature
- Stored Power
- Giga Drain
- Substitute
- Nasty Plot
";
$g10629 = "Dragonite @ Starf Berry
Ability: Multiscale
Tera Type: &
EVs: 244 HP / 12 Atk / 252 SpD
Sassy Nature
- Dragon Claw
- Draco Meteor
- Substitute
- Roost
";
$g10638 = "Mawile @ Light Ball
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 52 Def / 52 SpD / 152 Spe
Impish Nature
- Play Rough
- Foul Play
- Pain Split
- Fling
";
$g10647 = "Cresselia @ Lum Berry
Ability: Levitate
Tera Type: &
EVs: 108 HP / 24 Def / 124 SpA / 252 Spe
Timid Nature
- Psychic
- Substitute
- Moonlight
- Calm Mind
";
$g10656 = "Electivire @ Lum Berry
Ability: Motor Drive
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Wild Charge
- Ice Punch
- Low Kick
- Volt Switch
";
$g10665 = "Zapdos-Galar @ Lum Berry
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Close Combat
- Dual Wingbeat
- U-turn
- Protect
";
$g10674 = "Latios @ Lum Berry
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 132 SpA / 124 Spe
Lonely Nature
- Zen Headbutt
- Draco Meteor
- Earthquake
- Dragon Dance
";
$g10683 = "Miltank @ Heavy-Duty Boots
Ability: Thick Fat
Tera Type: &
EVs: 84 HP / 132 Def / 252 SpD / 40 Spe
Careful Nature
- Body Press
- Toxic
- Milk Drink
- Heal Bell
";
$g10692 = "Clefable @ Focus Sash
Ability: Magic Guard
Tera Type: &
EVs: 228 Atk / 28 SpA / 252 Spe
Mild Nature
- Moonblast
- Dig
- Counter
- Work Up
";
$g10701 = "Alakazam @ Focus Sash
Ability: Magic Guard
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psybeam
- Confusion
- Disable
- Nasty Plot
";
$g10710 = "Porygon2 @ Eviolite
Ability: Download
Shiny: Yes
Tera Type: &
EVs: 252 HP / 128 Def / 92 SpA / 36 SpD
Modest Nature
- Shadow Ball
- Curse
- Recover
- Conversion
";
$g10720 = "Glastrier @ Weakness Policy
Ability: Chilling Neigh
Tera Type: &
EVs: 200 HP / 192 Atk / 52 Def / 64 SpD
Careful Nature
- Icicle Spear
- Close Combat
- Outrage
- High Horsepower
";
$g10729 = "Entei @ Eject Pack
Ability: Pressure
Tera Type: &
EVs: 72 HP / 12 Atk / 252 SpA / 120 SpD / 52 Spe
Modest Nature
- Sacred Fire
- Overheat
- Sunny Day
- Eruption
";
$g10738 = "Whimsicott @ Maranga Berry
Ability: Prankster
Tera Type: &
EVs: 188 HP / 252 Atk / 48 Def / 20 Spe
Adamant Nature
- Beat Up
- Leech Seed
- Cotton Guard
- Protect
";
$g10747 = "Arcanine @ Power Herb
Ability: Intimidate
Tera Type: &
EVs: 160 HP / 96 Atk / 252 Spe
Adamant Nature
- Flame Charge
- Solar Beam
- Skull Bash
- Sunny Day
";
$g10756 = "Garbodor @ Assault Vest
Ability: Stench
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Acid Spray
- Toxic
- Spikes
- Rest
";
$g10765 = "Sableye @ Choice Band
Ability: Keen Eye
Tera Type: &
EVs: 252 HP / 144 Atk / 112 Def
Adamant Nature
- Knock Off
- Recover
- Disable
- Trick
";
$g10774 = "Carbink @ Soft Sand
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 96 Def / 80 SpA / 64 SpD / 16 Spe
Nature
- Earth Power
- Toxic
- Magnet Rise
- Stealth Rock
";
$g10783 = "Spectrier @ Weakness Policy
Ability: Grim Neigh
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Modest Nature
- Shadow Ball
- Dark Pulse
- Agility
- Calm Mind
";
$g10792 = "Diancie @ Assault Vest
Ability: Clear Body
Tera Type: &
EVs: 240 HP / 100 Def / 100 SpA / 68 Spe
Lonely Nature
- Diamond Storm
- Moonblast
- Body Press
- Endeavor
";
$g10801 = "Sirfetch’d @ Aguav Berry
Ability: Scrappy
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Close Combat
- Brave Bird
- Poison Jab
- Substitute
";
$g10810 = "Butterfree @ Lum Berry
Ability: Tinted Lens
Shiny: Yes
Tera Type: &
EVs: 176 HP / 252 SpA / 80 Spe
Modest Nature
- Bug Buzz
- Hurricane
- Roost
- U-turn
";
$g10820 = "Genesect @ Life Orb
Ability: Download
Tera Type: &
EVs: 68 HP / 252 Atk / 188 SpD
Adamant Nature
- U-turn
- Shift Gear
-
-
";
$g10829 = "Kingdra @ Adrenaline Orb
Ability: Sniper
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Muddy Water
- Focus Energy
- Protect
";
$g10838 = "Bellossom @ Assault Vest
Ability: Chlorophyll
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Giga Drain
- Moonblast
- Sludge Bomb
- Infestation
";
$g10847 = "Aggron @ Kee Berry
Ability: Sturdy
Tera Type: &
EVs: 92 HP / 40 Atk / 252 Def / 80 SpD / 44 Spe
Impish Nature
- Stone Edge
- Body Press
- Stealth Rock
- Heavy Slam
";
$g10856 = "Cofagrigus @ Leftovers
Ability: Mummy
Tera Type: &
EVs: 252 HP / 108 Def / 12 SpA / 136 SpD
Quiet Nature
- Shadow Ball
- Spite
- Grudge
- Pain Split
";
$g10865 = "Dracozolt @ Rocky Helmet
Ability: Hustle
Tera Type: &
EVs: 100 Atk / 156 Def / 252 Spe
Naive Nature
- Bolt Beak
- Draco Meteor
- Earthquake
- Rest
";
$g10874 = "Azumarill @ Kee Berry
Ability: Sap Sipper
Tera Type: &
EVs: 252 HP / 188 Def / 68 SpA
Bold Nature
- Scald
- Seismic Toss
- Rest
- Amnesia
";
$g10883 = "Keldeo @ Chesto Berry
Ability: Justified
Tera Type: &
EVs: 24 HP / 184 Def / 48 SpA / 252 Spe
Timid Nature
- Scald
- Secret Sword
- Rest
- Calm Mind
";
$g10892 = "Dragalge @ Black Sludge
Ability: Adaptability
Tera Type: &
EVs: 164 HP / 8 Def / 252 SpA / 4 SpD / 80 Spe
Modest Nature
- Draco Meteor
- Sludge Bomb
- Rest
- Flip Turn
";
$g10901 = "Dragalge @ Black Sludge
Ability: Adaptability
Tera Type: &
EVs: 148 HP / 252 Atk / 108 SpD
Adamant Nature
- Gunk Shot
- Toxic Spikes
- Rest
- Flip Turn
";
$g10910 = "Porygon-Z @ Chesto Berry
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 112 Def / 144 Spe
Modest Nature
- Tri Attack
- Defense Curl
- Rest
- Agility
";
$g10919 = "Celebi @ Leftovers
Ability: Natural Cure
Tera Type: &
EVs: 60 HP / 196 SpA / 252 Spe
Timid Nature
- Giga Drain
- Aura Sphere
- Magic Coat
- Calm Mind
";
$g10928 = "Altaria @ Lum Berry
Ability: Natural Cure
Tera Type: &
EVs: 108 HP / 252 Atk / 120 SpD / 28 Spe
Careful Nature
- Dual Wingbeat
- Cotton Guard
- Roost
- Dragon Dance
";
$g10937 = "Bouffalant @ Chesto Berry
Ability: Reckless
Tera Type: &
EVs: 252 HP / 180 SpD / 76 Spe
Careful Nature
- Head Charge
- Throat Chop
- Cotton Guard
- Rest
";
$g10946 = "Sylveon @ Choice Specs
Ability: Pixilate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Hyper Beam
- Mystical Fire
- Sleep Talk
- Heal Bell
";
$g10955 = "Sylveon @ Life Orb
Ability: Pixilate
Tera Type: &
EVs: 84 HP / 172 SpA / 252 Spe
Timid Nature
- Hyper Beam
- Mystical Fire
- Wish
- Calm Mind
";
$g10964 = "Sylveon @ Kee Berry
Ability: Pixilate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Hyper Beam
- Protect
- Wish
- Calm Mind
";
$g10973 = "Sylveon @ Lum Berry
Ability: Pixilate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Hyper Beam
- Protect
- Wish
- Calm Mind
";
$g10982 = "Sylveon @ Quick Claw
Ability: Pixilate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Hyper Beam
- Protect
- Wish
- Calm Mind
";
$g10991 = "Clefable @ Quick Claw
Ability: Magic Guard
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Moonblast
- Stored Power
- Soft-Boiled
- Cosmic Power
";
$g11001 = "Metagross @ Quick Claw
Ability: Clear Body
Tera Type: &
EVs: 100 HP / 88 Atk / 156 Def / 164 SpD
Impish Nature
- Meteor Mash
- Body Press
- Rest
- Cosmic Power
";
$g11010 = "Hawlucha @ Power Herb
Ability: Mold Breaker
Shiny: Yes
Tera Type: &
EVs: 252 HP / 64 SpD / 192 Spe
Jolly Nature
- Drain Punch
- Sky Attack
- Encore
- Bulk Up
";
$g11020 = "Entei @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 132 HP / 80 SpA / 44 SpD / 252 Spe
Timid Nature
- Fire Spin
- Toxic
- Substitute
- Protect
";
$g11029 = "Whimsicott @ Maranga Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 56 Def / 200 SpD
Calm Nature
- Encore
- Cotton Guard
- Endeavor
- Leech Seed
";
$g11038 = "Tyranitar @ Chesto Berry
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 196 Atk / 56 Def / 4 SpD
Adamant Nature
- Stone Edge
- Crunch
- Rest
- Curse
";
$g11047 = "Appletun @ Rocky Helmet
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Apple Acid
- Body Press
- Leech Seed
- Recover
";
$g11056 = "Cottonee @ Bright Powder
Ability: Prankster
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Leech Seed
- Encore
- Substitute
- Protect
";
$g11065 = "Aegislash @ Eject Pack
Ability: Stance Change
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Careful Nature
- Iron Head
- Shadow Sneak
- Close Combat
- Kings Shield
";
$g11074 = "Shedinja @ Protective Pads
Ability: Wonder Guard
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Adamant Nature
- Poltergeist
- Shadow Sneak
- Leech Life
- Will-O-Wisp
";
$g11083 = "Urshifu-Rapid-Strike @ Protective Pads
Ability: Unseen Fist
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Surging Strikes
- U-turn
- Low Kick
- Dive
";
$g11092 = "Slowbro @ Red Card
Ability: Oblivious
Tera Type: &
EVs: 240 HP / 224 Def / 12 SpA / 32 SpD
Bold Nature
- Psychic
- Whirlpool
- Slack Off
- Calm Mind
";
$g11101 = "Terrakion @ Eject Pack
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Close Combat
- Poison Jab
- Stealth Rock
";
$g11110 = "Togekiss @ Adrenaline Orb
Ability: Super Luck
Tera Type: &
EVs: 16 HP / 248 SpA / 4 SpD / 240 Spe
Modest Nature
- Draining Kiss
- Fire Blast
- Roost
- Nasty Plot
";
$g11119 = "Victini @ Chesto Berry
Ability: Victory Star
Tera Type: &
EVs: 164 HP / 100 SpA / 244 Spe
Hasty Nature
- Blue Flare
- Energy Ball
- Rest
- Will-O-Wisp
";
$g11128 = "Slowking-Galar @ Kee Berry
Ability: Regenerator
Tera Type: &
EVs: 124 HP / 252 Def / 132 SpA
Quiet Nature
- Sludge Bomb
- Flamethrower
- Trick Room
- Slack Off
";
$g11137 = "Jirachi @ Weakness Policy
Ability: Serene Grace
Tera Type: &
EVs: 224 HP / 152 Atk / 132 Spe
Lonely Nature
- Drain Punch
- Stored Power
- Power-Up Punch
- Calm Mind
";
$g11146 = "Charizard @ Custap Berry
Ability: Blaze
Tera Type: &
EVs: 108 HP / 252 SpA / 4 SpD / 144 Spe
Modest Nature
- Fire Blast
- Solar Beam
- Endure
- Sunny Day
";
$g11155 = "Blastoise @ Heavy-Duty Boots
Ability: Torrent
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Scald
- Focus Punch
- Substitute
- Rapid Spin
";
$g11164 = "Cloyster @ Assault Vest
Ability: Skill Link
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Icicle Spear
- Rock Blast
- Rapid Spin
- Explosion
";
$g11173 = "Aerodactyl @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- Mimic
- Defog
- Roost
- Substitute
";
$g11182 = "Landorus-Therian @ Aguav Berry
Ability: Intimidate
Tera Type: &
EVs: 216 HP / 36 SpA / 160 SpD / 96 Spe
Timid Nature
- Earth Power
- Sludge Bomb
- Toxic
- Defog
";
$g11191 = "Roserade @ Bright Powder
Ability: Natural Cure
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
- Energy Ball
- Synthesis
- Stun Spore
- Substitute
";
$g11200 = "Dracozolt @ Assault Vest
Ability: Hustle
Tera Type: &
EVs: 252 HP / 44 Atk / 212 SpD
Adamant Nature
- Bolt Beak
- Draco Meteor
- Fire Blast
- High Horsepower
";
$g11209 = "Mudsdale @ Weakness Policy
Ability: Own Tempo
Tera Type: &
EVs: 252 HP / 188 Atk / 68 SpD
Adamant Nature
- High Horsepower
- Body Press
- Sleep Talk
- Rest
";
$g11218 = "Aromatisse @ Kee Berry
Ability: Aroma Veil
Tera Type: &
EVs: 252 HP / 60 Def / 196 SpA
Bold Nature
- Moonblast
- Protect
- Wish
- Calm Mind
";
$g11227 = "Victini @ Bright Powder
Ability: Victory Star
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Flamethrower
- Glaciate
- Thunder Wave
- Substitute
";
$g11236 = "Clawitzer @ Choice Scarf
Ability: Mega Launcher
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Water Pulse
- Dark Pulse
- Dragon Pulse
- Ice Beam
";
$g11245 = "Clawitzer @ Blunder Policy
Ability: Mega Launcher
Tera Type: &
EVs: 20 HP / 252 SpA / 92 SpD / 144 Spe
Modest Nature
- Muddy Water
- Dark Pulse
- Laser Focus
- Protect
";
$g11254 = "Lurantis @ Lum Berry
Ability: Contrary
Tera Type: &
EVs: 164 HP / 92 Atk / 252 SpA
Quiet Nature
- Leaf Storm
- Knock Off
- Defog
- Synthesis
";
$g11263 = "Lurantis @ Choice Specs
Ability: Contrary
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Leaf Storm
- Giga Drain
- Sleep Talk
-
";
$g11272 = "Lurantis @ Choice Scarf
Ability: Contrary
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Leaf Storm
- Knock Off
- Superpower
- Defog
";
$g11282 = "Conkeldurr @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Adamant Nature
- Close Combat
- Knock Off
- Fling
- Defog
";
$g11291 = "Malamar @ Blunder Policy
Ability: Suction Cups
Tera Type: &
EVs: 140 HP / 252 SpA / 116 Spe
Modest Nature
- Stored Power
- Dark Pulse
- Hypnosis
- Nasty Plot
";
$g11300 = "Turtonator @ Charti Berry
Ability: Shell Armor
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Bold Nature
- Draco Meteor
- Fire Blast
- Rapid Spin
- Shell Smash
";
$g11309 = "Primarina @ Life Orb
Ability: Torrent
Tera Type: &
EVs: 12 HP / 252 Def / 76 SpA / 168 Spe
Bold Nature
- Scald
- Ice Beam
- Magic Coat
- Protect
";
$g11318 = "Blastoise @ Leftovers
Ability: Torrent
Tera Type: &
EVs: 252 HP / 112 Def / 144 Spe
Impish Nature
- Dive
- Power-Up Punch
- Rapid Spin
- Substitute
";
$g11327 = "Cinccino @ Leftovers
Ability: Cute Charm
Tera Type: &
EVs: 40 HP / 216 Atk / 252 Spe
Adamant Nature
- Last Resort
- Toxic
- Substitute
- Protect
";
$g11336 = "Ivysaur @ Eviolite
Ability: Overgrow
Tera Type: &
EVs: 228 HP / 240 Def / 40 SpA
Bold Nature
- Frenzy Plant
- Leech Seed
- Synthesis
- Amnesia
";
$g11345 = "Comfey @ Life Orb
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Energy Ball
- Draining Kiss
- Rest
- Protect
";
$g11354 = "Comfey @ Flame Orb
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 220 Def / 32 SpA / 4 SpD
Bold Nature
- Draining Kiss
- Leech Seed
- Fling
- Rest
";
$g11363 = "Blastoise @ Wacan Berry
Ability: Torrent
Tera Type: &
EVs: 252 HP / 236 SpA / 20 SpD
Modest Nature
- Hydro Pump
- Toxic
- Endure
- Rapid Spin
";
$g11372 = "Delibird @ Heavy-Duty Boots
Ability: Vital Spirit
Tera Type: &
EVs: 64 HP / 8 Atk / 184 SpA / 252 Spe
Hasty Nature
- Freeze-Dry
- Toxic
- Fly
- Rapid Spin
";
$g11381 = "Frosmoth @ Heavy-Duty Boots
Ability: Shield Dust
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Ice Beam
- Hurricane
- Defog
- Giga Drain
";
$g11391 = "Mandibuzz @ Rocky Helmet
Ability: Overcoat
Tera Type: &
EVs: 252 HP / 132 Def / 124 Spe
Bold Nature
- Foul Play
- Taunt
- Defog
- Roost
";
$g11400 = "Aerodactyl @ Life Orb
Ability: Rock Head
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Aqua Tail
- Defog
- Protect
";
$g11410 = "Landorus-Therian @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 212 HP / 44 Atk / 252 SpD
Sassy Nature
- Earth Power
- Fly
- Toxic
- Defog
";
$g11419 = "Zapdos @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Fly
- Defog
- Toxic
- Roost
";
$g11428 = "Mew @ Rocky Helmet
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Toxic
- Roost
- Block
- Cosmic Power
";
$g11437 = "Decidueye @ Life Orb
Ability: Overgrow
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Giga Drain
- Shadow Ball
- Defog
- Protect
";
$g11446 = "Morpeko @ Assault Vest
Ability: Hunger Switch
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Aura Wheel
- Brick Break
- Seed Bomb
- Rapid Spin
";
$g11455 = "Tapu Fini @ Sitrus Berry
Ability: Misty Surge
Tera Type: &
EVs: 200 HP / 104 Def / 4 SpA / 200 Spe
Timid Nature
- Draining Kiss
- Calm Mind
- Defog
- Taunt
";
$g11464 = "Exploud @ Custap Berry
Ability: Scrappy
Tera Type: &
EVs: 220 HP / 160 Def / 128 SpA
Modest Nature
- Boomburst
- Fire Blast
- Ice Beam
- Counter
";
$g11473 = "Naganadel @ Leftovers
Ability: Beast Boost
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Sludge Bomb
- Fire Blast
- Protect
";
$g11482 = "Trevenant @ Leftovers
Ability: Natural Cure
Tera Type: &
EVs: 76 HP / 220 Atk / 212 Spe
Adamant Nature
- Phantom Force
- Leech Seed
- Rest
- Dig
";
$g11491 = "Blaziken @ Life Orb
Ability: Speed Boost
Tera Type: &
EVs: 220 HP / 252 Def / 36 SpD
Modest Nature
- Flamethrower
- Focus Blast
- Defog
- Protect
";
$g11500 = "Audino @ Life Orb
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Hyper Voice
- Shadow Ball
- Flamethrower
- Protect
";
$g11509 = "Mienshao @ Choice Band
Ability: Regenerator
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Close Combat
- Poison Jab
- Dual Chop
- U-turn
";
$g11518 = "Zeraora @ Sitrus Berry
Ability: Volt Absorb
Shiny: Yes
Tera Type: &
EVs: 252 HP / 8 Atk / 100 Def / 32 SpD / 116 Spe
Adamant Nature
- Plasma Fists
- Drain Punch
- Play Rough
- Bulk Up
";
$g11528 = "Tapu Koko @ Sitrus Berry
Ability: Electric Surge
Tera Type: &
EVs: 216 HP / 196 Def / 96 SpA
Bold Nature
- Thunderbolt
- Defog
- Roost
- Calm Mind
";
$g11537 = "Necrozma @ Custap Berry
Ability: Prism Armor
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Prismatic Laser
- Heat Wave
- Moonlight
- Calm Mind
";
$g11546 = "Torkoal @ Custap Berry
Ability: Drought
Tera Type: &
EVs: 200 HP / 112 Def / 188 SpA / 8 SpD
Modest Nature
- Overheat
- Solar Beam
- Body Press
- Rapid Spin
";
$g11555 = "Volcanion @ Shuca Berry
Ability: Water Absorb
Tera Type: &
EVs: 68 HP / 192 SpA / 148 SpD / 100 Spe
Modest Nature
- Overheat
- Steam Eruption
- Defog
- Protect
";
$g11564 = "Celebi @ Heavy-Duty Boots
Ability: Natural Cure
Tera Type: &
EVs: 220 HP / 252 SpA / 36 Spe
Modest Nature
- Leaf Storm
- Rest
- Psychic
- Stealth Rock
";
$g11573 = "Oranguru @ Colbur Berry
Ability: Inner Focus
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Sassy Nature
- Trick Room
- Instruct
- Pain Split
- Extrasensory
";
$g11582 = "Oranguru @ Choice Scarf
Ability: Inner Focus
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Extrasensory
- Focus Blast
- Instruct
- Trick
";
$g11591 = "Oranguru @ Sitrus Berry
Ability: Inner Focus
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Magic Coat
- Instruct
- Pain Split
- Psychic
";
$g11600 = "Dragapult @ Focus Sash
Ability: Infiltrator
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Phantom Force
- Grudge
- Dragon Darts
- Will-O-Wisp
";
$g11609 = "Uxie @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Protect
- Toxic
- Stealth Rock
- Psychic
";
$g11618 = "Uxie @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Trick
- Rest
- Psychic
- Helping Hand
";
$g11627 = "Uxie @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Calm Mind
- Stored Power
- Draining Kiss
- Protect
";
$g11636 = "Mesprit @ Choice Band
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Fire Punch
- Drain Punch
- Zen Headbutt
- Ice Punch
";
$g11645 = "Mesprit @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Protect
- Calm Mind
- Stored Power
- Draining Kiss
";
$g11654 = "Zygarde @ Maranga Berry
Ability: Aura Break
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 SpD
Careful Nature
- Thousand Waves
- Protect
- Coil
- Rest
";
$g11664 = "Umbreon @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Wish
- Heal Bell
- Protect
- Foul Play
";
$g11673 = "Sableye @ Choice Scarf
Ability: Prankster
Tera Type: &
EVs: 252 HP / 36 Def / 220 SpD
Bold Nature
- Trick
- Mean Look
- Disable
- Recover
";
$g11682 = "Impidimp @ Focus Sash
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Fake Tears
- Protect
- Thunder Wave
- Trick
";
$g11691 = "Klefki @ Toxic Orb
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Defog
- Metal Sound
- Flash Cannon
- Switcheroo
";
$g11700 = "Mesprit @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Calm Nature
- Protect
- Substitute
- Imprison
- Toxic
";
$g11709 = "Crobat @ Black Sludge
Ability: Infiltrator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Haze
- Roost
- Brave Bird
- Super Fang
";
$g11718 = "Crobat @ Black Sludge
Ability: Infiltrator
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Sludge Bomb
- Giga Drain
- Heat Wave
";
$g11727 = "Zygarde-10% @ Leftovers
Ability: Aura Break
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Protect
- Haze
- Stomping Tantrum
- Outrage
";
$g11736 = "Roserade @ Black Sludge
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Leaf Storm
- Rest
- Leech Seed
- Protect
";
$g11745 = "Marowak-Alola @ Sitrus Berry
Ability: Lightning Rod
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Bold Nature
- Fire Spin
- Perish Song
- Protect
- Toxic
";
$g11754 = "Cresselia @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Calm Mind
- Stored Power
- Moonlight
- Moonblast
";
$g11763 = "Sharpedo @ Focus Sash
Ability: Speed Boost
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Protect
- Substitute
- Destiny Bond
- Waterfall
";
$g11772 = "Delibird @ Custap Berry
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Gunk Shot
- Ice Punch
- Endure
- Destiny Bond
";
$g11781 = "Palossand @ Absorb Bulb
Ability: Water Compaction
Tera Type: &
EVs: 252 HP / 252 SpD
Calm Nature
- Shore Up
- Earth Power
- Shadow Ball
- Giga Drain
";
$g11790 = "Suicune @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Calm Mind
- Rest
- Sleep Talk
- Scald
";
$g11799 = "Suicune @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Waterfall
- Extreme Speed
- Protect
- Crunch
";
$g11808 = "Tornadus-Therian @ Damp Rock
Ability: Regenerator
Tera Type: &
EVs: 156 HP / 100 SpA / 252 Spe
Timid Nature
- Rain Dance
- Hurricane
- U-turn
- Focus Blast
";
$g11817 = "Moltres-Galar @ Zoom Lens
Ability: Berserk
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Quiet Nature
- Hurricane
- Sucker Punch
- Protect
- Fiery Wrath
";
$g11826 = "Arcanine @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 8 Atk / 40 Def / 212 SpD
Sassy Nature
- Burn Up
- Teleport
- Close Combat
- Morning Sun
";
$g11835 = "Rapidash @ Heat Rock
Ability: Flash Fire
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Sunny Day
- Morning Sun
- Flare Blitz
- Solar Blade
";
$g11844 = "Emolga @ Leftovers
Ability: Motor Drive
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Nuzzle
- Defog
- Roost
- Air Slash
";
$g11853 = "Sliggoo @ Eviolite
Ability: Hydration
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Rain Dance
- Rest
- Acid Spray
- Draco Meteor
";
$g11862 = "Salamence @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Protect
- Wish
- Toxic
- Dragon Pulse
";
$g11871 = "Blissey @ Heavy-Duty Boots
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Wish
- Protect
- Counter
- Seismic Toss
";
$g11880 = "Diancie @ Kee Berry
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Calm Mind
- Rest
- Sleep Talk
- Moonblast
";
$g11889 = "Machamp @ Choice Scarf
Ability: No Guard
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Dynamic Punch
- Fire Punch
- Ice Punch
- Heavy Slam
";
$g11898 = "Mienshao @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- High Jump Kick
- Fake Out
- U-turn
- Knock Off
";
$g11907 = "Stoutland @ Flame Orb
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Facade
- Rest
- Sleep Talk
- Superpower
";
$g11916 = "Bronzong @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Calm Mind
- Speed Swap
- Flash Cannon
- Psychic
";
$g11925 = "Comfey @ Leftovers
Ability: Triage
Tera Type: &
EVs: 252 HP / 88 Def / 168 SpA
Modest Nature
- U-turn
- Draining Kiss
- Giga Drain
- Toxic
";
$g11934 = "Zapdos-Galar @ Choice Scarf
Ability: Defiant
Tera Type: &
EVs: 8 HP / 252 Atk / 248 Spe
Jolly Nature
- U-turn
- Brave Bird
- Blaze Kick
- Close Combat
";
$g11943 = "Weezing-Galar @ Choice Scarf
Ability: Neutralizing Gas
Shiny: Yes
Tera Type: &
EVs: 252 HP / 16 Def / 240 Spe
Timid Nature
- Sludge Bomb
- Strange Steam
- Fire Blast
- Will-O-Wisp
";
$g11953 = "Rufflet @ Eviolite
Ability: Hustle
Tera Type: &
EVs: 248 HP / 80 SpD / 180 Spe
Jolly Nature
- U-turn
- Aerial Ace
- Tailwind
- Whirlwind
";
$g11962 = "Slowbro-Galar @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 16 SpA / 240 SpD
Quiet Nature
- Future Sight
- Psyshock
- Shell Side Arm
- Flamethrower
";
$g11971 = "Dragonite @ Heavy-Duty Boots
Ability: Multiscale
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpA
Quiet Nature
- Hurricane
- Draco Meteor
- Roost
- Iron Head
";
$g11980 = "Dragonite @ Heavy-Duty Boots
Ability: Multiscale
Tera Type: &
EVs: 252 HP / 28 Atk / 228 Spe
Jolly Nature
- Dragon Dance
- Earthquake
- Outrage
- Roost
";
$g11989 = "Mamoswine @ Assault Vest
Ability: Thick Fat
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Icicle Crash
- Earthquake
- Ice Shard
- Knock Off
";
$g11998 = "Jirachi @ Choice Scarf
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- U-turn
- Iron Head
- Trick
- Healing Wish
";
$g12007 = "Sylveon @ Lum Berry
Ability: Pixilate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Shadow Ball
- Hyper Voice
- Mystical Fire
- Wish
";
$g12016 = "Muk-Alola @ Assault Vest
Ability: Poison Touch
Tera Type: &
EVs: 248 HP / 36 Atk / 28 Def / 192 SpD / 4 Spe
Careful Nature
- Knock Off
- Fire Punch
- Poison Jab
- Shadow Sneak
";
$g12025 = "Milotic @ Heavy-Duty Boots
Ability: Marvel Scale
Tera Type: &
EVs: 248 HP / 144 Def / 14 SpA / 102 SpD
Modest Nature
- Flip Turn
- Ice Beam
- Toxic
- Recover
";
$g12034 = "Krookodile @ Life Orb
Ability: Intimidate
Tera Type: &
EVs: 48 HP / 252 Atk / 208 Spe
Jolly Nature
- Stealth Rock
- Knock Off
- Earthquake
- Thunder Fang
";
$g12043 = "Aegislash @ Weakness Policy
Ability: Stance Change
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Autotomize
- Close Combat
- Shadow Claw
- Kings Shield
";
$g12052 = "Slowking @ Choice Specs
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Quiet Nature
- Teleport
- Scald
- Psychic
- Future Sight
";
$g12061 = "Haxorus @ Lum Berry
Ability: Mold Breaker
Tera Type: &
EVs: 12 HP / 252 Atk / 244 Spe
Jolly Nature
- Dragon Dance
- Outrage
- Earthquake
- Close Combat
";
$g12070 = "Virizion @ Expert Belt
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Close Combat
- Leaf Blade
- Megahorn
- Smart Strike
";
$g12079 = "Mew @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 40 SpA / 216 Spe
Timid Nature
- Psychic
- Shadow Ball
- Calm Mind
- Toxic
";
$g12088 = "Rotom-Heat @ Rocky Helmet
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe
Timid Nature
- Overheat
- Volt Switch
- Thunderbolt
- Defog
";
$g12097 = "Mandibuzz @ Sitrus Berry
Ability: Weak Armor
Tera Type: &
EVs: 48 HP / 252 SpA / 112 SpD / 96 Spe
Modest Nature
- Dark Pulse
- Iron Defense
- Roost
- Nasty Plot
";
$g12106 = "Mandibuzz @ Heavy-Duty Boots
Ability: Overcoat
Shiny: Yes
Tera Type: &
EVs: 248 HP / 164 Def / 96 Spe
Impish Nature
- Knock Off
- Defog
- U-turn
- Roost
";
$g12116 = "Mandibuzz @ Leftovers
Ability: Overcoat
Tera Type: &
EVs: 232 HP / 24 Atk / 252 Spe
Jolly Nature
- Knock Off
- Toxic
- Roost
- Substitute
";
$g12125 = "Mandibuzz @ Heavy-Duty Boots
Ability: Overcoat
Tera Type: &
EVs: 252 HP / 68 Atk / 28 Def / 100 SpD / 60 Spe
Impish Nature
- Brave Bird
- Psych Up
- Defog
- Roost
";
$g12134 = "Kartana @ Kings Rock
Ability: Beast Boost
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Leaf Blade
- Knock Off
- Sacred Sword
- Protect
";
$g12143 = "Victini @ Chesto Berry
Ability: Victory Star
Tera Type: &
EVs: 152 HP / 104 Atk / 252 Spe
Adamant Nature
- Flare Blitz
- Bolt Strike
- U-turn
- Rest
";
$g12152 = "Necrozma @ Chesto Berry
Ability: Prism Armor
Tera Type: &
EVs: 228 HP / 52 Def / 228 Spe
Bold Nature
- Photon Geyser
- Earth Power
- Rest
- Calm Mind
";
$g12161 = "Bouffalant @ Silk Scarf
Ability: Reckless
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Head Charge
- Assurance
- Sleep Talk
- Rest
";
$g12170 = "Glastrier @ Blunder Policy
Ability: Chilling Neigh
Tera Type: &
EVs: 56 HP / 200 Def / 252 Spe
Jolly Nature
- Icicle Crash
- Body Press
- Iron Defense
- Blizzard
";
$g12179 = "Glastrier @ Blunder Policy
Ability: Chilling Neigh
Tera Type: &
EVs: 8 HP / 240 Atk / 28 SpD / 232 Spe
Jolly Nature
- Icicle Spear
- Close Combat
- Blizzard
- Swords Dance
";
$g12188 = "Slowbro @ Blunder Policy
Ability: Own Tempo
Tera Type: &
EVs: 96 HP / 160 Def / 252 Spe
Timid Nature
- Body Press
- Blizzard
- Slack Off
- Iron Defense
";
$g12197 = "Relicanth @ Blunder Policy
Ability: Rock Head
Tera Type: &
EVs: 180 Atk / 76 Def / 4 SpD / 248 Spe
Adamant Nature
- Head Smash
- Blizzard
- Body Press
- Iron Defense
";
$g12206 = "Tapu Fini @ Blunder Policy
Ability: Misty Surge
Tera Type: &
EVs: 192 HP / 252 SpA / 64 Spe
Modest Nature
- Draining Kiss
- Stored Power
- Blizzard
- Calm Mind
";
$g12215 = "Slowbro @ Blunder Policy
Ability: Own Tempo
Tera Type: &
EVs: 96 HP / 160 Def / 252 Spe
Timid Nature
- Body Press
- Muddy Water
- Slack Off
- Iron Defense
";
$g12224 = "Slowbro-Galar @ Life Orb
Ability: Quick Draw
Tera Type: &
EVs: 252 HP / 56 Atk / 200 SpD
Adamant Nature
- Shell Side Arm
- Drain Punch
- Slack Off
- Curse
";
$g12233 = "Pelipper @ Life Orb
Ability: Drizzle
Tera Type: &
EVs: 228 HP / 84 SpA / 196 Spe
Modest Nature
- Hydro Pump
- Hurricane
- Defog
- Roost
";
$g12242 = "Celesteela @ Chesto Berry
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 100 Def / 64 SpA / 92 Spe
Bold Nature
- Air Slash
- Leech Seed
- Rest
- Autotomize
";
$g12251 = "Celesteela @ Occa Berry
Ability: Beast Boost
Tera Type: &
EVs: 108 HP / 148 Def / 252 Spe
Jolly Nature
- Heavy Slam
- Leech Seed
- Substitute
- Protect
";
$g12260 = "Gothitelle @ Rocky Helmet
Ability: Competitive
Tera Type: &
EVs: 236 HP / 20 Def / 252 Spe
Timid Nature
- Stored Power
- Mean Look
- Rest
- Cosmic Power
";
$g12269 = "Gothitelle @ Chesto Berry
Ability: Competitive
Tera Type: &
EVs: 208 HP / 48 SpA / 252 Spe
Timid Nature
- Psychic
- Mean Look
- Rest
- Cosmic Power
";
$g12278 = "Volcanion @ Power Herb
Ability: Water Absorb
Tera Type: &
EVs: 232 HP / 252 SpA / 8 SpD / 16 Spe
Modest Nature
- Flamethrower
- Steam Eruption
- Solar Beam
- Protect
";
$g12287 = "Volcarona @ Heavy-Duty Boots
Ability: Flame Body
Tera Type: &
EVs: 248 HP / 36 Def / 72 SpA / 100 SpD / 52 Spe
Calm Nature
- Mystical Fire
- Toxic
- Defog
- Roost
";
$g12296 = "Volcarona @ Choice Specs
Ability: Flame Body
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Bug Buzz
- Overheat
- Hurricane
- Psychic
";
$g12305 = "Magmortar @ Leftovers
Ability: Vital Spirit
Shiny: Yes
Tera Type: &
EVs: 12 HP / 252 SpA / 244 Spe
Modest Nature
- Mystical Fire
- Focus Blast
- Substitute
- Protect
";
$g12315 = "Mew @ Choice Band
Ability: Synchronize
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Gunk Shot
- Sleep Talk
-
-
";
$g12324 = "Silvally-Ground @ Ground Memory
Ability: RKS System
Tera Type: &
EVs: 252 HP / 184 Atk / 72 Def
Brave Nature
- Multi-Attack
- Ice Beam
- Thunder Wave
- Defog
";
$g12333 = "Silvally-Poison @ Poison Memory
Ability: RKS System
Tera Type: &
EVs: 252 HP / 184 Atk / 72 Def
Brave Nature
- Multi-Attack
- Ice Beam
- Thunder Wave
- Defog
";
$g12342 = "Silvally @ Chesto Berry
Ability: RKS System
Tera Type: &
EVs: 216 HP / 252 Atk / 4 SpD / 36 Spe
Adamant Nature
- Multi-Attack
- Flame Charge
- Rest
- Swords Dance
";
$g12351 = "Silvally-Ghost @ Ghost Memory
Ability: RKS System
Tera Type: &
EVs: 252 HP / 32 Atk / 216 Def / 8 Spe
Impish Nature
- Multi-Attack
- Toxic
- Defog
- Protect
";
$g12360 = "Silvally-Fire @ Fire Memory
Ability: RKS System
Tera Type: &
EVs: 232 Atk / 252 SpA / 24 Spe
Naughty Nature
- Multi-Attack
- Draco Meteor
- Flame Charge
- Swords Dance
";
$g12369 = "Silvally @ Leftovers
Ability: RKS System
Tera Type: &
EVs: 132 HP / 120 Atk / 4 SpD / 252 Spe
Jolly Nature
- Multi-Attack
- Toxic
- Substitute
- Protect
";
$g12378 = "Silvally-Steel @ Steel Memory
Ability: RKS System
Tera Type: &
EVs: 252 HP / 60 Atk / 40 Def / 156 Spe
Naive Nature
- Multi-Attack
- Ice Beam
- Defog
- Parting Shot
";
$g12387 = "Silvally-Steel @ Steel Memory
Ability: RKS System
Tera Type: &
EVs: 36 HP / 16 Def / 252 SpA / 100 SpD / 104 Spe
Calm Nature
- Steel Beam
- Flamethrower
- Parting Shot
- Defog
";
$g12396 = "Silvally @ Leftovers
Ability: RKS System
Tera Type: &
EVs: 20 HP / 236 Atk / 252 Spe
Jolly Nature
- Multi-Attack
- Roar
- Substitute
- Swords Dance
";
$g12405 = "Silvally-Ghost @ Ghost Memory
Ability: RKS System
Tera Type: &
EVs: 252 HP / 96 Atk / 56 Def / 4 SpD / 100 Spe
Jolly Nature
- Multi-Attack
- Thunder Wave
- Roar
- U-turn
";
$g12414 = "Silvally-Fairy @ Fairy Memory
Ability: RKS System
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Multi-Attack
- Flame Charge
- Facade
- Swords Dance
";
$g12423 = "Kommo-o @ Custap Berry
Ability: Overcoat
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Scale Shot
- Drain Punch
- Poison Jab
- Swords Dance
";
$g12432 = "Kommo-o @ Leftovers
Ability: Overcoat
Tera Type: &
EVs: 96 HP / 160 Atk / 252 Spe
Jolly Nature
- Close Combat
- Toxic
- Substitute
- Protect
";
$g12441 = "Kommo-o @ Lum Berry
Ability: Bulletproof
Tera Type: &
EVs: 188 HP / 64 Atk / 4 SpD / 252 Spe
Adamant Nature
- Scale Shot
- Close Combat
- Poison Jab
- Swords Dance
";
$g12450 = "Kommo-o @ Life Orb
Ability: Bulletproof
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Outrage
- Close Combat
- Poison Jab
- Dragon Dance
";
$g12459 = "Kommo-o @ Leftovers
Ability: Bulletproof
Tera Type: &
EVs: 252 HP / 148 Def / 40 SpD / 68 Spe
Impish Nature
- Body Press
- Earthquake
- Stealth Rock
- Protect
";
$g12468 = "Kommo-o @ Throat Spray
Ability: Overcoat
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Clangorous Soul
- Clanging Scales
- Flamethrower
- Protect
";
$g12477 = "Kommo-o @ Salac Berry
Ability: Bulletproof
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Jolly Nature
- Substitute
- Belly Drum
- Drain Punch
- Thunder Punch
";
$g12486 = "Kommo-o @ Sitrus Berry
Ability: Bulletproof
Tera Type: &
EVs: 100 HP / 100 Def / 108 SpA / 100 SpD / 100 Spe
Modest Nature
- Draco Meteor
- Flamethrower
- Toxic
- Stealth Rock
";
$g12495 = "Heatran @ Custap Berry
Ability: Flash Fire
Tera Type: &
EVs: 152 HP / 160 SpA / 8 SpD / 188 Spe
Modest Nature
- Overheat
- Flash Cannon
- Eruption
- Stealth Rock
";
$g12504 = "Tapu Lele @ Life Orb
Ability: Psychic Surge
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psychic
- Moonblast
- Focus Blast
- Calm Mind
";
$g12513 = "Tapu Lele @ Psychic Seed
Ability: Psychic Surge
Tera Type: &
EVs: 252 HP / 80 SpD / 176 Spe
Modest Nature
- Psychic
- Moonblast
- Protect
- Calm Mind
";
$g12522 = "Drapion @ Shuca Berry
Ability: Battle Armor
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Swords Dance
- Knock Off
- Poison Jab
- Earthquake
";
$g12531 = "Drapion @ Black Sludge
Ability: Battle Armor
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Impish Nature
- Knock Off
- Dig
- Roar
- Toxic Spikes
";
$g12540 = "Salamence @ Leftovers
Ability: Moxie
Tera Type: &
EVs: 160 HP / 20 Atk / 76 SpD / 252 Spe
Adamant Nature
- Dual Wingbeat
- Iron Defense
- Roost
- Dragon Dance
";
$g12549 = "Foongus @ Eviolite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Sludge Bomb
- Clear Smog
- Foul Play
- Spore
";
$g12558 = "Rotom-Wash @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 72 HP / 252 SpD / 184 Spe
Calm Nature
- Foul Play
- Thunder Wave
- Pain Split
- Trick
";
$g12567 = "Rotom @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 72 HP / 252 SpD / 184 Spe
Calm Nature
- Foul Play
- Thunder Wave
- Pain Split
- Trick
";
$g12576 = "Registeel @ Custap Berry
Ability: Clear Body
Shiny: Yes
Tera Type: &
EVs: 252 HP / 136 Atk / 60 Def / 60 SpD
Sassy Nature
- Heavy Slam
- Hammer Arm
- Counter
- Curse
";
$g12586 = "Kartana @ Focus Sash
Ability: Beast Boost
Tera Type: &
EVs: 64 Atk / 252 SpA / 192 Spe
Naive Nature
- Leaf Blade
- Steel Beam
- Vacuum Wave
- Swords Dance
";
$g12595 = "Kubfu @ Eviolite
Ability: Inner Focus
Tera Type: &
EVs: 248 HP / 248 Atk / 12 Spe
Jolly Nature
- Close Combat
- Iron Head
- Counter
- Bulk Up
";
$g12604 = "Metagross @ Choice Band
Ability: Clear Body
Tera Type: &
EVs: 148 HP / 180 Atk / 180 SpD
Adamant Nature
- Bullet Punch
- Sleep Talk
- Rest
- Trick
";
$g12613 = "Araquanid @ Choice Specs
Ability: Water Bubble
Tera Type: &
EVs: 24 HP / 216 Def / 252 SpA / 8 SpD / 8 Spe
Modest Nature
- Hydro Pump
- Scald
- Ice Beam
- Sticky Web
";
$g12622 = "Tapu Lele @ Choice Scarf
Ability: Psychic Surge
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Psychic
- Moonblast
- Focus Blast
- Toxic
";
$g12631 = "Togekiss @ Sitrus Berry
Ability: Serene Grace
Tera Type: &
EVs: 12 HP / 252 Def / 244 SpD
Modest Nature
- Air Slash
- Dazzling Gleam
- Defog
- Nasty Plot
";
$g12640 = "Ninetales @ Assault Vest
Ability: Drought
Tera Type: &
EVs: 196 HP / 252 SpA / 60 Spe
Timid Nature
- Overheat
- Solar Beam
- Inferno
- Hex
";
$g12649 = "Kingdra @ Haban Berry
Ability: Damp
Tera Type: &
EVs: 96 HP / 96 Atk / 124 SpA / 36 SpD / 156 Spe
Lonely Nature
- Waterfall
- Iron Head
- Draco Meteor
- Dragon Dance
";
$g12658 = "Kingdra @ Flame Orb
Ability: Damp
Tera Type: &
EVs: 144 HP / 208 Atk / 108 SpA / 48 SpD
Brave Nature
- Facade
- Scald
- Ice Beam
- Flip Turn
";
$g12667 = "Mimikyu @ Weakness Policy
Ability: Disguise
Tera Type: &
EVs: 252 HP / 244 Atk / 12 Def
Impish Nature
- Shadow Sneak
- Thief
- Baby-Doll Eyes
- Thunder Wave
";
$g12676 = "Frosmoth @ Light Clay
Ability: Ice Scales
Tera Type: &
EVs: 184 HP / 32 Def / 40 SpA / 252 Spe
Timid Nature
- Ice Beam
- Light Screen
- Reflect
- Quiver Dance
";
$g12685 = "Dracovish @ Choice Scarf
Ability: Strong Jaw
Tera Type: &
EVs: 16 SpD
Nature
- Fishious Rend
- Outrage
- Psychic Fangs
- Rest
";
$g12694 = "Venusaur @ Petaya Berry
Ability: Overgrow
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Frenzy Plant
- Giga Drain
- Knock Off
- Substitute
";
$g12703 = "Nihilego @ Assault Vest
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Sludge Bomb
- Knock Off
- Charge Beam
- Mirror Coat
";
$g12712 = "Jellicent @ Maranga Berry
Ability: Water Absorb
Tera Type: &
EVs: 100 HP / 108 Def / 100 SpA / 100 SpD / 100 Spe
Timid Nature
- Scald
- Strength Sap
- Rain Dance
- Substitute
";
$g12721 = "Hydreigon @ Lum Berry
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 152 HP / 104 SpD / 252 Spe
Calm Nature
- Toxic
- Torment
- Substitute
- Roost
";
$g12731 = "Drifblim @ Bright Powder
Ability: Aftermath
Tera Type: &
EVs: 48 Def / 208 SpA / 252 SpD
Modest Nature
- Weather Ball
- Sunny Day
- Strength Sap
- Substitute
";
$g12740 = "Porygon-Z @ Focus Sash
Ability: Download
Tera Type: &
EVs: 252 Atk / 136 SpA / 120 Spe
Mild Nature
- Giga Impact
- Tri Attack
- Nasty Plot
- Agility
";
$g12749 = "Beheeyem @ Quick Claw
Ability: Synchronize
Shiny: Yes
Tera Type: &
EVs: 188 HP / 68 Def / 252 SpA
Modest Nature
- Expanding Force
- Thunderbolt
- Psychic Terrain
- Protect
";
$g12759 = "Archeops @ Choice Band
Ability: Defeatist
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Head Smash
- Dual Wingbeat
- Dig
- Knock Off
";
$g12768 = "Shiftry @ Choice Specs
Ability: Chlorophyll
Tera Type: &
EVs: 24 HP / 24 Def / 252 SpA / 36 SpD / 172 Spe
Modest Nature
- Leaf Storm
- Dark Pulse
- Heat Wave
- Giga Drain
";
$g12777 = "Blaziken @ Beast Ball
Ability: Speed Boost
Shiny: Yes
Tera Type: &
EVs: 4 HP / 212 Atk / 212 SpA / 80 Spe
Naive Nature
- Blaze Kick
- Close Combat
- Overheat
- Swords Dance
";
$g12787 = "Whimsicott @ Lum Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 92 Atk / 164 SpD
Adamant Nature
- Beat Up
- Leech Seed
- Protect
- Cotton Guard
";
$g12796 = "Kommo-o @ Life Orb
Ability: Bulletproof
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naive Nature
- Dragon Claw
- Close Combat
- Clanging Scales
- Swords Dance
";
$g12806 = "Clefable @ Flame Orb
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Moonblast
- Covet
- Fling
- Soft-Boiled
";
$g12815 = "Manectric @ Sticky Barb
Ability: Lightning Rod
Tera Type: &
EVs: 8 Def / 252 SpA / 4 SpD / 244 Spe
Modest Nature
- Thunderbolt
- Roar
- Switcheroo
- Volt Switch
";
$g12824 = "Stufful @ Eviolite
Ability: Fluffy
Tera Type: &
EVs: 204 HP / 164 Def / 140 Spe
Impish Nature
- Force Palm
- Iron Head
- Roar
- Pain Split
";
$g12833 = "Regidrago @ Eject Pack
Ability: Dragons Maw
Tera Type: &
EVs: 184 Def / 124 SpA / 16 SpD / 184 Spe
Modest Nature
- Draco Meteor
- Hammer Arm
- Laser Focus
- Substitute
";
$g12842 = "Alakazam @ Rocky Helmet
Ability: Magic Guard
Tera Type: &
EVs: 244 HP / 48 SpA / 40 SpD / 176 Spe
Hasty Nature
- Psyshock
- Guard Split
- Recover
- Calm Mind
";
$g12851 = "Primarina @ Throat Spray
Ability: Liquid Voice
Tera Type: &
EVs: 200 HP / 56 Def / 252 Spe
Timid Nature
- Scald
- Moonblast
- Sing
- Draining Kiss
";
$g12860 = "Slowbro @ Sitrus Berry
Ability: Oblivious
Tera Type: &
EVs: 252 HP / 80 Atk / 100 Def / 76 SpD
Adamant Nature
- Zen Headbutt
- Earthquake
- Ice Punch
- Belly Drum
";
$g12869 = "Slurpuff @ Throat Spray
Ability: Unburden
Tera Type: &
EVs: 12 HP / 124 SpA / 212 SpD / 160 Spe
Calm Nature
- Draining Kiss
- Cotton Guard
- Snore
- Rest
";
$g12878 = "Celesteela @ Throat Spray
Ability: Beast Boost
Tera Type: &
EVs: 72 HP / 84 Def / 100 SpA / 84 SpD / 168 Spe
Timid Nature
- Flash Cannon
- Giga Drain
- Metal Sound
- Block
";
$g12887 = "Zapdos @ Starf Berry
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Thunderbolt
- Roost
- Substitute
- Agility
";
$g12896 = "Togekiss @ Heavy-Duty Boots
Ability: Super Luck
Tera Type: &
EVs: 100 HP / 156 Atk / 252 Spe
Jolly Nature
- Extreme Speed
- Endeavor
- Thunder Wave
- Substitute
";
$g12905 = "Kommo-o @ Salac Berry
Ability: Soundproof
Tera Type: &
EVs: 20 HP / 216 Atk / 20 SpD / 252 Spe
Adamant Nature
- Drain Punch
- Thunder Punch
- Substitute
- Belly Drum
";
$g12914 = "Kommo-o @ Starf Berry
Ability: Soundproof
Tera Type: &
EVs: 116 HP / 128 Atk / 4 Def / 8 SpD / 252 Spe
Jolly Nature
- Drain Punch
- Thunder Punch
- Substitute
- Belly Drum
";
$g12923 = "Tapu Koko @ Starf Berry
Ability: Electric Surge
Tera Type: &
EVs: 244 HP / 4 Atk / 188 Def / 24 SpA / 12 SpD / 36 Spe
Bold Nature
- Thunderbolt
- Toxic
- Substitute
- Roost
";
$g12932 = "Scrafty @ Starf Berry
Ability: Shed Skin
Tera Type: &
EVs:
Nature
- Knock Off
- Substitute
- Rest
- Bulk Up
";
$g12941 = "Druddigon @ Custap Berry
Ability: Sheer Force
Tera Type: &
EVs: 252 HP / 84 Atk / 172 SpD
Adamant Nature
- Gunk Shot
- Glare
- Stealth Rock
- Rock Slide
";
$g12950 = "Shedinja @ Weakness Policy
Ability: Wonder Guard
Tera Type: &
EVs: 248 Atk / 4 Def / 4 SpA / 252 Spe
Naughty Nature
- Shadow Sneak
- X-Scissor
- Endure
- Swords Dance
";
$g12959 = "Avalugg @ Starf Berry
Ability: Sturdy
Tera Type: &
EVs: 52 HP / 252 SpD / 204 Spe
Careful Nature
- Icicle Spear
- Iron Defense
- Recover
- Rock Polish
";
$g12968 = "Salamence @ Choice Band
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Rush
- Fly
- Aqua Tail
- Earthquake
";
$g12977 = "Tirtouga @ Power Herb
Ability: Solid Rock
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Muddy Water
- Meteor Beam
- Ice Beam
- Shell Smash
";
$g12986 = "Stonjourner @ Smooth Rock
Ability: Power Spot
Tera Type: &
EVs: 188 HP / 164 Atk / 92 Def / 64 Spe
Impish Nature
- Self-Destruct
- Heat Crash
- Stealth Rock
- Sandstorm
";
$g12995 = "Stonjourner @ Power Herb
Ability: Power Spot
Tera Type: &
EVs: 4 Def / 252 SpA / 252 SpD
Modest Nature
- Meteor Beam
- Earth Power
- Ancient Power
- Protect
";
$g13004 = "Stonjourner @ Choice Band
Ability: Power Spot
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Superpower
- Rock Slide
- Body Slam
- Heat Crash
";
$g13013 = "Volcarona @ Choice Scarf
Ability: Flame Body
Tera Type: &
EVs: 28 HP / 168 Def / 44 SpA / 16 SpD / 252 Spe
Timid Nature
- Bug Buzz
- Fire Blast
- Psychic
- U-turn
";
$g13022 = "Litwick @ Eviolite
Ability: Flash Fire
Tera Type: &
EVs: 252 HP / 52 Def / 80 SpA / 124 SpD
Modest Nature
- Fire Spin
- Will-O-Wisp
- Pain Split
- Protect
";
$g13031 = "Torkoal @ Choice Band
Ability: Drought
Tera Type: &
EVs: 252 Atk / 252 Def / 4 SpA
Relaxed Nature
- Body Press
- Lava Plume
- Heat Crash
- Gyro Ball
";
$g13040 = "Suicune @ Black Glasses
Ability: Pressure
Tera Type: &
EVs: 104 HP / 252 Atk / 140 SpD / 12 Spe
Adamant Nature
- Crunch
- Scald
- Extreme Speed
- Curse
";
$g13049 = "Palpitoad @ Eviolite
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Scald
- Power Whip
- Toxic
- Stealth Rock
";
$g13058 = "Scizor @ Choice Band
Ability: Technician
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Bullet Punch
- U-turn
- Superpower
- Knock Off
";
$g13067 = "Diancie @ Charcoal
Ability: Clear Body
Tera Type: &
EVs: 164 HP / 32 Def / 56 SpA / 4 SpD / 252 Spe
Timid Nature
- Mystical Fire
- Encore
- Stealth Rock
- Calm Mind
";
$g13076 = "Zapdos @ Custap Berry
Ability: Static
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Thunderbolt
- Hurricane
- Heat Wave
- Endure
";
$g13085 = "Gengar @ Rocky Helmet
Ability: Cursed Body
Tera Type: &
EVs: 104 HP / 84 Def / 124 SpA / 196 Spe
Timid Nature
- Hex
- Dazzling Gleam
- Will-O-Wisp
- Reflect Type
";
$g13094 = "Heatran @ Assault Vest
Ability: Flash Fire
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Sassy Nature
- Magma Storm
- Heavy Slam
- Dragon Pulse
- Earth Power
";
$g13103 = "Rhyperior @ Choice Band
Ability: Solid Rock
Tera Type: &
EVs: 252 HP / 44 Atk / 212 Def
Adamant Nature
- Earthquake
- Rock Wrecker
- Heavy Slam
- Metal Burst
";
$g13112 = "Starmie @ Rocky Helmet
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Scald
- Ice Beam
- Reflect Type
- Recover
";
$g13121 = "Bisharp @ Choice Band
Ability: Defiant
Tera Type: &
EVs: 212 HP / 252 Atk / 44 SpD
Adamant Nature
- Sucker Punch
- Sleep Talk
-
-
";
$g13130 = "Sleep Talk @
Ability: Intimidate
Tera Type: &
EVs: 100 HP / 108 Atk / 100 Def / 100 SpD / 100 Spe
Adamant Nature
- Flare Blitz
- Close Combat
- Covet
- Morning Sun
";
$g13139 = "Lycanroc-Dusk @ Focus Sash
Ability: Tough Claws
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Adamant Nature
- Close Combat
- Stealth Rock
- Counter
- Accelerock
";
$g13148 = "Garchomp @ Normal Gem
Ability: Rough Skin
Tera Type: &
EVs: 240 HP / 40 Atk / 24 Def / 204 SpD
Careful Nature
- Stomping Tantrum
- Double-Edge
- Stealth Rock
- Incinerate
";
$g13157 = "Landorus-Therian @ Sitrus Berry
Ability: Intimidate
Tera Type: &
EVs: 28 HP / 112 SpA / 116 SpD / 252 Spe
Timid Nature
- Earth Power
- Sludge Bomb
- Protect
- Calm Mind
";
$g13166 = "Keldeo @ Leftovers
Ability: Justified
Tera Type: &
EVs: 220 HP / 40 Def / 248 Spe
Timid Nature
- Toxic
- Taunt
- Substitute
- Protect
";
$g13175 = "Boltund @ Odd Incense
Ability: Strong Jaw
Tera Type: &
EVs: 36 HP / 248 Atk / 224 Spe
Adamant Nature
- Nuzzle
- Psychic Fangs
- Fire Fang
- Protect
";
$g13184 = "Ferrothorn @ Sitrus Berry
Ability: Iron Barbs
Tera Type: &
EVs: 248 HP / 32 Def / 228 SpD
Impish Nature
- Heavy Slam
- Toxic
- Stealth Rock
- Worry Seed
";
$g13193 = "Gyarados @ Custap Berry
Ability: Moxie
Tera Type: &
EVs: 172 HP / 232 Atk / 40 SpD / 64 Spe
Impish Nature
- Waterfall
- Bounce
- Iron Head
- Curse
";
$g13202 = "Slurpuff @ Sitrus Berry
Ability: Unburden
Tera Type: &
EVs: 244 HP / 88 Atk / 48 Def / 128 Spe
Adamant Nature
- Play Rough
- Cotton Guard
- Rest
- Belly Drum
";
$g13211 = "Aerodactyl @ Protector
Ability: Rock Head
Tera Type: &
EVs: 252 HP / 132 Def / 124 Spe
Adamant Nature
- Stone Edge
- Double-Edge
- Torment
- Roost
";
$g13220 = "Wailord @ Leftovers
Ability: Pressure
Shiny: Yes
Tera Type: &
EVs: 252 Def / 252 SpD
Impish Nature
- Defense Curl
- Amnesia
- Rest
- Aqua Ring
";
$g13230 = "Incineroar @ Quick Claw
Ability: Intimidate
Tera Type: &
EVs: 80 HP / 16 Atk / 200 Def / 196 SpD / 16 Spe
Adamant Nature
- Flare Blitz
- Knock Off
- Close Combat
- Bulk Up
";
$g13239 = "Genesect @ Quick Claw
Ability: Download
Tera Type: &
EVs: 208 HP / 48 Atk / 252 SpD
Sassy Nature
- Leech Life
- Flamethrower
- Magic Coat
- Thunder Wave
";
$g13248 = "Amoonguss @ Quick Claw
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 112 Def / 144 Spe
Bold Nature
- Giga Drain
- Sludge Bomb
- Foul Play
- Spore
";
$g13257 = "Kyurem @ Heavy-Duty Boots
Ability: Pressure
Tera Type: &
EVs: 12 HP / 240 Atk / 160 SpA / 96 Spe
Naughty Nature
- Dragon Claw
- Icicle Spear
- Draco Meteor
- Dragon Dance
";
$g13266 = "Suicune @ Quick Claw
Ability: Inner Focus
Tera Type: &
EVs: 200 HP / 20 Atk / 96 Def / 72 SpA / 96 SpD / 24 Spe
Modest Nature
- Scald
- Ice Beam
- Roar
- Calm Mind
";
$g13275 = "Tapu Bulu @ Grassy Seed
Ability: Grassy Surge
Shiny: Yes
Tera Type: &
EVs: 176 HP / 72 Def / 204 SpA / 56 Spe
Modest Nature
- Dazzling Gleam
- Stored Power
- Leech Seed
- Calm Mind
";
$g13285 = "Tapu Bulu @ Rocky Helmet
Ability: Grassy Surge
Tera Type: &
EVs: 48 HP / 196 Atk / 24 Def / 240 Spe
Jolly Nature
- Horn Leech
- Zen Headbutt
- Whirlwind
- Substitute
";
$g13294 = "Dragapult @ Petaya Berry
Ability: Clear Body
Tera Type: &
EVs: 40 HP / 40 Atk / 64 Def / 184 SpA / 180 Spe
Hasty Nature
- Shadow Ball
- Acrobatics
- Disable
- Substitute
";
$g13303 = "Xatu @ Heavy-Duty Boots
Ability: Synchronize
Tera Type: &
EVs: 132 HP / 252 SpD / 124 Spe
Calm Nature
- Night Shade
- Thunder Wave
- Roost
- Cosmic Power
";
$g13312 = "Zeraora @ Heavy-Duty Boots
Ability: Volt Absorb
Tera Type: &
EVs: 214 Atk / 214 SpA / 8 SpD / 72 Spe
Rash Nature
- Thunderbolt
- Knock Off
- Close Combat
- Volt Switch
";
$g13321 = "Conkeldurr @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 160 HP / 160 Atk / 44 Def / 144 SpD
Adamant Nature
- Close Combat
- Facade
- Fling
- Protect
";
$g13330 = "Tapu Fini @ Rocky Helmet
Ability: Misty Surge
Tera Type: &
EVs: 100 HP / 100 Def / 100 SpA / 108 SpD / 100 Spe
Bold Nature
- Draining Kiss
- Defog
- Iron Defense
- Calm Mind
";
$g13339 = "Cinccino @ Wide Lens
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 Def / 4 SpD / 248 Spe
Adamant Nature
- Tail Slap
- Bullet Seed
- Triple Axel
- Iron Tail
";
$g13348 = "Raikou @ Heavy-Duty Boots
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Scald
- Toxic
- Volt Switch
";
$g13357 = "Weavile @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 100 HP / 156 Atk / 252 Spe
Jolly Nature
- Icicle Crash
- Spite
- Substitute
- Protect
";
$g13366 = "Maractus @ Sitrus Berry
Ability: Storm Drain
Tera Type: &
EVs: 252 HP / 236 Def / 20 Spe
Bold Nature
- Grass Knot
- Knock Off
- Synthesis
- Spiky Shield
";
$g13375 = "Urshifu-Rapid-Strike @ Choice Specs
Ability: Unseen Fist
Tera Type: &
EVs: 240 HP / 24 Def / 236 SpA / 4 SpD / 4 Spe
Modest Nature
- Scald
- Aura Sphere
- Counter
- U-turn
";
$g13384 = "Metagross @ Lagging Tail
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Trick
- Stealth Rock
- Bullet Punch
- Self-Destruct
";
$g13393 = "Metagross @ Power Herb
Ability: Clear Body
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Steel Beam
- Expanding Force
- Meteor Beam
- Sludge Bomb
";
$g13402 = "Lapras @ Light Clay
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA
Modest Nature
- Freeze-Dry
- Ice Shard
- Thunderbolt
- Sparkling Aria
";
$g13411 = "Zygarde @ Leftovers
Ability: Aura Break
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Thousand Arrows
- Glare
- Pain Split
- Substitute
";
$g13420 = "Suicune @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Scald
- Dig
- Substitute
- Calm Mind
";
$g13429 = "Mew @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 Atk / 200 Def / 36 SpD / 16 Spe
Impish Nature
- Beat Up
- Thunder Wave
- Defog
- Protect
";
$g13438 = "Moltres-Galar @ Quick Claw
Ability: Berserk
Tera Type: &
EVs: 248 HP / 72 Def / 112 SpA / 76 SpD
Modest Nature
- Protect
- Hurricane
- Fiery Wrath
- Nasty Plot
";
$g13447 = "Politoed @ Blunder Policy
Ability: Drizzle
Tera Type: &
EVs: 192 HP / 252 SpA / 64 Spe
Modest Nature
- Muddy Water
- Earth Power
- Hypnosis
- Ice Beam
";
$g13456 = "Mawile @ Choice Band
Ability: Sheer Force
Shiny: Yes
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Iron Head
- Play Rough
- Knock Off
- Ice Punch
";
$g13466 = "Ninetales-Alola @ Leftovers
Ability: Snow Warning
Tera Type: &
EVs: 196 HP / 4 Def / 88 SpA / 220 Spe
Timid Nature
- Freeze-Dry
- Pain Split
- Encore
- Substitute
";
$g13475 = "Jellicent @ Choice Specs
Ability: Water Absorb
Tera Type: &
EVs: 68 HP / 184 SpA / 4 SpD / 252 Spe
Modest Nature
- Water Spout
- Shadow Ball
- Recover
- Trick
";
$g13484 = "Blastoise @ Choice Specs
Ability: Torrent
Tera Type: &
EVs: 20 Def / 236 SpA / 252 Spe
Modest Nature
- Water Spout
- Hydro Pump
- Ice Beam
- Dark Pulse
";
$g13493 = "Octillery @ Mystic Water
Ability: Suction Cups
Tera Type: &
EVs: 120 HP / 136 Def / 252 SpA
Modest Nature
- Water Spout
- Scald
- Energy Ball
- Protect
";
$g13502 = "Lopunny @ Silk Scarf
Ability: Limber
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Last Resort
- Substitute
- Protect
-
";
$g13511 = "Bewear @ Custap Berry
Ability: Fluffy
Tera Type: &
EVs: 144 HP / 112 Atk / 244 SpD / 8 Spe
Adamant Nature
- Double-Edge
- Close Combat
- Darkest Lariat
- Swords Dance
";
$g13520 = "Bewear @ Choice Band
Ability: Fluffy
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Double-Edge
- Close Combat
- Darkest Lariat
- Ice Punch
";
$g13529 = "Bewear @ Leftovers
Ability: Fluffy
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe
Jolly Nature
- Facade
- Bulldoze
- Pain Split
- Protect
";
$g13538 = "Bewear @ Lum Berry
Ability: Fluffy
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Double-Edge
- Superpower
- High Horsepower
- Thunder Punch
";
$g13547 = "Bewear @ Leftovers
Ability: Fluffy
Tera Type: &
EVs: 184 HP / 52 Atk / 20 Def / 252 Spe
Adamant Nature
- Drain Punch
- Roar
- Substitute
- Swords Dance
";
$g13556 = "Drapion @ Leftovers
Ability: Keen Eye
Tera Type: &
EVs: 204 HP / 48 Atk / 84 Def / 4 SpD / 168 Spe
Jolly Nature
- Poison Jab
- Knock Off
- Protect
- Swords Dance
";
$g13565 = "Machamp @ Lum Berry
Ability: No Guard
Tera Type: &
EVs: 96 HP / 144 Atk / 16 SpD / 252 Spe
Adamant Nature
- Dynamic Punch
- Stone Edge
- Darkest Lariat
- Bulk Up
";
$g13574 = "Machamp @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 188 HP / 252 Atk / 8 SpD / 60 Spe
Adamant Nature
- Close Combat
- Darkest Lariat
- Facade
- Protect
";
$g13583 = "Machamp @ Assault Vest
Ability: No Guard
Tera Type: &
EVs: 252 HP / 40 Atk / 208 SpD / 8 Spe
Adamant Nature
- Dynamic Punch
- Knock Off
- Stone Edge
- Poison Jab
";
$g13592 = "Machamp @ Leftovers
Ability: No Guard
Tera Type: &
EVs: 252 HP / 56 Atk / 200 Def
Impish Nature
- Dynamic Punch
- Knock Off
- Encore
- Protect
";
$g13601 = "Incineroar @ Lum Berry
Ability: Blaze
Tera Type: &
EVs: 204 HP / 92 Atk / 8 Def / 204 Spe
Jolly Nature
- Flare Blitz
- Knock Off
- Low Kick
- Bulk Up
";
$g13610 = "Tapu Bulu @ Lum Berry
Ability: Grassy Surge
Tera Type: &
EVs: 168 Atk / 112 Def / 228 Spe
Jolly Nature
- Horn Leech
- High Horsepower
- Close Combat
- Swords Dance
";
$g13619 = "Cinderace @ Lum Berry
Ability: Libero
Tera Type: &
EVs: 240 Atk / 16 Def / 4 SpD / 248 Spe
Jolly Nature
- Pyro Ball
- Gunk Shot
- Low Kick
- Protect
";
$g13628 = "Genesect @ Life Orb
Ability: Download
Tera Type: &
EVs: 140 HP / 252 Atk / 116 Spe
Naughty Nature
- Iron Head
- Ice Beam
- Giga Impact
- Shift Gear
";
$g13637 = "Tapu Lele @ Custap Berry
Ability: Psychic Surge
Tera Type: &
EVs: 148 HP / 80 Def / 128 SpA / 152 Spe
Modest Nature
- Psyshock
- Moonblast
- Shadow Ball
- Calm Mind
";
$g13646 = "Dragapult @ Life Orb
Ability: Clear Body
Tera Type: &
EVs: 32 HP / 140 Atk / 232 SpA / 104 Spe
Hasty Nature
- Draco Meteor
- Phantom Force
- Disable
- Substitute
";
$g13655 = "Dragapult @ Weakness Policy
Ability: Infiltrator
Tera Type: &
EVs: 76 HP / 220 Def / 212 Spe
Timid Nature
- Hex
- Will-O-Wisp
- Disable
- Substitute
";
$g13664 = "Alakazam @ Leftovers
Ability: Magic Guard
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psychic
- Focus Blast
- Disable
- Substitute
";
$g13673 = "Armarouge @ Choice Specs
Ability: Flash Fire
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Armor Cannon
- Psyshock
- Tera Blast
- Lava Plume
";
$g13682 = "Sneasler @ White Herb
Ability: Unburden
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Gunk Shot
- Close Combat
- Acrobatics
- Swords Dance
";
$g13691 = "Talonflame @ Heavy-Duty Boots
Ability: Flame Body
Tera Type: &
EVs: 160 HP / 92 Atk / 4 SpA / 252 Spe
Naughty Nature
- Brave Bird
- Tera Blast
- Roost
- Swords Dance
";
$g13700 = "Ditto @ Bright Powder
Ability: Imposter
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Transform
-
-
-
";
$g13710 = "Basculegion (M) @ Choice Scarf
Ability: Adaptability
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Phantom Force
- Wave Crash
- Head Smash
- Facade
";
$g13719 = "Enamorus @ Sitrus Berry
Ability: Contrary
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Play Rough
- Iron Head
- Superpower
- Protect
";
$g13728 = "Enamorus @ Choice Scarf
Ability: Contrary
Tera Type: &
EVs: 108 HP / 252 Atk / 148 Spe
Adamant Nature
- Superpower
-
-
-
";
$g13737 = "Ursaluna @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Adamant Nature
- Facade
- Headlong Rush
- Fling
- Protect
";
$g13746 = "Meowscarada @ Expert Belt
Ability: Protean
Tera Type: &
EVs: 100 HP / 108 Atk / 100 Def / 100 SpD / 100 Spe
Nature
- Flower Trick
- Knock Off
- Low Kick
- Toxic Spikes
";
$g13755 = "Annihilape @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 252 HP / 36 Def / 220 SpD
Careful Nature
- Rage Fist
-
-
-
";
$g13764 = "Naclstack @ Eviolite
Ability: Purifying Salt
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Salt Cure
- Body Press
- Recover
- Iron Defense
";
$g13773 = "Palafin @ Sticky Barb
Ability: Zero to Hero
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Jet Punch
- Drain Punch
- Bounce
- Bulk Up
";
$g13782 = "Wo-Chien @ Leftovers
Ability: Tablets of Ruin
Tera Type: &
EVs: 100 HP / 104 Atk / 100 Def / 100 SpA / 100 SpD / 4 Spe
Nature
- Knock Off
- Giga Drain
- Protect
- Leech Seed
";
$g13791 = "Wo-Chien @ Normalium Z
Ability: Tablets of Ruin
Tera Type: &
EVs: 252 HP / 188 SpA / 68 Spe
Modest Nature
- Hyper Beam
- Leaf Storm
- Stun Spore
- Protect
";
$g13800 = "Wo-Chien @ Sitrus Berry
Ability: Tablets of Ruin
Tera Type: &
EVs: 196 HP / 20 Def / 40 SpD / 252 Spe
Jolly Nature
- Knock Off
- Leech Seed
- Substitute
- Protect
";
$g13809 = "Wooper-Paldea @ Eviolite
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Gunk Shot
- Stealth Rock
- Recover
- Curse
";
$g13818 = "Scream Tail @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 216 HP / 12 Atk / 128 Def / 128 SpD / 24 Spe
Sassy Nature
- Play Rough
- Flamethrower
- Wish
- Protect
";
$g13827 = "Scream Tail @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs:
Nature
- Play Rough
- Dig
- Wish
- Bulk Up
";
$g13836 = "Scream Tail @ Black Sludge
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Light Screen
- Reflect
- Perish Song
- Trick
";
$g13845 = "Scream Tail @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Calm Mind
- Flamethrower
- Grass Knot
- Ice Beam
";
$g13854 = "Appletun @ Dragonium Z
Ability: Thick Fat
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Apple Acid
- Draco Meteor
- Recover
- Body Press
";
$g13863 = "Palafin @ Choice Specs
Ability: Zero to Hero
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Boomburst
- Draining Kiss
- Flip Turn
- Ice Beam
";
$g13872 = "Tyranitar @ Darkinium Z
Ability: Sand Stream
Tera Type: &
EVs: 64 HP / 192 Atk / 44 Def / 20 SpD / 188 Spe
Adamant Nature
- Stone Edge
- Crunch
- Ice Punch
- Substitute
";
$g13881 = "Floatzel @ Waterium Z
Ability: Water Veil
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Wave Crash
- Dig
- Protect
- Bulk Up
";
$g13890 = "Cyclizar @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 8 SpA / 140 SpD / 112 Spe
Timid Nature
- Rapid Spin
- Knock Off
- Draco Meteor
- Shed Tail
";
$g13899 = "Cyclizar @ Flame Orb
Ability: Shed Skin
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Facade
- Outrage
- Knock Off
- Shift Gear
";
$g13908 = "Cyclizar @ Choice Specs
Ability: Regenerator
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Tera Blast
- Draco Meteor
- Overheat
- Shed Tail
";
$g13917 = "Cyclizar @ Sitrus Berry
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 48 Atk / 48 Def / 112 SpD / 48 Spe
Nature
- Fire Fang
- Protect
- Body Slam
- Shed Tail
";
$g13926 = "Espathra @ Kee Berry
Ability: Opportunist
Tera Type: &
EVs: 184 HP / 56 SpA / 16 SpD / 252 Spe
Timid Nature
- Psyshock
- Energy Ball
- Roost
- Calm Mind
";
$g13935 = "Espathra @ Sitrus Berry
Ability: Speed Boost
Tera Type: &
EVs:
Nature
- Stored Power
- Tera Blast
- Roost
- Calm Mind
";
$g13944 = "Espathra @ Aguav Berry
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Lax Nature
- Lumina Crash
- Dazzling Gleam
- Roost
- Calm Mind
";
$g13953 = "Espathra @ Leftovers
Ability: Speed Boost
Tera Type: &
EVs: 196 HP / 252 Def / 40 SpA / 20 SpD
Modest Nature
- Lumina Crash
- Hypnosis
- Substitute
- Calm Mind
";
$g13962 = "Iron Hands @ Assault Vest
Ability: Quark Drive
Shiny: Yes
Tera Type: &
EVs: 120 Atk / 136 Def / 252 SpD
Adamant Nature
- Wild Charge
- Close Combat
- Ice Punch
- Fake Out
";
$g13972 = "Glimmora @ Air Balloon
Ability: Corrosion
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Power Gem
- Protect
- Spikes
- Toxic
";
$g13981 = "Breloom @ Choice Band
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Bullet Seed
- Mach Punch
- Gunk Shot
- Facade
";
$g13990 = "Rotom-Frost @ Icium Z
Ability: Levitate
Tera Type: &
EVs: 56 HP / 148 SpA / 52 SpD / 252 Spe
Calm Nature
- Thunderbolt
- Blizzard
- Will-O-Wisp
- Substitute
";
$g13999 = "Dachsbun @ Leftovers
Ability: Well-Baked Body
Tera Type: &
EVs:
Nature
- Play Rough
- Body Press
- Protect
- Wish
";
$g14008 = "Dachsbun @ Choice Band
Ability: Well-Baked Body
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Play Rough
- Body Press
- Ice Fang
- Psychic Fangs
";
$g14017 = "Chesnaught @ Leftovers
Ability: Bulletproof
Tera Type: &
EVs: 252 HP / 20 Def / 236 Spe
Impish Nature
- Body Press
- Trailblaze
- Synthesis
- Iron Defense
";
$g14026 = "Chien-Pao @ Weakness Policy
Ability: Sword of Ruin
Tera Type: &
EVs: 4 HP / 72 Atk / 252 Def / 180 Spe
Impish Nature
- Ice Spinner
- Crunch
- Sucker Punch
- Snowscape
";
$g14035 = "Mew @ Normalium Z
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 144 Def / 112 Spe
Bold Nature
- Transform
- Light Screen
- Reflect
- Thunder Wave
";
$g14044 = "Skeledirge @ Assault Vest
Ability: Blaze
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Torch Song
- Blast Burn
- Earth Power
- Night Shade
";
$g14053 = "Skeledirge @ Kasib Berry
Ability: Unaware
Tera Type: &
EVs: 248 HP / 80 Def / 16 SpA / 160 SpD / 4 Spe
Modest Nature
- Will-O-Wisp
- Snarl
- Torch Song
- Slack Off
";
$g14062 = "Indeedee-F @ Colbur Berry
Ability: Psychic Surge
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Follow Me
- Protect
- Trick Room
- Helping Hand
";
$g14071 = "Cetitan @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Icicle Crash
- Play Rough
- Liquidation
- Ice Shard
";
$g14080 = "Chi-Yu @ Firium Z
Ability: Beads of Ruin
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Inferno
- Will-O-Wisp
- Memento
- Nasty Plot
";
$g14089 = "Gallade @ Choice Scarf
Ability: Sharpness
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Psycho Cut
- Sacred Sword
- Knock Off
- Trick
";
$g14098 = "Metagross @ Metagrossite
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Meteor Mash
- Thunder Punch
- Ice Punch
- Protect
";
$g14107 = "Quaquaval @ Assault Vest
Ability: Moxie
Tera Type: &
EVs: 152 HP / 104 Atk / 252 Spe
Jolly Nature
- Rapid Spin
- Aqua Step
- Low Sweep
- Icy Wind
";
$g14116 = "Iron Moth @ Heavy-Duty Boots
Ability: Quark Drive
Tera Type: &
EVs: 64 Def / 252 SpA / 192 Spe
Timid Nature
- Fire Blast
- Sludge Wave
- Dazzling Gleam
- Toxic Spikes
";
$g14125 = "Donphan @ Red Card
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 64 Atk / 96 Def / 100 SpD
Adamant Nature
- Stealth Rock
- Endure
- Earthquake
- Ice Shard
";
$g14134 = "Kilowattrel @ Heavy-Duty Boots
Ability: Wind Power
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Discharge
- Hurricane
- Roost
- Volt Switch
";
$g14143 = "Meowscarada @ Liechi Berry
Ability: Overgrow
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Knock Off
- Flower Trick
- Spikes
";
$g14153 = "Hippowdon @ Figy Berry
Ability: Sand Stream
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Impish Nature
- Stockpile
- Slack Off
- Sand Tomb
- Thunder Fang
";
$g14162 = "Celebi @ Colbur Berry
Ability: Natural Cure
Tera Type: &
EVs: 240 HP / 244 Def / 24 Spe
Bold Nature
- U-turn
- Stealth Rock
- Recover
- Psychic
";
$g14171 = "Slaking @ Assault Vest
Ability: Truant
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe
Careful Nature
- Mega Kick
- Bulldoze
- Focus Punch
- Sucker Punch
";
$g14180 = "Mareanie @ Eviolite
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Recover
- Infestation
- Toxic
- Stockpile
";
$g14189 = "Blissey @ Normalium Z
Ability: Serene Grace
Tera Type: &
EVs: 100 Def / 252 SpA / 156 Spe
Modest Nature
- Calm Mind
- Hyper Beam
- Fire Blast
- Ice Beam
";
$g14198 = "Sandy Shocks @ Booster Energy
Ability: Protosynthesis
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Earth Power
- Thunderbolt
- Tera Blast
- Stealth Rock
";
$g14208 = "Spidops @ Choice Band
Ability: Stakeout
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- U-turn
- Leech Life
- Sucker Punch
- Low Kick
";
$g14217 = "Spidops @ Custap Berry
Ability: Insomnia
Tera Type: &
EVs: 252 Spe
Jolly Nature
- Endure
- Sticky Web
- Spikes
- Toxic Spikes
";
$g14226 = "Glalie @ Glalitite
Ability: Refrigerate
Tera Type: &
EVs: 100 Atk / 152 Def / 4 SpD / 252 Spe
Jolly Nature
- Facade
- Crunch
- Disable
- Light Screen
";
$g14235 = "Delphox @ Blunder Policy
Ability: Magician
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe
Modest Nature
- Encore
- Fire Blast
- Focus Blast
- Hypnosis
";
$g14244 = "Oricorio @ Sitrus Berry
Ability: Dancer
Shiny: Yes
Tera Type: &
EVs: 152 HP / 100 SpA / 4 SpD / 252 Spe
Timid Nature
- Quiver Dance
- Revelation Dance
- Roost
- Hurricane
";
$g14254 = "Electrode-Hisui @ Leftovers
Ability: Soundproof
Tera Type: &
EVs: 216 HP / 252 SpA / 40 Spe
Timid Nature
- Chloroblast
- Thunder
- Leech Seed
- Substitute
";
$g14263 = "Wyrdeer @ Sitrus Berry
Ability: Intimidate
Tera Type: &
EVs: 100 HP / 196 SpA / 212 Spe
Modest Nature
- Calm Mind
- Tera Blast
- Agility
- Psychic
";
$g14272 = "Toedscruel @ Groundium Z
Ability: Mycelium Might
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Timid Nature
- Rapid Spin
- Earth Power
- Leaf Storm
- Leech Seed
";
$g14281 = "Hoopa @ Leftovers
Ability: Magician
Tera Type: &
EVs: 252 HP / 100 Def / 56 SpA / 100 Spe
Modest Nature
- Hyperspace Hole
- Hidden Power [Ghost]
- Signal Beam
- Charge Beam
";
$g14290 = "Houndoom @ Houndoominite
Ability: Solar Power
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Reversal
- Fire Fang
- Crunch
";
$g14299 = "Houndoom @ Custap Berry
Ability: Unnerve
Tera Type: &
EVs: 252 Atk / 252 SpA
Quiet Nature
- Fire Blast
- Dark Pulse
- Endure
- Reversal
";
$g14308 = "Dachsbun @ Rocky Helmet
Ability: Well-Baked Body
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Bold Nature
- Wish
- Lick
- Draining Kiss
- Protect
";
$g14317 = "Crabominable @ Assault Vest
Ability: Hyper Cutter
Tera Type: &
EVs: 252 HP / 100 Atk / 156 SpD
Adamant Nature
- Ice Hammer
- Close Combat
- Crabhammer
- Gunk Shot
";
$g14326 = "Baxcalibur @ Loaded Dice
Ability: Thermal Exchange
Tera Type: &
EVs: 252 Def / 4 SpD / 252 Spe
Jolly Nature
- Dragon Dance
- Icicle Spear
- Body Press
- Crunch
";
$g14335 = "Ting-Lu @ Maranga Berry
Ability: Vessel of Ruin
Tera Type: &
EVs: 252 Def / 252 SpD
Bold Nature
- Rest
- Sleep Talk
- Whirlwind
- Mud-Slap
";
$g14344 = "Quaquaval @ Choice Scarf
Ability: Torrent
Tera Type: &
EVs: 68 Atk / 252 SpD / 188 Spe
Adamant Nature
- U-turn
- Aqua Cutter
- Close Combat
- Ice Spinner
";
$g14353 = "Quaquaval @ Assault Vest
Ability: Moxie
Shiny: Yes
Tera Type: &
EVs: 132 Atk / 124 SpD / 252 Spe
Adamant Nature
- Aqua Cutter
- Aqua Step
- Aqua Jet
- Chilling Water
";
$g14363 = "Palafin @ Eject Pack
Ability: Zero to Hero
Tera Type: &
EVs: 100 Atk / 152 Def / 252 Spe
Impish Nature
- Dive
- Close Combat
- Acrobatics
- Counter
";
$g14372 = "Maushold @ Loaded Dice
Ability: Friend Guard
Tera Type: &
EVs: 200 Atk / 4 Def / 52 SpD / 252 Spe
Jolly Nature
- Tidy Up
- Population Bomb
- Bullet Seed
- Thief
";
$g14381 = "Tinkaton @ Ice Gem
Ability: Mold Breaker
Tera Type: &
EVs: 112 HP / 252 Atk / 80 Def / 64 SpD
Brave Nature
- Knock Off
- Thunder Wave
- Ice Hammer
- Stealth Rock
";
$g14390 = "Brute Bonnet @ Sticky Barb
Ability: Protosynthesis
Tera Type: &
EVs: 36 Atk / 96 Def / 124 SpD / 252 Spe
Jolly Nature
- Stun Spore
- Synthesis
- Tera Blast
- Trailblaze
";
$g14399 = "Iron Bundle @ Heavy-Duty Boots
Ability: Quark Drive
Tera Type: &
EVs: 48 HP / 40 Def / 40 SpA / 252 SpD / 32 Spe
Calm Nature
- Ice Beam
- Encore
- Whirlpool
- U-turn
";
$g14408 = "Great Tusk @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 100 Def / 156 SpD / 252 Spe
Jolly Nature
- Rapid Spin
- Knock Off
- Taunt
- Endeavor
";
$g14417 = "Iron Jugulis @ Darkinium Z
Ability: Quark Drive
Tera Type: &
EVs: 16 HP / 52 Def / 196 SpA / 44 SpD / 200 Spe
Timid Nature
- Taunt
- Charge Beam
- Hurricane
- Focus Blast
";
$g14426 = "Iron Jugulis @ Electric Seed
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 132 SpD / 124 Spe
Adamant Nature
- Electric Terrain
- Acrobatics
- Taunt
- Work Up
";
$g14435 = "Iron Thorns @ Loaded Dice
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Rock Blast
- Pin Missile
- Dig
";
$g14444 = "Iron Thorns @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- Swords Dance
- Rock Slide
- Thunder Punch
- Ice Punch
";
$g14453 = "Iron Thorns @ Leftovers
Ability: Quark Drive
Tera Type: &
EVs: 156 HP / 100 Atk / 252 Spe
Jolly Nature
- Substitute
- Dig
- Protect
- Dragon Tail
";
$g14462 = "Iron Thorns @ Leftovers
Ability: Quark Drive
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Careful Nature
- Stealth Rock
- Volt Switch
- Rock Blast
- Ice Punch
";
$g14471 = "Iron Thorns @ Choice Scarf
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Volt Switch
- Ice Punch
- Wild Charge
";
$g14480 = "Iron Thorns @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 156 HP / 252 SpA / 100 Spe
Modest Nature
- Thunderbolt
- Ice Beam
- Flamethrower
- Spikes
";
$g14489 = "Iron Thorns @ Chesto Berry
Ability: Quark Drive
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe
Modest Nature
- Spikes
- Tera Blast
- Volt Switch
- Rest
";
$g14498 = "Iron Thorns @ Leftovers
Ability: Quark Drive
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Swords Dance
- Rock Blast
- Dig
";
$g14507 = "Iron Valiant @ Iapapa Berry
Ability: Quark Drive
Shiny: Yes
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Knock Off
- Encore
- Icy Wind
- Thunder Wave
";
$g14517 = "Iron Hands @ Maranga Berry
Ability: Quark Drive
Shiny: Yes
Tera Type: &
EVs: 4 Atk / 252 Def / 252 SpD
Impish Nature
- Rest
- Sleep Talk
- Seismic Toss
- Force Palm
";
$g14527 = "Flapple @ Dragonium Z
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Outrage
- Dragon Dance
- Sucker Punch
- Grav Apple
";
$g14536 = "Brambleghast @ Leftovers
Ability: Wind Rider
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Bold Nature
- Infestation
- Strength Sap
- Rapid Spin
- Confuse Ray
";
$g14545 = "Chien-Pao @ Choice Specs
Ability: Sword of Ruin
Tera Type: &
EVs: 152 HP / 4 Def / 252 SpA / 100 Spe
Modest Nature
- Dark Pulse
- Tera Blast
- Blizzard
- Ruination
";
$g14554 = "Garganacl @ Quick Claw
Ability: Purifying Salt
Tera Type: &
EVs: 248 HP / 100 Atk / 60 Def / 100 SpD
Adamant Nature
- Curse
- Recover
- Tera Blast
- Avalanche
";
$g14563 = "Gholdengo @ Eject Pack
Ability: Good as Gold
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe
Calm Nature
- Make It Rain
- Shadow Ball
- Tera Blast
- Rest
";
$g14572 = "Great Tusk @ Maranga Berry
Ability: Protosynthesis
Tera Type: &
EVs: 16 HP / 100 Atk / 252 Def / 140 Spe
Impish Nature
- Bulk Up
- Body Press
- Knock Off
- Dig
";
$g14581 = "Houndstone @ Choice Scarf
Ability: Fluffy
Tera Type: &
EVs: 60 Atk / 196 SpD / 252 Spe
Jolly Nature
- Last Respects
- Destiny Bond
- Tera Blast
- Trick
";
$g14590 = "Baxcalibur @ Red Card
Ability: Thermal Exchange
Tera Type: &
EVs: 104 HP / 156 Atk / 12 Def / 4 SpA / 80 SpD / 152 Spe
Adamant Nature
- Dragon Dance
- Tera Blast
- Giga Impact
- Dig
";
$g14599 = "Roaring Moon @ Choice Specs
Ability: Protosynthesis
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Dark Pulse
- Draco Meteor
- Dragon Pulse
- Fire Blast
";
$g14608 = "Arboliva @ Normal Gem
Ability: Seed Sower
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe
Modest Nature
- Leech Seed
- Strength Sap
- Tera Blast
- Hyper Beam
";
$g14617 = "Orthworm @ Iapapa Berry
Ability: Earth Eater
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe
Calm Nature
- Shed Tail
-
-
-
";
$g14626 = "Shed Tail @ Eject Button
Ability: Beads of Ruin
Tera Type: &
EVs: 248 HP / 160 Def / 100 Spe
Bold Nature
- Flame Charge
- Dark Pulse
- Lava Plume
- Ruination
";
$g14635 = "Flamigo @ Kings Rock
Ability: Scrappy
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bulk Up
- Liquidation
- Throat Chop
- Double Kick
";
$g14644 = "Cetitan @ Assault Vest
Ability: Thick Fat
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpD
Adamant Nature
- Ice Spinner
- Facade
- Bounce
- Play Rough
";
$g14653 = "Wo-Chien @ Kee Berry
Ability: Tablets of Ruin
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Body Press
- Stun Spore
- Ruination
- Ingrain
";
$g14662 = "Scream Tail @ Kings Rock
Ability: Protosynthesis
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Calm Mind
- Boomburst
- Dazzling Gleam
- Psychic
";
$g14671 = "Clodsire @ Maranga Berry
Ability: Unaware
Tera Type: &
EVs: 92 HP / 252 Def / 164 SpD
Impish Nature
- Curse
- Recover
- Megahorn
- Tera Blast
";
$g14680 = "Pawmot @ Leppa Berry
Ability: Natural Cure
Tera Type: &
EVs: 1 HP / 1 Atk / 1 Def / 1 SpA / 252 SpD
Sassy Nature
- Revival Blessing
- Wild Charge
- Mach Punch
-
";
$g14689 = "Revival Blessing @ Maranga Berry
Ability: Orichalcum Pulse
Tera Type: &
EVs: 1 HP / 1 Atk / 1 Def / 1 SpA / 1 SpD / 1 Spe
Serious Nature
- Bulk Up
- Agility
- Acrobatics
- Counter
";
$g14698 = "Iron Jugulis @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 104 HP / 4 Def / 148 SpA / 252 Spe
Modest Nature
- Dragon Pulse
- Earth Power
- Flamethrower
- Hydro Pump
";
$g14707 = "Greninja @ Choice Scarf
Ability: Protean
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- U-turn
- Ice Punch
- Low Kick
- Night Slash
";
$g14716 = "Typhlosion-Hisui @ Heavy-Duty Boots
Ability: Frisk
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Eruption
- Shadow Ball
- Overheat
- Protect
";
$g14725 = "Kleavor @ Heavy-Duty Boots
Ability: Sharpness
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Axe
- U-turn
- Psycho Cut
- Close Combat
";
$g14734 = "Braviary-Hisui @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 248 HP / 76 Def / 184 SpA
Modest Nature
- Hurricane
- Heat Wave
- Roost
- Protect
";
$g14743 = "Heracross @ Heracronite
Ability: Moxie
Tera Type: &
EVs: 68 HP / 188 Atk / 252 Spe
Jolly Nature
- Pin Missile
- Bulk Up
- Substitute
- Focus Blast
";
$g14752 = "Muk-Alola @ Iapapa Berry
Ability: Gluttony
Tera Type: &
EVs: 252 HP / 64 Atk / 192 Def
Adamant Nature
- Gunk Shot
- Knock Off
- Moonblast
- Recycle
";
$g14761 = "Empoleon @ Chople Berry
Ability: Torrent
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Defog
- Stealth Rock
- Hydro Cannon
- Protect
";
$g14770 = "Empoleon @ Waterium Z
Ability: Torrent
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hydro Cannon
- Flash Cannon
- Knock Off
- Substitute
";
$g14779 = "Mew @ Mewnium Z
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Expanding Force
- Psychic
- Soft-Boiled
- Calm Mind
";
$g14788 = "Lopunny @ Lopunnite
Ability: Scrappy
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Close Combat
- Return
- Encore
- Protect
";
$g14797 = "Zamazenta @ Sticky Barb
Ability: Dauntless Shield
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Body Press
- Stone Edge
- Crunch
- Iron Defense
";
$g14806 = "Latios @ Latiosite
Ability: Levitate
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Earthquake
- Psychic
- Draco Meteor
- Protect
";
$g14815 = "Torterra @ Choice Scarf
Ability: Overgrow
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Wood Hammer
- Earthquake
- Superpower
- Rock Slide
";
$g14824 = "Torterra @ Sitrus Berry
Ability: Overgrow
Tera Type: &
EVs: 252 HP / 124 Atk / 100 Def / 4 SpD / 28 Spe
Adamant Nature
- Earthquake
- Heavy Slam
- Seed Bomb
- Stealth Rock
";
$g14833 = "Arcanine-Hisui @ Choice Band
Ability: Rock Head
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flare Blitz
- Head Smash
- Wild Charge
- Extreme Speed
";
$g14842 = "Hoopa-Unbound @ Leftovers
Ability: Magician
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Dark Pulse
- Toxic
- Substitute
- Protect
";
$g14851 = "Veluza @ Life Orb
Ability: Sharpness
Tera Type: &
EVs: 252 HP / 84 Atk / 172 Spe
Naughty Nature
- Aqua Cutter
- Psycho Cut
- Tera Blast
- Fillet Away
";
$g14860 = "Hoopa-Unbound @ Blunder Policy
Ability: Magician
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Lax Nature
- Charge Beam
- Psyshock
- Focus Blast
- Gunk Shot
";
$g14869 = "Blaziken @ Blazikenite
Ability: Speed Boost
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flare Blitz
- High Jump Kick
- Protect
- Bulk Up
";
$g14878 = "Altaria @ Altarianite
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Hyper Beam
- Fire Blast
- Roost
- Cotton Guard
";
$g14887 = "Altaria @ Altarianite
Ability: Natural Cure
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Double-Edge
- Earthquake
- Roost
- Dragon Dance
";
$g14896 = "Serperior @ Assault Vest
Ability: Contrary
Tera Type: &
EVs: 168 HP / 100 Def / 40 SpA / 100 SpD / 100 Spe
Nature
- Leaf Storm
- Mirror Coat
-
-
";
$g14905 = "Serperior @ Choice Scarf
Ability: Contrary
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Mild Nature
- Leaf Storm
- Knock Off
- Dragon Pulse
- Glare
";
$g14914 = "Charizard @ Charizardite X
Ability: Blaze
Tera Type: &
EVs: 16 HP / 28 Atk / 16 Def / 16 SpA / 12 SpD / 16 Spe
Nature
- Flare Blitz
- Dragon Claw
- Will-O-Wisp
- Roost
";
$g14923 = "Lokix @ Life Orb
Ability: Tinted Lens
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- First Impression
- Sucker Punch
- Axe Kick
- U-turn
";
$g14932 = "Zamazenta @ Leftovers
Ability: Dauntless Shield
Tera Type: &
EVs: 216 HP / 56 Atk / 88 Def / 68 SpD / 80 Spe
Adamant Nature
- Howl
- Dig
- Trailblaze
- Iron Tail
";
$g14941 = "Alomomola @ Pecha Berry
Ability: Regenerator
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe
Bold Nature
- Calm Mind
- Protect
- Wish
- Toxic
";
$g14950 = "Phione @ Leftovers
Ability: Hydration
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Bold Nature
- Whirlpool
- Knock Off
- U-turn
- Protect
";
$g14959 = "Alcremie-Matcha-Cream @ Pecha Berry
Ability: Sweet Veil Slow Start
Tera Type: &
EVs: 248 HP / 40 Atk / 100 Def / 108 SpD / 12 Spe
Adamant Nature
- Knock Off
- Stomping Tantrum
- Confuse Ray
- Protect
";
$g14968 = "Jumpluff @ Heavy-Duty Boots
Ability: Infiltrator
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Timid Nature
- U-turn
- Infestation
- Encore
- Stun Spore
";
$g14977 = "Ursaring @ Eviolite
Ability: Guts
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe
Adamant Nature
- Rest
- Sleep Talk
- Bulk Up
- Mega Kick
";
$g14986 = "Bellibolt @ Assault Vest
Ability: Electromorphosis
Tera Type: &
EVs: 252 HP / 116 SpA / 140 SpD
Modest Nature
- Thunderbolt
- Volt Switch
- Water Pulse
- Parabolic Charge
";
$g14995 = "Cherrim @ Sitrus Berry
Ability: Flower Gift
Tera Type: &
EVs: 160 HP / 248 SpA / 100 Spe
Modest Nature
- Sunny Day
- Morning Sun
- Solar Beam
- Weather Ball
";
$g15004 = "Ambipom @ Red Card
Ability: Technician
Tera Type: &
EVs: 120 HP / 252 Atk / 136 Spe
Jolly Nature
- Fake Out
- Last Resort
-
-
";
$g15013 = "Banette @ Banettite
Ability: Insomnia
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Careful Nature
- Knock Off
- Encore
- Pain Split
- Thunder Wave
";
$g15022 = "Banette @ Banettite
Ability: Prankster
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Trailblaze
- Phantom Force
- Knock Off
- Disable
";
$g15031 = "Gligar @ Salac Berry
Ability: Hyper Cutter
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Jolly Nature
- Swords Dance
- Substitute
- Acrobatics
- Earthquake
";
$g15040 = "Yanmega @ Heavy-Duty Boots
Ability: Speed Boost
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Bug Buzz
- Detect
- Air Slash
- U-turn
";
$g15049 = "Granbull @ Assault Vest
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 224 Atk / 36 SpD
Adamant Nature
- Play Rough
- Fire Punch
- Close Combat
- Ice Punch
";
$g15058 = "Arbok @ Black Sludge
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Coil
- Gunk Shot
- Aqua Tail
- Fire Fang
";
$g15067 = "Smeargle @ Leftovers
Ability: Own Tempo
Tera Type: &
EVs: 248 HP / 8 Def / 252 Spe
Jolly Nature
- Rapid Spin
- Grass Whistle
- Substitute
- Dragon Tail
";
$g15076 = "Staraptor @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 252 Spe
Adamant Nature
- Defog
- Roost
- Close Combat
- Brave Bird
";
$g15085 = "Oricorio-Sensu @ Iapapa Berry
Ability: Dancer
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Quiver Dance
- Hurricane
- Taunt
- Revelation Dance
";
$g15095 = "Camerupt @ Custap Berry
Ability: Solid Rock
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Quiet Nature
- Stealth Rock
- Overheat
- Earth Power
- Yawn
";
$g15104 = "Camerupt @ Passho Berry
Ability: Solid Rock
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpA
Quiet Nature
- Overheat
- Trailblaze
- Earth Power
- Tera Blast
";
$g15113 = "Bastiodon @ Choice Specs
Ability: Sturdy
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Flash Cannon
- Ancient Power
- Fire Blast
- Thunderbolt
";
$g15122 = "Kricketune @ Choice Band
Ability: Technician
Tera Type: &
EVs: 248 HP / 252 Atk / 4 SpD / 4 Spe
Adamant Nature
- Bug Bite
- Aerial Ace
- Power-Up Punch
- Sticky Web
";
$g15131 = "Emboar @ Assault Vest
Ability: Blaze
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Superpower
- Flame Charge
- Wild Charge
- Flare Blitz
";
$g15140 = "Eelektross @ Assault Vest
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 Spe
Modest Nature
- Volt Switch
- Acid Spray
- Giga Drain
- Flamethrower
";
$g15149 = "Florges-Orange @ Sitrus Berry
Ability: Flower Veil
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Calm Mind
- Moonblast
- Tera Blast
- Giga Drain
";
$g15158 = "Furfrou-Dandy @ Chesto Berry
Ability: Fur Coat
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Impish Nature
- Secret Power
- Rest
- U-turn
- Endeavor
";
$g15167 = "Bruxish @ Choice Band
Ability: Strong Jaw
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Aqua Tail
- Psychic Fangs
- Ice Fang
- Poison Fang
";
$g15176 = "Mabosstiff @ Choice Band
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Jaw Lock
- Fire Fang
- Ice Fang
- Psychic Fangs
";
$g15185 = "Skeledirge @ Sitrus Berry
Ability: Unaware
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe
Modest Nature
- Torch Song
- Yawn
- Slack Off
- Belch
";
$g15194 = "Pinsir @ Pinsirite
Ability: Aerilate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Swords Dance
- Rock Tomb
- Earthquake
";
$g15203 = "Zebstrika @ Electrium Z
Ability: Lightning Rod
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunder
- Volt Switch
- Overheat
- Signal Beam
";
$g15212 = "Feraligatr @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Waterfall
- Ice Punch
- Body Slam
";
$g15221 = "Registeel @ Chesto Berry
Ability: Clear Body
Tera Type: &
EVs: 232 HP / 132 Def / 144 SpD
Careful Nature
- Curse
- Body Press
- Heavy Slam
- Rest
";
$g15230 = "Pidgeot @ Maranga Berry
Ability: Keen Eye
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Careful Nature
- Curse
- Roost
- Fly
- Steel Wing
";
$g15239 = "Carnivine @ Figy Berry
Ability: Levitate
Tera Type: &
EVs: 248 HP / 200 Atk / 60 SpD
Adamant Nature
- Power Whip
- Knock Off
- Leech Seed
- Defog
";
$g15248 = "Primeape @ Leftovers
Ability: Vital Spirit
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Focus Punch
- Gunk Shot
- Rage Fist
";
$g15258 = "Dewgong @ Leftovers
Ability: Thick Fat
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 156 Def / 96 SpD
Sassy Nature
- Whirlpool
- Perish Song
- Protect
- Dive
";
$g15268 = "Furret @ Leftovers
Ability: Frisk
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- Protect
- Substitute
- Dig
- Secret Power
";
$g15277 = "Forretress @ Zoom Lens
Ability: Sturdy
Tera Type: &
EVs: 252 HP / 32 Def / 224 SpD
Relaxed Nature
- Rapid Spin
- Spikes
- Zap Cannon
- Ice Spinner
";
$g15286 = "Spinda @ Leftovers
Ability: Own Tempo
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Fake Out
- Encore
- Protect
- Dig
";
$g15295 = "Gorebyss @ Normalium Z
Ability: Swift Swim
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Shell Smash
- Surf
- Ice Beam
- Hyper Beam
";
$g15304 = "Empoleon @ Salac Berry
Ability: Torrent
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Substitute
- Liquidation
- Knock Off
";
$g15313 = "Infernape @ Red Card
Ability: Iron Fist
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bulk Up
- Close Combat
- Thunder Punch
- Fire Punch
";
$g15322 = "Torterra @ Yache Berry
Ability: Overgrow
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Swords Dance
- Rock Polish
- Wood Hammer
- Stomping Tantrum
";
$g15331 = "Gliscor @ Razor Fang
Ability: Hyper Cutter
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Fire Fang
- Thunder Fang
- Ice Fang
";
$g15340 = "Sawsbuck-Autumn @ Normal Gem
Ability: Chlorophyll
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Headbutt
- Horn Leech
- Jump Kick
";
$g15350 = "Simipour @ Choice Specs
Ability: Torrent
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hydro Pump
- Ice Beam
- Focus Blast
- Grass Knot
";
$g15359 = "Empoleon @ Choice Specs
Ability: Torrent
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Scald
- Ice Beam
- Flash Cannon
- Grass Knot
";
$g15368 = "Empoleon @ Leftovers
Ability: Torrent
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Scald
- Stealth Rock
- Roar
- Knock Off
";
$g15377 = "Oricorio @ Heavy-Duty Boots
Ability: Dancer
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Quiver Dance
- Roost
- Revelation Dance
- Teeter Dance
";
$g15386 = "Oricorio-Pom-Pom @ Choice Specs
Ability: Dancer
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Revelation Dance
- Hurricane
- U-turn
- Tera Blast
";
$g15395 = "Kricketune @ Focus Sash
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Protect
- Sticky Web
- Knock Off
- Leech Life
";
$g15404 = "Ursaring @ Toxic Orb
Ability: Guts
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Protect
- Facade
- Close Combat
- Shadow Claw
";
$g15413 = "Toedscool @ Eviolite
Ability: Mycelium Might
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Bold Nature
- Spikes
- Rapid Spin
- Knock Off
- Protect
";
$g15422 = "Iron Moth @ Air Balloon
Ability: Quark Drive
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sunny Day
- Fire Blast
- Solar Beam
- Dazzling Gleam
";
$g15431 = "Bastiodon @ Leftovers
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 156 Def / 104 SpD
Sassy Nature
- Stealth Rock
- Metal Burst
- Focus Energy
- Protect
";
$g15440 = "Donphan @ Assault Vest
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- High Horsepower
- Knock Off
- Ice Shard
- Gunk Shot
";
$g15449 = "Meowscarada @ Heavy-Duty Boots
Ability: Protean
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Knock Off
- U-turn
- Play Rough
- Taunt
";
$g15458 = "Phione @ Choice Specs
Ability: Hydration
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Scald
- Ice Beam
- U-turn
- Ancient Power
";
$g15467 = "Gliscor @ Power Herb
Ability: Poison Heal
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Sky Attack
- Dig
- Giga Impact
";
$g15476 = "Lapras @ Choice Specs
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Hydro Pump
- Ice Beam
- Thunderbolt
- Freeze-Dry
";
$g15485 = "Crabominable @ Life Orb
Ability: Iron Fist
Tera Type: &
EVs: 160 HP / 252 Atk / 96 Spe
Adamant Nature
- Ice Hammer
- Close Combat
- Thunder Punch
- Protect
";
$g15494 = "Rabsca @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 228 Def / 4 SpA / 24 SpD
Calm Nature
- Calm Mind
- Iron Defense
- Stored Power
- Protect
";
$g15503 = "Dudunsparce-Three-Segment @ Rocky Helmet
Ability: Serene Grace
Tera Type: &
EVs: 248 HP / 252 Spe
Careful Nature
- Coil
- Roost
- Glare
- Headbutt
";
$g15512 = "Klawf @ Sitrus Berry
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 100 Atk / 92 SpD / 68 Spe
Adamant Nature
- Stealth Rock
- Knock Off
- Crabhammer
- Rock Blast
";
$g15521 = "Slither Wing @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bulk Up
- Leech Life
- Close Combat
- Flame Charge
";
$g15530 = "Slither Wing @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Careful Nature
- Leech Life
- First Impression
- U-turn
- Lunge
";
$g15539 = "Florges @ Red Card
Ability: Flower Veil
Tera Type: &
EVs:
Nature
- Defog
- Endeavor
- Moonblast
- Chilling Water
";
$g15548 = "Chimecho @ Rocky Helmet
Ability: Levitate
Tera Type: &
EVs: 248 HP / 160 Def / 100 SpD
Calm Nature
- Defog
- Psychic
- Knock Off
- Recover
";
$g15557 = "Latios @ Latiosite
Ability: Levitate
Tera Type: &
EVs: 232 HP / 48 Def / 92 SpA / 80 SpD / 56 Spe
Modest Nature
- Defog
- Future Sight
- Toxic
- Mystical Fire
";
$g15566 = "Minior-Violet @ Flying Gem
Ability: Shields Down
Tera Type: &
EVs: 116 HP / 152 Atk / 72 Def / 60 SpD / 108 Spe
Adamant Nature
- Shell Smash
- Acrobatics
- Stone Edge
- Self-Destruct
";
$g15575 = "Goodra-Hisui @ Eject Pack
Ability: Gooey
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Draco Meteor
- Fire Blast
- Flash Cannon
- Toxic
";
$g15584 = "Scyther @ Heavy-Duty Boots
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Defog
- Roost
- U-turn
- Knock Off
";
$g15593 = "Cinderace @ Expert Belt
Ability: Libero
Tera Type: &
EVs: 20 HP / 160 Atk / 40 Def / 36 SpA / 252 Spe
Naive Nature
- Work Up
- Pyro Ball
- Electro Ball
- Court Change
";
$g15602 = "Castform @ Leftovers
Ability: Forecast
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Rain Dance
- Protect
- Weather Ball
- Thunder
";
$g15611 = "Parasect @ Leftovers
Ability: Effect Spore
Tera Type: &
EVs: 248 HP / 160 Def / 100 SpD
Impish Nature
- Spore
- Knock Off
- Protect
- Dig
";
$g15620 = "Ditto @ Eject Button
Ability: Imposter
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g15629 = "Swellow @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Protect
- Facade
- Fly
- Brave Bird
";
$g15638 = "Serperior @ Leftovers
Ability: Contrary
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Defog
- Leaf Tornado
- Knock Off
- Aromatherapy
";
$g15647 = "Samurott-Hisui @ Assault Vest
Ability: Sharpness
Tera Type: &
EVs: 192 HP / 140 Atk / 60 Def / 24 SpD / 92 Spe
Adamant Nature
- Aqua Cutter
- Ceaseless Edge
- Megahorn
- Sucker Punch
";
$g15656 = "Iron Treads @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Stomping Tantrum
- Iron Head
- Ice Spinner
- Megahorn
";
$g15665 = "Alomomola @ Choice Band
Ability: Regenerator
Tera Type: &
EVs: 252 Atk / 252 Def / 4 SpD
Adamant Nature
- Waterfall
- Knock Off
- Wake-Up Slap
- Healing Wish
";
$g15674 = "Shaymin @ Normalium Z
Ability: Natural Cure
Shiny: Yes
Tera Type: &
EVs: 192 HP / 100 Def / 52 SpA / 132 SpD / 32 Spe
Bold Nature
- Celebrate
- Leaf Storm
- Earth Power
- Grass Whistle
";
$g15684 = "Shaymin @ Grass Gem
Ability: Natural Cure
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Seed Bomb
- Facade
- Quick Attack
";
$g15694 = "Shaymin @ Eject Button
Ability: Natural Cure
Tera Type: &
EVs: 128 HP / 128 SpA / 252 Spe
Timid Nature
- Seed Flare
- Toxic
- Earth Power
- Quick Attack
";
$g15703 = "Shaymin @ Eject Pack
Ability: Natural Cure
Tera Type: &
EVs: 248 HP / 252 SpD / 8 Spe
Calm Nature
- Aromatherapy
- Leaf Storm
- Healing Wish
- Earth Power
";
$g15712 = "Chesnaught @ Salac Berry
Ability: Bulletproof
Tera Type: &
EVs: 4 Def / 252 SpD / 252 Spe
Jolly Nature
- Spikes
- Endeavor
- Substitute
- Pain Split
";
$g15721 = "Chesnaught @ Assault Vest
Ability: Bulletproof
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA
Brave Nature
- Seed Bomb
- Drain Punch
- Stone Edge
- Tera Blast
";
$g15730 = "Chesnaught @ White Herb
Ability: Overgrow
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Seed Bomb
- Close Combat
- Protect
";
$g15739 = "Chesnaught @ Salac Berry
Ability: Overgrow
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Jolly Nature
- Substitute
- Belly Drum
- Drain Punch
- Seed Bomb
";
$g15748 = "Greninja @ Rocky Helmet
Ability: Protean
Tera Type: &
EVs: 96 Atk / 200 Def / 128 SpA / 84 Spe
Naive Nature
- Substitute
- Rock Tomb
- Hydro Cannon
- Hidden Power [Fire]
";
$g15757 = "Greninja @ Expert Belt
Ability: Protean
Tera Type: &
EVs: 32 HP / 104 Def / 252 SpA / 36 SpD / 84 Spe
Modest Nature
- Water Pledge
- Ice Beam
- Grass Knot
- Extrasensory
";
$g15766 = "Greninja @ Water Gem
Ability: Battle Bond
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Scald
- Dark Pulse
- Toxic Spikes
- Work Up
";
$g15775 = "Greninja @ Normalium Z
Ability: Protean
Tera Type: &
EVs: 80 HP / 100 Atk / 108 Def / 64 SpA / 80 SpD / 76 Spe
Naughty Nature
- Happy Hour
- Extrasensory
- Rock Slide
- Low Kick
";
$g15784 = "Deoxys-Defense @ White Herb
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Psycho Boost
- Focus Blast
- Signal Beam
";
$g15793 = "Delcatty @ Leftovers
Ability: Wonder Skin
Shiny: Yes
Tera Type: &
EVs: 248 HP / 200 SpA / 8 SpD / 52 Spe
Modest Nature
- Calm Mind
- Thunderbolt
- Ice Beam
- Laser Focus
";
$g15803 = "Infernape @ Fightinium Z
Ability: Blaze
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Calm Mind
- Vacuum Wave
- Fire Blast
- Encore
";
$g15812 = "Jumpluff @ Flying Gem
Ability: Infiltrator
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Sleep Powder
- Swords Dance
- Seed Bomb
- Acrobatics
";
$g15821 = "Bronzong @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 48 Def / 152 SpA / 56 SpD
Modest Nature
- Calm Mind
- Tera Blast
- Power Gem
- Future Sight
";
$g15830 = "Crobat @ Heavy-Duty Boots
Ability: Inner Focus
Tera Type: &
EVs: 224 HP / 108 SpA / 176 Spe
Timid Nature
- Nasty Plot
- Air Slash
- Roost
- Giga Drain
";
$g15839 = "Giratina @ Red Card
Ability: Pressure
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Timid Nature
- Calm Mind
- Dark Pulse
- Thunderbolt
- Tera Blast
";
$g15848 = "Honchkrow @ Flying Gem
Ability: Moxie
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Adamant Nature
- Acrobatics
- Sucker Punch
- Taunt
- Superpower
";
$g15857 = "Manaphy @ Chesto Berry
Ability: Hydration
Tera Type: &
EVs: 252 HP / 64 Def / 140 SpA / 36 SpD / 16 Spe
Modest Nature
- Rest
- Calm Mind
- Scald
- Energy Ball
";
$g15866 = "Meloetta @ Liechi Berry
Ability: Serene Grace
Tera Type: &
EVs: 48 HP / 84 Atk / 168 Def / 208 Spe
Jolly Nature
- Relic Song
- Return
- Close Combat
- Substitute
";
$g15875 = "Meloetta @ Lum Berry
Ability: Serene Grace
Tera Type: &
EVs: 84 HP / 40 Def / 252 SpA / 84 SpD / 48 Spe
Modest Nature
- Calm Mind
- Psychic
- Tera Blast
- Dazzling Gleam
";
$g15884 = "Meganium @ Red Card
Ability: Overgrow
Tera Type: &
EVs: 248 HP / 100 Def / 140 SpD / 20 Spe
Impish Nature
- Swords Dance
- Petal Blizzard
- Dragon Tail
- Synthesis
";
$g15893 = "Typhlosion @ Eject Pack
Ability: Blaze
Tera Type: &
EVs: 148 HP / 8 Atk / 100 SpA / 252 Spe
Hasty Nature
- Overheat
- Laser Focus
- Toxic
- Dig
";
$g15902 = "Oinkologne @ Normal Gem
Ability: Lingering Aroma
Tera Type: &
EVs: 248 HP / 112 Atk / 80 Def / 68 SpD
Adamant Nature
- Yawn
- Covet
- Thief
- Body Slam
";
$g15911 = "Braviary-Hisui @ Pecha Berry
Ability: Tinted Lens
Tera Type: &
EVs: 12 HP / 44 Def / 252 SpA / 48 SpD / 152 Spe
Modest Nature
- Calm Mind
- Esper Wing
- Roost
- Tera Blast
";
$g15920 = "Girafarig @ Eviolite
Ability: Sap Sipper
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psyshock
- Hyper Beam
- Thunder
- Nasty Plot
";
$g15929 = "Flareon @ Toxic Orb
Ability: Guts
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flare Blitz
- Facade
- Trailblaze
- Protect
";
$g15938 = "Girafarig @ Eviolite
Ability: Sap Sipper
Tera Type: &
EVs: 204 HP / 100 Atk / 100 Def / 100 SpA / 4 SpD
Sassy Nature
- Future Sight
- Twin Beam
- Body Slam
- Foul Play
";
$g15947 = "Iron Treads @ Air Balloon
Ability: Quark Drive
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Smart Strike
- Rapid Spin
- Substitute
- Endeavor
";
$g15956 = "Quaxwell @ Eviolite
Ability: Moxie
Tera Type: &
EVs: 204 HP / 196 Def / 108 SpD
Impish Nature
- Liquidation
- Chilling Water
- Rapid Spin
- Roost
";
$g15965 = "Altaria @ Altarianite
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 24 Def / 144 SpA / 88 SpD
Modest Nature
- Fire Blast
- Roost
- Hyper Beam
- Defog
";
$g15974 = "Crabominable @ Choice Band
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Ice Hammer
- Drain Punch
- Thunder Punch
- Focus Punch
";
$g15983 = "Baxcalibur @ Moon Ball
Ability: Thermal Exchange
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Glaive Rush
- Dragon Dance
- Crunch
- Protect
";
$g15992 = "Sandy Shocks @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Thunder Wave
- Spikes
- Substitute
- Earth Power
";
$g16001 = "Deoxys-Defense @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 252 HP / 20 Def / 24 SpD / 212 Spe
Calm Nature
- Night Shade
- Magic Coat
- Recover
- Cosmic Power
";
$g16010 = "Deoxys-Defense @ Choice Specs
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psycho Boost
- Dark Pulse
- Ice Beam
- Mirror Coat
";
$g16019 = "Deoxys-Defense @ Light Clay
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Reflect
- Light Screen
- Recover
-
";
$g16028 = "Recover @ Psychium Z
Ability: Pressure
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Psycho Boost
- Focus Blast
- Recover
- Nasty Plot
";
$g16037 = "Deoxys-Defense @ Assault Vest
Ability: Pressure
Tera Type: &
EVs: 252 HP / 16 Def / 240 SpD
Sassy Nature
- Ice Beam
- Charge Beam
- Knock Off
- Mirror Coat
";
$g16046 = "Ceruledge @ Life Orb
Ability: Weak Armor
Tera Type: &
EVs: 32 HP / 124 Atk / 100 Def / 252 Spe
Jolly Nature
- Bitter Blade
- Protect
- Substitute
- Destiny Bond
";
$g16055 = "Tapu Fini @ Tapunium Z
Ability: Misty Surge
Tera Type: &
EVs: 188 HP / 16 Def / 48 SpA / 4 SpD / 252 Spe
Timid Nature
- Brine
- Natures Madness
- Defog
- Draining Kiss
";
$g16064 = "Regieleki @ Electrium Z
Ability: Transistor
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Thunder
- Endure
- Rapid Spin
- Rain Dance
";
$g16073 = "Medicham @ Medichamite
Ability: Telepathy
Shiny: Yes
Tera Type: &
EVs: 52 HP / 204 Def / 252 SpD
Sassy Nature
- Close Combat
- Zen Headbutt
- Thunder Punch
- Fake Out
";
$g16083 = "Blastoise @ Blastoisinite
Ability: Rain Dish
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Nature
- Hydro Cannon
- Dark Pulse
- Rock Tomb
- Fake Out
";
$g16092 = "Mienshao @ Sitrus Berry
Ability: Regenerator
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 208 Spe
Naive Nature
- Close Combat
- Knock Off
- U-turn
- Bulk Up
";
$g16101 = "Scizor @ Scizorite
Ability: Technician
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Bullet Punch
- Pounce
- Defog
- Roost
";
$g16110 = "Beedrill @ Beedrillite
Ability: Sniper
Tera Type: &
EVs: 100 Atk / 156 SpD / 252 Spe
Jolly Nature
- U-turn
- Poison Jab
- Defog
- Substitute
";
$g16119 = "Swellow @ Heavy-Duty Boots
Ability: Scrappy
Tera Type: &
EVs: 108 HP / 244 Def / 156 Spe
Modest Nature
- Boomburst
- U-turn
- Defog
- Roost
";
$g16128 = "Swellow @ Choice Specs
Ability: Scrappy
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Boomburst
- U-turn
- Heat Wave
- Toxic
";
$g16137 = "Gliscor @ Toxic Orb
Ability: Poison Heal
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 SpD / 4 Spe
Impish Nature
- Protect
- Roost
- Defog
- Poison Jab
";
$g16147 = "Honchkrow @ Flyinium Z
Ability: Moxie
Tera Type: &
EVs: 8 HP / 252 Atk / 248 Spe
Adamant Nature
- Brave Bird
- Sucker Punch
- Tera Blast
- U-turn
";
$g16156 = "Giratina-Origin @ Griseous Core
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Destiny Bond
- Shadow Force
- Pain Split
- Will-O-Wisp
";
$g16166 = "Giratina @ Eject Button
Ability: Pressure
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Will-O-Wisp
- Pain Split
- Hex
- Calm Mind
";
$g16175 = "Giratina-Origin @ Griseous Core
Ability: Levitate
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Defog
- Poltergeist
- Magic Coat
- Pain Split
";
$g16184 = "Giratina-Origin @ Griseous Core
Ability: Levitate
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Adamant Nature
- Outrage
- Magic Coat
- Tailwind
- Defog
";
$g16193 = "Darkrai @ Wide Lens
Ability: Bad Dreams
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Dark Void
- Spacial Rend
- Knock Off
- Dream Eater
";
$g16202 = "Arceus @ Silk Scarf
Ability: Multitype
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Jolly Nature
- Headbutt
- Defog
- Tera Blast
- Healing Wish
";
$g16211 = "Dialga @ Red Card
Ability: Pressure
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Stealth Rock
- Roar
- Dragon Tail
- Iron Head
";
$g16220 = "Shaymin-Sky @ Leftovers
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Seed Flare
- Leech Seed
- Protect
- Headbutt
";
$g16229 = "Groudon @ Leftovers
Ability: Drought
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Spikes
- Stealth Rock
- Dig
- Roar
";
$g16238 = "Kingambit @ Muscle Band
Ability: Supreme Overlord
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA
Brave Nature
- Iron Head
- Sucker Punch
- Tera Blast
- Knock Off
";
$g16247 = "Rayquaza @ Chesto Berry
Ability: Air Lock
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Rest
- Cosmic Power
- Twister
- Sleep Talk
";
$g16256 = "Sableye @ Sablenite
Ability: Prankster
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Moonlight
- Foul Play
- Bulk Up
- Drain Punch
";
$g16265 = "Avalugg-Hisui @ Icy Rock
Ability: Strong Jaw
Shiny: Yes
Tera Type: &
EVs: 4 HP / 252 Atk / 252 SpD
Adamant Nature
- Crunch
- Ice Fang
- Snowscape
- Aurora Veil
";
$g16275 = "Electrode-Hisui @ Sitrus Berry
Ability: Soundproof
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe
Timid Nature
- Chloroblast
- Discharge
- Grassy Terrain
- Giga Drain
";
$g16284 = "Brute Bonnet @ Rocky Helmet
Ability: Protosynthesis
Tera Type: &
EVs: 248 HP / 232 Atk / 28 Def
Adamant Nature
- Spore
- Clear Smog
- Seed Bomb
- Sucker Punch
";
$g16293 = "Farigiraf @ Petaya Berry
Ability: Cud Chew
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Protect
- Agility
- Psyshock
- Dazzling Gleam
";
$g16302 = "Sandy Shocks @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 64 SpD / 192 Spe
Adamant Nature
- Bulldoze
- Wild Charge
- Body Slam
- Supersonic
";
$g16311 = "Armarouge @ Choice Specs
Ability: Flash Fire
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Armor Cannon
- Psyshock
- Tera Blast
- Lava Plume
";
$g16320 = "Sneasler @ White Herb
Ability: Unburden
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Gunk Shot
- Close Combat
- Acrobatics
- Swords Dance
";
$g16329 = "Talonflame @ Heavy-Duty Boots
Ability: Flame Body
Tera Type: &
EVs: 160 HP / 92 Atk / 4 SpA / 252 Spe
Naughty Nature
- Brave Bird
- Tera Blast
- Roost
- Swords Dance
";
$g16338 = "Ditto @ Bright Powder
Ability: Imposter
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Transform
-
-
-
";
$g16347 = "Basculegion @ Choice Scarf
Ability: Adaptability
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Phantom Force
- Wave Crash
- Head Smash
- Facade
";
$g16356 = "Enamorus @ Sitrus Berry
Ability: Contrary
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Play Rough
- Iron Head
- Superpower
- Protect
";
$g16365 = "Enamorus @ Choice Scarf
Ability: Contrary
Tera Type: &
EVs: 108 HP / 252 Atk / 148 Spe
Adamant Nature
- Superpower
-
-
-
";
$g16374 = "Superpower @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Adamant Nature
- Facade
- Headlong Rush
- Fling
- Protect
";
$g16383 = "Meowscarada @ Expert Belt
Ability: Protean
Tera Type: &
EVs: 100 HP / 108 Atk / 100 Def / 100 SpD / 100 Spe
Nature
- Flower Trick
- Knock Off
- Low Kick
- Toxic Spikes
";
$g16392 = "Annihilape @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 252 HP / 36 Def / 220 SpD
Careful Nature
- Rage Fist
-
-
-
";
$g16401 = "Naclstack @ Eviolite
Ability: Purifying Salt
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Salt Cure
- Body Press
- Recover
- Iron Defense
";
$g16410 = "Palafin @ Sticky Barb
Ability: Zero to Hero
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Jet Punch
- Drain Punch
- Bounce
- Bulk Up
";
$g16419 = "Wo-Chien @ Leftovers
Ability: Tablets of Ruin
Tera Type: &
EVs: 100 HP / 104 Atk / 100 Def / 100 SpA / 100 SpD / 4 Spe
Nature
- Knock Off
- Giga Drain
- Protect
- Leech Seed
";
$g16428 = "Wo-Chien @ Normalium Z
Ability: Tablets of Ruin
Tera Type: &
EVs: 252 HP / 188 SpA / 68 Spe
Modest Nature
- Hyper Beam
- Leaf Storm
- Stun Spore
- Protect
";
$g16437 = "Wo-Chien @ Sitrus Berry
Ability: Tablets of Ruin
Shiny: Yes
Tera Type: &
EVs: 196 HP / 20 Def / 40 SpD / 252 Spe
Jolly Nature
- Knock Off
- Leech Seed
- Substitute
- Protect
";
$g16447 = "Wooper-Paldea @ Eviolite
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Gunk Shot
- Stealth Rock
- Recover
- Curse
";
$g16456 = "Scream Tail @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 216 HP / 12 Atk / 128 Def / 128 SpD / 24 Spe
Sassy Nature
- Play Rough
- Flamethrower
- Wish
- Protect
";
$g16465 = "Scream Tail @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs:
Nature
- Play Rough
- Dig
- Wish
- Bulk Up
";
$g16474 = "Scream Tail @ Black Sludge
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Light Screen
- Reflect
- Perish Song
- Trick
";
$g16483 = "Scream Tail @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Calm Mind
- Flamethrower
- Grass Knot
- Ice Beam
";
$g16492 = "Appletun @ Dragonium Z
Ability: Thick Fat
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Apple Acid
- Draco Meteor
- Recover
- Body Press
";
$g16501 = "Palafin @ Choice Specs
Ability: Zero to Hero
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Boomburst
- Draining Kiss
- Flip Turn
- Ice Beam
";
$g16510 = "Tyranitar @ Darkinium Z
Ability: Sand Stream
Tera Type: &
EVs: 64 HP / 192 Atk / 44 Def / 20 SpD / 188 Spe
Adamant Nature
- Stone Edge
- Crunch
- Ice Punch
- Substitute
";
$g16519 = "Floatzel @ Waterium Z
Ability: Water Veil
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Wave Crash
- Dig
- Protect
- Bulk Up
";
$g16528 = "Dudunsparce @ Leftovers
Ability: Rattled
Tera Type: &
EVs: 252 HP / 72 Def / 184 SpA
Modest Nature
- Boomburst
- Earth Power
- Roost
- Calm Mind
";
$g16537 = "Dudunsparce @ Normalium Z
Ability: Rattled
Tera Type: &
EVs: 252 HP / 200 SpA / 56 SpD
Modest Nature
- Boomburst
- Stealth Rock
- Protect
- Roost
";
$g16546 = "Dudunsparce @ Lum Berry
Ability: Rattled
Tera Type: &
EVs: 232 HP / 168 Def / 24 SpA / 84 SpD
Bold Nature
- Boomburst
- Amnesia
- Defense Curl
- Roost
";
$g16555 = "Abomasnow @ Heavy-Duty Boots
Ability: Snow Warning
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Wood Hammer
- Ice Shard
- Rock Slide
- Swords Dance
";
$g16564 = "Abomasnow @ Icium Z
Ability: Snow Warning
Tera Type: &
EVs: 40 HP / 216 Atk / 252 Spe
Jolly Nature
- Wood Hammer
- Low Kick
- Aurora Veil
- Swords Dance
";
$g16573 = "Abomasnow @ Light Clay
Ability: Snow Warning
Tera Type: &
EVs: 200 HP / 184 Def / 40 SpD / 84 Spe
Bold Nature
- Giga Drain
- Blizzard
- Chilling Water
- Aurora Veil
";
$g16582 = "Abomasnow @ Chesto Berry
Ability: Snow Warning
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Bold Nature
- Leech Seed
- Substitute
- Rest
- Body Press
";
$g16591 = "Pawmot @ Choice Scarf
Ability: Volt Absorb
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Double Shock
- Close Combat
- Volt Switch
- Revival Blessing
";
$g16600 = "Vaporeon @ Sitrus Berry
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 172 Def / 8 SpA / 80 SpD
Calm Nature
- Tera Blast
- Haze
- Wish
- Ice Beam
";
$g16609 = "Armarouge @ Heavy-Duty Boots
Ability: Flash Fire
Tera Type: &
EVs: 20 HP / 236 SpA / 252 Spe
Timid Nature
- Armor Cannon
- Disable
- Will-O-Wisp
- Substitute
";
$g16618 = "Iron Bundle @ Leftovers
Ability: Quark Drive
Tera Type: &
EVs: 96 HP / 16 Def / 252 SpA / 4 SpD / 140 Spe
Timid Nature
- Hydro Pump
- Freeze-Dry
- Substitute
- Protect
";
$g16627 = "Garganacl @ Custap Berry
Ability: Purifying Salt
Tera Type: &
EVs: 208 HP / 100 Atk / 100 Def / 100 SpD
Adamant Nature
- Salt Cure
- Body Press
- Iron Defense
- Recover
";
$g16636 = "Chi-Yu @ Weakness Policy
Ability: Beads of Ruin
Tera Type: &
EVs: 100 HP / 100 Def / 100 SpA / 100 SpD / 108 Spe
Nature
- Hex
- Will-O-Wisp
- Tera Blast
- Fire Blast
";
$g16645 = "Chi-Yu @ Chesto Berry
Ability: Beads of Ruin
Tera Type: &
EVs: 204 HP / 52 SpA / 252 Spe
Timid Nature
- Dark Pulse
- Will-O-Wisp
- Rest
- Protect
";
$g16654 = "Wo-Chien @ Chesto Berry
Ability: Tablets of Ruin
Tera Type: &
EVs: 104 HP / 100 Atk / 100 SpA / 204 SpD
Sassy Nature
- Knock Off
- Stun Spore
- Rest
- Leaf Storm
";
$g16663 = "Tinkaton @ Leftovers
Ability: Mold Breaker
Tera Type: &
EVs: 208 Atk / 48 SpD / 252 Spe
Jolly Nature
- Gigaton Hammer
- Knock Off
- Substitute
- Protect
";
$g16672 = "Palafin @ Flame Orb
Ability: Zero to Hero
Tera Type: &
EVs: 40 HP / 148 Atk / 64 Def / 4 SpD / 252 Spe
Jolly Nature
- Fling
- Flip Turn
- Wave Crash
- Protect
";
$g16681 = "Iron Hands @ Flame Orb
Ability: Quark Drive
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Wild Charge
- Drain Punch
- Fling
- Earthquake
";
$g16690 = "Mabosstiff @ Choice Scarf
Ability: Stakeout
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Crunch
- Play Rough
- Wild Charge
- Fire Fang
";
$g16699 = "Mabosstiff @ Assault Vest
Ability: Intimidate
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpD / 108 Spe
Nature
- Crunch
- Fire Fang
- Tera Blast
- Body Slam
";
$g16708 = "Farigiraf @ Heavy-Duty Boots
Ability: Sap Sipper
Tera Type: &
EVs: 156 HP / 204 Def / 116 SpA / 32 SpD
Relaxed Nature
- Future Sight
- Foul Play
- Low Kick
- Thunder Wave
";
$g16717 = "Floatzel @ Chesto Berry
Ability: Swift Swim
Tera Type: &
EVs: 212 HP / 40 Atk / 4 SpA / 252 Spe
Naughty Nature
- Wave Crash
- Tera Blast
- Rest
- Bulk Up
";
$g16726 = "Tatsugiri @ Heavy-Duty Boots
Ability: Storm Drain
Tera Type: &
EVs: 100 HP / 108 Def / 100 SpA / 100 SpD / 100 Spe
Nature
- Muddy Water
- Draco Meteor
- Rapid Spin
- Protect
";
$g16735 = "Decidueye-Hisui @ Leftovers
Ability: Scrappy
Tera Type: &
EVs: 252 HP / 68 Atk / 56 SpD / 132 Spe
Careful Nature
- Triple Arrows
- Trailblaze
- Roost
- Bulk Up
";
$g16744 = "Ho-Oh @ Leftovers
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Weather Ball
- Sunny Day
- Sandstorm
- Rain Dance
";
$g16753 = "Garganacl @ Leftovers
Ability: Purifying Salt
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Salt Cure
- Recover
- Stealth Rock
- Body Press
";
$g16762 = "Arceus-Ice @ Icicle Plate
Ability: Multitype
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Avalanche
- Recover
- Last Resort
-
";
$g16771 = "Lopunny @ Lopunnite
Ability: Limber
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Fake Out
- Triple Axel
- Facade
- Drain Punch
";
$g16780 = "Sceptile @ Sceptilite
Ability: Overgrow
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Leaf Storm
- Dragon Pulse
- Hone Claws
- Focus Blast
";
$g16789 = "Charizard @ Charizardite Y
Ability: Blaze
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hurricane
- Heat Wave
- Scorching Sands
- Hold Hands
";
$g16798 = "Annihilape @ Metronome
Ability: Vital Spirit
Tera Type: &
EVs: 100 HP / 128 Atk / 60 Def / 92 SpD / 128 Spe
Adamant Nature
- Rage Fist
- Karate Chop
- Metronome
- Rage
";
$g16807 = "Magearna @ Leftovers
Ability: Soul-Heart
Tera Type: &
EVs: 136 HP / 120 Atk / 252 Spe
Adamant Nature
- Shift Gear
- Iron Head
- Play Rough
- Spikes
";
$g16816 = "Pheromosa @ Bug Gem
Ability: Beast Boost
Tera Type: &
EVs: 100 Atk / 176 SpD / 232 Spe
Jolly Nature
- U-turn
- Close Combat
- Drill Run
- Facade
";
$g16825 = "Blastoise @ Blastoisinite
Ability: Torrent
Tera Type: &
EVs: 56 HP / 252 Def / 200 SpA
Quiet Nature
- Fake Out
- Water Pulse
- Dark Pulse
- Rapid Spin
";
$g16834 = "Marshadow @ Choice Specs
Ability: Technician
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Shadow Ball
- Aura Sphere
- Grass Knot
- Hex
";
$g16843 = "Floatzel @ Choice Band
Ability: Swift Swim
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Wave Crash
- Focus Punch
- Ice Spinner
- Dig
";
$g16852 = "Kangaskhan @ Kangaskhanite
Ability: Scrappy
Tera Type: &
EVs: 200 HP / 56 Atk / 24 Def / 200 SpD / 28 Spe
Adamant Nature
- Circle Throw
- Dig
- Skull Bash
- Curse
";
$g16861 = "Luvdisc @ Leftovers
Ability: Swift Swim
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Impish Nature
- Dive
- Toxic
- Icy Wind
- Wish
";
$g16870 = "Seviper @ Iapapa Berry
Ability: Shed Skin
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Coil
- Gunk Shot
- Sucker Punch
- Fire Fang
";
$g16879 = "Seviper @ Life Orb
Ability: Shed Skin
Tera Type: &
EVs: 152 HP / 252 SpA / 104 Spe
Modest Nature
- Sludge Wave
- Flamethrower
- Giga Drain
- Protect
";
$g16888 = "Kecleon @ Leftovers
Ability: Color Change
Tera Type: &
EVs: 248 HP / 188 Def / 72 SpD
Impish Nature
- Stealth Rock
- Recover
- Body Slam
- Dig
";
$g16897 = "Kecleon @ Choice Band
Ability: Protean
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Double-Edge
- Low Kick
- Aqua Tail
- Ice Punch
";
$g16906 = "Kecleon @ Sitrus Berry
Ability: Color Change
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Nasty Plot
- Ice Beam
- Thunderbolt
- Fire Blast
";
$g16915 = "Komala @ Choice Band
Ability: Comatose
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Sleep Talk
- Last Resort
-
-
";
$g16924 = "Watchog @ Leftovers
Ability: Analytic
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Swords Dance
- Thunder Wave
- Return
- Dig
";
$g16933 = "Venusaur @ Venusaurite
Ability: Chlorophyll
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Swords Dance
- Power Whip
- Knock Off
- Bulldoze
";
$g16942 = "Bellibolt @ Leftovers
Ability: Electromorphosis
Tera Type: &
EVs: 248 HP / 128 Def / 120 SpD / 12 Spe
Bold Nature
- Slack Off
- Discharge
- Tera Blast
- Muddy Water
";
$g16951 = "Chatot @ Leftovers
Ability: Keen Eye
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Encore
- Chatter
- Fly
";
$g16960 = "Victreebel @ Choice Band
Ability: Chlorophyll
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Power Whip
- Knock Off
- Poison Jab
- Tera Blast
";
$g16969 = "Victreebel @ Metronome
Ability: Chlorophyll
Tera Type: &
EVs: 144 HP / 4 Def / 252 SpA / 108 Spe
Modest Nature
- Sunny Day
- Solar Beam
- Weather Ball
- Encore
";
$g16978 = "Victreebel @ Black Sludge
Ability: Chlorophyll
Tera Type: &
EVs: 216 HP / 252 Atk / 40 Spe
Adamant Nature
- Swords Dance
- Protect
- Power Whip
- Knock Off
";
$g16987 = "Ledian @ Heavy-Duty Boots
Ability: Early Bird
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Roost
- Encore
- Defog
- Knock Off
";
$g16996 = "Pachirisu @ Red Card
Ability: Pickup
Tera Type: &
EVs: 248 HP / 252 Def
Impish Nature
- Nuzzle
- Dig
- Protect
- Super Fang
";
$g17005 = "Plusle @ Iapapa Berry
Ability: Lightning Rod
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Thunderbolt
- Encore
- Grass Knot
";
$g17014 = "Lunala @ Kasib Berry
Ability: Shadow Shield
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Teleport
- Roost
- Future Sight
- Hidden Power [Ghost]
";
$g17023 = "Samurott-Hisui @ Assault Vest
Ability: Sharpness
Tera Type: &
EVs: 124 HP / 164 Atk / 100 Def / 120 SpD
Adamant Nature
- Aqua Cutter
- Ceaseless Edge
- Sacred Sword
- Facade
";
$g17032 = "Samurott-Hisui @ Life Orb
Ability: Sharpness
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Razor Shell
- Ceaseless Edge
- Sacred Sword
- Substitute
";
$g17041 = "Samurott-Hisui @ Chesto Berry
Ability: Sharpness
Tera Type: &
EVs: 168 HP / 124 Atk / 216 SpD
Careful Nature
- Razor Shell
- Ceaseless Edge
- Encore
- Rest
";
$g17050 = "Braviary-Hisui @ Heavy-Duty Boots
Ability: Tinted Lens
Tera Type: &
EVs: 160 HP / 88 Def / 8 SpA / 252 Spe
Bold Nature
- Esper Wing
- Air Slash
- Roost
- Calm Mind
";
$g17059 = "Braviary-Hisui @ Normalium Z
Ability: Tinted Lens
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Esper Wing
- Hyper Beam
- Heat Wave
- Roost
";
$g17068 = "Braviary-Hisui @ Iapapa Berry
Ability: Sheer Force
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpA / 100 SpD / 8 Spe
Rash Nature
- Hurricane
- Shadow Ball
- Substitute
- Roost
";
$g17077 = "Braviary-Hisui @ Leftovers
Ability: Tinted Lens
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Esper Wing
- Protect
- Roost
- Calm Mind
";
$g17086 = "Braviary-Hisui @ Choice Specs
Ability: Sheer Force
Tera Type: &
EVs: 100 HP / 100 Def / 88 SpA / 16 SpD / 200 Spe
Rash Nature
- Esper Wing
- Hurricane
- Icy Wind
- Rock Slide
";
$g17095 = "Braviary-Hisui @ Sitrus Berry
Ability: Tinted Lens
Tera Type: &
EVs: 252 HP / 64 Def / 192 Spe
Modest Nature
- Esper Wing
- Bulk Up
- Calm Mind
- Stored Power
";
$g17104 = "Braviary-Hisui @ Kee Berry
Ability: Sheer Force
Tera Type: &
EVs: 252 HP / 76 Def / 164 SpA / 16 Spe
Modest Nature
- Stored Power
- Hurricane
- Roost
- Calm Mind
";
$g17113 = "Blastoise @ Blastoisinite
Ability: Torrent
Tera Type: &
EVs: 252 HP / 12 SpA / 4 SpD / 240 Spe
Modest Nature
- Scald
- Aura Sphere
- Rapid Spin
- Flip Turn
";
$g17122 = "Blaziken @ Passho Berry
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 128 Atk / 128 Spe
Lonely Nature
- Close Combat
- Overheat
- Thunder Punch
- Swords Dance
";
$g17131 = "Basculegion-F @ Choice Specs
Ability: Adaptability
Tera Type: &
EVs: 60 HP / 252 SpA / 4 SpD / 192 Spe
Modest Nature
- Hydro Pump
- Shadow Ball
- Tera Blast
- Tail Whip
";
$g17140 = "Basculegion-F @ Choice Scarf
Ability: Adaptability
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Hydro Pump
- Shadow Ball
- Phantom Force
- Ice Beam
";
$g17149 = "Basculegion @ Weakness Policy
Ability: Swift Swim
Shiny: Yes
Tera Type: &
EVs: 92 HP / 16 Atk / 200 Def / 200 SpD
Adamant Nature
- Liquidation
- Phantom Force
- Chilling Water
- Agility
";
$g17159 = "Blaziken @ Heavy-Duty Boots
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Naive Nature
- Overheat
- Close Combat
- Defog
- Protect
";
$g17168 = "Growlithe-Hisui @ Heavy-Duty Boots
Ability: Rock Head
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flare Blitz
- Head Smash
- Substitute
- Protect
";
$g17178 = "Great Tusk @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Head Smash
- Tera Blast
- Rapid Spin
- Protect
";
$g17187 = "Volcanion @ Chesto Berry
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 232 SpA / 28 SpD
Modest Nature
- Steam Eruption
- Fire Spin
- Rest
- Defog
";
$g17196 = "Genesect @ Chesto Berry
Ability: Download
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Bug Buzz
- Ice Beam
- Energy Ball
- Rest
";
$g17205 = "Genesect @ Wiki Berry
Ability: Download
Tera Type: &
EVs: 100 HP / 152 Atk / 100 Def / 100 SpD / 56 Spe
Nature
- Tera Blast
- Gunk Shot
- Explosion
- Iron Head
";
$g17214 = "Iron Bundle @ Eviolite
Ability: Quark Drive
Tera Type: &
EVs: 252 HP / 4 Atk / 40 Def / 212 Spe
Naive Nature
- Hydro Pump
- Freeze-Dry
- Play Rough
- Protect
";
$g17223 = "Alakazam @ Alakazite
Ability: Trace
Tera Type: &
EVs: 64 HP / 24 Atk / 68 SpA / 252 Spe
Hasty Nature
- Psychic
- Knock Off
- Focus Blast
- Calm Mind
";
$g17232 = "Kangaskhan @ Firium Z
Ability: Early Bird
Tera Type: &
EVs: 100 HP / 64 Atk / 100 Def / 240 SpD / 4 Spe
Careful Nature
- Return
- Disable
- Fire Punch
- Rest
";
$g17241 = "Samurott-Hisui @ Assault Vest
Ability: Sharpness
Tera Type: &
EVs: 124 HP / 164 Atk / 100 Def / 120 SpD
Adamant Nature
- Aqua Cutter
- Ceaseless Edge
- Sacred Sword
- Facade
";
$g17250 = "Samurott-Hisui @ Life Orb
Ability: Sharpness
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Razor Shell
- Ceaseless Edge
- Sacred Sword
- Substitute
";
$g17259 = "Samurott-Hisui @ Chesto Berry
Ability: Sharpness
Tera Type: &
EVs: 168 HP / 124 Atk / 216 SpD
Careful Nature
- Razor Shell
- Ceaseless Edge
- Encore
- Rest
";
$g17268 = "Braviary-Hisui @ Heavy-Duty Boots
Ability: Tinted Lens
Tera Type: &
EVs: 160 HP / 88 Def / 8 SpA / 252 Spe
Bold Nature
- Esper Wing
- Air Slash
- Roost
- Calm Mind
";
$g17277 = "Braviary-Hisui @ Normalium Z
Ability: Tinted Lens
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Esper Wing
- Hyper Beam
- Heat Wave
- Roost
";
$g17286 = "Braviary-Hisui @ Iapapa Berry
Ability: Sheer Force
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpA / 100 SpD / 8 Spe
Rash Nature
- Hurricane
- Shadow Ball
- Substitute
- Roost
";
$g17295 = "Braviary-Hisui @ Leftovers
Ability: Tinted Lens
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Esper Wing
- Protect
- Roost
- Calm Mind
";
$g17304 = "Braviary-Hisui @ Choice Specs
Ability: Sheer Force
Tera Type: &
EVs: 100 HP / 100 Def / 88 SpA / 16 SpD / 200 Spe
Rash Nature
- Esper Wing
- Hurricane
- Icy Wind
- Rock Slide
";
$g17313 = "Braviary-Hisui @ Sitrus Berry
Ability: Tinted Lens
Tera Type: &
EVs: 252 HP / 64 Def / 192 Spe
Modest Nature
- Esper Wing
- Bulk Up
- Calm Mind
- Stored Power
";
$g17322 = "Braviary-Hisui @ Kee Berry
Ability: Sheer Force
Tera Type: &
EVs: 252 HP / 76 Def / 164 SpA / 16 Spe
Modest Nature
- Stored Power
- Hurricane
- Roost
- Calm Mind
";
$g17331 = "Blastoise @ Blastoisinite
Ability: Torrent
Tera Type: &
EVs: 252 HP / 12 SpA / 4 SpD / 240 Spe
Modest Nature
- Scald
- Aura Sphere
- Rapid Spin
- Flip Turn
";
$g17340 = "Blaziken @ Passho Berry
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 128 Atk / 128 Spe
Lonely Nature
- Close Combat
- Overheat
- Thunder Punch
- Swords Dance
";
$g17349 = "Basculegion-F @ Choice Specs
Ability: Adaptability
Tera Type: &
EVs: 60 HP / 252 SpA / 4 SpD / 192 Spe
Modest Nature
- Hydro Pump
- Shadow Ball
- Tera Blast
- Tail Whip
";
$g17358 = "Basculegion-F @ Choice Scarf
Ability: Adaptability
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Hydro Pump
- Shadow Ball
- Phantom Force
- Ice Beam
";
$g17367 = "Basculegion @ Weakness Policy
Ability: Swift Swim
Tera Type: &
EVs: 92 HP / 16 Atk / 200 Def / 200 SpD
Adamant Nature
- Liquidation
- Last Respects
- Chilling Water
- Agility
";
$g17376 = "Blaziken @ Heavy-Duty Boots
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Naive Nature
- Overheat
- Close Combat
- Defog
- Protect
";
$g17385 = "Growlithe-Hisui @ Heavy-Duty Boots
Ability: Rock Head
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flare Blitz
- Head Smash
- Substitute
- Protect
";
$g17394 = "Great Tusk @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Head Smash
- Tera Blast
- Rapid Spin
- Protect
";
$g17403 = "Volcanion @ Chesto Berry
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 232 SpA / 28 SpD
Modest Nature
- Steam Eruption
- Fire Spin
- Rest
- Defog
";
$g17412 = "Genesect @ Chesto Berry
Ability: Download
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Bug Buzz
- Ice Beam
- Energy Ball
- Rest
";
$g17421 = "Genesect @ Wiki Berry
Ability: Download
Tera Type: &
EVs: 100 HP / 152 Atk / 100 Def / 100 SpD / 56 Spe
Nature
- Tera Blast
- Gunk Shot
- Explosion
- Iron Head
";
$g17430 = "Iron Bundle @ Eviolite
Ability: Quark Drive
Tera Type: &
EVs: 252 HP / 4 Atk / 40 Def / 212 Spe
Naive Nature
- Hydro Pump
- Freeze-Dry
- Play Rough
- Protect
";
$g17439 = "Alakazam @ Alakazite
Ability: Trace
Tera Type: &
EVs: 64 HP / 24 Atk / 68 SpA / 252 Spe
Hasty Nature
- Psychic
- Knock Off
- Focus Blast
- Calm Mind
";
$g17448 = "Kangaskhan @ Firium Z
Ability: Early Bird
Shiny: Yes
Tera Type: &
EVs: 100 HP / 64 Atk / 100 Def / 240 SpD / 4 Spe
Careful Nature
- Return
- Disable
- Fire Punch
- Rest
";
$g17458 = "Lunala @ Kasib Berry
Ability: Shadow Shield
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Teleport
- Roost
- Future Sight
- Hidden Power [Ghost]
";
$g17467 = "Dondozo @ Chesto Berry
Ability: Unaware
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Rest
- Liquidation
- Curse
- Body Press
";
$g17476 = "Beedrill @ Beedrillite
Ability: Swarm
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Protect
- U-turn
- Poison Jab
- Fell Stinger
";
$g17485 = "Venusaur @ Venusaurite
Ability: Chlorophyll
Tera Type: &
EVs: 252 HP / 60 Def / 196 SpD
Bold Nature
- Sleep Powder
- Leech Seed
- Weather Ball
- Earth Power
";
$g17494 = "Ting-Lu @ Maranga Berry
Ability: Vessel of Ruin
Tera Type: &
EVs: 252 HP / 4 Atk / 36 Def / 216 SpD
Relaxed Nature
- Dig
- Rest
- Tera Blast
- Ruination
";
$g17503 = "Zekrom @ Heavy-Duty Boots
Ability: Teravolt
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Defog
- Volt Switch
- Protect
- Hidden Power [Ice]
";
$g17512 = "Frogadier @ Eviolite
Ability: Protean
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Jolly Nature
- U-turn
- Bounce
- Scald
- Spikes
";
$g17521 = "Nacli @ Eviolite
Ability: Purifying Salt
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Careful Nature
- Curse
- Recover
- Dig
- Body Slam
";
$g17530 = "Ditto @ Heavy-Duty Boots
Ability: Imposter
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Transform
-
-
-
";
$g17539 = "Dustox @ Kings Rock
Ability: Shield Dust
Tera Type: &
EVs: 248 HP / 152 Def / 108 Spe
Bold Nature
- Roost
- Quiver Dance
- Sludge Bomb
- Bug Buzz
";
$g17548 = "Dustox @ Heavy-Duty Boots
Ability: Shield Dust
Tera Type: &
EVs: 248 HP / 132 Def / 128 SpD
Careful Nature
- Roost
- Defog
- Secret Power
- Whirlwind
";
$g17557 = "Dustox @ Maranga Berry
Ability: Shield Dust
Tera Type: &
EVs: 248 HP / 220 Atk / 32 Def / 8 Spe
Impish Nature
- Iron Defense
- Roost
- Thief
- Acrobatics
";
$g17566 = "Minun @ Flame Orb
Ability: Volt Absorb
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Impish Nature
- Nuzzle
- Switcheroo
- Wish
- Seismic Toss
";
$g17575 = "Gumshoos @ Normal Gem
Ability: Adaptability
Tera Type: &
EVs: 156 HP / 252 Atk / 100 Spe
Adamant Nature
- Thrash
- Yawn
- U-turn
- Protect
";
$g17584 = "Pyroar @ White Herb
Ability: Rivalry
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sunny Day
- Overheat
- Solar Beam
- Dig
";
$g17593 = "Swadloon @ Eviolite
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 200 Def / 60 SpD
Bold Nature
- Iron Defense
- Calm Mind
- Morning Sun
- Signal Beam
";
$g17602 = "Medicham @ Psychic Gem
Ability: Pure Power
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Fake Out
- High Jump Kick
- Zen Headbutt
- Ice Punch
";
$g17611 = "Fearow @ Heavy-Duty Boots
Ability: Keen Eye
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Work Up
- Roost
- Drill Peck
- Drill Run
";
$g17620 = "Dodrio @ Sitrus Berry
Ability: Run Away
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Double-Edge
- Brave Bird
- Jump Kick
";
$g17629 = "Meowscarada @ Flying Gem
Ability: Protean
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Acrobatics
- Thief
- Leech Seed
- Low Sweep
";
$g17638 = "Arctibax @ Eviolite
Ability: Thermal Exchange
Tera Type: &
EVs: 232 HP / 252 Atk / 24 Spe
Adamant Nature
- Swords Dance
- Protect
- Tera Blast
- Outrage
";
$g17647 = "Ferrothorn @ Mental Herb
Ability: Iron Barbs
Tera Type: &
EVs: 248 HP / 164 Atk / 96 Spe
Adamant Nature
- Toxic
- Rest
- Power Whip
- Swords Dance
";
$g17656 = "Pelipper @ Choice Scarf
Ability: Drizzle
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hurricane
- Weather Ball
- U-turn
- Defog
";
$g17665 = "Magcargo @ Blunder Policy
Ability: Weak Armor
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sunny Day
- Fire Blast
- Solar Beam
- Inferno
";
$g17674 = "Golem-Alola @ Air Balloon
Ability: Galvanize
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Rock Polish
- Explosion
- Return
- Stone Edge
";
$g17683 = "Scovillain @ Wise Glasses
Ability: Chlorophyll
Shiny: Yes
Tera Type: &
EVs: 120 HP / 252 SpA / 136 Spe
Modest Nature
- Sunny Day
- Solar Beam
- Fire Blast
- Tera Blast
";
$g17693 = "Scovillain @ Normalium Z
Ability: Chlorophyll
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Sunny Day
- Seed Bomb
- Fire Fang
- Giga Impact
";
$g17702 = "Scovillain @ Sitrus Berry
Ability: Insomnia
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Bold Nature
- Spicy Extract
- Leech Seed
- Will-O-Wisp
- Tera Blast
";
$g17711 = "Boltund @ Life Orb
Ability: Strong Jaw
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Thunder Fang
- Psychic Fangs
- Fire Fang
- Crunch
";
$g17720 = "Overqwil @ Choice Band
Ability: Intimidate
Tera Type: &
EVs: 252 Atk
Adamant Nature
- Self-Destruct
- Haze
- Toxic Spikes
- Spikes
";
$g17729 = "Crocalor @ Leftovers
Ability: Unaware
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Will-O-Wisp
- Yawn
- Encore
- Seed Bomb
";
$g17738 = "Finizen @ Eviolite
Ability: Water Veil
Tera Type: &
EVs: 132 HP / 124 SpA / 252 Spe
Timid Nature
- Surf
- Icy Wind
- Supersonic
- Focus Energy
";
$g17747 = "Dondozo @ Choice Band
Ability: Water Veil
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Wave Crash
- Earthquake
- Heavy Slam
- Ice Fang
";
$g17756 = "Glalie @ Glalitite
Ability: Inner Focus
Tera Type: &
EVs: 22 HP / 172 Atk / 252 SpA / 62 Spe
Naughty Nature
- Take Down
- Hyper Beam
- Trailblaze
- Fake Tears
";
$g17765 = "Glalie @ Glalitite
Ability: Ice Body
Tera Type: &
EVs: 252 SpA / 252 SpD / 4 Spe
Calm Nature
- Blizzard
- Freeze-Dry
- Snowscape
- Protect
";
$g17774 = "Glalie @ Glalitite
Ability: Inner Focus
Tera Type: &
EVs: 70 HP / 122 Def / 252 SpA / 64 SpD
Modest Nature
- Weather Ball
- Facade
- Iron Head
- Disable
";
$g17783 = "Zoroark-Hisui @
Ability: Illusion
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Thief
- Knock Off
- Fling
- Trick
";
$g17792 = "Zoroark-Hisui @ Choice Specs
Ability: Illusion
Tera Type: &
EVs: 144 HP / 24 Def / 252 SpA / 88 Spe
Modest Nature
- Tera Blast
- Bitter Malice
- Dark Pulse
- Sludge Bomb
";
$g17801 = "Zoroark-Hisui @ Toxic Orb
Ability: Illusion
Tera Type: &
EVs: 144 HP / 112 SpD / 252 Spe
Jolly Nature
- Facade
- Shadow Claw
- Fling
- Swords Dance
";
$g17810 = "Growlithe-Hisui @ Eviolite
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 144 Def / 112 SpD
Impish Nature
- Rock Tomb
- Will-O-Wisp
- Roar
- Morning Sun
";
$g17819 = "Zarude-Dada @ Lansat Berry
Ability: Leaf Guard
Tera Type: &
EVs: 56 Def / 140 SpA / 60 SpD / 252 Spe
Timid Nature
- Dark Pulse
- Leaf Storm
- U-turn
- Jungle Healing
";
$g17828 = "Zarude-Dada @ Focus Band
Ability: Leaf Guard
Tera Type: &
EVs: 252 HP / 24 SpA / 232 Spe
Timid Nature
- Solar Beam
- Growth
- Synthesis
- Sunny Day
";
$g17837 = "Zarude-Dada @ Assault Vest
Ability: Leaf Guard
Tera Type: &
EVs: 124 HP / 12 Atk / 124 Def / 124 SpD / 124 Spe
Adamant Nature
- Darkest Lariat
- Power Whip
- Close Combat
- U-turn
";
$g17846 = "Volcanion @ Choice Band
Ability: Water Absorb
Tera Type: &
EVs: 124 HP / 12 Atk / 124 Def / 124 SpD / 124 Spe
Adamant Nature
- Flare Blitz
- Liquidation
- Earthquake
- Stone Edge
";
$g17855 = "Calyrex @ Choice Scarf
Ability: Unnerve
Tera Type: &
EVs: 252 HP / 64 Def / 64 SpA / 64 SpD / 64 Spe
Bold Nature
- Psychic
- Protect
- Leech Seed
- Trick
";
$g17864 = "Calyrex @ Mago Berry
Ability: Unnerve
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Stored Power
- Giga Drain
- Calm Mind
- Substitute
";
$g17873 = "Falinks @ Assault Vest
Ability: Defiant
Tera Type: &
EVs: 44 HP / 252 Atk / 40 SpD / 172 Spe
Adamant Nature
- Brick Break
- Counter
- First Impression
- Megahorn
";
$g17882 = "Slither Wing @ Cell Battery
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Leech Life
- Body Press
- Flame Charge
- Bulk Up
";
$g17891 = "Slither Wing @ Blunder Policy
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 112 Def / 144 SpD
Impish Nature
- Lunge
- Acrobatics
- Stun Spore
- Morning Sun
";
$g17900 = "Slither Wing @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- First Impression
- Wild Charge
- Flare Blitz
- Whirlwind
";
$g17909 = "Audino @ Audinite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Knock Off
- Wish
- Protect
- Trick Room
";
$g17918 = "Audino @ Audinite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Knock Off
- Wish
- Protect
- Toxic
";
$g17927 = "Audino @ Audinite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Knock Off
- Wish
- Heal Bell
- Toxic
";
$g17936 = "Grafaiai @ Toxic Orb
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Switcheroo
- Protect
- Parting Shot
- Poison Jab
";
$g17945 = "Slowbro @ Slowbronite
Ability: Shell Armor
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Calm Mind
- Flamethrower
- Scald
- Ice Beam
";
$g17954 = "Absol @ Absolite
Ability: Pressure
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Throat Chop
- Psycho Cut
- Will-O-Wisp
- Megahorn
";
$g17963 = "Feraligatr @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Dragon Dance
- Ice Fang
- Waterfall
- Crunch
";
$g17972 = "Banette @ Banettite
Ability: Frisk
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Will-O-Wisp
- Sucker Punch
- Shadow Claw
- Shadow Sneak
";
$g17981 = "Shaymin @ Normalium Z
Ability: Natural Cure
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Bullet Seed
- Zen Headbutt
- Headbutt
- Earth Power
";
$g17990 = "Torterra @ Custap Berry
Ability: Overgrow
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Endure
- Wood Hammer
- Earthquake
- Swords Dance
";
$g17999 = "Hatterene @ Grassium Z
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 4 Atk / 24 Def / 144 SpA / 84 SpD
Sassy Nature
- Power Whip
- Healing Wish
- Psychic
- Protect
";
$g18008 = "Manaphy @ Rocky Helmet
Ability: Hydration
Tera Type: &
EVs: 84 HP / 80 Atk / 80 Def / 104 SpA / 80 SpD / 80 Spe
Nature
- Scald
- Knock Off
- Rest
- Rain Dance
";
$g18017 = "Gorebyss @ Kee Berry
Ability: Hydration
Shiny: Yes
Tera Type: &
EVs: 212 HP / 112 Def / 140 SpA / 44 SpD
Modest Nature
- Muddy Water
- Amnesia
- Rest
- Rain Dance
";
$g18027 = "Delphox @ Blunder Policy
Ability: Blaze
Tera Type: &
EVs: 120 HP / 132 SpA / 4 SpD / 252 Spe
Timid Nature
- Fire Blast
- Psychic
- Hypnosis
- Nasty Plot
";
$g18036 = "Golem-Alola @ Leftovers
Ability: Galvanize
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Return
- Dig
- Toxic
- Substitute
";
$g18045 = "Golem-Alola @ Chople Berry
Ability: Magnet Pull
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Explosion
- Double-Edge
- Counter
- Stealth Rock
";
$g18054 = "Skeledirge @ Heavy-Duty Boots
Ability: Unaware
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Torch Song
- Will-O-Wisp
- Roar
- Slack Off
";
$g18063 = "Beautifly @ Heavy-Duty Boots
Ability: Swarm
Tera Type: &
EVs: 100 HP / 100 Def / 108 SpA / 100 SpD / 100 Spe
Nature
- Bug Buzz
- Tera Blast
- Defog
- Roost
";
$g18072 = "Beautifly @ Heavy-Duty Boots
Ability: Rivalry
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Defog
- U-turn
- Roost
- Stun Spore
";
$g18081 = "Cramorant @ Heavy-Duty Boots
Ability: Gulp Missile
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Brave Bird
- Superpower
- Defog
- Roost
";
$g18091 = "Cramorant @ Waterium Z
Ability: Gulp Missile
Tera Type: &
EVs: 248 HP / 28 Atk / 216 SpD / 16 Spe
Gentle Nature
- Dive
- Tera Blast
- Roost
- Defog
";
$g18100 = "Latias @ Latiasite
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Defog
- Mystical Fire
- Roost
- Ice Beam
";
$g18109 = "Oricorio-Sensu @ Heavy-Duty Boots
Ability: Dancer
Tera Type: &
EVs: 220 SpA / 36 SpD / 252 Spe
Timid Nature
- Revelation Dance
- Hurricane
- Defog
- Roost
";
$g18118 = "Oricorio-Sensu @ Life Orb
Ability: Dancer
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Revelation Dance
- Hurricane
- Roost
- U-turn
";
$g18127 = "Oricorio @ Heavy-Duty Boots
Ability: Dancer
Tera Type: &
EVs: 136 HP / 116 SpA / 4 SpD / 252 Spe
Timid Nature
- Revelation Dance
- Air Slash
- Defog
- Roost
";
$g18136 = "Muk-Alola @ Leftovers
Ability: Poison Touch
Tera Type: &
EVs: 100 HP / 208 Atk / 100 Def / 100 SpD
Nature
- Gunk Shot
- Knock Off
- Haze
- Memento
";
$g18145 = "Quaquaval @ Life Orb
Ability: Moxie
Shiny: Yes
Tera Type: &
EVs: 156 HP / 252 Atk / 100 Spe
Jolly Nature
- Aqua Step
- Close Combat
- Roost
- Bulk Up
";
$g18155 = "Lucario @ Lucarionite
Ability: Adaptability
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Flash Cannon
- Aura Sphere
- Extreme Speed
- Swords Dance
";
$g18164 = "Mr. Mime-Galar @ Eviolite
Ability: Screen Cleaner
Tera Type: &
EVs: 8 HP / 8 Atk / 252 SpD / 240 Spe
Gentle Nature
- Freeze-Dry
- Focus Blast
- Encore
- Rapid Spin
";
$g18173 = "Scovillain @ Mental Herb
Ability: Chlorophyll
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Leaf Storm
- Protect
- Spicy Extract
- Leech Seed
";
$g18182 = "Scovillain @ Heavy-Duty Boots
Ability: Chlorophyll
Tera Type: &
EVs: 100 HP / 100 Def / 100 SpA / 100 SpD / 108 Spe
Nature
- Leaf Storm
- Flamethrower
- Substitute
- Leech Seed
";
$g18191 = "Swampert @ Swampertite
Ability: Torrent
Tera Type: &
EVs: 208 Def / 224 SpD / 76 Spe
Calm Nature
- Waterfall
- Rest
- Body Press
- Curse
";
$g18200 = "Abomasnow @ Abomasite
Ability: Snow Warning
Tera Type: &
EVs: 252 HP / 144 Def / 112 SpA
Relaxed Nature
- Leaf Storm
- Icicle Spear
- Substitute
- Focus Punch
";
$g18209 = "Altaria @ Altarianite
Ability: Natural Cure
Tera Type: &
EVs: 176 HP / 4 Atk / 76 Def / 252 SpD
Sassy Nature
- Body Slam
- Will-O-Wisp
- Roost
- Dragon Breath
";
$g18218 = "Wugtrio @ Kings Rock
Ability: Gooey
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Spe
Adamant Nature
- Triple Dive
- Protect
- Final Gambit
- Dig
";
$g18227 = "Castform @ Fire Gem
Ability: Forecast
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Sunny Day
- Fire Blast
- Solar Beam
- Ice Beam
";
$g18236 = "Wormadam-Trash @ Bug Gem
Ability: Overcoat
Tera Type: &
EVs: 56 HP / 200 SpA / 252 Spe
Modest Nature
- Quiver Dance
- Flash Cannon
- Signal Beam
- Protect
";
$g18245 = "Wormadam-Trash @
Ability: Anticipation
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Stealth Rock
- Metal Burst
- Thief
- Infestation
";
$g18254 = "Wormadam @ Sitrus Berry
Ability: Anticipation
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Quiver Dance
- Bug Buzz
- Giga Drain
- Tera Blast
";
$g18263 = "Wormadam-Sandy @ Leftovers
Ability: Anticipation
Tera Type: &
EVs: 248 HP / 28 SpA / 232 Spe
Modest Nature
- Quiver Dance
- Protect
- Signal Beam
- Earth Power
";
$g18272 = "Raichu-Alola @ Normalium Z
Ability: Surge Surfer
Tera Type: &
EVs: 248 HP / 252 SpA / 8 Spe
Modest Nature
- Happy Hour
- Thunderbolt
- Stored Power
- Fly
";
$g18281 = "Exeggutor-Alola @ Normalium Z
Ability: Frisk
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Celebrate
- Dragon Hammer
- Power Whip
- Brick Break
";
$g18290 = "Lopunny @ Lopunnite
Ability: Cute Charm
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Fake Out
- Quick Attack
- Ice Punch
- Healing Wish
";
$g18299 = "Hariyama @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 252 Atk / 156 Def / 100 Spe
Adamant Nature
- Fake Out
- Close Combat
- Ice Punch
- Facade
";
$g18308 = "Hariyama @ Assault Vest
Ability: Guts
Tera Type: &
EVs: 88 Atk / 168 Def / 252 SpD
Careful Nature
- Fling
- Bulk Up
- Close Combat
- Thunder Punch
";
$g18317 = "Revavroom @ Air Balloon
Ability: Filter
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Toxic Spikes
- Spin Out
- Thief
- Parting Shot
";
$g18326 = "Revavroom @ Iapapa Berry
Ability: Filter
Tera Type: &
EVs: 152 HP / 252 Atk / 4 Def / 100 Spe
Adamant Nature
- Shift Gear
- Iron Head
- Gunk Shot
- Tera Blast
";
$g18335 = "Revavroom @ White Herb
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 168 SpD / 92 Spe
Careful Nature
- Spin Out
- Thief
- Magnet Rise
- Rest
";
$g18344 = "Bisharp @ Eviolite
Ability: Defiant
Tera Type: &
EVs: 80 HP / 100 Atk / 24 Def / 120 SpD / 184 Spe
Adamant Nature
- Swords Dance
- Knock Off
- Dig
- Rock Tomb
";
$g18353 = "Rabsca @ Leppa Berry
Ability: Synchronize
Tera Type: &
EVs: 100 HP / 116 Def / 148 SpA / 144 SpD
Nature
- Revival Blessing
- Recover
- Psyshock
- Trick Room
";
$g18362 = "Rabsca @ Leppa Berry
Ability: Synchronize
Tera Type: &
EVs: 100 HP / 100 Def / 252 SpA / 28 SpD / 28 Spe
Nature
- Cosmic Power
- Earth Power
- Revival Blessing
- Protect
";
$g18371 = "Rabsca @ Heavy-Duty Boots
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Sassy Nature
- Revival Blessing
- Memento
- Trick Room
- Sludge Bomb
";
$g18380 = "Bellibolt @ Blunder Policy
Ability: Electromorphosis
Tera Type: &
EVs: 208 HP / 48 SpD / 252 Spe
Timid Nature
- Zap Cannon
- Tera Blast
- Chilling Water
- Slack Off
";
$g18389 = "Grafaiai @ Leftovers
Ability: Prankster
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 40 Def / 184 SpD / 28 Spe
Careful Nature
- Encore
- Gunk Shot
- Parting Shot
- Flatter
";
$g18399 = "Shaymin @ Leftovers
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpA / 116 SpD / 136 Spe
Timid Nature
- Seed Flare
- Leech Seed
- Protect
- Substitute
";
$g18408 = "Shaymin @ Chesto Berry
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 20 SpA / 236 Spe
Naive Nature
- Seed Flare
- Rest
- Substitute
- Endeavor
";
$g18417 = "Bellibolt @ Leftovers
Ability: Electromorphosis
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Thunderbolt
- Muddy Water
- Protect
- Slack Off
";
$g18426 = "Annihilape @ Roseli Berry
Ability: Defiant
Tera Type: &
EVs: 136 HP / 116 Atk / 240 SpD / 16 Spe
Careful Nature
- Taunt
- Gunk Shot
- Rage Fist
- Drain Punch
";
$g18435 = "Flutter Mane @ Wiki Berry
Ability: Protosynthesis
Tera Type: &
EVs: 208 HP / 244 Def / 56 Spe
Timid Nature
- Charm
- Shadow Ball
- Pain Split
- Memento
";
$g18444 = "Ambipom @ Life Orb
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Fake Out
- Double Hit
- Giga Impact
- Beat Up
";
$g18453 = "Manectric @ Manectite
Ability: Static
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Thunderbolt
- Rest
- Agility
- Charge
";
$g18462 = "Manectric @ Manectite
Ability: Static
Tera Type: &
EVs: 116 HP / 136 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Light Screen
- Roar
- Volt Switch
";
$g18471 = "Manectric @ Firium Z
Ability: Static
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Overheat
- Snarl
- Protect
";
$g18480 = "Hatterene @ Leftovers
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Future Sight
- Mystical Fire
- Giga Drain
- Protect
";
$g18489 = "Cresselia @ Heavy-Duty Boots
Ability: Levitate
Tera Type: &
EVs: 196 HP / 188 SpD / 124 Spe
Calm Nature
- Future Sight
- Toxic
- Tera Blast
- Moonlight
";
$g18498 = "Bellibolt @ Blunder Policy
Ability: Damp
Tera Type: &
EVs: 92 HP / 12 Def / 128 SpA / 24 SpD / 252 Spe
Bold Nature
- Zap Cannon
- Slack Off
- Muddy Water
- Substitute
";
$g18507 = "Latios @ Latiosite
Ability: Levitate
Tera Type: &
EVs: 252 HP / 56 SpA / 200 SpD
Calm Nature
- Future Sight
- Defog
- Roost
- Ice Beam
";
$g18516 = "Metagross @ Metagrossite
Ability: Clear Body
Tera Type: &
EVs: 8 HP / 248 Def / 252 Spe
Jolly Nature
- Body Press
- Iron Defense
- Reflect
- Rest
";
$g18525 = "Grumpig @ Poisonium Z
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Stored Power
- Toxic
- Rest
- Calm Mind
";
$g18534 = "Cetoddle @ Normalium Z
Ability: Sheer Force
Tera Type: &
EVs: 44 HP / 252 Atk / 212 Def
Adamant Nature
- Ice Shard
- Belly Drum
- Play Rough
- Superpower
";
$g18543 = "Cetoddle @ Eviolite
Ability: Sheer Force
Tera Type: &
EVs: 252 HP / 160 Def / 96 SpD
Impish Nature
- Icicle Crash
- Play Rough
- Yawn
- Protect
";
$g18552 = "Garbodor @ Ghostium Z
Ability: Aftermath
Tera Type: &
EVs: 252 HP / 212 Atk / 44 Def
Adamant Nature
- Gunk Shot
- Spikes
- Spite
- Stockpile
";
$g18561 = "Tapu Fini @ Icium Z
Ability: Misty Surge
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Scald
- Iron Defense
- Haze
- Calm Mind
";
$g18570 = "Pawmo @ Eviolite
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Wish
- Rest
- Volt Switch
- Body Press
";
$g18579 = "Iron Thorns @ Chople Berry
Ability: Quark Drive
Tera Type: &
EVs: 140 HP / 112 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stone Edge
- Wild Charge
- Low Kick
- Dragon Dance
";
$g18588 = "Gholdengo @ Assault Vest
Ability: Good as Gold
Tera Type: &
EVs: 88 HP / 240 Atk / 180 SpA
Nature
- Low Kick
- Power Gem
- Psychic
- Shadow Ball
";
$g18597 = "Gholdengo @ Leftovers
Ability: Good as Gold
Tera Type: &
EVs: 252 HP / 80 Def / 120 SpA / 24 SpD / 24 Spe
Bold Nature
- Make It Rain
- Memento
- Recover
- Protect
";
$g18606 = "Gholdengo @ Choice Scarf
Ability: Good as Gold
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Shadow Ball
- Charge Beam
- Recover
- Trick
";
$g18616 = "Gholdengo @ Aguav Berry
Ability: Good as Gold
Tera Type: &
EVs: 232 HP / 136 Spe
Lax Nature
- Steel Beam
- Substitute
- Shadow Ball
- Recover
";
$g18625 = "Pinsir @ Pinsirite
Ability: Hyper Cutter
Tera Type: &
EVs: 36 HP / 112 Atk / 36 Def / 72 SpD / 252 Spe
Jolly Nature
- Giga Impact
- Hyper Beam
- Rock Tomb
- Bulk Up
";
$g18634 = "Gholdengo @ Light Clay
Ability: Good as Gold
Shiny: Yes
Tera Type: &
EVs: 240 HP / 12 SpA / 4 SpD / 252 Spe
Timid Nature
- Shadow Ball
- Make It Rain
- Reflect
- Nasty Plot
";
$g18644 = "Gholdengo @ Light Clay
Ability: Good as Gold
Tera Type: &
EVs: 240 HP / 12 SpA / 4 SpD / 252 Spe
Timid Nature
- Shadow Ball
- Make It Rain
- Light Screen
- Nasty Plot
";
$g18653 = "Gholdengo @ Covert Cloak
Ability: Good as Gold
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Rest
- Thunder Wave
- Hex
- Sleep Talk
";
$g18662 = "Gliscor @ Flame Orb
Ability: Poison Heal
Tera Type: &
EVs: 184 HP / 36 Atk / 184 Def / 104 Spe
Impish Nature
- Facade
- Curse
- Roost
- Defog
";
$g18671 = "Gliscor @ Toxic Orb
Ability: Poison Heal
Tera Type: &
EVs: 184 HP / 36 Atk / 184 Def / 104 Spe
Impish Nature
- Facade
- Curse
- Roost
- Defog
";
$g18680 = "Hoopa-Unbound @ Light Ball
Ability: Magician
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Psychic
- Energy Ball
- Fling
- Protect
";
$g18689 = "Gurdurr @ Eviolite
Ability: Sheer Force
Tera Type: &
EVs: 168 HP / 68 Atk / 84 Def / 188 SpD
Adamant Nature
- Ice Punch
- Thunder Punch
- Defog
- Bulk Up
";
$g18698 = "Landorus @ Toxic Orb
Ability: Sheer Force
Tera Type: &
EVs: 32 HP / 112 Def / 112 SpA / 252 Spe
Timid Nature
- Sandsear Storm
- Defog
- Rest
- Sleep Talk
";
$g18707 = "Ho-Oh @ Heavy-Duty Boots
Ability: Pressure
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 108 SpD / 100 Spe
Nature
- Sacred Fire
- Brave Bird
- Defog
- Whirlwind
";
$g18716 = "Tangrowth @ Eject Pack
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 112 Def / 140 SpA
Quiet Nature
- Leaf Storm
- Focus Blast
- Stun Spore
- Knock Off
";
$g18725 = "Tropius @ Sitrus Berry
Ability: Harvest
Tera Type: &
EVs: 244 HP / 12 SpA / 252 SpD
Calm Nature
- Tera Blast
- Leech Seed
- Substitute
- Protect
";
$g18734 = "Arboliva @ Sitrus Berry
Ability: Harvest
Tera Type: &
EVs: 252 HP / 100 Def / 4 SpA / 152 SpD
Calm Nature
- Hyper Voice
- Leech Seed
- Substitute
- Protect
";
$g18743 = "Tangrowth @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Lax Nature
- Toxic
- Giga Drain
- Earthquake
- Protect
";
$g18752 = "Tangrowth @ Maranga Berry
Ability: Regenerator
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Bullet Seed
- Brick Break
- Morning Sun
- Curse
";
$g18762 = "Lilligant-Hisui @ Occa Berry
Ability: Leaf Guard
Tera Type: &
EVs: 124 HP / 152 SpD / 232 Spe
Adamant Nature
- Leaf Blade
- Axe Kick
- Synthesis
- Victory Dance
";
$g18771 = "Lilligant-Hisui @ Life Orb
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Leaf Blade
- Close Combat
- Defog
- Synthesis
";
$g18780 = "Heracross @ Heracronite
Ability: Guts
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Arm Thrust
- Rock Blast
- Trailblaze
- Bulk Up
";
$g18789 = "Glaceon @ Leftovers
Ability: Ice Body
Tera Type: &
EVs: 252 HP / 176 Def / 12 SpA / 68 Spe
Bold Nature
- Freeze-Dry
- Tera Blast
- Wish
- Calm Mind
";
$g18798 = "Lurantis @ Custap Berry
Ability: Contrary
Tera Type: &
EVs: 100 HP / 100 Def / 144 SpA / 164 Spe
Mild Nature
- Leaf Storm
- Tera Blast
- Substitute
- Synthesis
";
$g18807 = "Appletun @ Psychium Z
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 188 Def / 64 SpA / 4 SpD
Bold Nature
- Apple Acid
- Leech Seed
- Reflect
- Light Screen
";
$g18816 = "Cinderace @ Heat Rock
Ability: Blaze
Tera Type: &
EVs: 216 Atk / 184 SpA / 108 Spe
Naive Nature
- Pyro Ball
- Overheat
- Substitute
- Sunny Day
";
$g18825 = "Ceruledge @ Heat Rock
Ability: Flash Fire
Tera Type: &
EVs: 20 HP / 252 Atk / 4 SpD / 232 Spe
Adamant Nature
- Bitter Blade
- Solar Blade
- Sunny Day
- Flame Charge
";
$g18834 = "Orthworm @ Assault Vest
Ability: Earth Eater
Tera Type: &
EVs: 248 HP / 20 Atk / 240 SpD
Careful Nature
- Iron Tail
- Body Press
- Dig
- Facade
";
$g18843 = "Orthworm @ Chesto Berry
Ability: Earth Eater
Tera Type: &
EVs: 248 HP / 8 Atk / 8 SpD / 244 Spe
Jolly Nature
- Iron Tail
- Body Press
- Rest
- Coil
";
$g18852 = "Orthworm @ Leftovers
Ability: Earth Eater
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Iron Head
- Body Press
- Stealth Rock
- Protect
";
$g18861 = "Orthworm @ Chople Berry
Ability: Earth Eater
Tera Type: &
EVs: 252 HP / 100 Atk / 100 Def / 56 Spe
Careful Nature
- Coil
- Helping Hand
- Stealth Rock
- Iron Tail
";
$g18870 = "Orthworm @ Psychic Seed
Ability: Earth Eater
Tera Type: &
EVs: 248 HP / 8 Atk / 64 Def / 188 SpD
Impish Nature
- Iron Head
- Body Press
- Stealth Rock
- Protect
";
$g18879 = "Slither Wing @ Booster Energy
Ability: Protosynthesis
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Close Combat
- Wild Charge
- Tera Blast
- Bulk Up
";
$g18889 = "Garganacl @ Normalium Z
Ability: Purifying Salt
Tera Type: &
EVs: 252 HP / 4 Atk / 56 Def / 196 SpD
Impish Nature
- Salt Cure
- Explosion
- Recover
- Curse
";
$g18898 = "Enamorus-Therian @ Sitrus Berry
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Springtide Storm
- Mystical Fire
- Draining Kiss
- Calm Mind
";
$g18907 = "Enamorus-Therian @ Heavy-Duty Boots
Ability: Overcoat
Shiny: Yes
Tera Type: &
EVs: 248 HP / 144 SpA / 116 SpD
Modest Nature
- Draining Kiss
- Focus Blast
- Iron Defense
- Calm Mind
";
$g18917 = "Enamorus-Therian @ Fairium Z
Ability: Overcoat
Tera Type: &
EVs: 100 HP / 100 Def / 152 SpA / 156 SpD
Quiet Nature
- Springtide Storm
- Mystical Fire
- Healing Wish
- Taunt
";
$g18926 = "Hoopa-Unbound @ Psychium Z
Ability: Magician
Tera Type: &
EVs: 248 HP / 44 SpA / 36 SpD / 180 Spe
Modest Nature
- Psyshock
- Dark Pulse
- Reflect
- Calm Mind
";
$g18935 = "Landorus-Therian @ Kings Rock
Ability: Intimidate
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpA / 8 SpD / 100 Spe
Nature
- Sandsear Storm
- Rock Tomb
- Tera Blast
- Protect
";
$g18944 = "Kingambit @ Assault Vest
Ability: Supreme Overlord
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Kowtow Cleave
- Iron Head
- Sucker Punch
- Low Kick
";
$g18953 = "Klawf @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Stone Edge
- Knock Off
- Brick Break
- Trailblaze
";
$g18962 = "Slowbro @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Scald
- Body Press
- Future Sight
- Fire Blast
";
$g18971 = "Slowbro @ Slowbronite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Lax Nature
- Body Press
- Iron Defense
- Yawn
- Rest
";
$g18980 = "Slowbro @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 148 Def / 4 SpA / 104 SpD
Bold Nature
- Foul Play
- Future Sight
- Slack Off
- Thunder Wave
";
$g18989 = "Enamorus @ Metronome
Ability: Contrary
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Naive Nature
- Springtide Storm
- Superpower
- Healing Wish
- Substitute
";
$g18998 = "Enamorus-Therian @ Choice Specs
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Springtide Storm
- Tera Blast
- Earth Power
- Healing Wish
";
$g19007 = "Sandy Shocks @ Life Orb
Ability: Protosynthesis
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Gravity
- Earth Power
- Zap Cannon
- Protect
";
$g19016 = "Bronzor @ Eviolite
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Sassy Nature
- Helping Hand
- Safeguard
- Trick Room
- Confuse Ray
";
$g19025 = "Kilowattrel @ Focus Sash
Ability: Wind Power
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Tailwind
- Thunderbolt
- Hurricane
- Electro Ball
";
$g19034 = "Bellibolt @ Custap Berry
Ability: Electromorphosis
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Endure
- Soak
- Parabolic Charge
- Muddy Water
";
$g19043 = "Iron Treads @ Choice Specs
Ability: Quark Drive
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Steel Beam
- Earth Power
-
-
";
$g19052 = "Tatsugiri-Stretchy @ Haban Berry
Ability: Storm Drain
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Counter
- Icy Wind
- Mirror Coat
- Draco Meteor
";
$g19062 = "Aron @ Shell Bell
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Bold Nature
- Endeavor
- Protect
- Toxic
- Stealth Rock
";
$g19071 = "Togedemaru @ Shell Bell
Ability: Sturdy
Tera Type: &
EVs: 172 Def / 92 SpD
Timid Nature
- Endeavor
- Spiky Shield
- Toxic
- Encore
";
$g19080 = "Eiscue @ Salac Berry
Ability: Ice Face
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Ice Punch
- Substitute
- Reversal
- Belly Drum
";
$g19089 = "Slaking @ Life Orb
Ability: Truant
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naive Nature
- Body Slam
- Earthquake
- Gunk Shot
- Icy Wind
";
$g19098 = "Lokix @ Choice Band
Ability: Tinted Lens
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- First Impression
-
-
-
";
$g19107 = "First Impression @ Leftovers
Ability: Stamina
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Rest
- Sleep Talk
- Body Press
- Earthquake
";
$g19116 = "Frogadier @ Life Orb
Ability: Protean
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Grass Knot
- Ice Beam
- U-turn
- Gunk Shot
";
$g19125 = "Glimmora @ Normal Gem
Ability: Toxic Debris
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Endure
- Power Gem
- Self-Destruct
- Sludge Wave
";
$g19134 = "Espathra @ Weakness Policy
Ability: Speed Boost
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Mild Nature
- Lumina Crash
- Dazzling Gleam
- Low Kick
- Endure
";
$g19143 = "Miraidon @ Flying Gem
Ability: Hadron Engine
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Acrobatics
- Body Slam
- Crunch
- U-turn
";
$g19152 = "Arcanine-Hisui @ Choice Scarf
Ability: Rock Head
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Head Smash
- Raging Fury
- Outrage
- Close Combat
";
$g19161 = "Orthworm @ Leftovers
Ability: Earth Eater
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Rest
- Sleep Talk
- Shed Tail
- Metal Burst
";
$g19170 = "Sunflora @ Choice Specs
Ability: Solar Power
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Leaf Storm
- Earth Power
- Sludge Bomb
- Tera Blast
";
$g19179 = "Slaking @ Choice Band
Ability: Truant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Giga Impact
- Fire Punch
- Wild Charge
- Gunk Shot
";
$g19188 = "Zangoose @ Toxic Orb
Ability: Toxic Boost
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Facade
- Close Combat
- Protect
- Fling
";
$g19197 = "Ariados @ Occa Berry
Ability: Insomnia
Tera Type: &
EVs: 248 HP / 8 Atk / 100 Def / 152 SpD
Relaxed Nature
- Sticky Web
- Toxic Spikes
- Electroweb
- Dig
";
$g19206 = "Latias @ Weakness Policy
Ability: Levitate
Tera Type: &
EVs: 128 HP / 128 SpA / 252 Spe
Timid Nature
- Calm Mind
- Stored Power
- Tera Blast
- Wish
";
$g19215 = "Swalot @ Leftovers
Ability: Sticky Hold
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Bold Nature
- Rest
- Acid Armor
- Body Press
- Amnesia
";
$g19224 = "Swalot @ Custap Berry
Ability: Liquid Ooze
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Sludge Bomb
- Ice Beam
- Encore
- Destiny Bond
";
$g19233 = "Swoobat @ Sitrus Berry
Ability: Simple
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Nasty Plot
- Psychic
- Fly
- Tera Blast
";
$g19243 = "Quaquaval @ Choice Band
Ability: Moxie
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Aqua Step
- Close Combat
- Ice Spinner
- U-turn
";
$g19252 = "Florges @ Choice Specs
Ability: Flower Veil
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Moonblast
- Tera Blast
- Giga Drain
- Pollen Puff
";
$g19261 = "Grapploct @ Choice Band
Ability: Limber
Tera Type: &
EVs: 164 HP / 212 Atk / 36 Def / 64 SpD / 32 Spe
Adamant Nature
- Close Combat
- Stomping Tantrum
- Ice Punch
- Liquidation
";
$g19270 = "Guzzlord @ Choice Band
Ability: Beast Boost
Tera Type: &
EVs: 232 Atk / 100 Def / 152 SpD / 24 Spe
Adamant Nature
- Knock Off
- Outrage
- Iron Tail
- Heat Crash
";
$g19279 = "Guzzlord @ Life Orb
Ability: Beast Boost
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Dark Pulse
- Draco Meteor
- Fire Blast
- Protect
";
$g19288 = "Guzzlord @ Choice Specs
Ability: Beast Boost
Tera Type: &
EVs: 252 Def / 232 SpA / 24 Spe
Modest Nature
- Dark Pulse
- Draco Meteor
- Sludge Bomb
- Fire Blast
";
$g19297 = "Corsola @ Choice Band
Ability: Hustle
Tera Type: &
EVs: 236 HP / 252 Atk / 20 Spe
Adamant Nature
- Head Smash
- Liquidation
- Icicle Spear
- Sucker Punch
";
$g19306 = "Dedenne @ Choice Specs
Ability: Cheek Pouch
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Tera Blast
- Grass Knot
- Volt Switch
";
$g19315 = "Heliolisk @ Life Orb
Ability: Dry Skin
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Thunderbolt
- Focus Blast
- Grass Knot
- Dragon Pulse
";
$g19324 = "Braviary @ Maranga Berry
Ability: Defiant
Tera Type: &
EVs: 128 HP / 128 Atk / 252 Spe
Jolly Nature
- Bulk Up
- Roost
- Acrobatics
- Close Combat
";
$g19333 = "Weavile @ Durin Berry
Ability: Pickpocket
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Natural Gift
- Dig
- Tera Blast
";
$g19342 = "Durant @ Leftovers
Ability: Truant
Tera Type: &
EVs: 216 HP / 84 Def / 208 Spe
Jolly Nature
- Entrainment
- Toxic
- Protect
- Stomping Tantrum
";
$g19351 = "Magearna @ Petaya Berry
Ability: Soul-Heart
Tera Type: &
EVs: 144 HP / 120 Def / 64 SpA / 88 SpD / 92 Spe
Bold Nature
- Agility
- Substitute
- Draining Kiss
- Volt Switch
";
$g19360 = "Roaring Moon @ Liechi Berry
Ability: Protosynthesis
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Hasty Nature
- Substitute
- Acrobatics
- Jaw Lock
- Tera Blast
";
$g19369 = "Roaring Moon @ Assault Vest
Ability: Protosynthesis
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 252 SpD / 4 Spe
Adamant Nature
- U-turn
- Jaw Lock
- Iron Head
- Dragon Claw
";
$g19379 = "Roaring Moon @ Snowball
Ability: Protosynthesis
Tera Type: &
EVs: 60 Atk / 200 Def / 188 SpD / 60 Spe
Adamant Nature
- Roost
- Taunt
- Jaw Lock
- Dragon Tail
";
$g19388 = "Bibarel @ Sitrus Berry
Ability: Simple
Tera Type: &
EVs: 252 Atk / 252 SpD / 4 Spe
Adamant Nature
- Swords Dance
- Protect
- Return
- Aqua Jet
";
$g19397 = "Raikou @ Air Balloon
Ability: Pressure
Tera Type: &
EVs: 132 HP / 60 Def / 96 SpA / 120 SpD / 100 Spe
Timid Nature
- Calm Mind
- Weather Ball
- Rain Dance
- Thunder
";
$g19406 = "Huntail @ White Herb
Ability: Swift Swim
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naughty Nature
- Shell Smash
- Dive
- Tera Blast
- Protect
";
$g19415 = "Dunsparce @ Eviolite
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Headbutt
- Stomping Tantrum
- Glare
- Roost
";
$g19424 = "Muk-Alola @ Choice Specs
Ability: Power of Alchemy
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Sludge Bomb
- Dark Pulse
- Fire Blast
- Thunder
";
$g19433 = "Arboliva @ Life Orb
Ability: Seed Sower
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Energy Ball
- Hyper Beam
- Substitute
- Strength Sap
";
$g19442 = "Zangoose @ Toxic Orb
Ability: Toxic Boost
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Facade
- Close Combat
- Night Slash
- Protect
";
$g19451 = "Zangoose @ Fightinium Z
Ability: Immunity
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Gunk Shot
- Crush Claw
- Taunt
- Detect
";
$g19460 = "Crustle @ Rock Gem
Ability: Sturdy
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Adamant Nature
- Shell Smash
- Rock Wrecker
- Rock Blast
- Counter
";
$g19469 = "Crustle @ Heavy-Duty Boots
Ability: Weak Armor
Tera Type: &
EVs: 100 HP / 84 Atk / 72 Def / 252 Spe
Jolly Nature
- Stone Edge
- Heavy Slam
- Stealth Rock
- Spikes
";
$g19478 = "Flamigo @ Yache Berry
Ability: Scrappy
Tera Type: &
EVs: 108 HP / 128 Atk / 108 SpD / 164 Spe
Careful Nature
- Brave Bird
- Close Combat
- Roost
- Bulk Up
";
$g19487 = "Skeledirge @ Power Herb
Ability: Blaze
Tera Type: &
EVs: 248 HP / 88 SpA / 40 SpD / 132 Spe
Modest Nature
- Torch Song
- Solar Beam
- Will-O-Wisp
- Slack Off
";
$g19496 = "Hatterene @ Psychium Z
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Draining Kiss
- Tera Blast
- Reflect
- Light Screen
";
$g19505 = "Arboliva @ Psychium Z
Ability: Seed Sower
Tera Type: &
EVs: 252 HP / 248 SpA / 8 SpD
Modest Nature
- Energy Ball
- Strength Sap
- Reflect
- Light Screen
";
$g19514 = "Ceruledge @ Psychium Z
Ability: Flash Fire
Tera Type: &
EVs: 196 HP / 56 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bitter Blade
- Reflect
- Light Screen
- Swords Dance
";
$g19523 = "Polteageist @ Psychium Z
Ability: Cursed Body
Tera Type: &
EVs: 252 HP / 184 SpD / 72 Spe
Modest Nature
- Shadow Ball
- Strength Sap
- Reflect
- Calm Mind
";
$g19532 = "Rotom-Wash @ Psychium Z
Ability: Levitate
Tera Type: &
EVs: 252 HP / 124 Def / 36 SpA / 96 Spe
Bold Nature
- Hydro Pump
- Will-O-Wisp
- Pain Split
- Light Screen
";
$g19541 = "Celesteela @ Flying Gem
Ability: Beast Boost
Shiny: Yes
Tera Type: &
EVs: 120 HP / 136 Atk / 252 Def
Relaxed Nature
- Acrobatics
- Flamethrower
- Giga Drain
- Protect
";
$g19551 = "Banette @ Banettite
Ability: Insomnia
Tera Type: &
EVs: 252 HP / 56 Atk / 200 SpD
Careful Nature
- Shadow Claw
- Knock Off
- Encore
- Disable
";
$g19560 = "Iron Valiant @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 176 HP / 188 Def / 144 Spe
Timid Nature
- Protect
- Encore
- Disable
- Moonblast
";
$g19569 = "Iron Bundle @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 208 HP / 92 Def / 104 SpA / 104 Spe
Modest Nature
- Freeze-Dry
- Hydro Pump
- Encore
- Thief
";
$g19578 = "Brute Bonnet @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 176 HP / 80 Atk / 252 Def
Impish Nature
- Body Press
- Thief
- Sucker Punch
- Bullet Seed
";
$g19587 = "Brute Bonnet @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Seed Bomb
- Spore
- Thief
- Synthesis
";
$g19596 = "Samurott-Hisui @ Metronome
Ability: Sharpness
Tera Type: &
EVs: 244 HP / 4 Atk / 4 Def / 4 SpD / 252 Spe
Jolly Nature
- Ceaseless Edge
- Sacred Sword
- Substitute
- Swords Dance
";
$g19605 = "Pyroar @ Heavy-Duty Boots
Ability: Unnerve
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Fire Blast
- Tera Blast
- Will-O-Wisp
- Work Up
";
$g19614 = "Manaphy @ Leftovers
Ability: Hydration
Tera Type: &
EVs: 100 HP / 100 Def / 108 SpA / 100 SpD / 100 Spe
Nature
- Scald
- Ice Beam
- Covet
- Aqua Ring
";
$g19623 = "Mr. Rime @ Psychium Z
Ability: Screen Cleaner
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Triple Axel
- Drain Punch
- Tera Blast
- Meditate
";
$g19632 = "Grumpig @ Normalium Z
Ability: Thick Fat
Tera Type: &
EVs: 104 HP / 252 Atk / 4 SpD / 148 Spe
Adamant Nature
- Ice Punch
- Zen Headbutt
- Drain Punch
- Splash
";
$g19641 = "Grafaiai @ Darkinium Z
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Super Fang
- Taunt
- Encore
- Parting Shot
";
$g19650 = "Pikachu @ Light Ball
Ability: Lightning Rod
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Hasty Nature
- Volt Tackle
- Surf
- Encore
- Protect
";
$g19659 = "Misdreavus @ Ghostium Z
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Calm Nature
- Foul Play
- Pain Split
- Destiny Bond
- Will-O-Wisp
";
$g19668 = "Cacturne @ Ghostium Z
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Leaf Storm
- Spikes
- Destiny Bond
- Spiky Shield
";
$g19677 = "Glimmora @ Psychium Z
Ability: Toxic Debris
Tera Type: &
EVs: 40 HP / 216 SpA / 252 Spe
Timid Nature
- Sludge Bomb
- Reflect
- Light Screen
- Spiky Shield
";
$g19686 = "Chesnaught @ Leftovers
Ability: Bulletproof
Tera Type: &
EVs: 100 HP / 52 Atk / 100 Def / 184 SpD / 72 Spe
Impish Nature
- Trailblaze
- Leech Seed
- Substitute
- Spiky Shield
";
$g19695 = "Overqwil @ Ghostium Z
Ability: Intimidate
Tera Type: &
EVs: 48 Atk / 208 SpD / 252 Spe
Jolly Nature
- Barb Barrage
- Bite
- Spikes
- Destiny Bond
";
$g19704 = "Overqwil @ Choice Band
Ability: Poison Point
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Barb Barrage
- Crunch
- Aqua Jet
- Tera Blast
";
$g19713 = "Overqwil @ Heavy-Duty Boots
Ability: Poison Point
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Barb Barrage
- Protect
- Spikes
- Toxic Spikes
";
$g19722 = "Overqwil @ Icium Z
Ability: Poison Point
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Barb Barrage
- Crunch
- Toxic Spikes
- Haze
";
$g19731 = "Dragalge @ Icium Z
Ability: Adaptability
Tera Type: &
EVs: 200 HP / 100 SpA / 208 SpD
Calm Nature
- Draco Meteor
- Sludge Bomb
- Hydro Pump
- Haze
";
$g19740 = "Overqwil @ Assault Vest
Ability: Poison Point
Tera Type: &
EVs: 236 HP / 16 Atk / 4 Def / 252 Spe
Jolly Nature
- Barb Barrage
- Crunch
- Tera Blast
- Fell Stinger
";
$g19749 = "Overqwil @ Damp Rock
Ability: Swift Swim
Tera Type: &
EVs: 168 HP / 252 Atk / 4 SpD / 84 Spe
Adamant Nature
- Gunk Shot
- Crunch
- Liquidation
- Rain Dance
";
$g19758 = "Qwilfish-Hisui @ Eviolite
Ability: Poison Point
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Barb Barrage
- Spikes
- Rest
- Protect
";
$g19767 = "Overqwil @ Lum Berry
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Gunk Shot
- Crunch
- Aqua Jet
- Swords Dance
";
$g19776 = "Overqwil @ Rocky Helmet
Ability: Poison Point
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Impish Nature
- Barb Barrage
- Crunch
- Spikes
- Rest
";
$g19785 = "Overqwil @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 152 HP / 104 SpD / 252 Spe
Jolly Nature
- Crunch
- Toxic
- Substitute
- Protect
";
$g19794 = "Overqwil @ Leftovers
Ability: Poison Point
Tera Type: &
EVs: 252 HP / 4 Atk / 60 Def / 108 SpD / 84 Spe
Impish Nature
- Barb Barrage
- Taunt
- Icy Wind
- Protect
";
$g19803 = "Overqwil @ Shuca Berry
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 192 Atk / 24 Def / 40 Spe
Adamant Nature
- Gunk Shot
- Crunch
- Agility
- Swords Dance
";
$g19812 = "Overqwil @ Bright Powder
Ability: Intimidate
Tera Type: &
EVs: 100 HP / 100 Atk / 108 Def / 100 SpD / 100 Spe
Nature
- Crunch
- Gunk Shot
- Haze
- Spikes
";
$g19821 = "Overqwil @ Shuca Berry
Ability: Poison Point
Tera Type: &
EVs: 176 HP / 4 Atk / 128 Def / 200 Spe
Jolly Nature
- Barb Barrage
- Icy Wind
- Destiny Bond
- Protect
";
$g19830 = "Overqwil @ Normalium Z
Ability: Poison Point
Tera Type: &
EVs: 108 HP / 144 Atk / 4 SpD / 252 Spe
Jolly Nature
- Poison Sting
- Swords Dance
- Stockpile
- Self-Destruct
";
$g19839 = "Overqwil @ Blunder Policy
Ability: Poison Point
Tera Type: &
EVs: 252 HP / 8 Def / 248 SpD
Careful Nature
- Barb Barrage
- Rest
- Blizzard
- Stockpile
";
$g19848 = "Ting-Lu @ Groundium Z
Ability: Vessel of Ruin
Shiny: Yes
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Ruination
- Body Press
- Whirlwind
- Spikes
";
$g19858 = "Girafarig @ Eviolite
Ability: Sap Sipper
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
- Mirror Coat
- Future Sight
- Thunder Wave
- Wish
";
$g19867 = "Girafarig @ Eviolite
Ability: Early Bird
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Twin Beam
- Thunderbolt
- Rest
- Nasty Plot
";
$g19876 = "Bronzong @ Colbur Berry
Ability: Levitate
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpD / 108 Spe
Impish Nature
- Heavy Slam
- Ice Spinner
- Stealth Rock
- Protect
";
$g19885 = "Bronzong @ Choice Band
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 252 Def / 4 SpD
Brave Nature
- Gyro Ball
- Ice Spinner
- Body Press
- Trick
";
$g19894 = "Bronzong @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 16 Def / 192 SpA / 48 SpD
Modest Nature
- Psychic
- Charge Beam
- Power Gem
- Protect
";
$g19903 = "Bronzong @ Life Orb
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpA
Brave Nature
- Rock Blast
- Ice Spinner
- Steel Beam
- Tera Blast
";
$g19912 = "Swalot @ Heavy-Duty Boots
Ability: Liquid Ooze
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Gunk Shot
- Pain Split
- Thunder Wave
- Destiny Bond
";
$g19921 = "Swalot @ Petaya Berry
Ability: Sticky Hold
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Belch
- Giga Drain
- Tera Blast
- Stuff Cheeks
";
$g19930 = "Swalot @ Leftovers
Ability: Liquid Ooze
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Gunk Shot
- Swallow
- Swords Dance
- Stockpile
";
$g19939 = "Oinkologne @ Maranga Berry
Ability: Lingering Aroma
Tera Type: &
EVs: 248 HP / 8 Atk / 184 Def / 68 SpD
Impish Nature
- Dig
- Body Press
- Rest
- Stuff Cheeks
";
$g19948 = "Oinkologne-F @ Liechi Berry
Ability: Thick Fat
Tera Type: &
EVs: 192 Atk / 252 Def / 64 SpD
Impish Nature
- Body Press
- Body Slam
- Thief
- Stuff Cheeks
";
$g19957 = "Aggron @ Aggronite
Ability: Rock Head
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Heavy Slam
- Dragon Tail
- Icy Wind
- Magnet Rise
";
$g19966 = "Charizard @ Charizardite X
Ability: Blaze
Shiny: Yes
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Outrage
- Will-O-Wisp
- Roost
- Roar
";
$g19976 = "Roaring Moon @ Lum Berry
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Outrage
- Tera Blast
- Dig
- Dragon Dance
";
$g19985 = "Shaymin @ Air Balloon
Ability: Natural Cure
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Last Resort
- Leech Seed
- Substitute
- Protect
";
$g19994 = "Sawsbuck @ Silk Scarf
Ability: Sap Sipper
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Impish Nature
- Last Resort
- Leech Seed
- Substitute
- Protect
";
$g20003 = "Roaring Moon @ Air Balloon
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Scale Shot
- Crunch
- Stone Edge
- U-turn
";
$g20012 = "Cursola @ Ghostium Z
Ability: Perish Body
Tera Type: &
EVs: 252 HP / 96 SpA / 160 SpD
Calm Nature
- Shadow Ball
- Stealth Rock
- Will-O-Wisp
- Destiny Bond
";
$g20021 = "Cursola @ Heavy-Duty Boots
Ability: Perish Body
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Shadow Ball
- Giga Drain
- Stealth Rock
- Protect
";
$g20030 = "Slaking @ Leftovers
Ability: Truant
Tera Type: &
EVs: 240 HP / 76 Def / 120 SpD / 72 Spe
Impish Nature
- Amnesia
- Rest
- Return
- Counter
";
$g20039 = "Swalot @ Life Orb
Ability: Liquid Ooze
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Gunk Shot
- Fire Punch
- Thunder Punch
- Swords Dance
";
$g20048 = "Thundurus @ Leftovers
Ability: Prankster
Tera Type: &
EVs: 228 HP / 252 SpA / 28 SpD
Calm Nature
- Wildbolt Storm
- Torment
- Substitute
- Charge
";
$g20057 = "Garchomp @ Garchompite
Ability: Sand Veil
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Earthquake
- Fire Fang
- Scale Shot
- Swords Dance
";
$g20066 = "Wugtrio @ Choice Specs
Ability: Gooey
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hydro Pump
- Final Gambit
- Ice Beam
- Earth Power
";
$g20075 = "Dondozo @ Choice Specs
Ability: Oblivious
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Hydro Pump
- Hyper Beam
- Tera Blast
- Rain Dance
";
$g20084 = "Corviknight @ Choice Specs
Ability: Unnerve
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Steel Beam
- Flash Cannon
- Air Slash
- Tera Blast
";
$g20093 = "Meloetta @ Choice Band
Ability: Serene Grace
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Zen Headbutt
- U-turn
- Tera Blast
- Drain Punch
";
$g20102 = "Cinderace @ Choice Specs
Ability: Libero
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Electro Ball
- Fire Blast
- Shadow Ball
- Tera Blast
";
$g20111 = "Murkrow @ Flyinium Z
Ability: Prankster
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Thunder Wave
- Brave Bird
- Roost
- Quash
";
$g20120 = "Haxorus @ Dragonium Z
Ability: Rivalry
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draco Meteor
- Focus Blast
- Grass Knot
- Protect
";
$g20129 = "Basculin @ Waterium Z
Ability: Adaptability
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hydro Pump
- Ice Beam
- Tera Blast
- Final Gambit
";
$g20138 = "Tropius @ Sitrus Berry
Ability: Harvest
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Sunny Day
- Leech Seed
- Protect
- Giga Drain
";
$g20147 = "Iron Treads @ Choice Specs
Ability: Quark Drive
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Earth Power
- Flash Cannon
- Steel Beam
- Thunder
";
$g20156 = "Pyroar @ Choice Band
Ability: Moxie
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Flare Blitz
- Body Slam
- Trailblaze
- Psychic Fangs
";
$g20166 = "Tauros @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Blizzard
- Fire Blast
- Body Slam
- Thunder
";
$g20175 = "Brute Bonnet @ Assault Vest
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 124 Def / 132 SpD
Brave Nature
- Payback
- Sucker Punch
- Seed Bomb
- Close Combat
";
$g20184 = "Goodra @ Choice Band
Ability: Gooey
Tera Type: &
EVs: 128 HP / 252 Atk / 128 Spe
Adamant Nature
- Outrage
- Dragon Tail
- Superpower
- Poison Tail
";
$g20193 = "Tinkaton @ Quick Claw
Ability: Mold Breaker
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def
Brave Nature
- Swords Dance
- Gigaton Hammer
- Knock Off
- Tera Blast
";
$g20202 = "Cloyster @ White Herb
Ability: Overcoat
Tera Type: &
EVs: 232 SpA / 100 SpD / 176 Spe
Modest Nature
- Shell Smash
- Ice Beam
- Hydro Pump
- Tera Blast
";
$g20211 = "Hitmonchan @ Choice Scarf
Ability: Iron Fist
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Close Combat
- Ice Punch
- Stone Edge
- Rapid Spin
";
$g20220 = "Mabosstiff @ Liechi Berry
Ability: Guard Dog
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Jaw Lock
- Dig
- Trailblaze
- Fire Fang
";
$g20229 = "Cryogonal @ Choice Specs
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Ice Beam
- Freeze-Dry
- Tera Blast
- Signal Beam
";
$g20239 = "Ursaring @ Flame Orb
Ability: Quick Feet
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Swords Dance
- Facade
- Close Combat
- Crunch
";
$g20248 = "Ursaluna @ Ground Gem
Ability: Guts
Tera Type: &
EVs: 164 Atk / 148 SpD / 196 Spe
Adamant Nature
- Dig
- Last Resort
-
-
";
$g20257 = "Last Resort Ursaluna @ Leftovers
Ability: Guts
Tera Type: &
EVs: 252 HP / 56 Def / 200 SpD
Careful Nature
- Rest
- Sleep Talk
- Dynamic Punch
- Body Slam
";
$g20266 = "Ursaluna @ Normalium Z
Ability: Guts
Tera Type: &
EVs: 108 Atk / 148 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Trailblaze
- Dig
- Last Resort
";
$g20275 = "Ursaluna @ Assault Vest
Ability: Guts
Tera Type: &
EVs: 252 Atk / 252 SpD / 4 Spe
Careful Nature
- Facade
- Headlong Rush
- Avalanche
- Drain Punch
";
$g20284 = "Ursaluna @ Maranga Berry
Ability: Guts
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe
Careful Nature
- Rest
- Sleep Talk
- Bulk Up
- Body Slam
";
$g20293 = "Claydol @ Life Orb
Ability: Levitate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Earth Power
- Psyshock
- Rapid Spin
- Ice Beam
";
$g20302 = "Claydol @ Salac Berry
Ability: Levitate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Nasty Plot
- Substitute
- Psychic
- Earth Power
";
$g20311 = "Claydol @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpD
Relaxed Nature
- Teleport
- Rapid Spin
- Stealth Rock
- Dig
";
$g20320 = "Runerigus @ Chesto Berry
Ability: Wandering Spirit
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Relaxed Nature
- Sand Tomb
- Haze
- Night Shade
- Rest
";
$g20329 = "Brute Bonnet @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Sunny Day
- Synthesis
- Trailblaze
- Crunch
";
$g20338 = "Grimmsnarl @ Maranga Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 44 Atk / 128 Def / 36 SpD / 48 Spe
Adamant Nature
- Rest
- Sleep Talk
- Bulk Up
- Spirit Break
";
$g20347 = "Obstagoon @ Choice Scarf
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Knock Off
- Switcheroo
- Parting Shot
- Double-Edge
";
$g20356 = "Serperior @ Iapapa Berry
Ability: Overgrow
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swords Dance
- Leaf Blade
- Knock Off
- Tera Blast
";
$g20365 = "Vanilluxe @ Light Clay
Ability: Snow Warning
Tera Type: &
EVs: 252 Def / 4 SpD / 252 Spe
Jolly Nature
- Weather Ball
- Aurora Veil
- Explosion
- Blizzard
";
$g20374 = "Watchog @ Leftovers
Ability: Analytic
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Swords Dance
- Thunder Wave
- Return
- Dig
";
$g20383 = "Xurkitree @ Air Balloon
Ability: Beast Boost
Tera Type: &
EVs: 252 Def / 252 SpD
Serious Nature
- Gravity
- Zap Cannon
- Hypnosis
- Energy Ball
";
$g20392 = "Slowking-Galar @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Psyshock
- Sludge Bomb
- Fire Blast
- Chilling Water
";
$g20401 = "Slowking-Galar @ Air Balloon
Ability: Curious Medicine
Tera Type: &
EVs: 252 HP / 100 Def / 84 SpA / 72 SpD
Modest Nature
- Eerie Spell
- Iron Defense
- Slack Off
- Calm Mind
";
$g20410 = "Ursaluna @ Leftovers
Ability: Bulletproof
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Headlong Rush
- Body Press
- Yawn
- Protect
";
$g20419 = "Ursaluna @ Assault Vest
Ability: Bulletproof
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Body Slam
- Headlong Rush
- Drain Punch
- Crunch
";
$g20428 = "Ursaluna @ Chople Berry
Ability: Guts
Tera Type: &
EVs: 52 HP / 204 Atk / 252 Spe
Jolly Nature
- Headlong Rush
- Play Rough
- Trailblaze
- Swords Dance
";
$g20437 = "Ursaluna @ Eject Pack
Ability: Unnerve
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Headlong Rush
- Close Combat
- Ice Punch
- Thief
";
$g20446 = "Ursaluna @ Yache Berry
Ability: Bulletproof
Tera Type: &
EVs: 252 Atk / 252 Def / 4 SpD
Adamant Nature
- Body Slam
- Body Press
- Dig
- Bulk Up
";
$g20455 = "Ursaluna @ Blunder Policy
Ability: Bulletproof
Tera Type: &
EVs: 92 HP / 8 Atk / 40 Def / 116 SpD / 252 Spe
Adamant Nature
- Headlong Rush
- Stone Edge
- Cross Chop
- Gunk Shot
";
$g20464 = "Whiscash @ Leftovers
Ability: Hydration
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Waterfall
- Rain Dance
- Rest
- Dragon Dance
";
$g20473 = "Decidueye-Hisui @ Leftovers
Ability: Scrappy
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Triple Arrows
- Leaf Storm
- Roost
- Defog
";
$g20482 = "Decidueye-Hisui @ Rocky Helmet
Ability: Scrappy
Tera Type: &
EVs: 252 HP / 84 Atk / 172 Def
Adamant Nature
- Triple Arrows
- Defog
- Roost
- Bulk Up
";
$g20491 = "Decidueye-Hisui @ Life Orb
Ability: Overgrow
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Leaf Storm
- Aura Sphere
- Air Slash
- Nasty Plot
";
$g20500 = "Decidueye-Hisui @ Choice Band
Ability: Scrappy
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Triple Arrows
- Leaf Blade
- Sucker Punch
- Close Combat
";
$g20509 = "Decidueye-Hisui @ Eject Pack
Ability: Scrappy
Tera Type: &
EVs: 252 HP / 252 Spe
Jolly Nature
- Close Combat
- Knock Off
- Defog
- Synthesis
";
$g20518 = "Decidueye-Hisui @ Grassy Seed
Ability: Overgrow
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Grassy Glide
- Close Combat
- Grassy Terrain
- Swords Dance
";
$g20527 = "Greninja @ Focus Sash
Ability: Protean
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Ice Beam
- Shadow Sneak
- Toxic Spikes
- Spikes
";
$g20536 = "Sandy Shocks @ Rockium Z
Ability: Protosynthesis
Tera Type: &
EVs: 40 Def / 216 SpA / 252 Spe
Timid Nature
- Thunderbolt
- Earth Power
- Stealth Rock
- Body Press
";
$g20545 = "Iron Moth @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 128 HP / 128 SpA / 252 SpD
Calm Nature
- Fiery Dance
- Energy Ball
- Whirlwind
- Morning Sun
";
$g20554 = "Iron Treads @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 4 Atk / 252 Def / 252 Spe
Jolly Nature
- Heavy Slam
- Ice Spinner
- Stealth Rock
- Rapid Spin
";
$g20563 = "Dragapult @ Psychium Z
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 148 Atk / 108 Spe
Adamant Nature
- Dragon Darts
- Reflect
- Light Screen
- Dragon Dance
";
$g20572 = "Dragapult @ Light Clay
Ability: Clear Body
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Shadow Ball
- U-turn
- Reflect
- Light Screen
";
$g20581 = "Oricorio-Pom-Pom @ Heavy-Duty Boots
Ability: Dancer
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Revelation Dance
- Air Slash
- Roost
- Quiver Dance
";
$g20590 = "Oricorio-Pa'u @ Life Orb
Ability: Dancer
Tera Type: &
EVs: 96 SpA / 160 SpD / 252 Spe
Timid Nature
- Revelation Dance
- Hurricane
- Defog
- Roost
";
$g20599 = "Scizor @ Scizorite
Ability: Swarm
Tera Type: &
EVs: 252 HP / 4 Atk / 100 Def / 80 SpD / 72 Spe
Careful Nature
- U-turn
- Tailwind
- Defog
- Roost
";
$g20608 = "Palafin @ Wise Glasses
Ability: Zero to Hero
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Flip Turn
- Hydro Pump
- Ice Beam
- Grass Knot
";
$g20617 = "Typhlosion-Hisui @ Choice Scarf
Ability: Blaze
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Eruption
- Infernal Parade
- Tera Blast
- Lava Plume
";
$g20626 = "Typhlosion-Hisui @ Kee Berry
Ability: Blaze
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Will-O-Wisp
- Infernal Parade
- Calm Mind
- Lava Plume
";
$g20635 = "Forretress @ Leftovers
Ability: Sturdy
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Relaxed Nature
- Rapid Spin
- Gyro Ball
- Body Press
- Stealth Rock
";
$g20644 = "Swanna @ Choice Specs
Ability: Keen Eye
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hurricane
- Scald
- Tera Blast
- Ice Beam
";
$g20653 = "Toucannon @ Heavy-Duty Boots
Ability: Skill Link
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Beak Blast
- Rock Blast
- Bullet Seed
- Roost
";
$g20662 = "Toucannon @ Choice Band
Ability: Sheer Force
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Brave Bird
- Gunk Shot
- Brick Break
- U-turn
";
$g20671 = "Toucannon @ Choice Specs
Ability: Sheer Force
Tera Type: &
EVs: 248 HP / 252 SpA
Quiet Nature
- Boomburst
- Overheat
- Tera Blast
- Beak Blast
";
$g20680 = "Furfrou @ Maranga Berry
Ability: Fur Coat
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Cotton Guard
- Rest
- Sleep Talk
- Toxic
";
$g20689 = "Maushold @ Wide Lens
Ability: Technician
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Population Bomb
- Tidy Up
- Baton Pass
- Bite
";
$g20698 = "Glalie @ Glalitite
Ability: Ice Body
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Laser Focus
- Explosion
- Trailblaze
- Earthquake
";
$g20707 = "Gyarados @ Gyaradosite
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 92 Def / 164 SpD
Adamant Nature
- Lash Out
- Rest
- Dive
- Curse
";
$g20716 = "Aerodactyl @ Focus Sash
Ability: Pressure
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Mimic
- Taunt
- Tailwind
- Earthquake
";
$g20725 = "Dragapult @ Choice Specs
Ability: Infiltrator
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Sucker Punch
- Tera Blast
- Flamethrower
- Shadow Ball
";
$g20734 = "Turtonator @ Heavy-Duty Boots
Ability: Shell Armor
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Shell Smash
- Fire Blast
- Draco Meteor
- Flash Cannon
";
$g20743 = "Turtonator @ White Herb
Ability: Shell Armor
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Shell Smash
- Fire Blast
- Draco Meteor
- Dragon Pulse
";
$g20752 = "Primeape @ Red Card
Ability: Defiant
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Body Slam
- Close Combat
- Counter
- Drain Punch
";
$g20761 = "Alomomola @ Scope Lens
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Scald
- Wish
- Protect
- Toxic
";
$g20770 = "Gardevoir @ Gardevoirite
Ability: Trace
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Will-O-Wisp
- Tera Blast
- Aura Sphere
- Healing Wish
";
$g20779 = "Pinsir @ Pinsirite
Ability: Moxie
Tera Type: &
EVs: 128 HP / 128 Atk / 252 Spe
Naive Nature
- Tera Blast
- Quick Attack
- High Horsepower
- Bulldoze
";
$g20788 = "Wyrdeer @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Jump Kick
- Body Slam
- Psyshield Bash
- Sucker Punch
";
$g20797 = "Mawile @ Mawilite
Ability: Intimidate
Tera Type: &
EVs: 248 HP / 252 Atk
Adamant Nature
- Stealth Rock
- Sucker Punch
- Pain Split
- Counter
";
$g20806 = "Volbeat @ Heavy-Duty Boots
Ability: Illuminate
Tera Type: &
EVs: 252 HP / 252 Def
Calm Nature
- Defog
- Toxic
- Counter
- Roost
";
$g20815 = "Volbeat @ Focus Sash
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Tail Glow
- Psych Up
- Power-Up Punch
- Baton Pass
";
$g20824 = "Volbeat @ Choice Scarf
Ability: Prankster
Tera Type: &
EVs: 252 HP / 8 Def / 248 SpD
Careful Nature
- Trick
- Fling
- Toxic
- Roost
";
$g20833 = "Volbeat @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Thunder Wave
- Encore
- Defog
- Roost
";
$g20842 = "Volbeat @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Encore
- Seismic Toss
- Infestation
- Roost
";
$g20851 = "Volbeat @ Sitrus Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Tailwind
- U-turn
- Thief
- Helping Hand
";
$g20860 = "Illumise @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Wish
- Protect
- U-turn
- Aromatherapy
";
$g20869 = "Illumise @ Kee Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Sunny Day
- Growth
- Baton Pass
- Bug Buzz
";
$g20878 = "Illumise @ Focus Sash
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 Def
Impish Nature
- Fake Tears
- Counter
- Protect
- Roost
";
$g20887 = "Illumise @ Choice Specs
Ability: Tinted Lens
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Bug Buzz
- Tera Blast
- Thunderbolt
- Water Pulse
";
$g20896 = "Carnivine @ Wide Lens
Ability: Levitate
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Leech Seed
- Power Whip
- Protect
- Sleep Powder
";
$g20905 = "Volbeat @ Sticky Barb
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 Def
Calm Nature
- Trick
- Roost
- Seismic Toss
- Thunder Wave
";
$g20914 = "Volbeat @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 Def / 4 SpD / 252 Spe
Timid Nature
- Silver Wind
- Tail Glow
- Roost
- Baton Pass
";
$g20923 = "Kyurem-Black @ Babiri Berry
Ability: Teravolt
Tera Type: &
EVs: 100 HP / 252 Def / 156 SpD
Relaxed Nature
- Freeze-Dry
- Earth Power
- Fusion Bolt
- Dragon Dance
";
$g20932 = "Iron Bundle @ Kings Rock
Ability: Quark Drive
Tera Type: &
EVs: 4 Atk / 212 Def / 40 SpA / 252 Spe
Timid Nature
- Hydro Pump
- Freeze-Dry
- Fling
- Protect
";
$g20941 = "Genesect @ Mirror Herb
Ability: Download
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Iron Head
- Blaze Kick
- Swagger
- Protect
";
$g20950 = "Gholdengo @ Flame Orb
Ability: Good as Gold
Tera Type: &
EVs: 188 HP / 204 SpA / 116 Spe
Modest Nature
- Hex
- Thunder Wave
- Fling
- Recover
";
$g20959 = "Clodsire @ Life Orb
Ability: Water Absorb
Tera Type: &
EVs: 208 HP / 48 Def / 252 SpA
Modest Nature
- Earth Power
- Acid Spray
- Body Press
- Recover
";
$g20968 = "Charizard @ Charizardite X
Ability: Tough Claws
Tera Type: &
EVs: 128 HP / 236 SpD / 144 Spe
Adamant Nature
- Flame Charge
- Outrage
- Flare Blitz
- Belly Drum
";
$g20977 = "Magearna @ Fairium Z
Ability: Soul-Heart
Tera Type: &
EVs: 248 HP / 92 Def / 120 SpA / 48 SpD
Modest Nature
- Trick Room
- Substitute
- Heart Swap
- Fleur Cannon
";
$g20986 = "Magearna @ Assault Vest
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Sassy Nature
- Draining Kiss
- Stored Power
- Volt Switch
- Gyro Ball
";
$g20995 = "Magearna @ Leftovers
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 16 Def / 92 SpA / 4 SpD / 144 Spe
Modest Nature
- Ice Beam
- Magnet Rise
- Zap Cannon
- Mind Reader
";
$g21004 = "Magearna @ Eject Button
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 84 SpA / 4 SpD / 168 Spe
Modest Nature
- Draining Kiss
- Stored Power
- Shift Gear
- Calm Mind
";
$g21013 = "Greninja @ Assault Vest
Ability: Protean
Tera Type: &
EVs: 252 HP / 56 Atk / 4 SpA / 12 SpD / 184 Spe
Hasty Nature
- Ice Beam
- Low Kick
- Gunk Shot
- U-turn
";
$g21022 = "Skarmory @ Groundium Z
Ability: Weak Armor
Tera Type: &
EVs: 96 HP / 252 Def / 136 SpD / 24 Spe
Bold Nature
- Body Press
- Spikes
- Taunt
- Roost
";
$g21031 = "Greninja @ Choice Band
Ability: Protean
Shiny: Yes
Tera Type: &
EVs: 80 HP / 80 Atk / 252 Def / 96 Spe
Jolly Nature
- Waterfall
- Rock Tomb
- Gunk Shot
- Low Kick
";
$g21041 = "Houndstone @ Custap Berry
Ability: Fluffy
Tera Type: &
EVs: 252 Atk / 252 Def / 4 SpD
Impish Nature
- Last Respects
- Body Press
- Destiny Bond
- Endure
";
$g21050 = "Houndstone @ Chesto Berry
Ability: Sand Rush
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Last Respects
- Rest
- Will-O-Wisp
- Sandstorm
";
$g21059 = "Gallade @ Kee Berry
Ability: Sharpness
Tera Type: &
EVs: 252 HP / 100 Def / 156 SpD
Jolly Nature
- Sacred Sword
- Will-O-Wisp
- Wish
- Protect
";
$g21068 = "Gallade @ Lum Berry
Ability: Sharpness
Tera Type: &
EVs: 176 HP / 76 Atk / 4 SpD / 252 Spe
Adamant Nature
- Psycho Cut
- Sacred Sword
- Agility
- Swords Dance
";
$g21077 = "Iron Thorns @ Lum Berry
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Stone Edge
- Wild Charge
- Earthquake
- Dragon Dance
";
$g21086 = "Slither Wing @ Lum Berry
Ability: Protosynthesis
Tera Type: &
EVs: 100 HP / 100 Atk / 252 SpD / 56 Spe
Jolly Nature
- Leech Life
- Close Combat
- Trailblaze
- Bulk Up
";
$g21095 = "Alomomola @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 120 HP / 136 Def / 252 SpD
Calm Nature
- Scald
- Tera Blast
- Knock Off
- Mirror Coat
";
$g21104 = "Alomomola @ Waterium Z
Ability: Regenerator
Tera Type: &
EVs: 144 HP / 112 Def / 252 SpD
Bold Nature
- Scald
- Aqua Ring
- Rest
- Calm Mind
";
$g21113 = "Alomomola @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 Atk / 120 Def / 136 SpD
Adamant Nature
- Waterfall
- Knock Off
- Toxic
- Healing Wish
";
$g21122 = "Great Tusk @ Lum Berry
Ability: Protosynthesis
Tera Type: &
EVs: 252 Def / 252 SpD / 4 Spe
Impish Nature
- Body Press
- Stone Edge
- Rapid Spin
- Bulk Up
";
$g21131 = "Wo-Chien @ Lum Berry
Ability: Tablets of Ruin
Tera Type: &
EVs: 128 HP / 64 Def / 252 SpD / 64 Spe
Calm Nature
- Foul Play
- Stun Spore
- Leech Seed
- Substitute
";
$g21140 = "Mandibuzz @ Leftovers
Ability: Big Pecks
Tera Type: &
EVs: 252 HP / 20 Def / 236 Spe
Jolly Nature
- Foul Play
- Toxic
- Taunt
- Roost
";
$g21149 = "Flygon @ Silk Scarf
Ability: Levitate
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Boomburst
- Earth Power
- Roost
- Defog
";
$g21158 = "Kingambit @ Darkinium Z
Ability: Supreme Overlord
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Foul Play
- Poison Jab
- Stealth Rock
- Tera Blast
";
$g21167 = "Kingambit @ Choice Band
Ability: Defiant
Tera Type: &
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature
- Pursuit
- Tera Blast
- Aerial Ace
- Dig
";
$g21176 = "Metagross @ Metagrossite
Ability: Clear Body
Tera Type: &
EVs: 20 HP / 252 Atk / 224 SpD / 12 Spe
Adamant Nature
- Zen Headbutt
- Hammer Arm
- Stealth Rock
- Pursuit
";
$g21185 = "Regieleki @ Electrium Z
Ability: Transistor
Tera Type: &
EVs: 140 HP / 16 Def / 252 SpA / 100 Spe
Rash Nature
- Zap Cannon
- Rapid Spin
- Thrash
- Sleep Talk
";
$g21194 = "Slowking @ Light Clay
Ability: Regenerator
Shiny: Yes
Tera Type: &
EVs: 252 HP / 64 Def / 192 SpD
Calm Nature
- Counter
- Reflect
- Light Screen
- Teleport
";
$g21204 = "Garchomp @ Weakness Policy
Ability: Rough Skin
Tera Type: &
EVs: 144 HP / 84 Atk / 156 Def / 124 Spe
Adamant Nature
- Spikes
- Dragon Rush
- Scale Shot
- Hone Claws
";
$g21213 = "Maushold @ Sitrus Berry
Ability: Cheek Pouch
Tera Type: &
EVs: 132 HP / 252 Atk / 4 SpD / 120 Spe
Adamant Nature
- Facade
- Low Kick
- Encore
- Tidy Up
";
$g21222 = "Zoroark-Hisui @ Normalium Z
Ability: Illusion
Shiny: Yes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hex
- Hyper Beam
- U-turn
- Will-O-Wisp
";
$g21232 = "Zoroark-Hisui @ Ghostium Z
Ability: Illusion
Tera Type: &
EVs: 228 HP / 24 SpA / 4 SpD / 252 Spe
Timid Nature
- Bitter Malice
- Focus Blast
- Spite
- Calm Mind
";
$g21241 = "Dedenne @ Sitrus Berry
Ability: Cheek Pouch
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Hasty Nature
- Thunderbolt
- Draining Kiss
- Nuzzle
- Substitute
";
$g21250 = "Zoroark-Hisui @ Choice Band
Ability: Illusion
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Body Slam
- Phantom Force
- Low Kick
- U-turn
";
$g21259 = "Zoroark-Hisui @ Heavy-Duty Boots
Ability: Illusion
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Bitter Malice
- Flamethrower
- Protect
- Nasty Plot
";
$g21268 = "Zoroark-Hisui @ Leftovers
Ability: Illusion
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Hasty Nature
- Bitter Malice
- Dig
- Substitute
- Protect
";
$g21277 = "Zoroark-Hisui @ Psychium Z
Ability: Illusion
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Phantom Force
- Knock Off
- Imprison
- Swords Dance
";
$g21286 = "Zoroark @ Choice Specs
Ability: Illusion
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Night Daze
- Grass Knot
- Tera Blast
- Extrasensory
";
$g21295 = "Typhlosion @ Leftovers
Ability: Blaze
Tera Type: &
EVs: 212 HP / 44 SpA / 252 Spe
Timid Nature
- Lava Plume
- Dig
- Substitute
- Protect
";
$g21304 = "Typhlosion @ Charcoal
Ability: Flash Fire
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Eruption
- Lava Plume
- Tera Blast
- Protect
";
$g21313 = "Typhlosion @ Choice Specs
Ability: Flash Fire
Tera Type: &
EVs: 88 HP / 252 SpA / 4 SpD / 164 Spe
Modest Nature
- Overheat
- Focus Blast
- Tera Blast
- Eruption
";
$g21322 = "Great Tusk @ Eject Pack
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Brave Nature
- Headlong Rush
- Close Combat
- Head Smash
- Rapid Spin
";
$g21331 = "Great Tusk @ Coba Berry
Ability: Protosynthesis
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpD / 108 Spe
Nature
- Headlong Rush
- Body Press
- Knock Off
- Rapid Spin
";
$g21340 = "Medicham @ Medichamite
Ability: Pure Power
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Axe Kick
- High Jump Kick
- Focus Punch
- Feint
";
$g21350 = "Spidops @ Heavy-Duty Boots
Ability: Insomnia
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- First Impression
- U-turn
- Spikes
- Silk Trap
";
$g21359 = "Thundurus-Therian @ Choice Specs
Ability: Volt Absorb
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Wildbolt Storm
- Focus Blast
- Grass Knot
- Volt Switch
";
$g21368 = "Thundurus-Therian @ Leftovers
Ability: Volt Absorb
Tera Type: &
EVs: 24 HP / 232 SpA / 252 Spe
Timid Nature
- Thunderbolt
- Taunt
- Substitute
- Protect
";
$g21377 = "Thundurus-Therian @ Chesto Berry
Ability: Volt Absorb
Tera Type: &
EVs: 188 HP / 64 SpA / 4 SpD / 252 Spe
Timid Nature
- Wildbolt Storm
- Grass Knot
- Rest
- Charge
";
$g21386 = "Thundurus-Therian @ Blunder Policy
Ability: Volt Absorb
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Modest Nature
- Wildbolt Storm
- Sleep Talk
- Charge
- Rest
";
$g21395 = "Primeape @ Eviolite
Ability: Defiant
Tera Type: &
EVs: 252 HP / 32 Def / 224 SpD
Careful Nature
- Drain Punch
- Gunk Shot
- Power Trip
- Bulk Up
";
$g21404 = "Bisharp @ Eviolite
Ability: Defiant
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Iron Head
- Knock Off
- Sucker Punch
- Swords Dance
";
$g21413 = "Electrode-Hisui @ Grassium Z
Ability: Aftermath
Tera Type: &
EVs: 140 HP / 252 SpA / 116 Spe
Modest Nature
- Chloroblast
- Thunderbolt
- Giga Drain
- Volt Switch
";
$g21422 = "Electrode @ Light Clay
Ability: Soundproof
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Volt Switch
- Explosion
- Reflect
- Light Screen
";
$g21431 = "Electrode @ Leftovers
Ability: Soundproof
Tera Type: &
EVs: 160 HP / 252 SpD / 96 Spe
Timid Nature
- Toxic
- Taunt
- Thunderbolt
- Mirror Coat
";
$g21440 = "Magneton @ Magnet
Ability: Magnet Pull
Tera Type: &
EVs: 32 HP / 192 Def / 252 SpA / 16 SpD / 16 Spe
Modest Nature
- Thunderbolt
- Tera Blast
- Thunder Wave
- Substitute
";
$g21449 = "Frogadier @ Eviolite
Ability: Protean
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
- Ice Beam
- Scald
- Spikes
- Taunt
";
$g21458 = "Greninja @ Leftovers
Ability: Torrent
Tera Type: &
EVs: 20 HP / 236 SpA / 252 Spe
Timid Nature
- Scald
- Work Up
- Substitute
- Protect
";
$g21467 = "Gengar @ Focus Sash
Ability: Cursed Body
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hex
- Sludge Bomb
- Will-O-Wisp
- Haze
";
$g21476 = "Sceptile @ Sceptilite
Ability: Overgrow
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Hasty Nature
- Giga Drain
- Breaking Swipe
- Leech Seed
- Substitute
";
$g21485 = "Grafaiai @ Leftovers
Ability: Prankster
Tera Type: &
EVs: 252 HP / 20 Def / 236 SpD
Careful Nature
- Cross Poison
- Metronome
- Parting Shot
- Shadow Claw
";
$g21494 = "Revavroom @ Darkinium Z
Ability: Filter
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Naive Nature
- Spin Out
- Torment
- Overheat
- Parting Shot
";
$g21503 = "Revavroom @ Firium Z
Ability: Filter
Tera Type: &
EVs: 72 HP / 184 Atk / 252 Spe
Naughty Nature
- Toxic Spikes
- Overheat
- Taunt
- Gunk Shot
";
$g21512 = "Deoxys-Defense @ Choice Scarf
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psycho Boost
- Recover
- Spikes
- Trick
";
$g21521 = "Darmanitan-Galar @ Flame Orb
Ability: Gorilla Tactics
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Icicle Crash
- Facade
- Flare Blitz
- Fling
";
$g21530 = "Gardevoir @ Gardevoirite
Ability: Trace
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Relaxed Nature
- Hyper Voice
- Encore
- Disable
- Trick Room
";
$g21539 = "Gardevoir @ Gardevoirite
Ability: Synchronize
Tera Type: &
EVs: 240 HP / 16 SpA / 252 Spe
Timid Nature
- Hyper Voice
- Will-O-Wisp
- Wish
- Protect
";
$g21548 = "Absol @ Absolite
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Knock Off
- Will-O-Wisp
- Wish
- Protect
";
$g21557 = "Absol @ Absolite
Ability: Justified
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Knock Off
- Close Combat
- Sucker Punch
- Swords Dance
";
$g21566 = "Absol @ Absolite
Ability: Justified
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Mild Nature
- Knock Off
- Ice Beam
- Future Sight
- Flamethrower
";
$g21575 = "Ting-Lu @ Ghostium Z
Ability: Vessel of Ruin
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Earthquake
- Whirlwind
- Spite
- Substitute
";
$g21584 = "Wo-Chien @ Grassium Z
Ability: Tablets of Ruin
Tera Type: &
EVs: 100 HP / 200 Def / 64 SpA / 144 SpD
Sassy Nature
- Leaf Storm
- Leech Seed
- Knock Off
- Grassy Terrain
";
$g21593 = "Ursaluna @ Flame Orb
Ability: Guts
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def
Adamant Nature
- Last Resort
- Protect
-
-
";
$g21602 = "Flutter Mane @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 100 Def / 12 SpA / 144 Spe
Modest Nature
- Draining Kiss
- Charge Beam
- Charm
- Substitute
";
$g21611 = "Lucario @ Lucarionite
Ability: Adaptability
Tera Type: &
EVs: 4 HP / 4 Atk / 252 SpA / 248 Spe
Hasty Nature
- Tera Blast
- Circle Throw
- Substitute
- Calm Mind
";
$g21620 = "Chien-Pao @ Heavy-Duty Boots
Ability: Sword of Ruin
Tera Type: &
EVs: 252 HP / 180 Atk / 76 Def
Adamant Nature
- Icicle Crash
- Ruination
- Taunt
- Protect
";
$g21629 = "Blaziken @ Blazikenite
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 80 Atk / 176 Spe
Adamant Nature
- Flare Blitz
- Close Combat
- Thunder Punch
- Bulk Up
";
$g21638 = "Metagross @ Metagrossite
Ability: Clear Body
Tera Type: &
EVs: 80 HP / 228 Atk / 200 Spe
Jolly Nature
- Toxic
- Zen Headbutt
- Iron Head
- Ice Punch
";
$g21647 = "Metagross @ Metagrossite
Ability: Tough Claws
Tera Type: &
EVs: 152 HP / 164 Atk / 192 Spe
Jolly Nature
- Rock Tomb
- Earthquake
- Substitute
- Rain Dance
";
$g21656 = "Zeraora @ Dragonium Z
Ability: Volt Absorb
Tera Type: &
EVs: 32 HP / 252 Atk / 24 Def / 200 Spe
Jolly Nature
- Fake Out
- Outrage
- Plasma Fists
- Bulk Up
";
$g21665 = "Skarmory @ Flyinium Z
Ability: Sturdy
Tera Type: &
EVs: 28 HP / 240 Atk / 8 Def / 232 Spe
Adamant Nature
- Rock Tomb
- Iron Defense
- Brave Bird
- Roost
";
$g21674 = "Kyurem-Black @ Choice Scarf
Ability: Teravolt
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Ice Beam
- Draco Meteor
- Fusion Bolt
- Tera Blast
";
$g21683 = "Durant @ Rockium Z
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Jolly Nature
- Screech
- Stone Edge
- Iron Head
- X-Scissor
";
$g21692 = "Kyurem-Black @ Psychium Z
Ability: Teravolt
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Freeze-Dry
- Reflect
- Light Screen
- Roost
";
$g21701 = "Talonflame @ Choice Specs
Ability: Gale Wings
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Hyper Beam
- Overheat
- Flamethrower
- Hidden Power [Flying]
";
$g21710 = "Togedemaru @ Liechi Berry
Ability: Sturdy
Tera Type: &
EVs: 252 Atk / 28 Def / 228 Spe
Adamant Nature
- Nuzzle
- Substitute
- Reversal
- Zing Zap
";
$g21719 = "Weavile @ Micle Berry
Ability: Pressure
Tera Type: &
EVs: 64 HP / 252 Atk / 192 Spe
Adamant Nature
- Fake Out
- Natural Gift
- Ice Punch
- Substitute
";
$g21728 = "Ampharos @ Ampharosite
Ability: Static
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Thunderbolt
- Rest
- Dragon Tail
- Cotton Guard
";
$g21737 = "Ampharos @ Ampharosite
Ability: Static
Tera Type: &
EVs: 220 HP / 36 SpA / 252 Spe
Timid Nature
- Charge Beam
- Rest
- Cotton Guard
- Agility
";
$g21746 = "Ampharos @ Ampharosite
Ability: Static
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunder
- Dragon Pulse
- Magnet Rise
- Agility
";
$g21755 = "Tyranitar @ Flyinium Z
Ability: Sand Stream
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Crunch
- Rock Slide
- Aerial Ace
- Dragon Dance
";
$g21764 = "Kartana @ Grassium Z
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Adamant Nature
- Iron Defense
- Synthesis
- Leaf Blade
- Swords Dance
";
$g21773 = "Farigiraf @ Sitrus Berry
Ability: Armor Tail
Tera Type: &
EVs: 88 HP / 52 Def / 244 SpA / 124 SpD
Quiet Nature
- Hyper Voice
- Dazzling Gleam
- Trick Room
- Protect
";
$g21782 = "Deoxys-Speed @ Electrium Z
Ability: Pressure
Tera Type: &
EVs: 120 HP / 252 Def / 128 SpA / 8 Spe
Bold Nature
- Nasty Plot
- Psycho Boost
- Zap Cannon
- Ice Beam
";
$g21791 = "Deoxys-Speed @ Rocky Helmet
Ability: Pressure
Tera Type: &
EVs: 160 HP / 108 Def / 240 Spe
Timid Nature
- Iron Defense
- Amnesia
- Recover
- Taunt
";
$g21800 = "Avalugg @ Groundium Z
Ability: Sturdy
Tera Type: &
EVs: 28 HP / 252 Atk / 228 Def
Impish Nature
- Earthquake
- Curse
- Avalanche
- Recover
";
$g21809 = "Avalugg @ Custap Berry
Ability: Ice Body
Tera Type: &
EVs: 252 HP / 112 Atk / 108 Def / 36 SpD
Impish Nature
- Icicle Spear
- Recover
- Snowscape
- Rapid Spin
";
$g21818 = "Keldeo @ Waterium Z
Ability: Justified
Tera Type: &
EVs: 108 HP / 208 Def / 192 Spe
Timid Nature
- Hydro Pump
- Calm Mind
- Taunt
- Icy Wind
";
$g21827 = "Latios @ Custap Berry
Ability: Levitate
Tera Type: &
EVs: 252 SpA / 52 SpD / 204 Spe
Timid Nature
- Endure
- Draco Meteor
- Psychic
- Bulldoze
";
$g21836 = "Latios @ Ghostium Z
Ability: Levitate
Tera Type: &
EVs: 252 Atk / 60 SpA / 196 Spe
Hasty Nature
- Shadow Claw
- Draco Meteor
- Ice Beam
- Laser Focus
";
$g21845 = "Rhyperior @ Liechi Berry
Ability: Solid Rock
Shiny: Yes
Tera Type: &
EVs: 248 HP / 72 Atk / 188 Def
Adamant Nature
- Rock Wrecker
- Substitute
- Reversal
- Swords Dance
";
$g21855 = "Rhyperior @ Rindo Berry
Ability: Solid Rock
Tera Type: &
EVs: 100 HP / 8 Atk / 200 Def / 200 SpD
Adamant Nature
- High Horsepower
- Rock Wrecker
- Dragon Tail
- Stealth Rock
";
$g21864 = "Rotom-Heat @ Electrium Z
Ability: Levitate
Tera Type: &
EVs: 40 HP / 252 SpA / 216 Spe
Timid Nature
- Overheat
- Thunder
- Toxic
- Uproar
";
$g21873 = "Scrafty @ Darkinium Z
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 180 Atk / 76 SpD
Adamant Nature
- Foul Play
- High Jump Kick
- Bulk Up
- Fake Out
";
$g21882 = "Slaking @ Assault Vest
Ability: Truant
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Def
Adamant Nature
- Giga Impact
- Hammer Arm
- Gunk Shot
- Earthquake
";
$g21891 = "Umbreon @ Fairium Z
Ability: Inner Focus
Tera Type: &
EVs: 252 HP / 228 Def / 28 SpD
Calm Nature
- Charm
- Moonlight
- Foul Play
- Snarl
";
$g21900 = "Illumise @ Normalium Z
Ability: Oblivious
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Captivate
- Roost
- Encore
- Infestation
";
$g21909 = "Illumise @ Fairium Z
Ability: Oblivious
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Charm
- Roost
- Infestation
- Encore
";
$g21918 = "Muk-Alola @ Rockium Z
Ability: Poison Touch
Shiny: Yes
Tera Type: &
EVs: 188 HP / 68 Atk / 252 SpD
Adamant Nature
- Stone Edge
- Shadow Sneak
- Gunk Shot
- Payback
";
$g21928 = "Iron Valiant @ Icium Z
Ability: Quark Drive
Tera Type: &
EVs: 192 SpA / 92 SpD / 224 Spe
Mild Nature
- Moonblast
- Close Combat
- Icy Wind
- Calm Mind
";
$g21937 = "Clodsire @ Normalium Z
Ability: Unaware
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Impish Nature
- Gunk Shot
- Bulldoze
- Recover
- Stockpile
";
$g21946 = "Magearna @ Eject Pack
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 116 SpA / 140 SpD
Quiet Nature
- Fleur Cannon
- Encore
- Grass Knot
- Calm Mind
";
$g21955 = "Magearna @ Normalium Z
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Timid Nature
- Stored Power
- Calm Mind
- Pain Split
- Thunder Wave
";
$g21964 = "Chatot @ Throat Spray
Ability: Keen Eye
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Modest Nature
- Boomburst
- Synchronoise
- Taunt
- Roost
";
$g21973 = "Umbreon @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 100 HP / 156 Def / 252 SpD
Calm Nature
- Foul Play
- Synchronoise
- Wish
- Protect
";
$g21982 = "Latios @ Latiosite
Ability: Levitate
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Stored Power
- Shadow Ball
- Heal Block
- Calm Mind
";
$g21992 = "Tapu Lele @ Tapunium Z
Ability: Psychic Surge
Tera Type: &
EVs: 168 HP / 84 SpA / 4 SpD / 252 Spe
Timid Nature
- Psyshock
- Moonblast
- Future Sight
- Natures Madness
";
$g22001 = "Thundurus-Therian @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Tera Blast
- Defog
- Nasty Plot
";
$g22010 = "Mew @ Waterium Z
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Hydro Cannon
- Calm Mind
- Soft-Boiled
- Defog
";
$g22019 = "Gardevoir @ Starf Berry
Ability: Synchronize
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Draining Kiss
- Psychic
- Recycle
- Substitute
";
$g22028 = "Jirachi @ Starf Berry
Ability: Serene Grace
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Stored Power
- Aura Sphere
- Recycle
- Substitute
";
$g22037 = "Muk-Alola @ Starf Berry
Ability: Gluttony
Tera Type: &
EVs: 252 HP / 208 Def / 48 SpD
Impish Nature
- Knock Off
- Gunk Shot
- Recycle
- Pain Split
";
$g22046 = "Appletun @ Starf Berry
Ability: Gluttony
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Tera Blast
- Leech Seed
- Recycle
- Substitute
";
$g22055 = "Dedenne @ Starf Berry
Ability: Cheek Pouch
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Timid Nature
- Discharge
- Super Fang
- Substitute
- Recycle
";
$g22064 = "Snorlax @ Starf Berry
Ability: Gluttony
Tera Type: &
EVs: 188 HP / 252 Def / 68 SpD
Impish Nature
- Return
- Rest
- Recycle
- Curse
";
$g22073 = "Snorlax @ Snorlium Z
Ability: Thick Fat
Tera Type: &
EVs: 80 HP / 252 Atk / 164 Def / 12 SpD
Adamant Nature
- Giga Impact
-
-
-
";
$g22082 = "Altaria @ Altarianite
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 24 Def / 232 SpD
Careful Nature
- Return
- Pursuit
- Roost
- Cotton Guard
";
$g22091 = "Skeledirge @ Mirror Herb
Ability: Unaware
Tera Type: &
EVs: 248 HP / 252 Def / 8 SpA
Bold Nature
- Torch Song
- Shadow Ball
- Sing
- Slack Off
";
$g22100 = "Skeledirge @ Ghostium Z
Ability: Blaze
Tera Type: &
EVs: 252 HP / 68 SpA / 160 SpD / 28 Spe
Modest Nature
- Torch Song
- Curse
- Slack Off
- Protect
";
$g22109 = "Annihilape @ Ghostium Z
Ability: Defiant
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Rage Fist
- Curse
- Rest
- Bulk Up
";
$g22118 = "Gourgeist-Small @ Ghostium Z
Ability: Pickup
Tera Type: &
EVs: 228 HP / 12 Atk / 104 Def / 164 Spe
Jolly Nature
- Phantom Force
- Curse
- Synthesis
- Substitute
";
$g22127 = "Poliwrath @ Normalium Z
Ability: Water Absorb
Tera Type: &
EVs: 160 HP / 96 Atk / 252 Def
Impish Nature
- Waterfall
- Drain Punch
- Amnesia
- Splash
";
$g22136 = "Baxcalibur @ Groundium Z
Ability: Thermal Exchange
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Glaive Rush
- Icicle Spear
- Earthquake
- Dragon Dance
";
$g22145 = "Urshifu @ Lagging Tail
Ability: Unseen Fist
Tera Type: &
EVs: 100 HP / 252 Atk / 104 Def / 12 SpD / 40 Spe
Adamant Nature
- Wicked Blow
- Close Combat
- Sucker Punch
- Swords Dance
";
$g22154 = "Grumpig @ Starf Berry
Ability: Gluttony
Tera Type: &
EVs: 252 HP / 232 Def / 20 SpA / 4 SpD
Bold Nature
- Psychic
- Rest
- Recycle
- Calm Mind
";
$g22163 = "Slowking @ Life Orb
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 128 SpA / 124 SpD
Quiet Nature
- Psychic
- Dragon Tail
- Fire Blast
- Chilly Reception
";
$g22172 = "Cloyster @ Heavy-Duty Boots
Ability: Skill Link
Tera Type: &
EVs: 252 Atk / 72 Def / 184 Spe
Adamant Nature
- Icicle Spear
- Rock Blast
- Clamp
- Toxic
";
$g22181 = "Trevenant @ Grassium Z
Ability: Frisk
Tera Type: &
EVs: 140 HP / 120 Def / 248 SpD
Careful Nature
- Wood Hammer
- Phantom Force
- Drain Punch
- Forests Curse
";
$g22190 = "Trevenant @ Grassium Z
Ability: Frisk
Tera Type: &
EVs: 168 HP / 252 SpA / 88 Spe
Modest Nature
- Giga Drain
- Shadow Ball
- Focus Blast
- Forests Curse
";
$g22199 = "Shaymin @ Normalium Z
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Seed Flare
- Earth Power
- Synthesis
- Celebrate
";
$g22208 = "Zygarde @ Mirror Herb
Ability: Aura Break
Tera Type: &
EVs: 252 HP / 28 Atk / 184 Def / 36 SpD / 8 Spe
Impish Nature
- Thousand Arrows
- Glare
- Iron Tail
- Pain Split
";
$g22217 = "Diancie @ Mirror Herb
Ability: Clear Body
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpA
Quiet Nature
- Diamond Storm
- Draining Kiss
- Body Press
- Calm Mind
";
$g22226 = "Bellibolt @ Red Card
Ability: Electromorphosis
Tera Type: &
EVs: 248 HP / 128 Def / 4 SpA / 128 SpD
Bold Nature
- Charge
- Muddy Water
- Zap Cannon
- Slack Off
";
$g22235 = "Roaring Moon @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 168 SpD / 88 Spe
Careful Nature
- Dig
- Protect
- Jaw Lock
- Dragon Tail
";
$g22244 = "Quaquaval @ Petaya Berry
Ability: Torrent
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Substitute
- Rain Dance
- Hurricane
- Hydro Pump
";
$g22253 = "Quaquaval @ Assault Vest
Ability: Moxie
Tera Type: &
EVs: 252 HP / 200 SpD / 56 Spe
Careful Nature
- Fling
- Swords Dance
- Aqua Step
- Close Combat
";
$g22262 = "Gengar @ Gengarite
Ability: Cursed Body
Tera Type: &
EVs: 252 HP / 240 Def / 16 Spe
Timid Nature
- Imprison
- Encore
- Mimic
- Metronome
";
$g22271 = "Darkrai @ Blunder Policy
Ability: Bad Dreams
Tera Type: &
EVs: 252 HP / 216 Atk / 40 Spe
Adamant Nature
- Dark Void
- Power-Up Punch
- Pursuit
- Drain Punch
";
$g22280 = "Amoonguss @ Rocky Helmet
Ability: Effect Spore
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Rage Powder
- Secret Power
- Rest
- Sleep Talk
";
$g22289 = "Cyclizar @ Life Orb
Ability: Shed Skin
Tera Type: &
EVs: 248 HP / 80 Atk / 180 Spe
Lonely Nature
- Power Whip
- Overheat
- Tera Blast
- Rest
";
$g22298 = "Charizard @ Charizardite X
Ability: Tough Claws
Tera Type: &
EVs: 248 HP / 76 Def / 184 SpD
Careful Nature
- Substitute
- Focus Punch
- Sky Drop
- Defog
";
$g22307 = "Crocalor @ Eviolite
Ability: Unaware
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Encore
- Slack Off
- Helping Hand
- Roar
";
$g22316 = "Houndstone @ Thick Club
Ability: Fluffy
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Howl
- Lick
- Dig
- Play Rough
";
$g22325 = "Metagross @ Metagrossite
Ability: Clear Body
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Stealth Rock
- Hone Claws
- Explosion
- Dynamic Punch
";
$g22334 = "Bronzong @ Steelium Z
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Brave Nature
- Psychic Terrain
- Steel Roller
- Zen Headbutt
- Speed Swap
";
$g22343 = "Xurkitree @ Psychium Z
Ability: Beast Boost
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Gravity
- Zap Cannon
- Hypnosis
- Magnet Rise
";
$g22352 = "Azumarill @ Normalium Z
Ability: Huge Power
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Splash
- Aqua Jet
- Play Rough
- Giga Impact
";
$g22361 = "Gholdengo @ Bright Powder
Ability: Good as Gold
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Thunder Wave
- Electro Ball
- Hex
- Substitute
";
$g22371 = "Wigglytuff @ Normalium Z
Ability: Competitive
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD
Modest Nature
- Stockpile
- Spit Up
- Wish
- Protect
";
$g22380 = "Alcremie-Lemon-Cream @ Normalium Z
Ability: Aroma Veil
Tera Type: &
EVs: 252 HP / 32 SpA / 224 Spe
Modest Nature
- Attract
- Celebrate
- Stored Power
- Draining Kiss
";
$g22389 = "Iron Moth @ Air Balloon
Ability: Quark Drive
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Toxic Spikes
- Whirlwind
- Fiery Dance
- Hyper Beam
";
$g22398 = "Jynx @ Focus Sash
Ability: Dry Skin
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Lovely Kiss
- Sweet Kiss
- Draining Kiss
- Role Play
";
$g22407 = "Jellicent @ Grassium Z
Ability: Cursed Body
Tera Type: &
EVs: 252 HP / 188 Def / 68 SpD
Calm Nature
- Muddy Water
- Strength Sap
- Giga Drain
- Ominous Wind
";
$g22416 = "Mewtwo @ Mewtwonite X
Ability: Unnerve
Tera Type: &
EVs: 32 HP / 252 Atk / 224 Spe
Adamant Nature
- Gravity
- Laser Focus
- Dynamic Punch
- Metronome
";
$g22425 = "Hoopa-Unbound @ Darkinium Z
Ability: Magician
Tera Type: &
EVs: 248 HP / 64 Atk / 132 SpA / 64 Spe
Lonely Nature
- Hyperspace Hole
- Hyperspace Fury
- Quash
- Snatch
";
$g22434 = "Marshadow @ Darkinium Z
Ability: Technician
Tera Type: &
EVs: 248 HP / 4 Atk / 128 Def / 128 SpD
Adamant Nature
- Spectral Thief
- Snatch
- Bounce
- Feint
";
$g22443 = "Mr. Mime-Galar @ Eviolite
Ability: Vital Spirit
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Calm Mind
- Psych Up
- Ice Beam
- Stored Power
";
$g22452 = "Mr. Rime @ Heavy-Duty Boots
Ability: Screen Cleaner
Tera Type: &
EVs: 252 HP / 196 Def / 60 SpD
Calm Nature
- Magic Coat
- Rapid Spin
- Metronome
- Slack Off
";
$g22461 = "Melmetal @ Quick Claw
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Brave Nature
- Electric Terrain
- Steel Roller
- Thunder Punch
- Self-Destruct
";
$g22470 = "Toxtricity @ Air Balloon
Ability: Punk Rock
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Boomburst
- Nuzzle
- Hex
- Toxic Spikes
";
$g22479 = "Great Tusk @ Booster Energy
Ability: Protosynthesis
Tera Type: &
EVs: 248 HP / 4 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Headlong Rush
- Reversal
- Ice Spinner
";
$g22488 = "Slowking-Galar @ Never-Melt Ice
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA
Quiet Nature
- Chilly Reception
- Blizzard
- Yawn
- Acid Spray
";
$g22497 = "Manaphy @ Mirror Herb
Ability: Hydration
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swagger
- Last Resort
-
-
";
$g22506 = "Pupitar @ Eviolite
Ability: Shed Skin
Tera Type: &
EVs: 252 HP / 128 Def / 128 SpD
Adamant Nature
- Dragon Dance
- Rock Slide
- Stomping Tantrum
- Rest
";
$g22515 = "Flapple @ Choice Scarf
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Adamant Nature
- Grav Apple
- Outrage
- Dual Wingbeat
- U-turn
";
$g22524 = "Meloetta @ Blunder Policy
Ability: Serene Grace
Tera Type: &
EVs: 232 HP / 252 SpA / 24 Spe
Modest Nature
- Rest
- Snore
- Thunder
- Focus Blast
";
$g22533 = "Meloetta @ Blunder Policy
Ability: Serene Grace
Tera Type: &
EVs: 232 HP / 252 Atk / 24 Spe
Adamant Nature
- Relic Song
- Sing
- Wake-Up Slap
- Frustration
";
$g22542 = "Grapploct @ Quick Claw
Ability: Limber
Tera Type: &
EVs: 252 HP / 56 Atk / 100 Def / 100 SpD
Adamant Nature
- Octolock
- Drain Punch
- Protect
- Topsy-Turvy
";
$g22551 = "Latias @ Binding Band
Ability: Levitate
Tera Type: &
EVs: 252 HP / 200 Def / 56 SpD
Calm Nature
- Whirlpool
- Wish
- Protect
- Refresh
";
$g22560 = "Starmie @ Power Herb
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 84 Def / 8 SpA / 84 SpD / 80 Spe
Modest Nature
- Reflect Type
- Meteor Beam
- Skull Bash
- Recover
";
$g22569 = "Golem-Alola @ Choice Band
Ability: Galvanize
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Explosion
- Rock Slide
- Fire Punch
- Stealth Rock
";
$g22578 = "Mabosstiff @ Focus Sash
Ability: Guard Dog
Shiny: Yes
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Destiny Bond
- Comeuppance
- Endeavor
- Trailblaze
";
$g22588 = "Diggersby @ Liechi Berry
Ability: Huge Power
Shiny: Yes
Tera Type: &
EVs: 136 HP / 252 Atk / 120 Spe
Adamant Nature
- Endure
- Agility
- Thief
- Flail
";
$g22598 = "Grimmsnarl @ Sitrus Berry
Ability: Pickpocket
Tera Type: &
EVs: 200 HP / 56 Atk / 252 Spe
Jolly Nature
- Bulk Up
- Darkest Lariat
- Play Rough
- Trailblaze
";
$g22607 = "Glimmora @ Poisonium Z
Ability: Corrosion
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Spiky Shield
- Mortal Spin
- Sludge Wave
- Toxic
";
$g22616 = "Heatran @ Grassium Z
Ability: Flash Fire
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Rash Nature
- Magma Storm
- Dig
- Solar Beam
- Will-O-Wisp
";
$g22625 = "Yanmega @ Flyinium Z
Ability: Frisk
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
- Bug Bite
- Thief
- Air Slash
- Roost
";
$g22634 = "Snubbull @ Eviolite
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Bold Nature
- Charm
- Counter
- Seismic Toss
- Rest
";
$g22643 = "Murkrow @ Flyinium Z
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Taunt
- Night Shade
- Hurricane
- Roost
";
$g22652 = "Serperior @ Rocky Helmet
Ability: Contrary
Tera Type: &
EVs: 252 HP / 164 Def / 92 Spe
Bold Nature
- Reflect
- Leaf Storm
- Synthesis
- Leech Seed
";
$g22661 = "Ambipom @ Light Ball
Ability: Pickup
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Fling
- Last Resort
-
-
";
$g22670 = "Drapion @ Leftovers
Ability: Battle Armor
Tera Type: &
EVs: 248 HP / 64 Atk / 136 SpD / 60 Spe
Adamant Nature
- Rest
- Sleep Talk
- Acupressure
- Knock Off
";
$g22679 = "Maractus @ Leftovers
Ability: Storm Drain
Tera Type: &
EVs: 248 HP / 128 Def / 132 SpD
Bold Nature
- Acupressure
- Spikes
- Leech Seed
- Giga Drain
";
$g22688 = "Maractus @ Leftovers
Ability: Chlorophyll
Tera Type: &
EVs: 128 HP / 252 SpA / 128 Spe
Modest Nature
- Sunny Day
- Acupressure
- Solar Beam
- Tera Blast
";
$g22697 = "Toedscruel @ Leftovers
Ability: Mycelium Might
Tera Type: &
EVs: 248 HP / 160 Def / 100 SpA
Modest Nature
- Acupressure
- Earth Power
- Energy Ball
- Protect
";
$g22706 = "Seaking @ Life Orb
Ability: Swift Swim
Tera Type: &
EVs: 120 HP / 252 Atk / 4 Def / 132 Spe
Adamant Nature
- Rain Dance
- Aqua Tail
- Megahorn
- Drill Run
";
$g22715 = "Seaking @ Leftovers
Ability: Lightning Rod
Tera Type: &
EVs: 248 HP / 100 Def / 160 SpD
Adamant Nature
- Knock Off
- Dive
- Protect
- Acupressure
";
$g22724 = "Durant @ Iapapa Berry
Ability: Hustle
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naive Nature
- Hone Claws
- Iron Head
- Tera Blast
- Thunder Fang
";
$g22733 = "Hippopotas @ Eviolite
Ability: Sand Stream
Tera Type: &
EVs: 252 HP / 52 Def / 204 SpD
Impish Nature
- Curse
- Slack Off
- High Horsepower
- Body Slam
";
$g22742 = "Ting-Lu @ Choice Band
Ability: Vessel of Ruin
Tera Type: &
EVs: 252 Atk / 128 SpD / 128 Spe
Adamant Nature
- Throat Chop
- Stomping Tantrum
- Stone Edge
- Heavy Slam
";
$g22751 = "Kyurem @ Never-Melt Ice
Ability: Pressure
Tera Type: &
EVs: 200 SpA
Modest Nature
- Ice Beam
- Freeze-Dry
- Glaciate
- Hail
";
$g22760 = "Sneasel-Hisui @ Choice Band
Ability: Inner Focus
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Switcheroo
- Gunk Shot
- Close Combat
- Toxic Spikes
";
$g22769 = "Glimmora @ Leftovers
Ability: Toxic Debris
Tera Type: &
EVs: 252 HP / 200 Def / 56 Spe
Bold Nature
- Rest
- Sleep Talk
- Power Gem
- Acid Spray
";
$g22778 = "Ferrothorn @ Leftovers
Ability: Iron Barbs
Tera Type: &
EVs: 248 HP / 252 Atk / 8 Spe
Adamant Nature
- Rest
- Sleep Talk
- Knock Off
- Tera Blast
";
$g22787 = "Arctozolt @ Life Orb
Ability: Static
Tera Type: &
EVs: 252 Atk / 4 Def / 252 Spe
Adamant Nature
- Bolt Beak
- Icicle Crash
- Low Kick
- Taunt
";
$g22796 = "Sirfetch’d @ Power Herb
Ability: Scrappy
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Defog
- Close Combat
- Sky Attack
- Solar Blade
";
$g22805 = "Emboar @ Life Orb
Ability: Reckless
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flare Blitz
- Superpower
- Flame Charge
- Wild Charge
";
$g22814 = "Articuno @ Heavy-Duty Boots
Ability: Pressure
Shiny: Yes
Tera Type: &
EVs: 4 Def / 252 SpA / 252 Spe
Modest Nature
- Defog
- Hurricane
- Blizzard
- Roost
";
$g22824 = "Latias @ Soul Dew
Ability: Levitate
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Roost
- Mist Ball
- Roar
- Aura Sphere
";
$g22833 = "Rampardos @ Life Orb
Ability: Mold Breaker
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Head Smash
- Protect
- Hammer Arm
- Stomping Tantrum
";
$g22842 = "Rampardos @ Life Orb
Ability: Sheer Force
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Mild Nature
- Stone Edge
- Ice Beam
- Thunderbolt
- Flamethrower
";
$g22851 = "Rampardos @ Assault Vest
Ability: Mold Breaker
Tera Type: &
EVs: 252 HP / 100 Atk / 156 SpD
Adamant Nature
- Head Smash
- Stone Edge
- Avalanche
- Stomping Tantrum
";
$g22860 = "Rampardos @ Choice Scarf
Ability: Mold Breaker
Tera Type: &
EVs: 208 Atk / 48 SpA / 252 Spe
Naive Nature
- Head Smash
- Ice Beam
- Brick Break
- Stomping Tantrum
";
$g22869 = "Porygon-Z @ Life Orb
Ability: Adaptability
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Tri Attack
- Dark Pulse
- Charge Beam
- Zap Cannon
";
$g22878 = "Glaceon @ Normalium Z
Ability: Ice Body
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
- Celebrate
- Frost Breath
- Shadow Ball
- Tera Blast
";
$g22887 = "Glaceon @ Choice Specs
Ability: Snow Cloak
Tera Type: &
EVs: 128 HP / 252 SpA / 128 Spe
Modest Nature
- Frost Breath
- Hyper Beam
- Chilling Water
- Echoed Voice
";
$g22896 = "Vivillon-Elegant @ Heavy-Duty Boots
Ability: Compound Eyes
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Sleep Powder
- U-turn
- Hurricane
- Pollen Puff
";
$g22905 = "Iron Treads @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 200 HP / 4 Atk / 252 SpD / 52 Spe
Careful Nature
- Stomping Tantrum
- Iron Head
- Knock Off
- Rapid Spin
";
$g22914 = "Iron Treads @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 92 Atk / 164 SpD / 252 Spe
Adamant Nature
- Stomping Tantrum
- Volt Switch
- Smart Strike
- Knock Off
";
$g22923 = "Kingambit @ Air Balloon
Ability: Defiant
Tera Type: &
EVs: 144 HP / 52 Atk / 96 Def / 124 SpD / 92 Spe
Adamant Nature
- Knock Off
- Stealth Rock
- Poison Jab
- Thunder Wave
";
$g22932 = "Glimmora @ Choice Specs
Ability: Corrosion
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Power Gem
- Sludge Bomb
- Earth Power
- Tera Blast
";
$g22941 = "Tauros-Paldea-Aqua @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Substitute
- Wave Crash
- Close Combat
- Work Up
";
$g22950 = "Tauros-Paldea-Blaze @ Sitrus Berry
Ability: Cud Chew
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Bulk Up
- Raging Bull
- Close Combat
- Endeavor
";
$g22959 = "Tauros-Paldea-Combat @ Choice Band
Ability: Intimidate
Shiny: Yes
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Close Combat
- Stone Edge
- Iron Head
- Zen Headbutt
";
$g22969 = "Tauros-Paldea-Aqua @ Assault Vest
Ability: Intimidate
Tera Type: &
EVs: 204 HP / 208 Atk / 96 SpD
Adamant Nature
- Raging Bull
- Close Combat
- Wild Charge
- Stomping Tantrum
";
$g22978 = "Entei @ Leftovers
Ability: Pressure
Tera Type: &
EVs: 128 Atk / 128 Def / 252 Spe
Jolly Nature
- Swagger
- Sacred Fire
- Psych Up
- Dig
";
$g22987 = "Golisopod @ Wacan Berry
Ability: Emergency Exit
Tera Type: &
EVs: 80 HP / 252 Atk / 168 SpD / 8 Spe
Adamant Nature
- Swords Dance
- Liquidation
- Leech Life
- Aqua Jet
";
$g22996 = "Persian-Alola @ Leftovers
Ability: Fur Coat
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Swagger
- Psych Up
- Knock Off
- Dig
";
$g23005 = "Mandibuzz @ Rocky Helmet
Ability: Weak Armor
Tera Type: &
EVs: 240 HP / 252 Atk / 16 Spe
Adamant Nature
- Swagger
- Roost
- Knock Off
- Psych Up
";
$g23014 = "Eelektross @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 252 HP / 164 Atk / 92 SpD
Adamant Nature
- Coil
- Thunder Punch
- Drain Punch
- Knock Off
";
$g23023 = "Eelektross @ Sitrus Berry
Ability: Levitate
Tera Type: &
EVs: 200 HP / 148 SpA / 160 Spe
Modest Nature
- Discharge
- Hex
- Super Fang
- Protect
";
$g23032 = "Gogoat @ Heavy-Duty Boots
Ability: Sap Sipper
Tera Type: &
EVs: 120 HP / 196 Atk / 192 Spe
Adamant Nature
- Bulk Up
- Milk Drink
- Trailblaze
- Tera Blast
";
$g23041 = "Jirachi @ Kings Rock
Ability: Serene Grace
Tera Type: &
EVs: 248 HP / 80 Def / 180 Spe
Impish Nature
- Wish
- Body Slam
- Mud-Slap
- Dynamic Punch
";
$g23050 = "Meloetta @ Sitrus Berry
Ability: Serene Grace
Tera Type: &
EVs: 248 HP / 8 Atk / 244 Def / 8 SpD
Relaxed Nature
- Perish Song
- Thunder Wave
- Metronome
- U-turn
";
$g23059 = "Pincurchin @ Sitrus Berry
Ability: Electric Surge
Shiny: Yes
Tera Type: &
EVs: 248 HP / 64 Def / 196 SpA
Quiet Nature
- Rising Voltage
- Spikes
- Scald
- Sucker Punch
";
$g23069 = "Cacturne @ Darkinium Z
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Swords Dance
- Seed Bomb
- Sucker Punch
- Drain Punch
";
$g23078 = "Cacturne @ Life Orb
Ability: Water Absorb
Tera Type: &
EVs: 112 HP / 252 SpA / 144 Spe
Mild Nature
- Leaf Storm
- Dark Pulse
- Spikes
- Sucker Punch
";
$g23087 = "Cacturne @ Rocky Helmet
Ability: Water Absorb
Tera Type: &
EVs: 116 HP / 140 Def / 252 Spe
Timid Nature
- Substitute
- Spikes
- Leech Seed
- Spiky Shield
";
$g23096 = "Alcremie-Ruby-Swirl @ Mirror Herb
Ability: Aroma Veil
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Decorate
- Acid Armor
- Recover
- Draining Kiss
";
$g23105 = "Volbeat @ Mirror Herb
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Swagger
- Tail Glow
- Baton Pass
- Toxic
";
$g23114 = "Toedscruel @ Leftovers
Ability: Mycelium Might
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Calm Nature
- Spore
- Sludge Bomb
- Leech Seed
- Reflect Type
";
$g23123 = "Abomasnow @ Abomasite
Ability: Snow Warning
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
- Aurora Veil
- Blizzard
- Leaf Storm
- Body Press
";
$g23132 = "Deoxys-Attack @ Focus Sash
Ability: Pressure
Tera Type: &
EVs: 248 HP / 8 SpD / 252 Spe
Timid Nature
- Stealth Rock
- Spikes
- Counter
- Detect
";
$g23141 = "Zamazenta @ Rocky Helmet
Ability: Dauntless Shield
Tera Type: &
EVs: 4 HP / 252 Def / 252 Spe
Jolly Nature
- Body Press
- Tera Blast
- Coaching
- Play Rough
";
$g23150 = "Manaphy @ Wise Glasses
Ability: Hydration
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Tail Glow
- Scald
- Ice Beam
- Tera Blast
";
$g23159 = "Victini @ Normalium Z
Ability: Victory Star
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Celebrate
- Stored Power
- Tera Blast
- Baton Pass
";
$g23168 = "Victini @ Choice Scarf
Ability: Victory Star
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Final Gambit
- Bolt Strike
- V-create
- Double-Edge
";
$g23177 = "Aggron @ Aggronite
Ability: Sturdy
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Heavy Slam
- Curse
- Rest
- Sleep Talk
";
$g23186 = "Deoxys-Defense @ Heavy-Duty Boots
Ability: Pressure
Tera Type: &
EVs: 248 HP / 176 Def / 84 SpD
Calm Nature
- Counter
- Mirror Coat
- Recover
- Taunt
";
$g23195 = "Darmanitan @ Choice Band
Ability: Sheer Force
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Flare Blitz
- Superpower
- Trick
- U-turn
";
$g23204 = "Pidgeot @ Pidgeotite
Ability: Keen Eye
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Hurricane
- Heat Wave
- U-turn
- Roost
";
$g23213 = "Shaymin-Sky @ Heavy-Duty Boots
Ability: Serene Grace
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Seed Flare
- Air Slash
- Healing Wish
- Leech Seed
";
$g23222 = "Klawf @ Lum Berry
Ability: Anger Shell
Tera Type: &
EVs: 172 HP / 88 Atk / 8 SpD / 240 Spe
Adamant Nature
- Stone Edge
- High Horsepower
- Knock Off
- Stealth Rock
";
$g23231 = "Klawf @ Chople Berry
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA
Naughty Nature
- Rock Blast
- Crabhammer
- Tera Blast
- Swords Dance
";
$g23240 = "Kleavor @ Choice Band
Ability: Sharpness
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- X-Scissor
- Stone Axe
- Knock Off
- U-turn
";
$g23249 = "Shaymin-Sky @ Assault Vest
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 128 SpD / 128 Spe
Timid Nature
- Seed Flare
- Air Slash
- Earth Power
- Tera Blast
";
$g23258 = "Charizard @ Normalium Z
Ability: Blaze
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Blaze Kick
- Thunder Punch
- Substitute
- Belly Drum
";
$g23267 = "Braviary @ Mirror Herb
Ability: Sheer Force
Tera Type: &
EVs: 248 HP / 8 Atk / 152 SpD / 100 Spe
Careful Nature
- Body Slam
- Iron Head
- Roost
- Bulk Up
";
$g23276 = "Chesnaught @ Rocky Helmet
Ability: Bulletproof
Tera Type: &
EVs: 248 HP / 252 Def / 8 Spe
Impish Nature
- Stone Edge
- Leech Seed
- Toxic
- Synthesis
";
$g23285 = "Tornadus @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Bleakwind Storm
- Heat Wave
- Knock Off
- U-turn
";
$g23294 = "Tornadus-Therian @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Hasty Nature
- Bleakwind Storm
- Heat Wave
- Knock Off
- Smack Down
";
$g23303 = "Tornadus-Therian @ Darkinium Z
Ability: Regenerator
Tera Type: &
EVs: 204 HP / 252 SpA / 4 SpD / 48 Spe
Modest Nature
- Hurricane
- Focus Blast
- Chilling Water
- Embargo
";
$g23312 = "Tornadus-Therian @ Starf Berry
Ability: Regenerator
Tera Type: &
EVs: 60 HP / 224 Atk / 4 SpA / 220 Spe
Lonely Nature
- Acrobatics
- Crunch
- Bleakwind Storm
- Bulk Up
";
$g23321 = "Tornadus-Therian @ Yache Berry
Ability: Regenerator
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Bleakwind Storm
- Knock Off
- U-turn
- Defog
";
$g23330 = "Tornadus-Therian @ Lum Berry
Ability: Regenerator
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpA / 100 SpD / 8 Spe
Nature
- Hurricane
- U-turn
- Defog
- Nasty Plot
";
$g23339 = "Tornadus @ Lum Berry
Ability: Prankster
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Bleakwind Storm
- U-turn
- Toxic
- Rest
";
$g23348 = "Swampert @ Swampertite
Ability: Damp
Tera Type: &
EVs: 172 HP / 252 SpA / 4 SpD / 80 Spe
Modest Nature
- Scald
- Rain Dance
- Endeavor
- Substitute
";
$g23357 = "Swampert @ Yache Berry
Ability: Torrent
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Sassy Nature
- Hydro Pump
- High Horsepower
- Mirror Coat
- Stealth Rock
";
$g23366 = "Swampert @ Swampertite
Ability: Damp
Tera Type: &
EVs: 252 HP / 16 Atk / 204 Def / 36 SpD
Adamant Nature
- Dive
- Earthquake
- Power-Up Punch
- Stealth Rock
";
$g23375 = "Swampert @ Swampertite
Ability: Damp
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Careful Nature
- Flip Turn
- Rest
- Stealth Rock
- Roar
";
$g23384 = "Swampert @ Swampertite
Ability: Damp
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Adamant Nature
- Earthquake
- Sleep Talk
- Rest
- Curse
";
$g23393 = "Gallade @ Galladite
Ability: Justified
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Zen Headbutt
- Will-O-Wisp
- Substitute
- Wish
";
$g23402 = "Veluza @ Sitrus Berry
Ability: Sharpness
Tera Type: &
EVs: 108 HP / 24 Atk / 224 SpA / 152 Spe
Rash Nature
- Stored Power
- Aqua Cutter
- Drill Run
- Fillet Away
";
$g23411 = "Veluza @ Normalium Z
Ability: Sharpness
Tera Type: &
EVs: 248 HP / 236 SpA / 4 SpD / 20 Spe
Modest Nature
- Hydro Pump
- Stored Power
- Focus Energy
- Fillet Away
";
$g23420 = "Veluza @ Choice Scarf
Ability: Sharpness
Tera Type: &
EVs: 252 HP / 4 Def / 252 Spe
Jolly Nature
- Aqua Cutter
- Psycho Cut
- Crunch
- Final Gambit
";
$g23429 = "Muk-Alola @ Normalium Z
Ability: Poison Touch
Shiny: Yes
Tera Type: &
EVs: 164 HP / 148 Atk / 96 Def / 100 SpD
Adamant Nature
- Poison Jab
- Gunk Shot
- Clear Smog
- Stockpile
";
$g23439 = "Kingambit @ TR71
Ability: Supreme Overlord
Tera Type: &
EVs: 108 HP / 236 Atk / 20 SpD / 144 Spe
Adamant Nature
- Fling
- Tera Blast
- Metal Claw
- Swords Dance
";
$g23448 = "Hoopa-Unbound @ TR71
Ability: Magician
Tera Type: &
EVs: 100 HP / 152 Atk / 4 SpD / 252 Spe
Jolly Nature
- Fling
- Power-Up Punch
- Gunk Shot
- Protect
";
$g23457 = "Hoopa-Unbound @ Flame Orb
Ability: Magician
Tera Type: &
EVs: 252 Atk / 100 SpD / 156 Spe
Careful Nature
- Hyperspace Fury
- Brick Break
- Fling
- Destiny Bond
";
$g23466 = "Hoopa-Unbound @ Flame Orb
Ability: Magician
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Fling
- Hyperspace Hole
- Nasty Plot
- Protect
";
$g23475 = "Hoopa-Unbound @ Sticky Barb
Ability: Magician
Tera Type: &
EVs: 100 HP / 100 SpA / 100 SpD / 208 Spe
Modest Nature
- Hyperspace Hole
- Taunt
- Trick
- Calm Mind
";
$g23484 = "Hoopa-Unbound @ Starf Berry
Ability: Magician
Tera Type: &
EVs: 252 Def / 4 SpD / 252 Spe
Timid Nature
- Dark Pulse
- Recycle
- Substitute
- Calm Mind
";
$g23493 = "Hoopa-Unbound @ Life Orb
Ability: Magician
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Relaxed Nature
- Hyperspace Fury
- Gunk Shot
- Thunderbolt
- Protect
";
$g23502 = "Araquanid @ Weakness Policy
Ability: Water Absorb
Tera Type: &
EVs: 248 HP / 228 Atk / 24 Def / 8 SpD
Adamant Nature
- Liquidation
- Leech Life
- Sticky Web
- Aqua Ring
";
$g23511 = "Manaphy @ Normalium Z
Ability: Hydration
Tera Type: &
EVs: 16 HP / 236 SpA / 4 SpD / 252 Spe
Timid Nature
- Scald
- Energy Ball
- Ice Beam
- Psych Up
";
$g23520 = "Landorus-Therian @ White Herb
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Lax Nature
- Sandsear Storm
- Protect
- Defog
- Fling
";
$g23529 = "Metagross @ Normalium Z
Ability: Clear Body
Tera Type: &
EVs: 200 Atk / 252 Def / 4 SpA / 52 Spe
Lax Nature
- Meteor Mash
- Body Press
- Psychic
- Psych Up
";
$g23538 = "Zapdos @ Psychium Z
Ability: Pressure
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Thunderbolt
- Reflect
- Light Screen
- Roost
";
$g23547 = "Nihilego @ Normalium Z
Ability: Beast Boost
Tera Type: &
EVs: 176 HP / 252 Def / 80 SpD
Bold Nature
- Knock Off
- Power Gem
- Pain Split
- Thunder Wave
";
$g23556 = "Garchomp @ Rockium Z
Ability: Sand Veil
Tera Type: &
EVs: 228 HP / 200 Atk / 52 SpD / 28 Spe
Adamant Nature
- Earthquake
- Stone Edge
- Swords Dance
- Sandstorm
";
$g23565 = "Murkrow @ Eviolite
Ability: Prankster
Tera Type: &
EVs: 248 HP / 92 Def / 8 SpA / 160 SpD
Calm Nature
- Quash
- Hurricane
- Roost
- Calm Mind
";
$g23574 = "Gengar @ Gengarite
Ability: Cursed Body
Tera Type: &
EVs: 104 HP / 152 Def / 252 Spe
Timid Nature
- Clear Smog
- Reflect Type
- Substitute
- Protect
";
$g23583 = "Lapras @ Heavy-Duty Boots
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
- Whirlpool
- Perish Song
- Body Press
- Protect
";
$g23592 = "Gengar @ Gengarite
Ability: Cursed Body
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Spe
Jolly Nature
- Perish Song
- Disable
- Substitute
- Protect
";
$g23601 = "Garchomp @ Choice Specs
Ability: Rough Skin
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Scorching Sands
- Draco Meteor
- Fire Blast
- Tera Blast
";
$g23610 = "Lapras @ Normalium Z
Ability: Water Absorb
Tera Type: &
EVs: 252 HP / 124 Atk / 132 Def
Adamant Nature
- Ice Shard
- Curse
- Captivate
- Rest
";
$g23619 = "Greninja @ Lum Berry
Ability: Battle Bond
Shiny: Yes
Tera Type: &
EVs: 44 HP / 164 Atk / 48 SpA / 252 Spe
Hasty Nature
- Hydro Pump
- Brutal Swing
- Gunk Shot
- Work Up
";
$g23629 = "Milotic @ Lum Berry
Ability: Competitive
Tera Type: &
EVs: 224 HP / 96 Def / 188 SpD
Calm Nature
- Muddy Water
- Mud Sport
- Mud Shot
- Recover
";
$g23638 = "Bellibolt @ Lum Berry
Ability: Electromorphosis
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Volt Switch
- Thunder
- Tera Blast
- Acid Spray
";
$g23647 = "Gholdengo @
Ability: Good as Gold
Tera Type: &
EVs: 236 HP / 152 SpA / 48 SpD / 72 Spe
Calm Nature
- Make It Rain
- Dazzling Gleam
- Nasty Plot
- Thief
";
$g23656 = "Brambleghast @
Ability: Wind Rider
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Strength Sap
- Rapid Spin
- Beat Up
- Thief
";
$g23665 = "Palossand @ Blunder Policy
Ability: Water Compaction
Tera Type: &
EVs: 116 HP / 140 SpA / 252 Spe
Modest Nature
- Spit Up
- Swallow
- Stockpile
- Hypnosis
";
$g23674 = "Dudunsparce @ Spell Tag
Ability: Serene Grace
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpA
Modest Nature
- Shadow Ball
- Stealth Rock
- Roost
- Substitute
";
$g23683 = "Hatterene @ Big Root
Ability: Magic Bounce
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Psyshock
- Draining Kiss
- Giga Drain
- Calm Mind
";
$g23692 = "Farigiraf @ Sitrus Berry
Ability: Cud Chew
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
- Foul Play
- Growl
- Amnesia
- Baton Pass
";
$g23701 = "Wyrdeer @ Heavy-Duty Boots
Ability: Sap Sipper
Tera Type: &
EVs: 100 HP / 156 SpD / 252 Spe
Jolly Nature
- Psyshield Bash
- Earthquake
- Protect
- Helping Hand
";
$g23710 = "Wyrdeer @ Choice Band
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Psyshield Bash
- Earthquake
- Body Slam
- Megahorn
";
$g23719 = "Wyrdeer @ Lum Berry
Ability: Sap Sipper
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Tera Blast
- Psychic
- Earth Power
- Calm Mind
";
$g23728 = "Wyrdeer @ Assault Vest
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 72 Atk / 4 SpA / 180 SpD
Brave Nature
- Psyshield Bash
- Thunder
- Double Kick
- Dig
";
$g23737 = "Wyrdeer @ Normalium Z
Ability: Sap Sipper
Tera Type: &
EVs: 120 HP / 252 SpA / 4 SpD / 132 Spe
Modest Nature
- Hyper Beam
- Stored Power
- Agility
- Calm Mind
";
$g23746 = "Wyrdeer @ Leftovers
Ability: Frisk
Tera Type: &
EVs: 252 HP / 72 Atk / 184 Spe
Adamant Nature
- Psyshield Bash
- Disable
- Protect
- Substitute
";
$g23755 = "Wyrdeer @ Sitrus Berry
Ability: Frisk
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Relaxed Nature
- Psyshield Bash
- Shadow Ball
- Disable
- Thrash
";
$g23764 = "Wyrdeer @ Blunder Policy
Ability: Frisk
Tera Type: &
EVs: 252 HP / 84 Def / 140 SpA / 32 Spe
Modest Nature
- Psyshock
- Earth Power
- Hypnosis
- Calm Mind
";
$g23773 = "Wyrdeer @ Chesto Berry
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Psyshield Bash
- Disable
- Rest
- Protect
";
$g23782 = "Wyrdeer @ Bright Powder
Ability: Frisk
Tera Type: &
EVs: 100 HP / 108 Atk / 100 Def / 100 SpD / 100 Spe
Adamant Nature
- Psyshield Bash
- Body Slam
- Sand Attack
- Hypnosis
";
$g23791 = "Wyrdeer @ Metronome
Ability: Intimidate
Tera Type: &
EVs: 176 HP / 128 Atk / 204 Spe
Adamant Nature
- Psyshield Bash
- Sleep Talk
- Rest
- Substitute
";
$g23800 = "Wyrdeer @ Maranga Berry
Ability: Intimidate
Tera Type: &
EVs: 244 HP / 64 Atk / 20 Def / 180 SpD
Careful Nature
- Psyshield Bash
- Skill Swap
- Substitute
- Rest
";
$g23809 = "Wyrdeer @ Red Card
Ability: Frisk
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpA
Quiet Nature
- Trick
- Tera Blast
- Shadow Ball
- Calm Mind
";
$g23818 = "Wyrdeer @ Choice Specs
Ability: Sap Sipper
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Psychic
- Hyper Beam
- Shadow Ball
- Energy Ball
";
$g23827 = "Wyrdeer @ Colbur Berry
Ability: Intimidate
Tera Type: &
EVs: 36 HP / 252 Atk / 192 Def / 28 SpD
Adamant Nature
- Psyshield Bash
- Thunder Wave
- Rest
- Giga Impact
";
$g23836 = "Wyrdeer @ Colbur Berry
Ability: Frisk
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Psychic
- Thunderbolt
- Disable
- Calm Mind
";
$g23845 = "Wyrdeer @ Light Clay
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Body Slam
- Thunder Wave
- Reflect
- Light Screen
";
$g23854 = "Wyrdeer @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Brave Nature
- Psyshield Bash
- Megahorn
- Wild Charge
- Trick Room
";
$g23862 = "Makuhita @ Clear Amulet
Ability: Thick Fat
Tera Type: &
EVs: 20 HP / 240 Atk / 36 Def / 196 SpD
Adamant Nature
- Close Combat
- Earthquake
- Knock Off
- Bullet Punch
";
$g23871 = "Zorua-Hisui @ Eviolite
Ability: Illusion
Tera Type: &
EVs: 40 Def / 236 SpA / 36 SpD / 196 Spe
Timid Nature
- Knock Off
- Hyper Beam
- Dig
- Bitter Malice
";
$g23880 = "Bronzor @ Choice Scarf
Ability: Levitate
Tera Type: &
EVs: 220 HP / 4 SpA / 252 Spe
Timid Nature
IVs: 0 Atk
- Psychic
- Iron Defense
- Rest
- Trick
";
$g23890 = "Sawsbuck-Winter @ Sitrus Berry
Ability: Chlorophyll
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Calm Nature
IVs: 0 Atk
- Leech Seed
- Thunder Wave
- Substitute
- Protect
";
$g23900 = "Froakie @ Eviolite
Ability: Protean
Tera Type: &
EVs: 188 HP / 196 Def / 100 SpA
Bold Nature
- Hydro Pump
- Ice Beam
- Counter
- Quick Attack
";
$g23909 = "Tauros-Paldea-Aqua (M) @ Sitrus Berry
Ability: Cud Chew
Tera Type: &
EVs: 252 HP / 80 Atk / 176 Spe
Adamant Nature
- Raging Bull
- Close Combat
- Outrage
- Bulk Up
";
$g23918 = "Kleavor @ Choice Scarf
Ability: Sharpness
Tera Type: &
EVs: 72 HP / 252 Atk / 184 Spe
Adamant Nature
- X-Scissor
- Stone Axe
- U-turn
- Close Combat
";
$g23927 = "Iron Valiant @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 16 SpD / 240 Spe
Jolly Nature
- Spirit Break
- Close Combat
- Knock Off
- Swords Dance
";
$g23936 = "Dragonite @ Heavy-Duty Boots
Ability: Multiscale
Tera Type: &
EVs: 252 HP / 32 Atk / 224 Spe
Adamant Nature
- Ice Spinner
- Earthquake
- Roost
- Dragon Dance
";
$g23945 = "Iron Treads @ Life Orb
Ability: Quark Drive
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe
Jolly Nature
- Earthquake
- Heavy Slam
- Stone Edge
- Knock Off
";
$g23954 = "Mew @ Life Orb
Ability: Synchronize
Tera Type: &
EVs: 40 HP / 252 Atk / 216 Spe
Adamant Nature
- Earthquake
- Psychic Fangs
- Ice Spinner
- Dragon Dance
";
$g23963 = "Samurott @ Choice Band
Ability: Torrent
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Liquidation
- Aqua Jet
- Knock Off
- Body Slam
";
$g23972 = "Samurott @ Petaya Berry
Ability: Torrent
Tera Type: &
EVs: 40 HP / 216 SpA / 252 Spe
Timid Nature
- Scald
- Knock Off
- Hydro Cannon
- Substitute
";
$g23981 = "Samurott @ Liechi Berry
Ability: Torrent
Tera Type: &
EVs: 164 HP / 232 Atk / 112 SpD
Adamant Nature
- Aqua Jet
- Encore
- Substitute
- Swords Dance
";
$g23990 = "Roselia @ Leftovers
Ability: Natural Cure
Tera Type: &
EVs: 252 HP / 208 Def / 48 Spe
Bold Nature
IVs: 2 Atk / 30 Spe
- Hidden Power [Psychic]
- Leech Seed
- Spikes
- Protect
";
$g24000 = "Roselia @ Eviolite
Ability: Natural Cure
Tera Type: &
EVs: 248 HP / 8 SpA / 252 SpD
Calm Nature
IVs: 0 Atk
- Grass Whistle
- Spikes
- Toxic Spikes
- Giga Drain
";
$g24010 = "Sneasel-Hisui @ Life Orb
Ability: Inner Focus
Tera Type: &
EVs: 252 Atk / 80 Def / 176 Spe
Adamant Nature
- Gunk Shot
- Close Combat
- Tera Blast
- Swords Dance
";
$g24019 = "Iron Valiant @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 88 Atk / 252 SpA / 168 Spe
Naive Nature
- Moonblast
- Close Combat
- Encore
- Calm Mind
";
$g24028 = "Iron Treads @ Assault Vest
Ability: Quark Drive
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Jolly Nature
- Earthquake
- Heavy Slam
- Knock Off
- Rapid Spin
";
$g24037 = "Mew @ Leftovers
Ability: Synchronize
Tera Type: &
EVs: 252 HP / 72 Def / 184 Spe
Jolly Nature
- Body Press
- Dragon Tail
- Toxic Spikes
- Encore
";
$g24046 = "Arcanine @ Heavy-Duty Boots
Ability: Intimidate
Tera Type: &
EVs: 240 HP / 252 SpD / 16 Spe
Careful Nature
- Flare Blitz
- Play Rough
- Roar
- Morning Sun
";
$g24055 = "Dragonite @ Life Orb
Ability: Multiscale
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
IVs: 0 Atk
- Draco Meteor
- Hurricane
- Fire Blast
- Roost
";
$g24065 = "Surskit @ Focus Sash
Ability: Swift Swim
Tera Type: &
EVs: 248 HP / 8 SpA / 252 Spe
Timid Nature
IVs: 0 Atk
- Infestation
- Scald
- Sticky Web
- Haze
";
$g24075 = "Flutter Mane @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Timid Nature
IVs: 0 Atk
- Wish
- Hex
- Protect
- Calm Mind
";
$g24085 = "Zamazenta @ Leftovers
Ability: Dauntless Shield
Tera Type: &
EVs: 252 Def / 100 SpA / 156 Spe
Bold Nature
IVs: 0 Atk
- Body Press
- Focus Blast
- Rest
- Imprison
";
$g24095 = "Dragonite @ Heavy-Duty Boots
Ability: Multiscale
Tera Type: &
EVs: 232 HP / 252 SpA / 4 SpD / 20 Spe
Modest Nature
IVs: 0 Atk
- Thunderbolt
- Ice Beam
- Roost
- Agility
";
$g24105 = "Dragonite @ Metronome
Ability: Multiscale
Tera Type: &
EVs: 248 HP / 168 SpD / 92 Spe
Careful Nature
- Breaking Swipe
- Dragon Dance
- Substitute
- Roost
";
$g24114 = "Cyclizar @ Assault Vest
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 88 SpD / 168 Spe
Jolly Nature
- Breaking Swipe
- U-turn
- Knock Off
- Double-Edge
";
$g24123 = "Dunsparce @ Eviolite
Ability: Serene Grace
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Relaxed Nature
- Body Slam
- Ancient Power
- Substitute
- Roost
";
$g24132 = "Miltank (F) @ Leftovers
Ability: Thick Fat
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Def
Impish Nature
- Double-Edge
- Stealth Rock
- Milk Drink
- Protect
";
$g24141 = "Regieleki @ Assault Vest
Ability: Transistor
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
- Thunderbolt
- Volt Switch
- Tera Blast
- Rapid Spin
";
$g24150 = "Roaring Moon @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Adamant Nature
- Jaw Lock
- Taunt
- Roost
- Dragon Dance
";
$g24159 = "Palafin @ Icium Z
Ability: Zero to Hero
Tera Type: &
EVs: 220 HP / 32 Atk / 252 SpD / 4 Spe
Adamant Nature
- Jet Punch
- Bulk Up
- Drain Punch
- Mist
";
$g24168 = "Lopunny @ Lopunnite
Ability: Limber
Tera Type: &
EVs: 252 HP / 4 Atk / 252 Spe
Jolly Nature
- Drain Punch
- Encore
- Toxic
- Substitute
";
$g24177 = "Kangaskhan (F) @ Kangaskhanite
Ability: Inner Focus
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Body Slam
- Circle Throw
- Wish
- Protect
";
$g24186 = "Kangaskhan (F) @ Kangaskhanite
Ability: Early Bird
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Double-Edge
- Beat Up
- Disable
- Substitute
";
$g24195 = "Kangaskhan (F) @ Kangaskhanite
Ability: Early Bird
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 108 SpD / 100 Spe
Jolly Nature
- Body Slam
- Earthquake
- Sleep Talk
- Rest
";
$g24204 = "Garganacl @ Choice Band
Ability: Purifying Salt
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Salt Cure
- Hammer Arm
- Ice Punch
- Dig
";
$g24213 = "Quaquaval @ Chilan Berry
Ability: Torrent
Tera Type: &
EVs: 4 HP / 252 Atk / 252 Spe
Adamant Nature
- Aqua Step
- Substitute
- Agility
- Swords Dance
";
$g24222 = "Houndstone @ Heavy-Duty Boots
Ability: Fluffy
Tera Type: &
EVs: 252 HP / 252 Def / 4 Spe
Lax Nature
- Last Respects
- Will-O-Wisp
- Mud-Slap
- Protect
";
$g24231 = "Orthworm @ Chesto Berry
Ability: Earth Eater
Tera Type: &
EVs: 248 HP / 100 Def / 8 SpA / 152 SpD
Bold Nature
- Iron Tail
- Rest
- Mud-Slap
- Shed Tail
";
$g24240 = "Blissey (F) @ Leftovers
Ability: Serene Grace
Tera Type: &
EVs: 204 HP / 252 Def / 52 SpA
Bold Nature
- Shadow Ball
- Thief
- Soft-Boiled
- Aromatherapy
";
$g24249 = "Alakazam @ Black Sludge
Ability: Magic Guard
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Timid Nature
IVs: 0 Atk
- Psyshock
- Recover
- Trick
- Protect
";
$g24259 = "Alakazam @ Choice Band
Ability: Synchronize
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Timid Nature
- Psychic
- Substitute
- Fire Punch
- Trick
";
$g24268 = "Gengar @ Leftovers
Ability: Levitate
Tera Type: &
EVs: 248 HP / 44 Def / 8 SpA / 112 SpD / 96 Spe
Timid Nature
- Will-O-Wisp
- Explosion
- Thunderbolt
- Ice Punch
";
$g24277 = "Silvally @ Life Orb
Ability: RKS System
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naughty Nature
- Explosion
- Ice Beam
- Defog
- Swords Dance
";
$g24286 = "Magearna @ Red Card
Ability: Soul-Heart
Tera Type: &
EVs: 132 HP / 196 Atk / 4 SpD / 176 Spe
Adamant Nature
- Iron Head
- Play Rough
- Ice Spinner
- Shift Gear
";
$g24295 = "Veluza @ Bright Powder
Ability: Sharpness
Tera Type: &
EVs: 100 HP / 156 Atk / 252 Spe
Adamant Nature
- Psychic Fangs
- Aqua Cutter
- Pluck
- Fillet Away
";
$g24304 = "Garchomp @ Rocky Helmet
Ability: Rough Skin
Tera Type: &
EVs: 252 HP / 4 SpA / 252 Spe
Naive Nature
- Stomping Tantrum
- Mud Shot
- Spikes
- Dragon Rush
";
$g24313 = "Garchomp @ Rocky Helmet
Ability: Rough Skin
Tera Type: &
EVs: 104 HP / 240 Atk / 4 SpD / 160 Spe
Adamant Nature
- Earthquake
- Thunder Fang
- Facade
- Swords Dance
";
$g24322 = "Crabominable @ Air Balloon
Ability: Iron Fist
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Ice Hammer
- Drain Punch
- Thunder Punch
- Protect
";
$g24331 = "Moltres @ Mirror Herb
Ability: Pressure
Tera Type: &
EVs: 248 HP / 8 Atk / 252 Def
Lax Nature
- Acrobatics
- Incinerate
- Roost
- Swagger
";
$g24340 = "Tapu Koko @ Mirror Herb
Ability: Electric Surge
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Wild Charge
- Acrobatics
- Swagger
- Roost
";
$g24349 = "Alomomola @ Mirror Herb
Ability: Regenerator
Tera Type: &
EVs: 108 HP / 148 Atk / 252 SpD
Adamant Nature
- Liquidation
- Acrobatics
- Swagger
- Wish
";
$g24358 = "Greninja @ Choice Specs
Ability: Protean
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
IVs: 0 Atk
- Hyper Beam
- Dark Pulse
- Mud Shot
- Echoed Voice
";
$g24368 = "Chien-Pao @ Life Orb
Ability: Sword of Ruin
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
IVs: 0 Atk
- Blizzard
- Dark Pulse
- Ruination
- Recover
";
$g24378 = "Espathra @ Psychium Z
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 184 Def / 72 SpA
Modest Nature
IVs: 0 Atk
- Lumina Crash
- Reflect
- Light Screen
- Roost
";
$g24388 = "Espathra @ Light Clay
Ability: Speed Boost
Tera Type: &
EVs: 252 HP / 24 SpA / 196 SpD / 36 Spe
Timid Nature
IVs: 0 Atk
- Lumina Crash
- Light Screen
- Reflect
- Roost
";
$g24398 = "Espathra @ Rocky Helmet
Ability: Speed Boost
Tera Type: &
EVs: 236 HP / 232 Def / 32 SpD / 8 Spe
Timid Nature
IVs: 0 Atk
- Lumina Crash
- Feather Dance
- Roost
- Calm Mind
";
$g24408 = "Espathra @ Mirror Herb
Ability: Opportunist
Tera Type: &
EVs: 100 HP / 100 Atk / 100 Def / 100 SpA / 100 SpD / 8 Spe
- Stored Power
- Low Kick
- Roost
- Calm Mind
";
$g24416 = "Espathra @ Fairium Z
Ability: Opportunist
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
IVs: 0 Atk
- Confusion
- Dazzling Gleam
- Roost
- Calm Mind
";
$g24426 = "Escavalier @ Normalium Z
Ability: Shell Armor
Tera Type: &
EVs: 252 HP / 88 Atk / 136 SpD / 32 Spe
Adamant Nature
- Megahorn
- Knock Off
- Encore
- Swords Dance
";
$g24435 = "Escavalier @ Steelium Z
Ability: Overcoat
Tera Type: &
EVs: 248 HP / 252 SpA / 8 SpD
Modest Nature
IVs: 0 Atk
- Giga Drain
- Protect
- Steel Beam
- Laser Focus
";
$g24445 = "Escavalier @ Mirror Herb
Ability: Swarm
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Megahorn
- Iron Head
- Drill Run
- Swagger
";
$g24454 = "Escavalier @ Liechi Berry
Ability: Swarm
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Megahorn
- Flail
- Substitute
- Swords Dance
";
$g24463 = "Gyarados @ Gyaradosite
Ability: Moxie
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Power Whip
- Dragon Dance
- Flail
- Substitute
";
$g24472 = "Escavalier @ Occa Berry
Ability: Swarm
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Megahorn
- Drill Run
- Toxic
- Protect
";
$g24481 = "Escavalier @ Choice Band
Ability: Swarm
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Megahorn
- Pursuit
- Iron Head
- Bug Bite
";
$g24490 = "Escavalier @ Steelium Z
Ability: Swarm
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Metal Burst
- Knock Off
- Drill Run
- Swords Dance
";
$g24499 = "Murkrow @ Eviolite
Ability: Prankster
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Careful Nature
- U-turn
- Toxic
- Haze
- Protect
";
$g24508 = "Murkrow @ Heavy-Duty Boots
Ability: Prankster
Tera Type: &
EVs: 248 HP / 8 Def / 252 SpD
Careful Nature
- Haze
- Quash
- U-turn
- Protect
";
$g24517 = "Murkrow @ Eviolite
Ability: Prankster
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpD
Bold Nature
IVs: 0 Atk
- Mean Look
- Substitute
- Protect
- Perish Song
";
$g24527 = "Bronzong @ Light Clay
Ability: Levitate
Tera Type: &
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Heavy Slam
- Stealth Rock
- Reflect
- Light Screen
";
$g24536 = "Slowbro-Galar @ Slowbronite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
- Shell Side Arm
- Thunder Wave
- Foul Play
- Slack Off
";
$g24545 = "Slowbro @ Choice Band
Ability: Regenerator
Tera Type: &
EVs: 24 HP / 228 Atk / 252 Def / 4 SpA
Relaxed Nature
- Liquidation
- Body Press
- Earthquake
- Fire Blast
";
$g24554 = "Genesect @ Psychium Z
Ability: Download
Tera Type: &
EVs: 212 HP / 40 Atk / 4 SpD / 252 Spe
Jolly Nature
- Leech Life
- Psychic
- Reflect
- Light Screen
";
$g24563 = "Genesect @ Flyinium Z
Ability: Download
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Lonely Nature
- Techno Blast
- Extreme Speed
- Fly
- Shift Gear
";
$g24572 = "Genesect @ Choice Band
Ability: Download
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- U-turn
- Gunk Shot
- Blaze Kick
- Giga Impact
";
$g24581 = "Zoroark-Hisui @ Normalium Z
Ability: Illusion
Tera Type: &
EVs: 200 HP / 128 SpA / 4 SpD / 176 Spe
Timid Nature
IVs: 0 Atk
- Shadow Ball
- Focus Blast
- Grass Knot
- Happy Hour
";
$g24591 = "Vivillon-Fancy @ Normalium Z
Ability: Compound Eyes
Tera Type: &
EVs: 216 HP / 160 Def / 68 SpA / 16 SpD / 48 Spe
Modest Nature
IVs: 0 Atk
- Hurricane
- Calm Mind
- Hold Hands
- Quiver Dance
";
$g24601 = "Pyukumuku @ Poisonium Z
Ability: Innards Out
Tera Type: &
EVs: 252 HP / 4 Def / 252 SpD
Calm Nature
IVs: 0 Atk
- Toxic
- Counter
- Purify
- Recover
";
$g24611 = "Zoroark-Hisui @ Mirror Herb
Ability: Illusion
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Bitter Malice
- Detect
- Flamethrower
- Calm Mind
";
$g24621 = "Corviknight @ Buginium Z
Ability: Pressure
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Brave Bird
- U-turn
- Roost
- Bulk Up
";
$g24630 = "Oinkologne (M) @ Petaya Berry
Ability: Lingering Aroma
Tera Type: &
EVs: 48 HP / 208 Def / 252 SpA
Modest Nature
IVs: 0 Atk
- Body Press
- Earth Power
- Belch
- Stuff Cheeks
";
$g24640 = "Decidueye @ Decidium Z
Ability: Overgrow
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Bullet Seed
- Spirit Shackle
- Synthesis
- Swords Dance
";
$g24649 = "Ursaluna @ Custap Berry
Ability: Bulletproof
Tera Type: &
EVs: 248 HP / 212 Atk / 44 Def / 4 SpD
Adamant Nature
- Giga Impact
- Headlong Rush
- Swords Dance
- Endure
";
$g24658 = "Annihilape @ Flame Orb
Ability: Vital Spirit
Tera Type: &
EVs: 204 HP / 48 Atk / 4 SpD / 252 Spe
Jolly Nature
- Rage Fist
- Power-Up Punch
- Thief
- Fling
";
$g24667 = "Eevee @ Eevium Z
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 80 Atk / 176 Spe
Adamant Nature
- Last Resort
- Protect
";
$g24674 = "Eevee @ Eevium Z
Ability: Adaptability
Tera Type: &
EVs: 252 HP / 4 SpD / 252 Spe
Jolly Nature
- Last Resort
- Substitute
- Protect
- Baton Pass
";
$g24683 = "Pikachu-Unova (M) @ Pikashunium Z
Ability: Lightning Rod
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Timid Nature
- Thunderbolt
- Fake Out
- Encore
- Grass Knot
";
$g24692 = "Pikachu @ Pikanium Z
Ability: Lightning Rod
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Volt Tackle
- Volt Switch
- Charge
- Fake Out
";
$g24701 = "Pikachu-Unova (M) @ Light Ball
Ability: Static
Tera Type: &
EVs: 64 HP / 252 Atk / 192 Spe
Adamant Nature
- Volt Tackle
- Knock Off
- Substitute
- Focus Punch
";
$g24710 = "Pikachu-Unova (M) @ Pikashunium Z
Ability: Lightning Rod
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Hasty Nature
- Thunderbolt
- Nuzzle
- Substitute
- Charge
";
$g24719 = "Pikachu-Unova (M) @ Assault Vest
Ability: Lightning Rod
Tera Type: &
EVs: 252 HP / 160 SpD / 96 Spe
Hasty Nature
- Thunderbolt
- Surf
- Nuzzle
- Fake Out
";
$g24728 = "Garbodor @ Poisonium Z
Ability: Aftermath
Tera Type: &
EVs: 184 HP / 252 Def / 72 SpD
Bold Nature
IVs: 0 Atk
- Body Press
- Poison Gas
- Spikes
- Protect
";
$g24738 = "Hypno @ Poisonium Z
Ability: Insomnia
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
IVs: 0 Atk
- Psychic
- Body Press
- Poison Gas
- Protect
";
$g24748 = "Walking Wake @ Lum Berry
Ability: Protosynthesis
Tera Type: &
EVs: 184 HP / 252 Atk / 4 SpD / 68 Spe
Adamant Nature
- Liquidation
- Dragon Claw
- Fire Fang
- Dragon Dance
";
$g24757 = "Iron Leaves @ Grassium Z
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Solar Blade
- Close Combat
- Trailblaze
- Swords Dance

";

$twinkietonrogue = "Tinkaton (F)
Ability: Mold Breaker
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Gigaton Hammer
- Ice Hammer
- Knock Off
- Covet
";
$g24775 = "Iron Leaves @ Focus Sash
Ability: Quark Drive
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Hasty Nature
- Leaf Blade
- Psyblade
- Focus Blast
- Wild Charge
";
$g24784 = "Iron Leaves @ Booster Energy
Ability: Quark Drive
Tera Type: &
EVs: 252 HP / 88 Atk / 168 SpD
Careful Nature
- Trailblaze
- Psyblade
- Close Combat
- Swords Dance
";
$g24793 = "Walking Wake @ Assault Vest
Ability: Protosynthesis
Tera Type: &
EVs: 136 HP / 120 SpA / 252 SpD
Modest Nature
- Hydro Steam
- Chilling Water
- Draco Meteor
- Dragon Tail
";
$g24802 = "Iron Leaves @ Electric Seed
Ability: Quark Drive
Tera Type: &
EVs: 232 HP / 252 Atk / 4 SpD / 20 Spe
Adamant Nature
- Psyblade
- Wild Charge
- Electric Terrain
- Swords Dance
";
$g24811 = "Walking Wake @ Life Orb
Ability: Protosynthesis
Tera Type: &
EVs: 168 HP / 4 Def / 84 SpA / 252 Spe
Timid Nature
IVs: 0 Atk
- Hydro Steam
- Flamethrower
- Dragon Pulse
- Sunny Day
";
$g24821 = "Walking Wake @ Firium Z
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 212 Def / 40 SpA / 4 SpD
Modest Nature
IVs: 0 Atk
- Hydro Steam
- Flamethrower
- Dragon Breath
- Sunny Day
";
$g24831 = "Walking Wake @ Leftovers
Ability: Protosynthesis
Tera Type: &
EVs: 252 HP / 32 Atk / 88 Def / 136 Spe
Modest Nature
- Chilling Water
- Dragon Tail
- Substitute
- Protect
";
$g24840 = "Walking Wake @ Petaya Berry
Ability: Protosynthesis
Tera Type: &
EVs: 4 HP / 252 SpA / 252 Spe
Timid Nature
IVs: 0 Atk
- Hydro Steam
- Flamethrower
- Substitute
- Sunny Day
";
$g24850 = "Walking Wake @ Dragonium Z
Ability: Protosynthesis
Tera Type: &
EVs: 252 SpA / 8 SpD / 248 Spe
Timid Nature
IVs: 0 Atk
- Hydro Pump
- Draco Meteor
- Substitute
- Roar
";
$g24860 = "Walking Wake @ Haban Berry
Ability: Protosynthesis
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
- Waterfall
- Outrage
- Breaking Swipe
- Dragon Dance
";
$g24869 = "Walking Wake @ Expert Belt
Ability: Protosynthesis
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Naive Nature
- Flamethrower
- Hydro Pump
- Dragon Rush
- Hone Claws
";
$g24878 = "Walking Wake @ Bright Powder
Ability: Protosynthesis
Tera Type: &
EVs: 224 HP / 4 Atk / 28 Def / 252 SpD
Sassy Nature
- Chilling Water
- Dragon Tail
- Sleep Talk
- Rest
";
$g24887 = "Walking Wake @ Eject Pack
Ability: Protosynthesis
Tera Type: &
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Draco Meteor
- Hydro Pump
- Chilling Water
- Protect
";
$g24897 = "Walking Wake @ Damp Rock
Ability: Protosynthesis
Tera Type: &
EVs: 176 HP / 216 SpA / 116 Spe
Modest Nature
- Hydro Pump
- Tera Blast
- Aqua Jet
- Rain Dance
";
$g24906 = "Slowking-Galar @ Heavy-Duty Boots
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
IVs: 0 Atk
- Acid Spray
- Scald
- Future Sight
- Chilly Reception
";
$g24916 = "Slowking-Galar @ Normalium Z
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
IVs: 0 Atk
- Sludge Bomb
- Fire Blast
- Hyper Beam
- Calm Mind
";
$g24926 = "Slowking-Galar @ Normalium Z
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Zen Headbutt
- Protect
- Drain Punch
- Belly Drum
";
$g24935 = "Slowbro-Galar @ Normalium Z
Ability: Quick Draw
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpA
Brave Nature
- Shell Side Arm
- Ice Punch
- Body Press
- Belly Drum
";
$g24944 = "Slowbro-Galar @ Slowbronite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
IVs: 0 Atk
- Scald
- Body Press
- Sludge Bomb
- Slack Off
";
$g24954 = "Slowbro-Galar @ Slowbronite
Ability: Quick Draw
IVs: 0 Atk
- Psychic
- Fire Blast
- Slack Off
- Calm Mind
";
$g24962 = "Slowbro-Galar @ Slowbronite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 4 Def / 4 SpA / 248 SpD
Bold Nature
IVs: 0 Atk
- Sludge Bomb
- Foul Play
- Disable
- Slack Off
";
$g24972 = "Glastrier @ Icium Z
Ability: Chilling Neigh
Tera Type: &
EVs: 248 HP / 8 Atk / 252 SpD
Careful Nature
- Trailblaze
- Body Press
- Mist
- Iron Defense
";
$g24981 = "Magearna @ Life Orb
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 252 Atk / 4 SpD
Adamant Nature
- Heavy Slam
- Play Rough
- Ice Spinner
- Spikes
";
$g24990 = "Toxapex @ Life Orb
Ability: Regenerator
Tera Type: &
EVs: 248 HP / 252 Atk / 8 SpD
Adamant Nature
- Spike Cannon
- Scald
- Gunk Shot
- Baneful Bunker
";
$g24999 = "Magearna @ Leftovers
Ability: Soul-Heart
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Modest Nature
IVs: 0 Atk
- Hyper Beam
- Spikes
- Encore
- Trick Room
";
$g25009 = "Glastrier @ Choice Band
Ability: Chilling Neigh
Tera Type: &
EVs: 244 HP / 252 Atk / 12 Spe
Adamant Nature
- Icicle Spear
- Close Combat
- High Horsepower
- Avalanche
";
$g25018 = "Glastrier @ Assault Vest
Ability: Chilling Neigh
Tera Type: &
EVs: 252 HP / 204 Atk / 4 Def / 48 SpD
Adamant Nature
- Icicle Spear
- Heavy Slam
- High Horsepower
- Avalanche
";
$g25027 = "Glastrier @ Weakness Policy
Ability: Chilling Neigh
Tera Type: &
EVs: 252 HP / 56 Atk / 200 Def
Adamant Nature
IVs: 30 Spe
- Icicle Spear
- Heavy Slam
- Close Combat
- Payback
";
$g25037 = "Landorus-Therian (M) @ Assault Vest
Ability: Intimidate
Tera Type: &
EVs: 168 HP / 116 Atk / 120 SpD / 104 Spe
Adamant Nature
- Earthquake
- Outrage
- Knock Off
- Smack Down
";
$g25046 = "Celesteela @ Choice Specs
Ability: Beast Boost
Tera Type: &
EVs: 176 HP / 252 Def / 80 SpA
Bold Nature
- Heavy Slam
- Air Slash
- Fire Blast
- Giga Drain
";
$g25055 = "Landorus-Therian (M) @ Assault Vest
Ability: Intimidate
Tera Type: &
EVs: 252 HP / 56 SpD / 200 Spe
Timid Nature
- Sandsear Storm
- Sludge Bomb
- Knock Off
- U-turn
";
$g25064 = "Landorus-Therian (M) @ Leftovers
Ability: Intimidate
Tera Type: &
EVs: 204 HP / 48 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Sandsear Storm
- Protect
- Defog
- Calm Mind
";
$g25074 = "Landorus-Therian (M) @ Passho Berry
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpA / 252 Spe
Naive Nature
- Dig
- Grass Knot
- Explosion
- Bulk Up
";
$g25083 = "Swampert @ Choice Specs
Ability: Torrent
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
IVs: 0 Atk
- Hydro Cannon
- Earth Power
- Muddy Water
- Sludge Wave
";
$g25093 = "Landorus-Therian (M) @ Eject Pack
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 Def / 252 SpA
Naughty Nature
- Sandsear Storm
- Fly
- Superpower
- Defog
";
$g25102 = "Tyranitar @ Scope Lens
Ability: Sand Stream
Tera Type: &
EVs: 168 HP / 200 Atk / 4 SpD / 136 Spe
Adamant Nature
- Stone Edge
- Aqua Tail
- Focus Energy
- Dragon Dance
";
$g25111 = "Decidueye-Hisui @ Flyinium Z
Ability: Overgrow
Tera Type: &
EVs: 196 HP / 36 Atk / 168 SpD / 108 Spe
Adamant Nature
- Triple Arrows
- Bulk Up
- Tailwind
- Synthesis
";
$g25120 = "Audino @ Audinite
Ability: Regenerator
Tera Type: &
EVs: 252 HP / 252 Def / 4 SpA
Bold Nature
IVs: 0 Atk
- Ice Beam
- Wish
- Protect
- Calm Mind
";
$g25130 = "Heatran @ Mirror Herb
Ability: Flash Fire
Tera Type: &
EVs: 4 Atk / 252 SpA / 252 Spe
Modest Nature
- Fire Blast
- Flash Cannon
- Facade
- Flame Charge
";
$g25139 = "Annihilape @ Shell Bell
Ability: Vital Spirit
Tera Type: &
EVs: 156 HP / 92 Atk / 4 SpA / 4 SpD / 252 Spe
Naive Nature
- Cross Chop
- Curse
- Endeavor
- Substitute
";
$g25148 = "Iron Treads @ Sticky Barb
Ability: Quark Drive
Tera Type: &
EVs: 140 HP / 8 Atk / 108 SpA / 252 Spe
Naive Nature
- Ice Fang
- Endeavor
- Rapid Spin
- Steel Beam
";
$g25157 = "Annihilape @ Chople Berry
Ability: Inner Focus
Tera Type: &
EVs: 252 HP / 252 SpA / 4 SpD
Modest Nature
- Rage Fist
- Bulk Up
- Rest
- Sleep Talk
";
$g25166 = "Landorus-Therian (M) @ Chilan Berry
Ability: Intimidate
Tera Type: &
EVs: 252 Atk / 4 SpD / 252 Spe
Jolly Nature
- Dig
- Fly
- Stealth Rock
- Swords Dance
";
$g25175 = "Landorus-Therian (M) @ Groundium Z
Ability: Intimidate
Tera Type: &
EVs: 188 HP / 252 Atk / 4 SpD / 64 Spe
Adamant Nature
- Earthquake
- Leer
- Swords Dance
- Bulk Up
";
$g25184 = "Landorus-Therian (M) @ Buginium Z
Ability: Intimidate
Tera Type: &
EVs: 12 Atk / 68 Def / 176 SpA / 252 Spe
Naive Nature
- Sandsear Storm
- Swords Dance
- U-turn
- Defog
";
$g25193 = "Chikorita @ Eviolite
Ability: Overgrow
Tera Type: &
EVs: 252 HP / 4 SpA / 252 SpD
Calm Nature
IVs: 0 Atk
- Grass Knot
- Leech Seed
- Protect
- Grass Whistle
";
?>